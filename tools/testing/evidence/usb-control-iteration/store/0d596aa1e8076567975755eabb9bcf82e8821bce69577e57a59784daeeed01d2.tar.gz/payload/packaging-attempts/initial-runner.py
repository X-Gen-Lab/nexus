from pathlib import Path
import hashlib,json,os,resource,shutil,subprocess,sys,time,tarfile
P=Path('/tmp/nexus-quality-20261019');W=Path('/tmp/nexus-usb-control-package-20261020');S=W/'payload';D=P/'tools/testing/evidence/usb-control-iteration'
assert not W.exists() and not D.exists();W.mkdir();S.mkdir()
sys.path.insert(0,str(P));from tools.dev import process
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def identity(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def memory():
 c=Path('/sys/fs/cgroup');e=dict(x.split() for x in (c/'memory.events').read_text().splitlines());return {'current':int((c/'memory.current').read_text()),'maximum':int((c/'memory.max').read_text()),'oom':int(e['oom']),'oom_kill':int(e['oom_kill'])}
before=memory();assert (before['oom'],before['oom_kill'])==(61,10);assert before['maximum']-before['current']>=150*1024*1024
roots={'io35-real-tdd':Path('/tmp/nexus-execution-20261020/io35-real-tdd'),'io35-arm-initial':Path('/tmp/nexus-io35-arm-20261020'),'io35-epoch-fix':Path('/tmp/nexus-io35-epoch-fix-20261020')}
original=[]
for label,root in roots.items():
 target=S/'evidence'/label;target.mkdir(parents=True)
 for source in sorted(root.rglob('*')):
  assert not source.is_symlink();dest=target/source.relative_to(root)
  if source.is_dir():dest.mkdir(exist_ok=True)
  else:
   assert source.is_file();dest.parent.mkdir(parents=True,exist_ok=True);os.link(source,dest)
   original.append({'original':str(source),'payload':dest.relative_to(S).as_posix(),'bytes':source.stat().st_size,'sha256':sha(source)})
 for source in root.rglob('*'):
  if source.is_dir():(target/source.relative_to(root)).chmod(source.stat().st_mode&0o777)
for label,directory in [('original-draft','/tmp/nexus-io35-draft-20261020'),('alignment-revision','/tmp/nexus-io35-revised-20261020')]:
 root=Path(directory);target=S/'draft-provenance'/label;target.mkdir(parents=True)
 for source in sorted(root.iterdir()):
  if source.is_file() and (source.suffix=='.patch' or source.name in ('manifest.json','README.txt')):os.link(source,target/source.name)
manifest=json.loads(Path('/tmp/nexus-io35-draft-20261020/manifest.json').read_text());freeze=json.loads(Path('/tmp/nexus-io35-epoch-fix-20261020/source-freeze.json').read_text());base='bacdc5b8a5d64baebb92517e770d0abac28421b8'
assert manifest['base_head']==base and len(manifest['files'])==23 and freeze['head']==base
for name,digest in freeze['source_sha256'].items():assert sha(P/name)==digest
names=sorted(set(manifest['files'])|set(freeze['source_sha256'])|{'tests/contracts/test_device_sdk_payload.py','tests/contracts/test_source_sdk.py'})
recovery=[]
for name in names:
 source=P/name;target=S/'final-source/content'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes());target.chmod(source.stat().st_mode&0o777)
 r=subprocess.run(['git','show',base+':'+name],cwd=P,capture_output=True)
 assert r.returncode in (0,128)
 recovery.append({'path':name,'payload_path':target.relative_to(S).as_posix(),'mode':source.stat().st_mode&0o777,'bytes':source.stat().st_size,'sha256':sha(source),'baseline_sha256':hashlib.sha256(r.stdout).hexdigest() if r.returncode==0 else None,'baseline_present':r.returncode==0})
write(S/'final-source/manifest.json',{'kind':'targeted_dirty_source_recovery','base_commit':base,'files':recovery,'file_count':len(recovery),'recovery':'In a separate checkout of base_commit, verify each existing baseline file hash (or absence), then copy only content/<path> to <path> preserving recorded mode; verify every final SHA. No whole source checkout is embedded.','scope':'USB C/header/CMake/config/generator/test payload only; ongoing docs/gettext and unrelated evidence are intentionally outside this source freeze. Exact independent ordinary complete-index and clean SDK results remain separate.'})
write(S/'provenance.json',{'kind':'usb_control_increment_development_evidence','base_commit':base,'original_roots':{k:str(v) for k,v in roots.items()},'all_original_files_included':len(original),'original_file_bytes':sum(x['bytes'] for x in original),'excluded_original_files':[],'original_file_identities':original,'original_draft_manifest':'draft-provenance/original-draft/manifest.json','original_draft_file_count':23,'draft_count_correction':'Historical revised draft listed descriptor8; actual executed descriptor7. Preserve original manifests unchanged. Initial actual9programs142cases and final9programs144cases establish only their recorded source scopes.','final_source_manifest':'final-source/manifest.json','historical_absolute_paths':'Raw reports/receipts/envelopes remain unchanged. Portable index supplies archive-member/restore navigation without rewriting report claims.','failure_preservation':['initial alignment/stub/port contract RED and142GREEN','initial inherited GIT_PAGER infrastructure rejection','old-production stale decision14/1RED including mock scaffold oversaturation','new-profile fixture missing-initializer compiler failure','actual Native55/2RED plus separate scaffold failure','atomic9program144GREEN and final6ARM/Python'],'binaries':'Original evidence roots contain ARM ELF/objects/libraries only; no Native Google binaries are embedded. Google execution hashes/logs/receipts/XML retain their original scope.','qualification_limits':['Dirty-development scope, not clean installed SDK/release candidate','Physical USB HIL not executed','No USB host/HS/ISO/class stack or cycle measurements','Native archive verifies byte/member closure, never promotes inner evidence scope']})
commands=[]
def command(label,args):
 log=W/'commands'/(label+'.raw');log.parent.mkdir(exist_ok=True)
 argv=[str(P/'.venv/bin/python'),'-B',str(P/'tools/evidence/store.py'),*args]
 result=process.run(argv,cwd=P,log=log,timeout=180,stage='io35-evidence-'+label)
 row={'label':label,'argv':argv,'actual_exit':result.returncode,'receipt_path':str(result.receipt_path)};commands.append(row)
 assert result.returncode==0,row
 return row
command('export',['export','--source',str(S),'--store',str(W/'store'),'--report',str(W/'io35.package.json')])
package=json.loads((W/'io35.package.json').read_text());archive=Path(package['archive']['path']);assert archive.stat().st_size<=5*1024*1024,('archive too large; do not copy primary',archive.stat().st_size)
command('verify',['verify','--package',str(W/'io35.package.json'),'--report',str(W/'io35.verify.json')])
with tarfile.open(archive,'r:gz') as t:members=t.extractfile('delivery-manifest.json').read()
assert hashlib.sha256(members).hexdigest()==package['manifest_sha256'];(W/'io35.members.json').write_bytes(members)
assert all(sha(x['original'])==x['sha256'] for x in original)
assert all(sha(P/n)==v for n,v in freeze['source_sha256'].items())
D.mkdir();(D/'store').mkdir();shutil.copyfile(archive,D/'store'/archive.name)
for name in ('io35.package.json','io35.verify.json','io35.members.json'):shutil.copyfile(W/name,D/name)
command('portable-verify',['verify','--package',str(D/'io35.package.json'),'--archive',str(D/'store'/archive.name),'--report',str(W/'io35.portable-verify.json')])
shutil.copyfile(W/'io35.portable-verify.json',D/'io35.portable-verify.json');shutil.copytree(W/'commands',D/'commands')
after=memory();assert (after['oom'],after['oom_kill'])==(61,10)
entry={n:{'relative_path':n,'bytes':(D/n).stat().st_size,'sha256':sha(D/n)} for n in ('io35.package.json','io35.verify.json','io35.portable-verify.json','io35.members.json')}
portable={'kind':'portable_usb_control_evidence_navigation','source_commit':base,'archive':{'relative_path':'store/'+archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},**entry,'payload_files':package['files'],'payload_bytes':package['bytes'],'source_recovery_manifest':'payload/final-source/manifest.json','final_summary_member':'payload/evidence/io35-epoch-fix/delivery.json','original_draft_manifest_member':'payload/draft-provenance/original-draft/manifest.json','original_roots':{k:{'original':str(v),'archive_prefix':'payload/evidence/'+k,'restore_relative_prefix':'evidence/'+k} for k,v in roots.items()},'transport_rule':'Keep original native package envelope byte-for-byte, including historical archive.path; use --archive for current transport navigation. Member manifest paths are payload-relative and tar member names use payload/. Inner absolute paths and failures remain unchanged.','verify_after_transport':'python -B tools/evidence/store.py verify --package <io35.package.json> --archive <store/archive.tar.gz> --report /tmp/usb-control-verify.json','restore_after_transport':'python -B tools/evidence/store.py restore --package <io35.package.json> --archive <store/archive.tar.gz> --destination /tmp/usb-control-restored-NEW --report /tmp/usb-control-restore.json','scope':'Byte/member closure only; original reports preserve software-development scope. No physical or clean-SDK promotion.'}
write(D/'portable-index.json',portable)
write(D/'index.json',{'kind':'usb_control_increment_compact_package','source_commit':base,'original_evidence_roots_preserved':True,'original_file_count':len(original),'original_logical_bytes':sum(x['bytes'] for x in original),'recovery_files':len(recovery),'package':package,'portable_index':identity(D/'portable-index.json'),'member_manifest_sha256':package['manifest_sha256'],'commands':commands,'archive_under_5_MiB':True,'archive_bytes':archive.stat().st_size,'memory_before':before,'memory_after':after,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'scope':'Maintained tools/evidence/store export/verify only; no test/compiler rerun and no primary code/docs/index/HEAD mutation. Local byte verification does not establish external persistence or product promotion.'})
print(json.dumps({'primary_directory':str(D),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'payload_files':package['files'],'payload_bytes':package['bytes'],'original_files':len(original),'recovery_files':len(recovery),'portable_index_sha256':sha(D/'portable-index.json'),'index_sha256':sha(D/'index.json'),'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'memory_after':after},indent=2))
