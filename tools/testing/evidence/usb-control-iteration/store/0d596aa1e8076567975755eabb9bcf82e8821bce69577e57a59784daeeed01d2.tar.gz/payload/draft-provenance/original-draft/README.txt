IO-35 review draft, not an applied or qualified delivery

Primary: /tmp/nexus-quality-20261019
Base HEAD: bacdc5b8a5d64baebb92517e770d0abac28421b8
This sparse directory contains only changed/new proposed files, not a checkout.
No primary/index/HEAD modification, C/C++ compiler or hardware run occurred.

Two-stage application, only after root authorizes a new independent increment:
1. Compare baseline hashes in manifest.json; review/apply
   01-contracts-and-stubs.patch. It includes interfaces, selected typed ROM
   profiles/generator, targets, tests and deliberately nonfunctional C stubs.
   These cannot send/cancel/stall USB packets or settle outer loans. Pure
   preparation/admission permits concrete port/progress assertions to execute.
   The stubs are not safe-to-reclaim adapters and never release material.
2. Actually build/execute focused tests to prove C behavioral RED. Missing
   headers, tooling errors and link failures are not behavioral evidence.
   Capture original diagnostics and fix baseline infrastructure first.
3. Review/apply 02-implementation.patch, then actual focused GREEN. Preserve
   original RED and all logs. complete-implementation.patch is an equivalent
   combined diff for review; applying it first omits required actual C RED.

Authored C inventories (not executed or compile-verified here):
  nexus_usb_control_test: 12 GoogleTest/GoogleMock port/loan/progress contracts.
  nexus_usb_descriptor_test: 6 pure descriptor/profile contracts.
  nexus_stm32_usb_factory_test: existing target, one added profile binding case.
  nexus_gd32_usb_factory_test: existing target, one added profile binding case.
Actual compilation/discovery can expose defects; do not predict RED counts.

After focused GREEN, execute old USB/clock regressions, all ordinary Native
modes/full-index gates and six existing exact USB ARM assemblies. The ARM
fixtures now link/call optional components with unchanged budgets and retention
checks, no new chip/board/backend claims. Source SDK requirements include all
new public/generator/optional component sources. Installed SDK and independent
consumer execution are still unexecuted; old qualifications do not transfer.
Documentation/bilingual catalogs, resources/costs and normal CI must be completed
in the applied increment. Physical stations are unbound and not executed.

Executed preview evidence:
  profile-red-primary: 2 Python tests, 3 family subtest failures for absent typed
    nx_factory_usb_profile; actual exit 1.
  profile-green-final: same 2 tests via explicit /tmp runtime-module overlay,
    exit 0, 0.358 seconds, peak 24,880 KiB. This is not source-SDK qualification.
  style-final: clang-format14 dry run, whole-file lexical comment checks of 15
    final/stub C-family files; Python AST parse. This does not compile C/C++.
  exec-server transport disconnected on the first final-packaging attempt;
    no process started. No failed infrastructure call is counted as validation.

Implemented draft scope:
  USB-specific selected ROM profile, absent with factory.capabilities=false;
  existing generic capability ABI/ops/faces/provider contexts remain unchanged.
  Caller-owned allocation-free EP0 packetizer. Buffers/descriptors, outer
  requests, profile and context remain borrowed until outer acquire SETTLED.
  Real STATUS wire ACK wins before newer epoch/closing/timeout. Wire success
  does not promise address/configuration commit: read authoritative state.
  OUT DATA_READY requires explicit same-epoch policy approval before STATUS IN.
  OUT0 quarantine exposes NEEDS_DEVICE_STOP; no automatic whole-controller stop.
  Each step performs at most one provider poll and one packet action.
  Descriptor helper validates complete selected-FS structures, totals/MPS and
  endpoint membership. Lookup/class dispatch/class content/VID/PID/strings and
  product/recovery policy stay external. This is not a CDC/HID stack, physical
  enumeration proof or support for Host/HS/ISO/DMA/new processors/workers/heap.

Independent review:
  /root/new_mode_hil read final production paths without edits/builds/tests;
  no new blocking root cause found in ACK/epoch/OUT approval/OUT0 ownership,
  one-packet and bounded descriptor paths. Review establishes no qualification.
