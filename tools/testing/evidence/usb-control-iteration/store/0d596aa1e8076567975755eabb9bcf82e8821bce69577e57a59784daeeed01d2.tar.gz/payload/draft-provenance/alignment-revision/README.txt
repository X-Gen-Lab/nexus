IO35 revised sparse draft: numeric metadata extent and natural alignment

Original frozen draft: /tmp/nexus-io35-draft-20261020
Original manifest SHA:
ed2d39288de4da02113dd34a74599742ad97b09651668ad8d2ec02ed989a798d
Primary baseline: bacdc5b8a5d64baebb92517e770d0abac28421b8
Neither original files/patches/evidence nor primary/index/HEAD were changed.
No C/C++ compilation or test execution is claimed for this revision.

Confirmed gap and scope:
  Existing io/src/adc_format.c and rtc.c check numerical extents/natural
  alignment before typed access. The original new USB draft missed struct
  outputs, most adapter context entries and selected profile metadata graphs.
  Misaligned accessible storage could therefore yield SUCCESS and writes,
  or undefined behavior on ARM, despite INVALID/unchanged-output promises.
  This revision rejects numerical misalignment/wrapped public struct extents
  before typed reads/writes. It does not probe arbitrary addresses or validate
  opaque provider contexts; every pointer still requires documented lifetime
  and readable/writable storage. Payload/descriptor bytes remain byte-aligned.

Only final production behavior changes, in three C files:
  io/src/usb_profile.c: profile, bounded endpoint array, face/ops metadata guards;
    endpoint lookup checks its actual profile/array reads without full graph
    revalidation or hardware discovery.
  components/usb_control/src/usb_control.c: numeric guards before every public
    adapter context/request read and typed out_view/snapshot output write.
  components/usb_control/src/usb_descriptors.c: descriptor-view struct guard
    before reading its byte pointer/count. No descriptor parsing/policy change.
Public headers state the numerical-check boundary. No new fields, worker,
allocation, old USB ops/face change or descriptor/class/product policy is added.

Four new authored GTest regressions (NOT executed):
  UnalignedOutputsAreRejectedWithoutOverwritingTheirStorage
  UnalignedAdapterRejectsBeforeAnyProviderReadOrOutputWrite
  UnalignedProfileGraphIsRejectedBeforeTypedReads
  UnalignedDescriptorMetadataRejectsValidReadableBytes
Tests use accessible overallocated byte arrays and memcpy of valid object
representations, then pass +1 addresses without typed access in the test.
Output bytes and adapter/request loans stay unchanged; valid aligned controls
remain usable. No unmapped/random address is passed as a memory probe.
Total authored new execution instances become 24 (14 control +8 pure +2 factory),
not a successful execution count. Do not inherit previous Python or C counts.

Recommended real TDD application in a newly authorized increment:
1. 01-contracts-and-stubs.patch: revised API/tests plus original nonfunctional
   no-traffic stubs. Build first, then obtain actual port-contract assertion RED;
   compiler/link/tool errors do not count.
2. 02-implementation-before-alignment.patch: original complete USB implementation
   with the new metadata regression tests still present. This exposes the exact
   misalignment/unchanged-output failures as a separate actual behavioral RED.
3. 03-metadata-alignment-fix.patch: only the minimal three-C-file numeric guards.
   Then obtain actual C GREEN, required old USB/clock regressions, six ARM source
   fixtures with unchanged budgets/retention, installed SDK/full ordinary gates
   and bilingual documentation integration before claiming final delivery.

Alternative if the original draft has already been applied:
  alignment-tests-against-original-draft.patch (only API comments/tests), actual
  C behavioral RED, then alignment-fix-against-original-draft.patch (same as03),
  actual GREEN. complete-implementation.patch is for review, not the first
  application if doing so would omit the required behavioral RED.

Only formatting, lexical comment checks, Python AST and git apply --check may
be executed for this revision. Those are not C runtime or compiler qualification.
Original generator preview RED/GREEN remain linked historical preview evidence,
not current C GREEN. No hardware/HIL, cost/latency/Flash/RAM claim is made.
