import hashlib,json,os,pathlib,resource,subprocess,sys,time
P=pathlib.Path('/tmp/nexus-quality-20261019');O=pathlib.Path('/tmp/nexus-io35-epoch-fix-20261020/python')
O.mkdir()
modules=['tools/configure/test_usb_profile.py','tools/configure/test_usb_device.py','tests/contracts/test_device_sdk_payload.py']
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(P),'PATH':str(P/'.venv/bin')+':/tmp/nexus-quality-arm/bin:'+os.environ['PATH']}
for key in list(env):
 if key.startswith('GIT_'):del env[key]
results=[]
for number,module in enumerate(modules):
 directory=O/(str(number)+'-'+pathlib.Path(module).stem);directory.mkdir()
 report=directory/'report.json'
 code='''import json,sys,unittest\nfrom pathlib import Path\np=Path(sys.argv[1]);suite=unittest.TestLoader().discover(str(p.parent),pattern=p.name)\nexpected=suite.countTestCases();r=unittest.TextTestRunner(verbosity=2).run(suite)\nv={"module":str(p),"discovered":expected,"executed":r.testsRun,"failures":len(r.failures),"errors":len(r.errors),"skipped":len(r.skipped),"expected_failures":len(r.expectedFailures),"unexpected_successes":len(r.unexpectedSuccesses)}\nok=expected>0 and r.testsRun==expected and r.wasSuccessful() and not r.skipped and not r.expectedFailures and not r.unexpectedSuccesses\nv["status"]="passed" if ok else "failed"\nPath(sys.argv[2]).write_text(json.dumps(v,indent=2)+"\\n")\nsys.exit(0 if ok else 1)\n'''
 command=[sys.executable,'-B','-c',code,str(P/module),str(report)]
 before=hashlib.sha256((P/module).read_bytes()).hexdigest();start=time.monotonic()
 r=subprocess.run(command,cwd=P,env=env,capture_output=True)
 (directory/'stdout.txt').write_bytes(r.stdout);(directory/'stderr.txt').write_bytes(r.stderr)
 entry={'module':module,'actual_exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'source_sha256':before,'source_stable':before==hashlib.sha256((P/module).read_bytes()).hexdigest(),'report':str(report),'command':command,'scope':'real full-file unit execution, not installed SDK/physical qualification; test-internal format oracles retain their original scope'}
 (directory/'receipt.json').write_text(json.dumps(entry,indent=2)+'\n');results.append(entry)
 print(json.dumps({k:v for k,v in entry.items() if k!='command'}),flush=True)
 if r.returncode:print(r.stderr.decode(),flush=True);break
(O/'summary.json').write_text(json.dumps({'results':results,'child_peak_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss},indent=2)+'\n')
sys.exit(0 if len(results)==len(modules) and all(x['actual_exit']==0 for x in results) else 1)
