/**
 * \file            usb_profile.h
 * \brief           Selected-only immutable USB facts
 * \author          Nexus Team
 * \note            Selection facts are not observed physical qualification.
 */
#ifndef NEXUS_IO_USB_PROFILE_H
#define NEXUS_IO_USB_PROFILE_H
#include "nexus/io/usb_device.h"
#ifdef __cplusplus
extern "C" {
#endif
enum {
    NX_USB_FS_PHY_CLOCK_HZ = 48000000U,
    NX_USB_FS_FIFO_WORDS = 320U,
    NX_USB_FS_ENDPOINT_NUMBERS = 4U,
    NX_USB_FS_MAX_PACKET = 64U
};
typedef enum { NX_USB_PROFILE_DEVICE } nx_usb_profile_role_t;
typedef enum { NX_USB_PROFILE_FULL_SPEED } nx_usb_profile_speed_t;
typedef enum { NX_USB_PROFILE_INTERNAL_FS } nx_usb_profile_phy_t;
typedef enum { NX_USB_PROFILE_PIO } nx_usb_profile_engine_t;
typedef enum {
    NX_USB_PROFILE_CONTROL,
    NX_USB_PROFILE_BULK
} nx_usb_profile_transfer_t;
typedef struct {
    const nx_usb_endpoint_port_t* port;
    uint16_t max_packet;
    uint8_t number;
    bool in;
    nx_usb_profile_transfer_t transfer;
} nx_usb_endpoint_profile_t;
typedef struct {
    const nx_usb_device_port_t* port;
    const nx_usb_endpoint_profile_t* endpoints;
    size_t endpoint_count;
    uint32_t phy_clock_hz;
    uint16_t fifo_words;
    uint16_t rx_fifo_words;
    uint8_t endpoint_numbers;
    nx_usb_profile_role_t role;
    nx_usb_profile_speed_t speed;
    nx_usb_profile_phy_t phy;
    nx_usb_profile_engine_t engine;
} nx_usb_device_profile_t;
/**
 * \brief           Validate exact selected FS facts without observing the
 *                  controller.
 *
 * \param[in]       profile: Stable readable immutable facts, faces and
 *                  endpoint array.
 *
 * \return          Success or INVALID, including misaligned public metadata;
 *                  no allocation, MMIO, discovery or lifecycle effect.
 *
 * \note            Task/ISR bounded and read-only. Facts identify selected
 *                  software support; they never imply PCB routing, VBUS
 *                  wiring or physical qualification. Public metadata,
 *                  endpoint arrays, faces and operations tables require their
 *                  natural C alignment and nonwrapping extents. Numeric
 *                  rejection is not a probe of arbitrary addresses or opaque
 *                  private contexts.
 */
nx_result_t nx_usb_profile_validate(const nx_usb_device_profile_t* profile);
/**
 * \brief           Find a direction in a previously validated immutable
 *                  profile.
 *
 * \param[in]       profile: Stable validated selected facts and endpoint
 *                  array.
 *
 * \param[in]       number: Endpoint number, independent of direction.
 *
 * \param[in]       in: IN direction when true; OUT when false.
 *
 * \return          Selected stable member or NULL, including misaligned
 *                  profile/array metadata. No new endpoint can be discovered.
 *
 * \note            Task/ISR read-only bounded lookup; all input lifetimes
 *                  remain external.
 */
const nx_usb_endpoint_profile_t*
nx_usb_profile_endpoint(const nx_usb_device_profile_t* profile, uint8_t number,
                        bool in);
/* Generated only when factory.capabilities=true and USB is selected:
 * const nx_usb_device_profile_t* nx_factory_usb_profile(nx_usb_device_id_t);
 * Existing generic *_capability getters keep their original types.
 */
#ifdef __cplusplus
}
#endif
#endif
