"""Apply only after the original-production behavioral RED has been recorded."""
from pathlib import Path
P=Path('/tmp/nexus-quality-20261019')
p=P/'io/include/nexus/io/usb_profile.h';s=p.read_text().replace('enum {\n    NX_USB_FS_PHY_CLOCK_HZ','enum nx_usb_fs_limit {\n    NX_USB_FS_PHY_CLOCK_HZ',1)
marker='typedef struct {\n    const nx_usb_device_port_t* port;'
new=r'''/** \brief Optional epoch-bound EP0 rejection, separate from generic ops. */
typedef struct {
    nx_result_t (*reject)(void*, uint64_t);
} nx_usb_setup_decision_ops_t;
typedef struct {
    const nx_usb_setup_decision_ops_t* ops;
    void* context;
} nx_usb_setup_decision_port_t;
'''
assert marker in s;s=s.replace(marker,new+marker,1)
s=s.replace('    nx_usb_profile_engine_t engine;','    nx_usb_profile_engine_t engine;\n    nx_usb_setup_decision_port_t setup_decision;',1)
marker='/* Generated only when factory.capabilities=true'
new=r'''/**
 * \brief           Reject one published SETUP epoch by a checked EP0 IN STALL.
 *
 * \param[in]       port: Stable selected decision face, same controller owner.
 *
 * \param[in]       epoch: Nonzero software-published SETUP identity to reject.
 *
 * \return          Success after guarded STALL readback; STATE for a superseded
 *                  epoch/closing source, BUSY while either EP0 packet is live,
 *                  INVALID for malformed metadata. Rejection retains no loan.
 *
 * \note            Same privileged unmasked single task executor. The provider
 *                  checks its published epoch and performs STALL in one local
 *                  IRQ critical section, preserving the incoming mask. This
 *                  excludes an already software-published replacement SETUP;
 *                  it does not promise atomicity with physical bus packets
 *                  not yet collected by the IRQ. No cancellation, global stop,
 *                  allocation, class policy or address commit is implicit.
 */
nx_result_t nx_usb_setup_reject(const nx_usb_setup_decision_port_t* port,
                                uint64_t epoch);
'''
assert marker in s;s=s.replace(marker,new+marker,1);p.write_text(s)
p=P/'io/private/usb_device_controller.h';s=p.read_text().replace('#include "nexus/io/usb_device.h"','#include "nexus/io/usb_device.h"\n#include "nexus/io/usb_profile.h"',1)
s=s.replace('extern const nx_usb_device_ops_t nx_usb_fs_device_ops;','extern const nx_usb_device_ops_t nx_usb_fs_device_ops;\nextern const nx_usb_setup_decision_ops_t nx_usb_fs_setup_decision_ops;',1);p.write_text(s)
p=P/'io/src/usb_profile.c';s=p.read_text()
marker='        p->port->ops->service == NULL || p->port->ops->state == NULL ||'
new='''        !metadata(p->setup_decision.ops, sizeof(*p->setup_decision.ops),
                  _Alignof(nx_usb_setup_decision_ops_t)) ||
        p->setup_decision.context != p->port->context ||
        p->setup_decision.ops->reject == NULL ||
'''
assert marker in s;s=s.replace(marker,new+marker,1)
s+=r'''
/** \brief Dispatch the versioned decision; the provider owns atomic admission. */
nx_result_t nx_usb_setup_reject(const nx_usb_setup_decision_port_t* port,
                                uint64_t epoch) {
    if (!metadata(port, sizeof(*port), _Alignof(nx_usb_setup_decision_port_t)) ||
        !metadata(port->ops, sizeof(*port->ops),
                  _Alignof(nx_usb_setup_decision_ops_t)) ||
        port->context == NULL || epoch == 0U) {
        return NX_ERROR_INVALID;
    }
    return port->ops->reject == NULL ? NX_ERROR_UNSUPPORTED
                                     : port->ops->reject(port->context, epoch);
}
''';p.write_text(s)
p=P/'components/usb_control/src/usb_control.c';s=p.read_text()
s=s.replace('overlap(bytes, n, p->port->ops, sizeof(*p->port->ops))) {','overlap(bytes, n, p->port->ops, sizeof(*p->port->ops)) ||\n        overlap(bytes, n, p->setup_decision.ops,\n                sizeof(*p->setup_decision.ops))) {',1)
s=s.replace('result = nx_usb_endpoint_stall(endpoint(c, 1U), true);','result = nx_usb_setup_reject(&c->profile->setup_decision,\n                                         c->setup.epoch);',1);p.write_text(s)
p=P/'components/usb_control/include/nexus/components/usb_control.h';s=p.read_text()
s=s.replace(' *                  supplied. A new SETUP cannot be stalled by a stale\n *                  decision; cancellation drains before the outer loan ends.', ' *                  supplied. A guarded decision excludes an already\n *                  software-published replacement SETUP. Physical bus packets\n *                  not yet collected by IRQ are outside that software epoch\n *                  boundary. Cancellation drains before the outer loan ends.');p.write_text(s)
p=P/'tools/configure/usb_profiles.py';s=p.read_text()
s=s.replace("'    NX_USB_PROFILE_INTERNAL_FS, NX_USB_PROFILE_PIO', '};']", "'    NX_USB_PROFILE_INTERNAL_FS, NX_USB_PROFILE_PIO,',\n            f'    {{ &nx_usb_fs_setup_decision_ops, &s_nx_port_{name} }}', '};']")
assert 's_nx_port_{name}' in s;p.write_text(s)
# Deliberately reproduce the old non-versioned behavior for actual provider RED.
p=P/'io/src/usb_device_controller.c';s=p.read_text()
marker='/** \\brief Independent monotonic timeout service, including after'
new=r'''/** \brief Transitional regression baseline: old unversioned decision. */
static nx_result_t reject_setup(void* context, uint64_t epoch) {
    (void)epoch;
    nx_usb_controller_t* c = context;
    if (c == NULL) {
        return NX_ERROR_INVALID;
    }
    nx_usb_endpoint_t* ep = endpoint(c, 0U, true);
    return ep == NULL ? NX_ERROR_INVALID : stall(ep, true);
}
'''
assert marker in s;s=s.replace(marker,new+marker,1)
s+='\nconst nx_usb_setup_decision_ops_t nx_usb_fs_setup_decision_ops = {\n    .reject = reject_setup};\n';p.write_text(s)
