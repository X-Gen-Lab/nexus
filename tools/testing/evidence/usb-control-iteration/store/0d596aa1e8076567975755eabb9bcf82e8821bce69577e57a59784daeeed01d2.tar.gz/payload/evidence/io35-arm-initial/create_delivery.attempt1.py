from pathlib import Path
import hashlib,json,sys
P=Path('/tmp/nexus-quality-20261019');O=Path('/tmp/nexus-io35-arm-20261020')
sys.path.insert(0,str(P));from tools.measurement.elf import Elf32

def identity(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
report_path=O/'retry-no-git-overrides/matrix/report.json';v=json.loads(report_path.read_text())
assert v['status']=='passed' and v['fixture_count']==6 and v['source_inputs_stable'] and v['tools_stable']
rows=[]
for row in v['fixtures']:
 for x in row['artifacts'].values():assert identity(x['path'])==x
 for x in row['compiler_dependencies']:assert identity(x['path'])==x
 resources=json.loads(Path(row['artifacts']['resources']['path']).read_text());retention=json.loads(Path(row['artifacts']['retention']['path']).read_text())
 assert resources['status']=='passed' and resources['violations']==[] and retention['status']=='passed'
 symbols={s['name'] for s in Elf32(Path(row['artifacts']['elf']['path']).read_bytes()).defined_symbols}
 expected={'nx_factory_usb_profile','nx_usb_profile_validate','nx_usb_control_initialize','nx_usb_control_status_prepare','nx_usb_control_begin','nx_usb_control_step','nx_usb_control_cancel','nx_usb_descriptor_validate'}
 assert expected.issubset(symbols),(row['part'],expected-symbols)
 rows.append({'part':row['part'],'backend':row['backend'],'configuration_sha256':row['configuration_sha256'],'flash_loaded_bytes':row['flash_loaded_bytes'],'ram_reserved_bytes':row['ram_reserved_bytes'],'resources_status':'passed','retention_status':'passed','confirmed_selected_component_symbols':sorted(expected),'compiler_dependency_count':len(row['compiler_dependencies']),'artifacts':row['artifacts']})
python=[]
for path in sorted((O/'python').glob('*/report.json')):
 entry=json.loads(path.read_text());assert entry['status']=='passed' and entry['discovered']==entry['executed'] and entry['executed']>0 and all(entry[k]==0 for k in ['failures','errors','skipped','expected_failures','unexpected_successes'])
 python.append({**entry,'report':identity(path),'receipt':identity(path.with_name('receipt.json'))})
assert len(python)==3
memory_events=dict(line.split() for line in Path('/sys/fs/cgroup/memory.events').read_text().splitlines());assert (int(memory_events['oom']),int(memory_events['oom_kill']))==(61,10)
delivery={'schema_version':1,'scope':'dirty development-source software verification, not a clean installed candidate or physical HIL','arm_matrix':identity(report_path),'arm_execution':identity(O/'retry-no-git-overrides/execution.json'),'first_infrastructure_attempt':{'execution':identity(O/'execution.json'),'report':identity(O/'matrix/report.json'),'reason':'inherited GIT_PAGER rejected before configure/compiler invocation','gate_actual_exit':1,'monitor_wrapper_exit':0,'counts_as_behavior_red':False},'source_identity':v['source_before'],'source_input_count':len(v['source_inputs']),'source_snapshot_stable':True,'tools_stable':True,'tools':v['tools'],'actual_command_count':len(v['commands']),'arm_fixtures':rows,'python_full_files':python,'python_actual_executed':sum(x['executed'] for x in python),'oom':61,'oom_kill':10,'new_c_test_inventory_correction':{'control':14,'descriptor_profile':7,'two_family_factory_additions':2,'new_execution_instances':23,'source':'parent actual GoogleTest discoveries; not independently rerun here'},'unexecuted':['clean committed installed SDK verification and independent installed consumers','physical electrical/USB enumeration HIL','IRQ/wire timing and dynamic RAM high-water','reproducibility qualification','ordinary complete-index commit gates/GitHub CI for this increment'],'source_not_modified_by_agent':True}
p=O/'delivery.json';p.write_text(json.dumps(delivery,indent=2)+'\n')
print(json.dumps({'delivery':identity(p),'arm_fixture_count':len(rows),'python_tests':delivery['python_actual_executed'],'resources':[{k:r[k] for k in ['part','backend','flash_loaded_bytes','ram_reserved_bytes']} for r in rows]},indent=2))
