"""Wire optional public decision metadata after original behavior RED only."""
from pathlib import Path
P=Path('/tmp/nexus-quality-20261019')
p=P/'tests/google/usb_control_test.cpp';s=p.read_text()
s=s.replace('    MOCK_METHOD(nx_result_t, Stop, ());','    MOCK_METHOD(nx_result_t, Stop, ());\n    MOCK_METHOD(nx_result_t, RejectSetup, (uint64_t));',1)
marker='const nx_usb_endpoint_ops_t endpoint_ops = {Submit, Cancel, Stall};'
new='''nx_result_t RejectSetup(void* context, uint64_t epoch) {
    return static_cast<UsbPorts*>(context)->RejectSetup(epoch);
}
const nx_usb_setup_decision_ops_t setup_ops = {RejectSetup};
''';assert marker in s;s=s.replace(marker,new+marker,1)
s=s.replace('NX_USB_PROFILE_INTERNAL_FS, NX_USB_PROFILE_PIO};','NX_USB_PROFILE_INTERNAL_FS, NX_USB_PROFILE_PIO, {&setup_ops, &ports}};',1)
marker='        ON_CALL(ports, Service()).WillByDefault([this] {'
new='''        ON_CALL(ports, RejectSetup(_)).WillByDefault([this](uint64_t epoch) {
            return epoch == observed.epoch ? NX_SUCCESS : NX_ERROR_STATE;
        });
''';assert marker in s;s=s.replace(marker,new+marker,1)
s=s.replace('EXPECT_CALL(ports, Stall(true, true)).WillOnce(Return(NX_SUCCESS));','EXPECT_CALL(ports, Stall(_, _)).Times(0);\n    EXPECT_CALL(ports, RejectSetup(7U)).WillOnce(Return(NX_SUCCESS));',1)
# Both before-approval and after-snapshot windows name old epoch E exactly.
a=s.index('TEST_F(UsbControl, StaleOutApprovalCannotAcknowledgeOrStallNewSetup) {');b=s.index('\nTEST_F(',a+10)
part=s[a:b];marker='        EXPECT_CALL(ports, Stall(_, _)).Times(0);'
assert marker in part;part=part.replace(marker,marker+'\n        EXPECT_CALL(ports, RejectSetup(7U)).Times(after_snapshot ? 1 : 0);',1)
s=s[:a]+part+s[b:]
s=s.replace('    other_profile.endpoints = other_endpoints;','    other_profile.endpoints = other_endpoints;\n    other_profile.setup_decision = {&setup_ops, &other_ports};',1)
p.write_text(s)
p=P/'tests/google/usb_descriptor_test.cpp';s=p.read_text()
marker='const nx_usb_endpoint_ops_t ep_ops{Packet, Packet, Stall};'
new='''nx_result_t RejectSetup(void*, uint64_t) { return NX_ERROR_UNSUPPORTED; }
const nx_usb_setup_decision_ops_t setup_ops{RejectSetup};
''';assert marker in s;s=s.replace(marker,new+marker,1)
s=s.replace('NX_USB_PROFILE_INTERNAL_FS, NX_USB_PROFILE_PIO};','NX_USB_PROFILE_INTERNAL_FS, NX_USB_PROFILE_PIO,\n        {&setup_ops, &storage[4]}};',1);p.write_text(s)
p=P/'tests/google/usb_factory_test.cpp';s=p.read_text()
marker='    EXPECT_EQ(profile->port, face);';assert marker in s
s=s.replace(marker,marker+'\n    EXPECT_EQ(profile->setup_decision.ops, &nx_usb_fs_setup_decision_ops);\n    EXPECT_EQ(profile->setup_decision.context, face->context);',1);p.write_text(s)
