import hashlib,json,os,resource,sys,threading,time,xml.etree.ElementTree as ET
from pathlib import Path
P=Path('/tmp/nexus-quality-20261019');O=Path('/tmp/nexus-io35-epoch-fix-20261020')
sys.path.insert(0,str(P));from tools.dev import process
phase=sys.argv[1];targets=sys.argv[2:];out=O/phase;out.mkdir()
C=Path('/sys/fs/cgroup')
def memory():
 e=dict(line.split() for line in (C/'memory.events').read_text().splitlines());return {'headroom':int((C/'memory.max').read_text())-int((C/'memory.current').read_text()),'oom':int(e['oom']),'oom_kill':int(e['oom_kill'])}
before=memory();assert before['headroom']>=450*1024*1024,before;assert (before['oom'],before['oom_kill'])==(61,10),before
paths=['io/include/nexus/io/usb_profile.h','io/private/usb_device_controller.h','io/src/usb_profile.c','io/src/usb_device_controller.c','io/native/usb_device.h','io/native/usb_device.c','components/usb_control/include/nexus/components/usb_control.h','components/usb_control/src/usb_control.c','components/usb_control/src/usb_descriptors.c','tools/configure/usb_profiles.py','tests/google/usb_control_test.cpp','tests/google/usb_descriptor_test.cpp','tests/google/usb_device_test.cpp','tests/google/usb_factory_test.cpp']
source={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in paths}
for n in paths:
 destination=out/'sources'/n;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes((P/n).read_bytes())
env={**os.environ,'PATH':str(P/'.venv/bin')+':/tmp/nexus-quality-arm/bin:'+os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1','NEXUS_BUILD_JOBS':'1','CMAKE_BUILD_PARALLEL_LEVEL':'1'}
for k in list(env):
 if k.startswith(('GTEST_','CTEST_','GIT_')):del env[k]
cancel=threading.Event();done=threading.Event();observations=[]
def monitor():
 while not done.wait(0.25):
  item=memory();observations.append(item)
  if item['headroom']<64*1024*1024 or (item['oom'],item['oom_kill'])!=(61,10):cancel.set()
watch=threading.Thread(target=monitor,daemon=True);watch.start()
command=['flock','/tmp/nexus-platform-compiler.lock',str(P/'.venv/bin/cmake'),'--build',str(P/'build/native-debug'),'--parallel','1','--target',*targets]
start=time.monotonic();build=process.run(command,cwd=P,env=env,log=out/'build.log',timeout=300,stage=phase+'-build',cancel_event=cancel)
print('build actual exit',build.returncode,flush=True)
results=[]
if build.returncode==0:
 for target in targets:
  xml=out/(target+'.xml');binary=P/'build/native-debug/bin'/target
  result=process.run([str(binary),'--gtest_output=xml:'+str(xml)],cwd=P,env=env,log=out/(target+'.log'),timeout=180,stage=phase,cancel_event=cancel)
  row={'target':target,'actual_exit':result.returncode,'receipt':str(result.receipt_path),'xml':str(xml)}
  if xml.exists():
   root=ET.parse(xml).getroot();row.update({key:int(root.attrib.get(key,0)) for key in ['tests','failures','errors','disabled','skipped']})
   row['failed_cases']=[case.attrib.get('classname','')+'.'+case.attrib['name'] for case in root.iter('testcase') if list(case.findall('failure')) or list(case.findall('error'))]
  results.append(row);print(json.dumps(row),flush=True)
done.set();watch.join()
after=memory();stable=all(hashlib.sha256((P/n).read_bytes()).hexdigest()==v for n,v in source.items())
record={'phase':phase,'source_sha256':source,'source_stable':stable,'preflight':before,'after':after,'minimum_headroom':min([before['headroom'],after['headroom']]+[x['headroom'] for x in observations]),'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'build_actual_exit':build.returncode,'build_receipt':str(build.receipt_path),'results':results,'elapsed_seconds':time.monotonic()-start,'cancelled':cancel.is_set()}
(out/'summary.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['source_sha256','results']}),flush=True)
sys.exit(0 if build.returncode==0 and stable and not cancel.is_set() else 1)
