import datetime,json,os,pathlib,signal,subprocess,time,resource
P=pathlib.Path('/tmp/nexus-quality-20261019');O=pathlib.Path('/tmp/nexus-io35-epoch-fix-20261020/arm')
O.mkdir()
C=pathlib.Path('/sys/fs/cgroup')
def state():
 events=dict(line.split() for line in (C/'memory.events').read_text().splitlines())
 current=int((C/'memory.current').read_text());maximum=int((C/'memory.max').read_text())
 return {'memory_current':current,'memory_max':maximum,'headroom':maximum-current,'oom':int(events['oom']),'oom_kill':int(events['oom_kill'])}
initial=state();(O/'preflight.json').write_text(json.dumps(initial,indent=2)+'\n')
assert initial['headroom']>=256*1024*1024,initial
assert (initial['oom'],initial['oom_kill'])==(61,10),initial
command=['flock','/tmp/nexus-platform-compiler.lock',str(P/'.venv/bin/python'),'-B',str(P/'scripts/ci/provider_assemblies.py'),'--root',str(P),'--compiler','/tmp/nexus-quality-arm/bin/arm-none-eabi-gcc','--parallel','1','--output',str(O/'matrix')]
for name in ('stm32-zg','stm32-zg-freertos','stm32-ve','stm32-ve-freertos','gd32','gd32-freertos'):
 command+=['--fixture',str(P/'tests/contracts/usb_assembly'/(name+'.toml'))]
env={**os.environ,'PATH':str(P/'.venv/bin')+':/tmp/nexus-quality-arm/bin:'+os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1'}
removed_git_environment_names=sorted(k for k in env if k.startswith('GIT_'))
for key in removed_git_environment_names:del env[key]
start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();why=None
minimum=initial['headroom']
with (O/'stdout.txt').open('xb') as out,(O/'stderr.txt').open('xb') as err:
 child=subprocess.Popen(command,cwd=P,env=env,stdout=out,stderr=err,start_new_session=True)
 while child.poll() is None:
  current=state();minimum=min(minimum,current['headroom'])
  if (current['oom'],current['oom_kill'])!=(61,10):
   why='OOM counters changed';os.killpg(child.pid,signal.SIGTERM);break
  if current['headroom']<64*1024*1024:
   why='hard memory headroom below64MiB';os.killpg(child.pid,signal.SIGTERM);break
  time.sleep(1)
 try:code=child.wait(timeout=20)
 except subprocess.TimeoutExpired:
  os.killpg(child.pid,signal.SIGKILL);code=child.wait()
receipt={'argv':command,'cwd':str(P),'started_at':started,'actual_exit':code,'elapsed_seconds':time.monotonic()-start,'preflight':initial,'removed_git_environment_names':removed_git_environment_names,'final':state(),'minimum_headroom_bytes':minimum,'child_peak_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'scope':'dirty development source ARM software matrix, not clean installed candidate or physical HIL','error':why}
(O/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)

raise SystemExit(code if why is None else 1)
