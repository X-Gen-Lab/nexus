"""Pure fresh same-input transform comparison; no tests, build or source copies."""
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import time
import types

sys.dont_write_bytecode=True
ROOT=Path('/tmp/nexus-quality-20261019');DOCS=ROOT/'docs';OUT=Path(__file__).resolve().parent
BASE='34955a3900f3314c8af8d0068bc154d1afc868ba'
OLD_SHA='2d69f111e46b9784155e1f5dfe2b4b37252079ebd60ad8571b952490a0a0a236'
NEW_SHA='bdd2959c115287f9c4f47863dd069779476292c5d9560be00534ba86ecaf08de'
TEST_SHA='3c748f8fada3fd2199cada9484665c7b036856d25488acb7ad9982c570720a0d'
HELPER='tools/documentation/sphinx_ext.py';TEST='tools/documentation/test_sphinx_ext.py'
INCLUDE=re.compile(r'^\s*(?:`{3,}|~{3,})\{include\}\s+(\S+)',re.MULTILINE)
sha=lambda data:hashlib.sha256(data).hexdigest()

def main():
 started=time.time_ns();before={p:sha((ROOT/p).read_bytes())for p in (HELPER,TEST)}
 assert before=={HELPER:NEW_SHA,TEST:TEST_SHA}
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert head==BASE
 old_bytes=subprocess.check_output(['git','show',BASE+':'+HELPER],cwd=ROOT);assert sha(old_bytes)==OLD_SHA
 # Load the exact committed baseline directly in memory; do not create a full source copy.
 old=types.ModuleType('committed_baseline_sphinx_ext');old.__file__=str(ROOT/HELPER)
 exec(old_bytes.decode('utf-8'),old.__dict__)
 spec=importlib.util.spec_from_file_location('current_sphinx_ext',ROOT/HELPER)
 new=importlib.util.module_from_spec(spec);spec.loader.exec_module(new)
 pages=sorted(p for p in DOCS.rglob('*.md')if p.relative_to(DOCS).parts[0]not in ('archive','locale','sphinx'))
 raw={};texts={};included=set()
 def read(page):
  if page not in raw:
   raw[page]=page.read_bytes();texts[page]=raw[page].decode('utf-8').replace('\r\n','\n').replace('\r','\n')
  return texts[page]
 pending=[]
 for page in pages:pending.extend((page.parent/m.group(1)).resolve()for m in INCLUDE.finditer(read(page)))
 while pending:
  page=pending.pop()
  if page in included or not page.is_file()or page.suffix!='.md':continue
  assert page.is_relative_to(ROOT);included.add(page)
  pending.extend((page.parent/m.group(1)).resolve()for m in INCLUDE.finditer(read(page)))
 rows=[];deltas=[]
 for page in sorted(set(pages)|included):
  source=read(page);options={'document_root_links':page in included};args=(source,page,DOCS,ROOT,'NEXUS-DOCUMENTATION-SOURCE')
  left=old.rewrite_local_links(*args,**options);right=new.rewrite_local_links(*args,**options)
  relative=page.relative_to(ROOT).as_posix()
  rows.append({'path':relative,'raw_source_sha256':sha(raw[page]),'transform_input_sha256':sha(source.encode()),'bytes':len(raw[page]),'document_root_links':page in included,'baseline_output_sha256':sha(left.encode()),'current_output_sha256':sha(right.encode()),'equal':left==right})
  if left!=right:deltas.append({'path':relative,'diff':''.join(difflib.unified_diff(left.splitlines(keepends=True),right.splitlines(keepends=True),fromfile=relative+':baseline',tofile=relative+':current'))})
 after={p:sha((ROOT/p).read_bytes())for p in (HELPER,TEST)}
 assert after==before and all(page.read_bytes()==value for page,value in raw.items())
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==head
 assert len(pages)==127 and len(included)==5 and len(rows)==132
 record={'status':'completed','classification':'Pure current same-input text transformation, not framework tests/primary GREEN/Sphinx/gettext/HTML/POT qualification','started_ns':started,'finished_ns':time.time_ns(),'repository':str(ROOT),'head':head,'source_before':before,'source_after':after,'source_stable_before_after':True,'baseline':{'git_locator':BASE+':'+HELPER,'sha256':OLD_SHA,'loaded_in_memory_only':True},'current':{'path':str(ROOT/HELPER),'sha256':NEW_SHA},'revision_placeholder':'NEXUS-DOCUMENTATION-SOURCE','inventory_scope':'Fresh docs/**/*.md excluding archive/locale/legacy sphinx, plus recursive declared MyST Markdown includes; literalinclude is code and excluded. No previous inventory used.','direct_markdown_files':len(pages),'included_markdown_files':len(included),'included_sources':sorted(str(p.relative_to(ROOT))for p in included),'same_input_transform_comparisons':len(rows),'changed_outputs':len(deltas),'inputs_and_outputs':rows,'deltas':deltas,'script_sha256':sha(Path(__file__).read_bytes()),'no_primary_or_index_writes':True,'no_tests_compiler_configure_docs_gettext_execution':True,'no_full_source_copy':True}
 destination=OUT/'comparison.json';assert not destination.exists();destination.write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'record':str(destination),'sha256':sha(destination.read_bytes()),'direct':len(pages),'includes':len(included),'comparisons':len(rows),'changed_outputs':len(deltas),'source_stable':True}))

if __name__=='__main__':main()
