"""Record one actual bounded pure transform command using the existing runner."""
from pathlib import Path
import hashlib,json,os,sys
ROOT=Path('/tmp/nexus-quality-20261019');OUT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT))
from tools.dev.process import run
sha=lambda data:hashlib.sha256(data).hexdigest()
paths=['tools/documentation/sphinx_ext.py','tools/documentation/test_sphinx_ext.py']
before={p:sha((ROOT/p).read_bytes())for p in paths}
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
result=run(['/tmp/nexus-quality-doc-tools/venv/bin/python','-B',str(OUT/'compare.py')],cwd=ROOT,env=env,log=OUT/'pure-transform.raw',timeout=60,stage='pure-current-doc-link-same-input-transform')
after={p:sha((ROOT/p).read_bytes())for p in paths};assert before==after
record={'classification':'Actual bounded pure text-processing command only, no test/build/Sphinx/gettext qualification','returncode':result.returncode,'receipt':str(result.receipt_path),'source_before':before,'source_after':after,'source_unchanged':True,'script_sha256':sha((OUT/'compare.py').read_bytes()),'reused_review':{'path':'/tmp/nexus-doc-link-final-review-20261021/review.json','sha256':sha(Path('/tmp/nexus-doc-link-final-review-20261021/review.json').read_bytes())}}
if result.returncode==0:
 comparison=OUT/'comparison.json';data=json.loads(comparison.read_text());record.update(comparison={'path':str(comparison),'sha256':sha(comparison.read_bytes())},direct_markdown_files=data['direct_markdown_files'],included_markdown_files=data['included_markdown_files'],comparisons=data['same_input_transform_comparisons'],changed_outputs=data['changed_outputs'])
p=OUT/'delivery.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));raise SystemExit(result.returncode)
