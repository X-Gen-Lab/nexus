from pathlib import Path
import hashlib,json,os,sys
ROOT=Path('/tmp/nexus-quality-20261019');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT))
from tools.dev.process import run
steps=json.loads(Path('/tmp/nexus-doc-link-final-review-20261021/execution-packet/execution-plan.json').read_text())['steps']
paths=['tools/documentation/sphinx_ext.py','tools/documentation/test_sphinx_ext.py']
before={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1')
rows=[]
for name,step in [('docs-suite',steps[3]),('strict-docs',steps[4])]:
 done=run(step['command'],cwd=ROOT,env=env,log=OUT/(name+'.raw'),timeout=step['timeout_seconds'],stage='doc-link-'+name)
 rows.append({'name':name,'returncode':done.returncode,'receipt':str(done.receipt_path)})
 after={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
 (OUT/'green-execution.json').write_text(json.dumps({'before':before,'after':after,'commands':rows},indent=2)+'\n')
 print(name,done.returncode,flush=True)
 if done.returncode:raise SystemExit(done.returncode)
 assert before==after
