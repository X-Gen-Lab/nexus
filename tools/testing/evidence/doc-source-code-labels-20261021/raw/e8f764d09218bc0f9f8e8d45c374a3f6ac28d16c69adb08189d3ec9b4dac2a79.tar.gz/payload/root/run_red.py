from pathlib import Path
import hashlib,json,os,re,sys
ROOT=Path('/tmp/nexus-quality-20261019');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT))
from tools.dev.process import run
paths=['tools/documentation/sphinx_ext.py','tools/documentation/test_sphinx_ext.py']
before={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
assert before[paths[0]]=='2d69f111e46b9784155e1f5dfe2b4b37252079ebd60ad8571b952490a0a0a236'
assert before[paths[1]]=='3c748f8fada3fd2199cada9484665c7b036856d25488acb7ad9982c570720a0d'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1')
done=run(['flock','/tmp/nexus-platform-compiler.lock','/tmp/nexus-quality-doc-tools/venv/bin/python','-B','-m','unittest','-v','tools.documentation.test_sphinx_ext.DocumentationSourceTests'],cwd=ROOT,env=env,log=OUT/'red.raw',timeout=120,stage='doc-link-test-only-actual-red')
error=(done.receipt_path.parent/'stderr.txt').read_text()
after={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
record={'returncode':done.returncode,'receipt':str(done.receipt_path),'before':before,'after':after,'source_unchanged_during_run':before==after,'scope':'whole DocumentationSourceTests class only; not complete DocsSuite'}
(OUT/'red-result.json').write_text(json.dumps(record,indent=2)+'\n')
assert done.returncode==1 and before==after
assert re.search(r'Ran 8 tests? in ',error)
assert re.search(r'FAILED \(failures=\d+\)',error) and 'ERROR:' not in error and 'skipped=' not in error
assert 'FAIL: test_source_link_code_labels_preserve_markup_and_bind_revision' in error
record.update(status='expected actual assertion RED',methods=8,failure_subtests=int(re.search(r'FAILED \(failures=(\d+)\)',error).group(1)))
(OUT/'red-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
