# Documentation code-label link development evidence

This compact collection preserves the actual documentation helper increment:
TEST-only runtime RED (eight methods, fourteen failing subtests), the complete
336-case documentation suite, fresh strict Doxygen/gettext/English/Chinese
commands with 127 pages and 254 language records, and the actual bounded current
132-input same-text comparison with zero output changes. These are development
results, not accepted ordinary-index or software/SDK/HIL qualification.

The final source freeze and patch bind two changed helper/test files to base
34955a3900f3314c8af8d0068bc154d1afc868ba and tree
c589c6db1c7dc69eaf3cc37ca8b953f617d69f6e. The committed old helper was loaded
in memory for comparison; no whole source after-images are included. The prior
semantic review and original three patch identities are reused unchanged.
Historical one-method/three-failure RED references inside that old review are
not the new eight-method/fourteen-subtest result. Fresh root RED is separate.

Original raw stdout/stderr and receipts accompany root commands and all four
strict build commands. The build JSON contains the original 254-record
translation manifest; all127 fresh POT files and the alias metadata are kept.
HTML, fonts, API XML, doctrees, whole build/tool/vendor/source trees and archive
bodies are excluded. The original full site/workspace remain outside this packet.
The docs build retains its original dirty working-tree identity. Later evidence
integration is not treated as a changed helper/document execution input.

The source/message contract changes only revision-bound source/archive/tree
links with code-containing labels. Inline/fenced examples, images, external URLs
and in-document code labels keep their current boundaries. Zero current input
transform differences do not replace actual tests or future external inputs.

The unsealed copy-stage status in collection-inputs.json is intentional. Later
single existing-store export/verify/full-restore/inventory receipts accompany
this collection externally; they establish byte/member closure only. There is no
product promotion or signature claim, and no physical execution is claimed.
