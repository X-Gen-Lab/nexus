# Independent read-only review: FS interrupt-IN hardware invariants

Decision: the existing nonzero-IN request, completion and drain machinery can
serve selected FS interrupt IN without a new scheduler or lifecycle owner.
The required controller touchpoints are cold plan/type selection and DATA0
reset/clear-halt classification. No new completion or drain algorithm is justified
by this review. This is source review, not executed test or physical evidence.

Primary reviewed input: `/tmp/nexus-quality-20261019`. The root is executing its
initial public/configuration RED separately. This review writes only here;
no production after-images may be created before the root reports observed RED.
No compiler, configure, tests, primary/index writes or original dirty-tree access.

## Single-packet programming and completion

- `io/src/usb_device_controller.c:159–229`: complete cold plan validation runs
  before clock validate/retain and MMIO (`initialize` :245–264). Preserve this
  order when replacing the private bool with a byte transfer selector. Unknown
  kinds must fail, not enter a CONTROL/BULK default branch. Selected interrupt
  is nonzero IN, MPS1..64, including non-powers-of-two. Existing FIFO minimum
  of 16 words covers any such packet; the disjoint 320-word plan is unchanged.
- Cold initialization :292–300 currently hardcodes EPTYP2 for every nonzero
  direction. The new explicit map is public CONTROL0 -> hardware0,
  BULK1 -> hardware2, INTERRUPT2 -> hardware3. Keep EP0 special handling and
  DATA0 command bit28 only on supported nonzero directions. Keep bit29 zero.
- `request_valid` :796–827 already bounds length by selected MPS, excludes
  STATUS/nonzero epoch from nonzero packets, and checks all request/payload
  overlaps through existing `storage_valid`. Interrupt needs no special
  admission side channel or borrowed descriptor metadata.
- `submit` :830–893 checks source state, request validity, ownership/latched
  events, hardware enable, deadline and free FIFO words before admission.
  Rejected submissions retain no new references. The selected FIFO is filled
  entirely under the existing IRQ guard; no refill work remains afterward.
- Keep TSIZ as PKTCNT1 plus actual IN length at :871–875, including a DATA ZLP.
  Do not program MCNT/MULCNT from shared CMSIS definitions. ST FS DIEPTSIZx
  marks bits31:29 reserved; GD FS MCPF describes ISO PID use. Both locked
  official interrupt transmit paths leave the field zero.
- `progress` :614–680 requires independent XFRC, EPENA clear and full configured
  FIFO free space. It then clears observed W1C flags and checks readback before
  SUCCESS. FIFO writes, FIFO-empty status or an IN token alone never settle.
  Preserve the existing completion-before-deadline ordering: an already proved
  ACK must not be replaced by a later software timeout.
- `finish` :603–610 runs nonzero-noop `control_complete`, clears the endpoint
  request reference, then release-publishes SETTLED. `control_complete` :574–601
  exits immediately for nonzero endpoints, so the interrupt success path must
  not update EP0 state/address/control epoch. No new retained reference exists.

## DATA0 reset and halt clearing

Both official vendor clear-stall routines explicitly reset DATA0 for bulk and
interrupt endpoints (ST LL :1112–1114; GD drv_usb_dev :526–527).

- `clear_halts` :545–572 currently limits DATA0 commands and DPID readback to
  `.bulk` (:559/:566). Extend both together to the exact supported nonzero
  BULK/INTERRUPT kinds. EP0 must remain excluded from PID commands, including
  generic `clear_halts(reset=false)` for a new SETUP.
- Reset invalidation :385–403 drains every active endpoint. `progress`
  :688–707 keeps reset admission closed until all requests detach, both FIFO
  flushes succeed, every selected halt/DATA0 readback succeeds and address-zero
  readback succeeds. Keep that conjunction and ordering unchanged.
- A failed DATA0 readback may leave some hardware STALL bits already clear.
  It must not clear the software reset barrier or any final software halted
  state. This existing partial-operation behavior is safe because admissions
  remain closed; it does not justify rolling forward or replaying requests.
- `stall_locked` :915–935 currently commands DATA0 and verifies DPID0 only for
  `.bulk` (:926/:932). Extend both together to BULK/INTERRUPT. On readback IO,
  keep `ep->halted` unchanged; a cleared hardware STALL alone is insufficient
  to admit a new request. Existing active/EPENA checks and BUSY returns stay.

## Error and instance isolation

- `ep_flags` :116–118 masks actual W1C events with 0x5B and excludes read-only
  TXFE bit7. `progress` :631–640 treats IN ITTXFE bit4 and NAK-effective bit6
  as hints. Keep these independent of XFRC and preserve the actual IN timeout
  error bit3 / OUT overrun bit4 distinction. Hint plus XFRC may still complete
  with all withdrawal proofs; hint alone never settles or starts a worker.
- Dedicated per-IN FIFOs avoid shared nonperiodic IN endpoint-mismatch handling.
  ST bit5 is shared-FIFO INEPNM; GD FS bit5 is reserved. Do not widen the flags
  mask or add retry/re-enable commands from generic/HS prose.
- `drain` :485–542 requires actual IN NAK before disable, then EN clear,
  EPDISD when requested, selected FIFO flush and W1C-clear proof. Missing facts
  retain DRAINING/QUARANTINED and the clock consumer. Do not reuse DATA0/reset
  operations as evidence that a borrowed request has drained.
- `progress` uses each endpoint's own offset/FIFO/reference. A new interrupt
  type must not alter bulk OUT copying, overflow drain, EP0 OUT0 quarantine,
  event-ring ownership, publisher counts or shared-controller stop.
- Reset and full controller stop intentionally act on all selected endpoints.
  That global authority remains explicit; a class adapter or per-endpoint
  timeout must not gain an implicit shared stop operation.

## Exact official source identity and resolved discrepancies

Full anchors are in
`/tmp/nexus-usb-interrupt-plan-20261021/dcd-review/facts.md`.

- ST RM0090 Rev22 §34.16.4: DIEPCTLx pp1299–1301, DIEPTSIZx p1311;
  dedicated FIFO §34.11.2 p1248; TX-empty mask p1296.
  <https://www.st.com/resource/en/reference_manual/dm00031020.pdf>
  SHA256 `f3ff2322eec21f4e49081f68481b764506eee81dba6031bc767e2f8955b27cca`.
- GD32F4xx UM Rev3.3 **USBFS chapter28**, §28.7.3 DIEPxCTL pp988–990,
  DIEPxLEN p998; FIFO §28.5.5 pp936–938; TX-empty mask p985.
  <https://www.gd32mcu.com/data/documents/userManual/GD32F4xx_User_Manual_Rev3.3.pdf>
  SHA256 `c8e1d20d7cde338892d08dcb233345e03f7960256a60a36c755c576d9cd65c13`.
- Existing maintained text cites GD §29.3, which is USBHS in these exact bytes.
  Correct new/current references, while preserving original historical reports.
- ST generic periodic prose refers to MCNT although its FS register definition
  reserves the bits. The FS map and both vendor ordinary interrupt paths
  establish the conservative decision to leave MCNT0, with no ISO/HS expansion.

## Review disposition

No high-confidence new lifecycle defect was identified. Narrow implementation
should change the byte selector, plan/type validation, EPTYP mapping and paired
DATA0 command/readback checks. Keep submit, completion, drain, final access,
IRQ masks, SETUP epoch and shared stop algorithms unchanged. Actual RED/GREEN,
ARM linked resource checks, ordinary gates and HIL remain separate evidence.

## Post-review finding and authorized implementation disposition

The ownership review above found no new final-access defect. A subsequent exact
register review did identify a **pre-existing functional F407 reset gap**: hardware
clears every nonzero USBAEP on bus reset (RM0090 p1301 for IN, p1304 for OUT),
whereas the existing reset path never restores it. Native reset injection omitted
that side effect. GD documents inactive EPACT ignoring tokens, but the reviewed
exact FS text does not establish the same automatic reset-clear side effect.

The root observed configuration/descriptor RED, then provider RED on all three
existing targets, then the new old-BULK inactive-admission RED. References and
receipt-file hashes are bound in `provider-afterimages-manifest.json`.
After those explicit signals, owned implementation after-images were prepared
in `after/` and `04-interrupt-provider-and-inactive-guard.patch`; none were
applied here and no compiler/configure/tests were executed by this reviewer.

The bounded correction is to reject a software-observed inactive nonzero
endpoint with STATE before request admission or hardware stores. It does not
activate endpoints during reset, clear-halt or submit. The external
SetConfiguration/SetInterface activation mechanism remains a separate follow-up;
this increment cannot claim complete post-reset nonzero USB traffic readiness.
The faithful Native fault represents the verified ST reset side effect only.
Existing reset tests retain their address/PID/halt/NAK proofs and use explicit
full stop/cold initialization before later successful admissions.

Independent text review of the four after-images found no blocking issue:
strict plan cases, explicit wire type3, paired DATA0 checks, short-circuiting
active-bit read and literal locked SDK assertion macros were inspected. All
completion, hints, drain, final-access and stop algorithms remain unchanged.
An active-bit read is a software snapshot, not atomicity with a later physical
bus reset; existing reset invalidation and accepted-loan drain remain essential.
