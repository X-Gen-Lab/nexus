# Provider test-only patch review

Read-only review of existing Native plus shared F407/GD470 GoogleTest fixtures.
No compiler, configure, tests or production writes performed.

Recommended groups in each existing provider suite:

1. **Dedicated FIFO and actual ACK**: after a clean stop, select EP1 IN interrupt
   with MPS13 and restart. Check EPTYP3, MPS13, TXFNUM1, selected FIFO partition,
   TX_EMPTY_MASK0, PKTCNT1 and MCNT0 for payload3 and standalone DATA ZLP. The
   request remains ACTIVE and `ep.request` retained after PIO fill. An injected
   XFRC with EPENA still set cannot settle; EPENA clear with FIFO space below its
   full configured capacity cannot settle; only independent completion plus
   withdrawal facts release the loan. Assert result/count and detached pointer.
2. **Cancel/drain**: data and ZLP remain borrowed when disable or flush proof is
   refused, transition to QUARANTINED after the existing drain deadline, retain
   clock ownership, and settle only after the fault clears and actual drain runs.
3. **Clear halt DATA0**: stall idle interrupt EP1 IN, seed DPID1, set existing
   `hold_bulk_pid`; clearing halt returns IO and retains software halted state.
   Release fault, clear again, observe DPID0 and reopened state.
4. **Reset DATA0**: seed the same fault and reset the idle endpoint. Reset remains
   pending, software halt remains, clock remains retained, and prepared request
   is rejected STATE without admission. Release fault and service; DATA0/reset
   readback reopens admission. Keep EPENA clear so this case isolates PID proof.
5. **Invalid plans before effects**: unknown transfer255, interrupt OUT,
   interrupt EP0, interrupt MPS0/65, and bulk MPS13. Check INVALID, zero clock
   consumers/retained flag and unchanged MMIO counters after a valid full stop.
   Restore every mutated field after each case, especially EP0 direction/type.

Existing fixture/model pitfalls:

- Both SetUp methods start a bulk controller. A new selected transfer/MPS plan
  must follow successful stop and cold reinitialize; calling initialize while
  started tests the wrong rejection condition.
- Native `nx_native_usb_initialize` directly stores RESET at
  `io/native/usb_device.c:70–72`, outside the MMIO counters. For a precise
  rejected-plan no-MMIO assertion, use `nx_usb_controller_initialize` directly
  after the initial wrapper has established its clock port and register base.
  Record counter baselines **after stop**, not before it.
- Shared SoC SetUp starts its explicit clock once. DCD stop releases its consumer;
  it does not stop that clock owner. DEVICE_INIT may cold restart the DCD against
  the still-ready owner. Its grouping read is replaced with constant3 in the
  existing `usb_device_soc_model.h`; its wrapper does not need extra MMIO ports.
- `clock.consumers==0` and `clock_retained==false` prove no retained clock, not
  that validate/retain were never invoked. A common-provider external clock
  mock/spy with zero expected calls can strengthen that exact ordering claim.
  The real-family tests should still exercise DEVICE_INIT and its actual clock
  owner instead of substituting the whole provider.
- SoC hardware uses a fixed mapped `nx_native_usb_hardware_t` leaf model, with a
  separate `nx_usb_controller_t`; it is **not** an `nx_native_usb_device_t`.
  Do not cast it to call native completion/reset helpers. Follow existing SoC
  test direct register injection: EP1 CTL0x920, INT0x928, TSIZ0x930,
  DTXFSTS0x938, global reset bit12 in register0x14. A simulated ACK should clear
  EPENA, set XFRC, restore DTXFSTS=fifo_words and set `tx_count[1]=0`.
- Existing native ACK helper toggles DPID for every nonzero IN endpoint, so it
  already models interrupt DATA0/DATA1. It does not decrement transfer-size
  registers; test programmed PKTCNT/MCNT before completion, not fictional model
  engine behavior afterward.
- `hold_bulk_pid` is named historically but applies to every nonzero endpoint
  at `io/native/usb_device.c:203`; reuse it without renaming production model.
- Native request/buffer fixture storage survives TearDown. Existing SoC tests
  use local request/buffer only when explicitly settled before returning. New
  failed-drain tests must use fixture-owned storage or complete stop before the
  local scope ends, including assertion-failure exits. Otherwise TearDown can
  dereference expired stack storage and create an irrelevant RED/crash.
- Clear all newly used faults in TearDown (`hold_bulk_pid`,
  `hold_stall_clear_mask`, plus existing hold_disable/flush/etc.) so an ASSERT
  abort remains safely reclaimable. Always retain the ordinary full stop.
- A W1C-clear refusal during a happy ACK changes its terminal result to IO and
  drain. Releasing that fault later must not be expected to restore SUCCESS.
- Reset helper only latches a global bit; it does not automatically clear
  nonzero EPENA. If a test seeds EN, reset correctly waits for separate inactive
  proof and is no longer isolating DATA0.
- Token-empty alone is a retry hint. Do not treat an unknown disabled endpoint
  as ACK, and do not add test-driven unconditional re-enable during cancel,
  reset or closing that could undo source withdrawal.

The same `usb_device_soc_test.cpp` is already compiled once for F407 and once
for GD470 in `tests/google/usb_device.cmake`; no target or dependency is needed.
TDD execution still belongs to root after the global gate is released. A missing
future `uint8_t transfer` member is an expected compile RED, but no behavior
claim follows until the complete selected cases actually execute.

## Review of `03-provider-tests.patch`

Text review found no blocking correctness defect in the four proposed groups.
The invalid-plan clock spies return IO if called and have no fatal ASSERT after
their temporary installation; metadata/clock restoration completes. Interrupt
OUT uses EP2 OUT with zero FIFO fields, avoiding duplicate EP1 OUT rejection.
Native cancellation uses fresh absolute deadlines and retains CANCELLED through
stop BUSY and eventual drain. DATA0 tests obtain DATA1 from the actual Native
ACK helper. Shared SDK tests use persistent accepted storage, all three nonzero
IN numbers and MPS1/10/64, then vary XFRC, EPENA and FIFO-space proof separately.
All added source lines fit the repository's 80-column limit by text inspection.

Two small optional strengthenings were sent to the author: re-inject token-empty
bit4 with the final valid completion so XFRC+hint success is covered, and assert
TX_EMPTY_MASK stays zero after submission/completion. Unchanged OUT register
assertions establish selected-field isolation; they do not establish simultaneous
independent bulk-request isolation, which should not be claimed in the review.
The patch still requires actual root-owned RED and GREEN executions after gate
release; no test execution or application of this patch occurred in this review.
