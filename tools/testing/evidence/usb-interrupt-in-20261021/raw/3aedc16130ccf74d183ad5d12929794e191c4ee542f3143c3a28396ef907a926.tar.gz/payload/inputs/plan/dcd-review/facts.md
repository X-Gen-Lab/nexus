# Read-only DCD facts for generic FS interrupt IN

Reviewed `/tmp/nexus-quality-20261019`; no source/index writes, compiler,
configure or tests. This is implementation planning, not hardware qualification.

## Official references

- ST RM0090 Rev22, §34.16.4, DIEPCTLx pp1299–1301 and DIEPTSIZx p1311:
  <https://www.st.com/resource/en/reference_manual/dm00031020.pdf>.
  Source identity is `soc/stm32f407/references.json`: SHA256
  `f3ff2322eec21f4e49081f68481b764506eee81dba6031bc767e2f8955b27cca`.
  Existing local text read from
  `/tmp/nexus-f407-i2s2-slave-20261020/research/rm0090.txt`.
- GD32F4xx User Manual Rev3.3, **§28.7.3** USBFS device registers,
  DIEPxCTL pp988–990 and DIEPxLEN p998; §28.5.6 operation guide pp941–942:
  <https://www.gd32mcu.com/data/documents/userManual/GD32F4xx_User_Manual_Rev3.3.pdf>.
  Downloaded PDF `gd32-manual.pdf` hashes to the repository's expected
  `c8e1d20d7cde338892d08dcb233345e03f7960256a60a36c755c576d9cd65c13`.
  Existing USB design/evidence says §29.3, but in this exact official PDF
  chapter 29 is USBHS. Correct new citations to chapter 28, retaining historical
  evidence unchanged.
- USB 2.0 Specification §5.7.3 and §9.6.6 is the normative source for FS
  interrupt payload ≤64 bytes and bInterval 1–255 frames:
  <https://www.usb.org/document-library/usb-20-specification>.
  No normative USB PDF downloaded in this review; do not claim byte-level
  verification of it. Both locked MCU USB FS SDKs state max packet=64.

## Register plan

Both FS controllers use DIEPCTL EPTYP[19:18]=3 for interrupt, MPS[10:0],
USBAEP/EPACT bit15, DPID bit16, TXFNUM[25:22], SD0PID bit28,
SNAK/CNAK bits27/26, disable bit30 and enable bit31. Each selected IN
direction owns its own numbered Tx FIFO. EP1–3 are valid selectable directions;
EP0 remains control with its reserved PID command bits untouched.

Local exact anchors (relative to primary tree):

- `vendors/st/cmsis_device_f4/Include/stm32f407xx.h:14650`:
  MPS/USBAEP/DPID/EPTYP/TXFNUM, SD0PID at :14686.
- `vendors/gigadevice/gd32f4xx/Firmware/GD32F4xx_usb_library/driver/Include/drv_usb_regs.h:515`:
  matching fields; `driver/Include/drv_usb_core.h:59`: interrupt type=3.
- `soc/stm32f407/drivers/usb_device.c:13` and
  `soc/gd32f470/drivers/usb_device.c:14`: existing static assertions
  establish 4 IN/4 OUT, 320 words, max64, register strides and IRQ67.

Change shared cold init `io/src/usb_device_controller.c:292` to choose
EPTYP from an explicitly validated transfer kind (public enum numbers are not
hardware values). DATA0 reset/init/clear-halt must apply to **bulk or
interrupt**, including readback failures at :559/:566 and :926/:932.
Retain bit29 clear in the control register for interrupt; no odd/even scheduling.

### Transfer-size reserved bits: do not infer MCNT writes

Keep one-packet IN size as `PKTCNT=1 | length`, including length zero.
ST FS DIEPTSIZx p1311 marks bits31:29 reserved. Its generic periodic prose on
p1358 refers to MCNT, while the union CMSIS header defines MULCNT at bits30:29;
the per-FS register definition controls reserved-bit treatment. GD FS p998 calls
these bits MCPF for periodic IN, used to calculate ISO data PID. Both actual
locked vendor interrupt transmit paths leave MULCNT/MCNT unset:

- `vendors/st/stm32f4_hal/Src/stm32f4xx_ll_usb.c:764`: ZLP sets PKTCNT1 at
  :776; only `EP_TYPE_ISOC` programs MULCNT at :804–807.
- `vendors/gigadevice/gd32f4xx/Firmware/GD32F4xx_usb_library/driver/Source/drv_usb_dev.c:342`:
  ZLP sets PCNT1 at :354–356; only ISOC programs MCNT at :370–372.

Do not add shared MCNT or frame state from generic/HS prose. Test exact
single-packet size bits and preserve this source discrepancy in the review.

Both vendor clear-stall implementations restart interrupt/bulk at DATA0:
ST LL :1112–1114; GD driver :526–527.

## Existing mechanisms to reuse unchanged

- Plan validation `io/src/usb_device_controller.c:159–229` runs before clock
  validate/retain and any MMIO. Preserve duplicate direction/FIFO rejection.
- RX FIFO≥64 words; each selected IN FIFO≥16 words; ranges start after RX,
  disjoint and within 320 words. Because interrupt MPS≤64, these existing
  minimums cover a whole packet; no new pool or FIFO resource is needed.
- Submission :796–893 admits only ≤MPS DATA packets with control_epoch=0 on
  nonzero endpoints, validates all storage aliases, checks active hardware,
  deadline and free FIFO words before admission, then uses existing PIO writes.
- Progress :614–680 publishes SUCCESS only with XFRC, EPENA clear, full FIFO
  capacity restored and successful W1C readback. ITTXFE is a retry hint;
  TXFE is read-only. The host's interrupt poll interval is descriptor metadata,
  not a hidden application scheduler or promise of bus timing.
- Drain :485–542 waits actual NAK before disable, EPDISD, FIFO flush and W1C
  proof; missing proof retains DRAINING/QUARANTINED loans.
- `finish` :603–610 detaches endpoint request before release SETTLED.
  Reset :693–707, shared stop :1123 onward and publisher join retain their
  ownership and final-access contract. Stop does not revoke a live loan.
- Native model PID fault control is still named `hold_bulk_pid`, but its
  implementation at `io/native/usb_device.c:203` applies to every nonzero
  endpoint. Tests can use it for interrupt DATA0 readback without expanding
  production hardware state or inventing a new port.

## Rejection boundaries

Reject unsupported/unknown kinds before effects; interrupt OUT, interrupt EP0,
ISO, HS, Host, DMA, MPS0/>64, interval0/>255, bulk interval≠0, conflicting
direction/FIFO identities, unsupported controller and malformed metadata.
Preserve EP0 MPS64 and bulk MPS8/16/32/64. Runtime admission still rejects
payload>MPS, wrong direction, nonzero control_epoch, STATUS on nonzero EP,
aliases, expired deadlines, halted/closing/reset-pending state and occupied
hardware. A rejected operation retains no new references. No new class
policy, worker, inferred Board route, HIL claim or full IO35 closure follows.

## Follow-up: TXFE mask, dedicated FIFOs, retry hints

`TX_EMPTY_MASK=0` and existing `IN_MASK=0x0b` remain suitable for this
one-packet, immediately filled PIO mechanism. This conclusion is about the
selected device FIFO architecture and the absence of remaining software payload
to fetch; it is not a timing/latency guarantee or a claim that payload precedes
EPENA on the bus.

### Device FIFO identity, separate from host/shared scheduling

- ST RM0090 Rev22 **§34.11.2, printed p1248**: "The core has a dedicated
  FIFO for each IN endpoint." EP0 uses TX0FSIZ; nonzero endpoints use DIEPTXFx.
  §34.12 on the same page separately introduces host periodic/nonperiodic shared
  FIFOs. Do not transplant the host HNPTXSTS/HPTXSTS scheduling path into this
  device DCD.
- GD Rev3.3 **§28.5.5, printed pp937–938**, says device mode owns one Rx
  FIFO plus four Tx FIFOs, "one for each IN endpoint", with separate endpoint
  FIFO access ranges. Its preceding host-mode description at pp935–936 is a
  different architecture with shared periodic and nonperiodic FIFOs.
- Shared DCD `io/src/usb_device_controller.c:296–302` binds IN FIFO number
  to endpoint number and programs a checked disjoint range; :888 writes that
  endpoint's FIFO. Neither a shared nonperiodic queue nor host FIFO request
  state exists in the selected path.

### TXFE is optional deferred-fill notification, not a transmit enable

- ST **§34.16.4, DIEPEMPMSK at printed p1296**: this register controls
  TXFE interrupt generation. A zero endpoint mask masks that notification.
  TXFE itself is read-only FIFO threshold state at p1306.
- GD **§28.7.3, DIEPFEINTEN at printed pp985–986**: these bits control
  whether TXFE flags generate endpoint interrupts; zero disables that interrupt.
  TXFE is read-only threshold state at p994.
- ST **§34.17.6, printed p1357**, nonperiodic programming sequence checks
  DTXFSTS space and explicitly says the application **can optionally use TXFE**
  before writing. The periodic sequence at **p1359** says enable endpoint then
  write next-frame payload to its FIFO, with no required TXFE interrupt step.
- Locked ST LL `vendors/st/stm32f4_hal/Src/stm32f4xx_ll_usb.c:841–846`
  enables the per-endpoint empty interrupt for non-ISO PIO (including interrupt)
  **when payload is still to be copied**. Its IRQ dispatcher
  `stm32f4xx_hal_pcd.c:1272–1274` calls `PCD_WriteEmptyTxFifo`;
  that helper checks DTXFSTS, writes the endpoint's packet at :2205–2223,
  then masks TXFE when all payload is loaded at **:2226–2229**. It also
  masks at XFRC :1216–1219. Thus the ordinary vendor interrupt transfer does
  not require TXFE to remain enabled once its software FIFO-fill job is done.
- GD matches: `driver/Source/drv_usb_dev.c:394–398` enables
  DIEPFEINTEN for non-ISO PIO; `driver/Source/drv_usbd_int.c:315–318`
  dispatches TXFE to `usbd_emptytxfifo_write`; **:565–586** checks FIFO
  capacity, copies packets and disables its endpoint empty interrupt once all
  payload is copied.
- Nexus already checks enough DTXFSTS words before admission at shared DCD
  :856–858 and synchronously copies the entire accepted ≤MPS payload at
  :881–889. It has no deferred software FIFO-fill job. Setting TXFE to zero
  avoids a level interrupt with no remaining work. Completion still comes from
  XFRC/EPENA-clear/full FIFO recovery/W1C proof, not TXFE.

### Token-empty and endpoint-mismatch handling

- ST **§34.17.6, periodic IN sequence printed p1359**: if an interrupt
  endpoint is already enabled when ITTXFE is detected, ignore the hint; if it is
  not enabled, enable it for the next IN token attempt. XFRC **with or without
  ITTXFE** indicates successful interrupt-IN completion when transfer size and
  packet count reach zero. At p1358 an incomplete periodic FIFO produces NAK
  for interrupt IN; ISO instead can transmit a zero packet. Those semantics
  must not be conflated.
- ST **§34.16.4, DIEPCTLx p1299** lists the automatic EPENA clear causes
  (SETUP-phase done, endpoint disabled, transfer completed); token-empty alone
  is not listed. DIEPINT p1307 labels ITTXFE nonperiodic-only despite the
  periodic programming sequence describing it. Preserve this documentation
  inconsistency explicitly: tolerate a latched bit4 on interrupt IN, and never
  promote it to transfer failure or success by itself.
- GD **§28.7.3, DIEPxINTF printed pp994–995** calls bit4 EPTXFUD:
  it records an arriving IN token when its FIFO lacks packet data. It does not
  establish completion or buffer release. Existing shared progress :633–635
  clears this retry hint and continues; :641–650 requires the independent
  completion proof.
- ST DIEPINT **p1306 bit5 INEPNM** means data at the top of a **shared
  nonperiodic TxFIFO** belongs to another endpoint than the incoming token.
  It is not applicable to the selected per-endpoint dedicated TxFIFO layout.
  GD corresponding FS DIEPxINTF **p994 bit5 is reserved**. Keep common
  IN_MASK bit5 zero and excluded from W1C (`ep_flags` :115–117), and do not
  add shared-FIFO mismatch recovery.
- Current IN_MASK `0x0b` enables XFRC, EPDISD and control-timeout. TXFE uses
  its independent per-endpoint mask; token-empty bit4 and ST mismatch bit5
  are not required interrupt sources for a synchronously filled single packet.
  The next actual ACK raises XFRC; existing explicit service calls also observe
  latched hints and deadlines without relying on SOF or hidden workers.

Required meaningful tests for implementation: interrupt IN remains ACTIVE and
borrows payload after an enabled token-empty hint, then settles only on actual
ACK proof; XFRC plus token-empty can succeed; initial submission writes all
payload with TX_EMPTY_MASK still zero; a full unrelated bulk IN FIFO cannot
consume or complete the interrupt endpoint's request. Unexpected disabled
hardware without XFRC must never falsely settle success; the existing deadline
and drain ownership rules continue to apply. Do not add an unconditional
re-enable after cancel/reset/closing, which would undo source withdrawal.
