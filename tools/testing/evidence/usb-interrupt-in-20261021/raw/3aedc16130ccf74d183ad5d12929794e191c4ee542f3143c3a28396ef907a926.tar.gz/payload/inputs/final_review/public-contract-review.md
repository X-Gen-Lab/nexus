# Final live USB public contract and configuration review

Reviewed the live `/tmp/nexus-quality-20261019` sources on 2026-10-21 after
integration and clang-format14 formatting. **No material finding** in the
reviewed public/profile/descriptor/configuration scope. Ready for root's remaining
execution and complete-index gates, subject to the explicit limitations below.
No compiler, configure, tests, primary/index writes or production after-images
were performed by this reviewer. Root separately reviews the final controller
and actual test/ARM evidence; reported passing counts were not independently
re-executed here.

## Scope and claims agree

- `docs/design/usb-device.md:3–13` limits support to selected FS PIO packet
  mechanisms and expressly excludes complete enumeration/reset recovery.
- **:115–120** documents that observed inactive nonzero endpoints reject STATE,
  prepared requests stay READY, no request/buffer loan or FIFO write occurs, and
  activation/SET_CONFIGURATION remains an independent follow-up. DATA0/reset
  processing and controller-not-closing do not imply configuration readiness.
  The current API return brief remains general; this explicit design contract
  adequately describes the changed inactive behavior without a material gap.
- **:273–278** keeps full IO35 completion, notification policy, class stack and
  complete configuration/reset recovery open. It explicitly disclaims clean
  candidate/product/physical qualification and records electrical routes,
  enumeration, retries, unplug/reset, PHY timing and ISR/WCET/HIL as unexecuted.
  No claim that the new safe rejection supplies activation was found.
- **:266–270** correctly cites GD Rev3.3 USBFS chapter28, preserving historical
  evidence rather than rewriting its original bytes.

## Public and descriptor boundaries agree

- `io/include/nexus/io/usb_profile.h:23–35` appends
  NX_USB_PROFILE_INTERRUPT (logical value2) without adding public struct fields.
  Its validation note **:73–77** selects nonzero IN/MPS1..64 and places host
  interval only in external descriptors. The generic endpoint/controller method
  table fields remain unchanged in `usb_device.h`.
- `io/src/usb_profile.c:63–76` exhaustively validates EP0 CONTROL64,
  BULK8/16/32/64 or nonzero INTERRUPT IN1..64. Natural metadata alignment,
  extent, exact identity, required EP0 directions and unknown-kind rejection
  remain in place; no hardware observation or lifecycle effect is added.
- `components/usb_control/src/usb_descriptors.c:56–81` validates exact endpoint
  descriptor structure, explicitly maps wire BULK2/INTERRUPT3 into logical
  profile values, checks selected direction/number/type/MPS and rejects zero
  interrupt bInterval. Because bInterval is a wire byte, nonzero means1..255.
  Bulk interval is still uninterpreted. Interrupt OUT, ISO, nonzero control and
  alternate settings remain unsupported. Reserved-field/type/profile mismatches
  remain fail-closed. The public descriptor header **:27–44** accurately limits
  this to structural validation and borrowed external bytes.
- `usb_device.h:126` now says clearing bulk/interrupt resets DATA0. Ownership,
  acquire SETTLED, final access and caller service/stop responsibilities remain
  explicit. No worker, queue, automatic packetization/class behavior or new
  runtime operation is introduced by the public surfaces.

## Authored, schema, IR and emission agree

- `tools/configure/authored.py:124–128` continues exact endpoint-key admission;
  **:309–313** adds only `interrupt` to the existing transfer enum. Checked
  `assembly.schema.json:1980–2022` matches that shape and keeps unknown endpoint
  fields rejected. No authored interval or second configuration authority exists.
- `usb_device.py:63–92` is the semantic boundary: exact field set, explicit
  transfer and direction, number 0..3, MPS 1..64, EP0 CONTROL64, constrained bulk
  sizes, interrupt IN only, and exact IN/OUT FIFO ownership. **:95–117** retains
  both EP0 directions, duplicate-direction rejection, numbered resource claims
  and the 320-word combined FIFO limit.
- `ir.py:459–467/:752–755` retains the existing frozen UsbEndpointOptions fields;
  transfer remains the existing explicit string. No interval, MCNT, scheduler or
  queue field was added. JSON-schema numeric shape checks are followed by the
  resolver's narrower semantic validation, so schema shape alone is not treated
  as endpoint support.
- `usb_device.py:153–164` and `usb_profiles.py:22–31` use the same explicit
  CONTROL/BULK/INTERRUPT mapping for private state and selected immutable ROM
  profiles. Generated profiles remain conditional on selected USB plus factory
  capabilities. No inferred Board wiring, endpoint discovery or initialization
  by getter appears.
- The design **:48–49/:68–70/:91–96** states that interval stays outside
  profile/IR/provider state, MCNT/reserved high bits stay zero, and the immediate
  whole-packet FIFO fill needs no TXFE refill worker or host-poll scheduler.

## Identity and formatting anchors

All 14 entries in
`/tmp/nexus-usb-interrupt-root-20261021/formatting/manifest.json` matched their
live `after` SHA256 at review time; no mismatch was found. This is byte identity
verification, not behavioral execution. Formatting-manifest SHA256:
`573f789322dd971847768e854f8362ed7d3849cc9947c83505c24e2c12881e9e`.

Reviewed file SHA256:

| File | SHA256 |
| --- | --- |
| `io/include/nexus/io/usb_profile.h` | `b2e3aa9138df1eccd4c763e590f2fbe835c6cfbbb58879c29cac854ffbac6683` |
| `io/include/nexus/io/usb_device.h` | `d4951c5796eed451aca3eeebc4a8bf140751304ef04e270ce297b9b385f1c0d5` |
| `components/usb_control/include/nexus/components/usb_descriptors.h` | `74175c6954f008c1255fe3887221d02418798b5393716683e01a148d0e530c99` |
| `io/src/usb_profile.c` | `a600f75d94f37dc50acdc8b2f0ebd35b7a31e7dbdd888e25a8b8d25b1323c62a` |
| `components/usb_control/src/usb_descriptors.c` | `eb582a480f9492c4d6e77807c7b8af61848992b27a4c07ad113af2e5a11f33d6` |
| `tools/configure/usb_device.py` | `d900279a0806754fdb5a47bd76cf3570331a1d717597561039e32ef264ecf525` |
| `tools/configure/usb_profiles.py` | `77d831f247d90dea41e717c0d14566239f6756601e131d54e0a928ef3151b339` |
| `tools/configure/authored.py` | `90f0f82539e5a795d15a6705f7312caaa5bf934ce099bcb0425c1e2e0a5c1682` |
| `tools/configure/ir.py` | `8b01b4b65cfb02a0837bd1eb05039a2e8c3abccbf0dc2bbd8c36a8bfc63930ca` |
| `tools/configure/assembly.schema.json` | `19aab3d9e21bf7221eb900ee9ef870422b6883bd51e615543c281ceb16643a68` |
| `docs/design/usb-device.md` | `a685025c4cd3b45e19b042c7815fd1b2a949f3b9994d10b54aea0aabd3b8434b` |

This review does not establish translation/catalog completeness, ordinary
complete-index gate success, current ARM resource costs, reproducibility or
physical station results. Those remain independently bound to root's final
source and executed evidence. Nonzero activation/SET_CONFIGURATION remains a
functional follow-up even when the reviewed narrow increment passes its gates.
