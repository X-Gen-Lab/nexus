# Final independent USB interrupt-IN review

Decision: **ready for root review and ordinary-gate continuation**. No material
implementation, lifecycle, test-retention or public-contract finding remains in
the reviewed live source. This is a read-only review; this reviewer ran no
compiler, configure or tests and made no primary/index writes.

Primary source is `/tmp/nexus-quality-20261019`. Final file and artifact hashes
are in `review-manifest.json`. Physical HIL remains not_executed. Ongoing ARM
builds, linked resource results, complete-index gates, the accepted-source tuple,
clean software candidate status and IO-35 exit are outside this review decision.

## Implementation and formatting successor

The current private header, common controller and both SoC binding files are the
recorded formatting successors of the four independently reviewed after-images.
For every file, the formatting manifest's before hash equals the reviewed
production after-image hash; its after hash equals the current live file hash.
All four also preserve their non-whitespace bytes. The actual transfer,
readiness and ownership paths were read again, rather than relying solely on
that byte comparison.

- `plan_valid` accepts EP0 CONTROL64, nonzero BULK8/16/32/64, or nonzero IN
  INTERRUPT1..64. Unknown transfer values, interrupt OUT/EP0, nonzero CONTROL
  and unsupported packet/FIFO plans reject before clock callbacks or MMIO.
- The private selector remains `uint8_t`; public profile/face/ops layouts add
  no fields. Public enum values CONTROL0/BULK1/INTERRUPT2 remain separate from
  hardware EPTYP0/2/3. Both locked SDK static assertions bind masks, shifts,
  FIFO selector, DATA0/DPID, active-bit and packet-count facts.
- Interrupt IN uses its selected dedicated FIFO and the existing complete
  packet PIO admission path. PKTCNT remains one even for DATA ZLP; no IN MCNT,
  odd/even scheduling, timer, queue, worker or refill policy was introduced.
- DATA0 command and DPID readback extend together to supported bulk/interrupt
  endpoints and explicitly exclude EP0. Halt/reset failures preserve their
  existing software barriers until actual readback succeeds.
- The inactive nonzero guard sits under the existing saved-IRQ transaction.
  Stopped/closing/halted/reset state short-circuits before the register read;
  observed inactive hardware returns STATE before admission, retained request
  references, TSIZ/CTL stores or FIFO writes. No reset/submit/clear-halt path
  automatically sets an inactive endpoint active.
- Single-packet completion still requires XFRC, EPENA clear, full selected FIFO
  free space and W1C-clear readback. TXFE remains read-only; token-empty remains
  a hint and may accompany a valid completion. Drain, quarantine, publisher
  join, shared stop and detach-before-release SETTLED are unchanged.

The active-bit read is a software snapshot. A later physical bus reset still
requires the existing reset invalidation and drain paths to retain accepted
loans. The change does not promise atomicity with USB wire activity.

## Meaningful regression boundaries

The new cases exercise actual provider code and replace only existing external
hardware/clock ports. They do not mock the DCD or duplicate a new implementation
algorithm as an expected-value helper.

- The same SDK model source runs for both F407 and GD470. EP1/MPS1,
  EP2/MPS10 and EP3/MPS64 data/ZLP vectors check official register values and
  independently withhold XFRC, EN-clear and FIFO-space facts. The provider
  reference must remain until all completion facts hold. XFRC plus token-empty
  and TX-empty-mask0 remain covered. Bulk OUT register preservation is field
  isolation, not a claim of concurrent bulk-request coverage.
- Native cancellation refuses actual disable/flush acknowledgement, checks
  DRAINING/QUARANTINED request/clock retention, and permits settlement only
  after hardware fault release and real service progress.
- DATA0 cases first obtain DATA1 through an acknowledged packet, then refuse
  DATA0 readback for clear-halt/reset. No reset test fabricates reactivation by
  directly writing the active bit. Existing address/halt/PID/NAK proofs remain;
  explicit full stop/cold initialization precedes later successful admission.
- Invalid-plan vectors isolate the intended violation: interrupt OUT has no
  duplicate identity or illegal OUT FIFO, and interrupt EP0 introduces no
  duplicate direction. Cold-clock callback spies and MMIO counters remain zero.
- The faithful Native reset port models the proven ST nonzero USBAEP-clear
  side effect, preserves EP0 and unrelated state, and does not claim the same
  side effect is established for GD. The old-BULK regression requires inactive
  IN/OUT STATE/READY/no-reference/no-hardware-store behavior.
- Public profile/descriptor cases use the named appended enum, test MPS1/10/64,
  interval1/16/255 versus zero, exact selected MPS/type, malformed attributes and
  unsupported interrupt OUT. Existing metadata-alignment and bulk cases remain.
- Python tests cover all three software assembly fixtures, immutable existing
  IR, exact resource/FIFO membership, unknown/unsupported rejection and profile
  opt-out. Exact C enum emission assertions establish an emitted-source boundary;
  the SDK provider cases and ARM assemblies separately establish integration.

## Root-executed reports observed read-only

`observed-report-summary.json` records exact hashes of all ten inspected USB
GoogleTest XML reports: 186 actual cases total, no failures/errors/disabled/skips,
with each report nonempty and its declared count matching discovered testcase
members. The root's execution summary records return code zero for those commands.
Native DCD has 59 cases, each SDK DCD 8 and descriptor 9. Clock/control/ACM/factory
reports retain their separate counts; this review does not collapse them into
new interrupt-only coverage.

The latest configuration rerun is `configure-green-r3-result.json`, return code 0.
Its captured stderr states `Ran 51 tests` and `OK`, including the new USB
configuration and maintained schema-authority checks. Earlier r1/r2 setup
failures remain retained and are not treated as passing executions.

These observations describe root-owned executions and their recorded source
succession. They are not fresh test executions by this reviewer, ARM linked
resource proof, physical USB qualification or a complete-index result.

## Public scope and remaining activation responsibility

`docs/design/usb-device.md` explicitly describes inactive nonzero STATE with
READY/no borrow/no FIFO effects, and says reset/DATA0 proof does not supply
endpoint activation or SET_CONFIGURATION policy. Its closing scope retains
nonzero activation, complete class/notification/reset behavior, IO-35 exit and
physical HIL as open. The generic API return brief is short, but the linked
canonical contract documents the new failure boundary; no material contradiction
was identified.

The descriptor's bInterval is the sole polling-interval authority: linear
1..255 full-speed frames. No profile/authored/IR interval field was introduced.
Configuration adds only the existing transfer field's interrupt value; typed IR
shape is unchanged and provider/profile emitters use exact type mappings.
