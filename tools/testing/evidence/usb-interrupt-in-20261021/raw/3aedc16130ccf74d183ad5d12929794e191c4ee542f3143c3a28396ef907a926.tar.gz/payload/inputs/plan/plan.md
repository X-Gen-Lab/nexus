# Generic FS interrupt-IN: implementation-ready plan

Status: plan and unapplied test-only proposals. Primary input is
`/tmp/nexus-quality-20261019`. No production after-images, primary/index writes,
compiler, configure or test execution were performed. `/workspace/nexus` was
not read or modified. The ongoing global gate owns all execution until released.
This increment does not close IO-35 or establish physical qualification.

## Minimal contract and authority

Add generic, selected EP1–EP3 interrupt IN, one PIO packet per request, to the
existing F407/GD470 internal-PHY FS device mechanism. Preserve EP0 control and
bulk IN/OUT. No CDC notification policy, class stack, queue, worker, periodic
scheduler, inferred Board wiring or new dependency.

- Append `NX_USB_PROFILE_INTERRUPT` to `nx_usb_profile_transfer_t`. Existing
  CONTROL=0 and BULK=1 stay unchanged; the appended value is 2. These public enum
  values are **not** USB register EPTYP values.
- Keep `nx_usb_endpoint_profile_t` fields exactly as today: `port`,
  `max_packet`, `number`, `in`, `transfer`. No interval or new profile storage.
- Replace private `nx_usb_endpoint_t.bulk` with **`uint8_t transfer`**, using the
  public enum constants as validated values. This replaces one byte with one
  byte rather than relying on C enum width or assumed padding. Reject every
  unknown value, including 255. Existing generic face/ops/request layouts and
  setup-decision face remain unchanged. No factory ABI epoch/schema bump.
- Profiles accept interrupt only for number 1..3, `in=true`, MPS **1..64**,
  including non-powers-of-two such as 10. EP0 still requires control MPS64;
  bulk still requires 8/16/32/64. Keep existing alignment/extent/member checks.
- `bInterval` belongs exclusively to the external endpoint descriptor bytes.
  The DCD neither reads it nor schedules polls; request admission and absolute
  deadlines do not need it. Do not duplicate this external host-poll policy in
  authored input, IR, profile or mutable endpoint storage. The descriptor
  helper has both selected profile and descriptor view, so it can validate
  the byte directly without a second authority.

For full-speed interrupt endpoints, `bInterval` is a **linear 1..255 count of
1 ms frames**, not the HS/ISO exponent encoding. A byte of zero is invalid;
nonzero already bounds the upper limit. The host chooses actual polling.

## Exact authored/schema/typed-IR change

Authored TOML adds only the existing field value `transfer="interrupt"`.
For example, an additional software fixture endpoint may select number2,
direction `in`, transfer `interrupt`, max_packet10 and fifo_words16. Keep its
controller and all electrical authorization explicit. No Board production
route is created by this fixture.

1. `tools/configure/usb_device.py:endpoint`: validate three cases explicitly:
   EP0 control/64; nonzero bulk/{8,16,32,64}; nonzero IN interrupt/1..64.
   Keep integer/bool rejection, driver identity, endpoint number 0..3, FIFO
   validation and exact field allowlist. Interrupt OUT and EP0 interrupt fail.
2. `tools/configure/authored.py:editor_schema`: add `interrupt` to the
   `usb_endpoint.transfer` enum, regenerate the existing maintained
   `assembly.schema.json`. Its endpoint field set and required fields stay
   unchanged. The production resolver remains the semantic authority.
3. `UsbEndpointOptions` already has immutable `transfer: str`. Preserve its
   existing field set; validated `interrupt` flows through the same typed IR,
   projection/snapshots and complete-plan resource claims. No IR field or
   version bump is needed. `configure.py`'s device field allowlist is unchanged.
4. `usb_device.py:constructor` emits `.transfer = NX_USB_PROFILE_*`, never
   `.bulk` or an inferred boolean. `usb_profiles.py:emit` uses an exact
   three-member mapping; its current `control else bulk` shortcut must go.
   Keep selected-only storage and `factory.capabilities=false` opt-out.
5. Reuse complete-plan identity and FIFO allocation: both EP0 directions
   required; each selected `(number,direction)` unique; IN FIFOs follow RX in
   one plan; all ranges disjoint and within 320 words. No new resource kind.

## Descriptor behavior and error boundary

`components/usb_control/src/usb_descriptors.c:configuration` recognizes wire
transfer2 (bulk) and transfer3 (interrupt IN). Retain all complete-length,
reserved-address/attribute, interface-count, duplicate and alternate checks.

- Bulk descriptor must still match selected BULK direction/number/MPS.
- Interrupt descriptor must have IN address, selected INTERRUPT direction and
  exact selected MPS; additionally require `d[6] != 0` for bInterval.
- Supported wire type with a missing/mismatched selected profile is INVALID.
  Thus the existing bulk-profile/type3 counterexample changes from UNSUPPORTED
  to INVALID; it must not become accepted.
- Interrupt OUT, ISO, nonzero control, alternate settings and remote-wake
  remain UNSUPPORTED. Malformed/reserved fields remain INVALID.
- Preserve existing bulk bInterval treatment; do not add a new restriction to
  the existing FS bulk path. Class-specific records remain bounds-only.

## Exact hardware changes and source resolution

See [independent facts](dcd-review/facts.md) for official URLs, versions, page
numbers and locked local vendor anchors. Both controllers expose four IN/four
OUT directions, IRQ67 and 320-word FIFO; interrupt EPTYP[19:18] is **3**.

- `io/src/usb_device_controller.c:plan_valid` checks the explicit private type,
  direction and MPS before clock validate/retain or MMIO. Keep all existing
  overlap, request-idle, duplicate and FIFO validations.
- Cold initialization maps CONTROL->0, BULK->2, INTERRUPT->3 for EPTYP.
  Keep EP0 special handling; never cast the public enum directly into EPTYP.
  Keep selected IN FIFO number in bits25:22, USBAEP bit15 and SNAK bit27.
- Initial DATA0, reset and clear-halt apply to supported nonzero **bulk and
  interrupt** endpoints. Update all former `.bulk` checks at current lines
  559/566 and 926/932, including DPID bit16 readback failure. SD0PID bit28 is
  valid here; bits29:28 remain untouched for EP0, and no odd/even frame command
  is added for interrupt.
- Extend the existing SoC static assertions with exact EPTYP/MPS/SD0PID/DPID/
  TXFNUM facts from each locked SDK. This is compile-time binding, not SDK
  algorithm copying or a hot function table.
- Keep one-packet DIEPTSIZ = `(1U<<19) | length`, including ZLP. **Do not set
  MCNT/MULCNT merely because generic periodic prose or a union CMSIS macro
  exists.** RM0090 Rev22 FS DIEPTSIZx p1311 reserves bits31:29; its later generic
  periodic prose mentions MCNT. The per-FS register map controls. GD FS MCPF
  describes ISO PID calculation. Both locked official transmit paths set this
  field only for ISO, leaving it zero for interrupt (ST LL :804–807; GD
  drv_usb_dev :370–372). Preserve reserved bits zero and test the exact value.
- Dedicated endpoint FIFO operation applies: RM0090 §34.11.2 p1248 and GD
  §28.5.5 pp936–938 assign one FIFO per IN endpoint. TX-empty masks only
  enable refill interrupts (ST DIEPEMPMSK p1296; GD DIEPFEINTEN p985).
  Vendor ordinary interrupt paths enable it for deferred refill and disable
  it once all bytes are loaded. Nexus checks free space and loads the entire
  <=64-byte packet synchronously, so `TX_EMPTY_MASK=0` and existing IN mask
  remain valid; there is no remaining refill work or shared nonperiodic FIFO
  scheduler. TXFE remains read-only and ITTXFE remains a retry hint.

Correct **new/current** GD manual references to the exact Rev3.3 **USBFS
chapter28**, especially §28.7.3 (DIEPxCTL pp988–990; DIEPxLEN p998).
Chapter29 is USBHS. Preserve historical evidence bytes; do not rewrite old
results to imply corrected tests ran.

## Ownership and lifecycle reuse

No new lifecycle owner is introduced. Admission still validates packet<=MPS,
DATA stage and epoch0 for nonzero endpoints, direction/storage aliases, deadline,
halt/closing/reset/occupied hardware and free FIFO capacity before borrowing.
REJECTED leaves request/buffer references and hardware effects unchanged.

Successful IN FIFO writes do not settle. Existing progress requires XFRC,
EPENA clear, full FIFO capacity restored and observed W1C flags cleared. Drain
requires real NAK, disable/EPDISD, FIFO flush and flag-clear readback. Failed
proof retains DRAINING/QUARANTINED and clock ownership. Reset/stop cannot revoke
a buffer loan. Existing finish detaches `ep->request` before release SETTLED;
callers retain storage through acquire SETTLED and join independent observers.
Keep publisher join, wake and event-ring semantics unchanged.

## Test-first handoff

Two **unapplied, unexecuted** patches are prepared with before hashes and
expected failures in [tests-manifest.json](tests-manifest.json):

1. [01-configure-tests.patch](01-configure-tests.patch): Python unittest
   contracts for all three maintained software fixtures, mixed existing bulk
   plus interrupt-IN, immutable IR/resource/FIFO identity, MPS1/10/64, exact
   state count, no DMA, profile opt-out and unsupported/unknown field rejection.
   Current resolver rejects the new transfer, giving a real runtime RED.
2. [02-descriptor-tests.patch](02-descriptor-tests.patch): existing GoogleTest
   target tests profile interrupt MPS/direction and descriptor interval1/16/255,
   interval0, MPS/type/reserved-attribute mismatch and unsupported interrupt OUT.
   It deliberately casts test-first enum value2 so it can execute against the
   current declarations and fail at runtime, rather than requiring a missing
   declaration to create RED. After observed RED, replace the cast with named
   `NX_USB_PROFILE_INTERRUPT` during GREEN/refactor.

Root must verify before hashes in its chosen isolated checkout, apply test-only
patches there and **actually run/record RED only after the global gate is free**.
No compilation or execution success is claimed here. Existing target names are
`nexus_usb_descriptor_test`, `nexus_usb_device_test`,
`nexus_stm32f407_usb_device_test`, `nexus_gd32f470_usb_device_test`, and existing
Python tool-domain tests. Do not add a framework, dependency or filtered-only
qualification gate.

Before provider implementation, extend existing real-provider GoogleTest models
(the model is the external hardware port, not a mocked implementation):

| Contract to add | Meaningful expected assertion |
|---|---|
| Interrupt cold plan EP1/2/3, MPS1/10/64 on Native and both SDK bindings | EPTYP3, correct selected FIFO; unsupported OUT/EP0/type/MPS rejected before clock borrow/MMIO |
| IN data and ZLP submission | Size exactly PKTCNT1+length with bits31:29 zero, no automatic periodic worker; FIFO load stays ACTIVE until actual ACK facts |
| Packet/epoch/stage/alias/expiry rejection | Request stays READY, no retained pointer/FIFO writes; other endpoint and EP0 state unchanged |
| Clear-halt after one completed interrupt packet | DATA1 observed first; held DATA0 readback returns IO and keeps halt; release fault then clear-halt proves DATA0 |
| Reset after DATA1 with held DATA0 readback | reset_pending keeps admission closed; only successful readback reopens; other endpoint halt/loan rules preserved |
| Cancel/timeout/suspend followed by held disable or flush | DRAINING then QUARANTINED retains request/buffer/clock; genuine stop/retry alone can settle |
| TXFE/ITTXFE hints with no XFRC | No premature settle, no refill IRQ needed; W1C excludes TXFE and ordinary retry remains active |

Use existing `hold_bulk_pid` fault control for interrupt tests: its model code
already acts on every nonzero endpoint despite its historical name. Avoid a
rename-only production change. Migrate the two existing private fixture `.bulk`
initializers to the byte `transfer` when introducing the private field, retaining
all existing control/bulk regressions. No new CDC/EP0 policy tests are needed.

After actual RED, implement the smallest above change, execute focused GREEN,
then complete existing whole-index gates, four Native modes and tool suites.
Compile both MCU common paths and execute actual selected/unselected ARM linked
resource checks; record ROM profile cost, private state bytes and GC behavior
from exact linked images, not host sizeof or assumed padding. Include current
USB API/design text and complete reviewed English/Chinese documentation inputs.
Report HIL as not_executed, clean candidate status separately and IO-35 as still
open beyond this generic mechanism.
