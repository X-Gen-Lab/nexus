# Independent read-only USB FS interrupt-IN DCD review

Reviewed `/tmp/nexus-quality-20261019/io/src/usb_device_controller.c` as present
on 2026-10-21. SHA256:
`f445737e1f5f47fa189bd67b404ff84770ba6d103efe83128b30e382ca3c78e1`.
No production after-images, primary/index writes, compiler, configure or test
execution were created by this reviewer. Root owns actual RED execution.

Scope: selected internal-PHY FS PIO, EP0 control plus existing nonzero bulk and
proposed generic interrupt **IN**. This review does not establish physical USB,
class compliance, Board routes, HIL or full IO35 completion.

## Finding F1: existing nonzero endpoint activation is lost on a real ST reset

High confidence, pre-existing common-DCD gap; it is not introduced by replacing
the private bulk field. It limits any assertion that the new interrupt endpoint
is ready after actual bus reset and subsequent configuration.

ST RM0090 Rev22 **§34.16.4, DIEPCTLx USBAEP bit15, printed p1301** says:

> The core clears this bit for all endpoints (other than EP 0) after detecting
> a USB reset. After receiving the SetConfiguration and SetInterface commands,
> the application must program endpoint registers accordingly and set this bit.

**§34.17.5, Endpoint activation, printed p1342** requires USB active endpoint=1,
MPS, endpoint type, start toggle and TxFIFO number; after deactivation the core
ignores tokens to that endpoint. Official URL:
<https://www.st.com/resource/en/reference_manual/dm00031020.pdf>.
The repository source lock is `soc/stm32f407/references.json`, PDF SHA256
`f3ff2322eec21f4e49081f68481b764506eee81dba6031bc767e2f8955b27cca`.
The exact quoted text was read in the existing local extracted copy
`/tmp/nexus-f407-i2s2-slave-20261020/research/rm0090.txt:80675` and :85222.

Current source facts:

- Cold initialize sets active bit15 at **:292**, before initial connection.
- Reset `invalidate` **:385–403** latches reset pending and drains requests.
- Reset `clear_halts` **:551–566** reads the hardware control register,
  clears STALL and resets DATA0 for bulk, preserving a hardware-cleared active
  bit15 at zero.
- Once drain, FIFO, halt/PID and address-zero proofs succeed, **:693–706**
  clears reset_pending and opens ordinary admission.
- `submit` **:877–880** preserves the current control register and adds only
  EPENA/CNAK. It does not restore active bit15 or reject its absence.
- Existing public operations expose packet submission/cancel/stall and
  controller service/state/address/stop, but no selected-endpoint activation
  operation. Clearing halt at **:925–929** also preserves bit15 zero.
- Native `nx_native_usb_reset` at `io/native/usb_device.c:287–290` only latches
  GINT reset bit12. It does not model hardware clearing nonzero USBAEP. Current
  reset tests therefore do not expose this gap.

Consequence: after a real F407 reset clears USBAEP, software can admit an
apparently ACTIVE nonzero packet even though the endpoint ignores tokens. It
will retain the loan until timeout/drain; software model post-reset SUCCESS
does not establish real endpoint reactivation. Initial host enumeration also
includes a reset, so this is material to claims of hardware enumeration.

GD32 Rev3.3 **§28.7.3 pp989–990** says EPACT=0 ignores all tokens and makes no
response; its checked text does not explicitly establish the same automatic
reset-clear side effect. Do not assert that silicon side effect for GD solely
from shared layout. Both families still share the above software path.

Required handling: record this separate existing gap, and have root execute a
specific regression that clears nonzero hardware active bit15 when injecting
reset before choosing the smallest authorized correction. Do not silently
reactivate configured endpoints from reset alone: configuration selection and
readiness remain external policy. If the current increment excludes activation
mechanism work, document this limitation explicitly and avoid post-reset
readiness or enumeration claims. This note deliberately contains no proposed
production code or after-image.

## Necessary interrupt touchpoints

- **:194–200**: replace the bulk-only gate with exhaustive kind validation
  before any clock/MMIO. EP0 remains CONTROL/MPS64. Nonzero BULK preserves
  MPS8/16/32/64; nonzero INTERRUPT requires IN and integer MPS1..64. Unknown
  kind values, CONTROL on nonzero, INTERRUPT OUT and EP0 remain rejected.
- **:292–295**: explicitly map logical transfer kind to hardware EPTYP;
  public profile enum values CONTROL0/BULK1/proposed INTERRUPT2 differ from
  hardware CONTROL0/BULK2/INTERRUPT3. Casting the enum into EPTYP is wrong.
- **:559/:566** and **:926/:932**: DATA0 command **and its readback** must
  cover bulk OR interrupt; retain inactive-direction checks and software halted
  state until readback succeeds. Do not broaden the predicate to EP0.
- `clear_halts` comment at **:544** and public `usb_device.h:126` should say
  bulk and interrupt when describing DATA0 after the implementation changes.
- Existing :871–875 should remain PKTCNT1|length for this one-packet IN path;
  no shared MCNT or odd/even scheduling field should be added.

## Error/hint separation already suitable for interrupt IN

- `ep_flags` **:115–117** excludes read-only TXFE bit7 and ST nonperiodic
  mismatch bit5; GD FS bit5 is reserved. Retain this exclusion.
- `progress` **:633–639** handles IN token-empty bit4 and NAK-effective bit6
  as hints, while IN control timeout bit3 and OUT overflow bit4 are errors in
  their respective directions. Do not reuse the OUT bit4 interpretation for
  interrupt IN. The common control-timeout mask does not make bit3 an ordinary
  interrupt-IN transfer fact; an unexpected latched error remains fail-closed.
- A token-empty hint alone neither fails nor completes a live IN packet.
  **:641–650** requires XFRC, EPENA clear, recovered whole FIFO capacity and
  successful W1C readback. XFRC with token-empty can succeed once those
  independent proofs hold.
- `submit` **:847–853** rejects stale terminal/hint flags before admission.
  An idle host poll can therefore produce BUSY until the caller services the
  controller and retries. That retains no new loan; the explicit service owner
  remains responsible. Do not add a hidden worker or erase stale completion
  indiscriminately to avoid BUSY.
- Active endpoint errors at **:637–639** start drain only for that endpoint.
  Idle W1C clear refusal at **:619–625** closes the shared controller, which is
  a shared hardware withdrawal failure rather than an isolation promise.
- Do not unconditionally re-enable an endpoint after token-empty: doing so after
  cancel/reset/closing could undo source withdrawal. ST's periodic recipe
  **p1359** says ignore the hint when the interrupt endpoint is already enabled.

## Resource, ownership and unsupported boundaries to retain

- **:209–225** preserves ≥16-word per-IN FIFO, numbered direction identity,
  disjoint ranges after RX and ≤320-word total. It covers the whole ≤64-byte
  interrupt packet without new storage or shared periodic queues.
- **:796–812** preserves capacity/direction/storage checks and requires DATA,
  control_epoch0 on any nonzero endpoint. ZLP still borrows the request even
  though there are no payload bytes.
- **:856–889** checks whole-packet FIFO capacity before admission and writes
  the whole accepted payload synchronously; TX_EMPTY_MASK remains zero at
  **:317** because no deferred fill remains. Keep shared IN_MASK0x0b at :314.
- **:485–542** retains actual NAK-before-disable, EPDISD, flush and W1C
  withdrawal proof. **:676–678** retains quarantine instead of revoking loans.
- **:603–610** detaches the endpoint request before SETTLED final access.
  No change is needed to turn packet FIFO writes into completion.
- No interrupt OUT, ISO, HS, Host, DMA, class notifications, workers, electrical
  inference, bInterval scheduler or changed generic operation-table ABI follows.

## Exact official/supporting references already retained

Detailed source excerpts and the TXFE/dedicated-FIFO analysis are in
`/tmp/nexus-usb-interrupt-plan-20261021/dcd-review/facts.md`.

- ST RM0090 Rev22 §34.11.2 p1248: dedicated FIFO per IN endpoint.
- ST §34.16.4 pp1296/1299–1301/1306–1307/1311: masks, endpoint control,
  token-empty/mismatch semantics and FS reserved transfer-size bits.
- ST §34.17.6 pp1357–1359: FIFO space/full payload, periodic IN retry and ACK.
- GD32F4xx UM Rev3.3 §28.5.5 pp937–938 and §28.7.3 pp985–990/994–998:
  four dedicated endpoint FIFOs, mask-only TXFE generation, endpoint control,
  underrun hint and transfer registers. Official URL:
  <https://www.gd32mcu.com/data/documents/userManual/GD32F4xx_User_Manual_Rev3.3.pdf>;
  verified PDF SHA256
  `c8e1d20d7cde338892d08dcb233345e03f7960256a60a36c755c576d9cd65c13`.
- Locked ST `vendors/st/stm32f4_hal/Src/stm32f4xx_ll_usb.c:804–807`
  and GD `driver/Source/drv_usb_dev.c:370–372` program MCNT only for ISO.
  Their clear-stall paths reset DATA0 for interrupt and bulk (ST :1112–1114,
  GD :526–527). Do not infer shared FS MCNT requirements from HS/union masks.

No additional definite interrupt-only lifecycle defect was found beyond the
listed necessary extensions and F1. This conclusion is a bounded source review,
not execution evidence, and does not close F1 or establish hardware support.

## Root-selected safe rejection contract and reset-test review

Root explicitly selected rejection of inactive nonzero endpoints without adding
automatic activation on reset/clear-halt. This is a sound minimal fail-closed
correction to F1's false admission. It does not supply the missing external
SetConfiguration/SetInterface activation mechanism or establish enumeration.

Guard properties for independent implementation review:

- Read the correct IN/OUT endpoint control active bit15 only for number≠0.
- Remain inside the existing saved-IRQ admission transaction and short-circuit
  on stopped/closing state before any clock-gated MMIO access.
- Return STATE before `nx_request_admit`, `ep->request` assignment, transfer-size,
  control or FIFO stores. A valid rejected READY request stays READY, retains no
  new reference and leaves active bit15 zero.
- Preserve malformed-request rejection and existing live loan ownership; a
  hardware deactivation never revokes an already accepted request or bypasses
  drain. Do not set active bit15 from submit, reset or clear-halt.
- Apply the safe observed-bit rejection to both MCU bindings; this does not
  assert that GD automatically clears that bit on bus reset.

The updated Native reset injector observed during this review explicitly
describes ST's reference side effect and clears bit15 on EP1–3 IN **and** OUT,
leaving EP0 and request/EN/STALL/PID state untouched. That is an appropriately
bounded model extension; no additional reset side effects should be inferred.
Only `tests/google/usb_device_test.cpp` calls this helper in the checked test
source, so unrelated EP0 component fixtures do not acquire an implicit reset
policy change.

Existing expectations requiring truthful adjustment are the new interrupt
DATA0 reset branch plus the three address-zero, bulk-halt and global-OUT-NAK
regressions. Their original ownership, PID, address and NAK proofs remain valid.
Only the assertion of immediate nonzero packet readiness after bus reset was
unsupported by the ST hardware facts.

At root's explicit request, this reviewer prepared **TEST-ONLY**, unapplied
`03-reset-policy-tests.patch` and `reset-policy-tests-manifest.json` in this
directory. The source before SHA256 is
`a6792a328e367fe98d01a599a2a6a683a2dba3313055c60069dd6335debe8d8a`,
which includes root's new `ResetInactiveBulkDirectionsRejectBeforeBorrowOrFifoWrites`
counterexample. The test after-image SHA256 is
`8cabf2d46bd823664bafc76aeb5ec7db7d6792c4153ae9ec0c414ce26029c0ff`.
The patch adds 40 lines and removes none; no test is removed or disabled.

After each retained post-reset readback proof, the four cases assert inactive
STATE, READY, no endpoint reference and active bit15 zero. Only an explicit
successful full stop plus cold initialize precedes their original successful
packet/ACK checks. The nonreset interrupt clear-halt branch remains immediately
successful. Bulk-halt checks IN and OUT separately and reprepares the IN packet
after restarting. No raw active-bit repair is written by these adjustments.
The after-image's added lines fit 80 columns by text inspection.

No test execution, patch application or production after-image was performed by
this reviewer. Root owns actual inactive-guard RED, implementation and GREEN.

## Text review of authorized provider implementation and inactive guard

Reviewed `04-interrupt-provider-and-inactive-guard.patch` and all four owned
`after/` files after root reported actual provider and inactive-bulk RED. No
blocking correctness finding in the reviewed changes. This is a source review;
the reviewer did not apply or execute these files.
Reviewed patch SHA256:
`cc1b33bd452c98dd7206b3c9ba0e4385c391208ef1aa6e053db5a07a6c5c9b76`.

- `plan_valid` exhaustively validates EP0 CONTROL/MPS64, nonzero BULK
  MPS8/16/32/64 or nonzero INTERRUPT **IN** MPS1..64. Unknown kind255,
  nonzero CONTROL, interrupt OUT and zero/>64 interrupt MPS reject before
  existing clock/MMIO acquisition. Existing FIFO/direction resource checks
  remain in place.
- Cold EPTYP encoding explicitly chooses interrupt3 versus bulk2 only after
  validation, so it does not cast logical INTERRUPT2 into hardware BULK2.
- `uses_data_toggle` excludes endpoint0 and includes only bulk/interrupt. Reset
  and clear-halt use it for both the DATA0 command and DPID0 readback, retaining
  the existing inactive-EN requirement and software halted state on refusal.
- The inactive guard reads bit15 only for nonzero endpoints, inside saved IRQ
  admission. Stopped/closing/halted/reset-pending conditions short-circuit
  before the read. STATE exits before `nx_request_admit`, new reference storage
  and any TSIZ/CTL/FIFO writes. It never sets active bit15. EP0, reset drain,
  finish final access, hint masks and one-packet PKTCNT/MCNT behavior are unchanged.
- Every asserted ST literal macro exists in locked `stm32f407xx.h`, including
  OUT EPTYP_Pos/EPTYP at :14964–14966, OUT SD0PID_SEVNFRM at :14958–14960,
  OUT USBAEP at :14952–14954, IN fields :14651–14688 and PKTCNT
  :14902–14904. All corresponding GD macros exist in locked `drv_usb_regs.h`
  at :521/:524/:527/:530–532/:564; their BIT/BITS definitions produce the
  asserted masks. No SDK API or register-name assumption was left unresolved.
- Added patch lines fit 80 columns by text inspection. The private byte field
  and helper do not add a public generic operation or new runtime registry.

Qualification: the guard checks a **software-observed** active bit. A physical
reset can still occur after that MMIO read while CPU interrupts are masked.
Existing later reset capture, drain and loan retention therefore remain
essential. No bus-atomic admission or completed activation API is claimed.
