import json,os,pathlib,sys
root=pathlib.Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(root))
from tools.dev import process,provenance
out=pathlib.Path(__file__).parent;build=pathlib.Path('/dev/shm/nexus-f407-tsan-fix-build-20261021')
env=process.execution_environment(dict(os.environ,PYTHONDONTWRITEBYTECODE='1',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1'))
config=['cmake','--preset','native-tsan','-B',str(build),'-DNEXUS_COMPILER_CACHE=OFF','-DPython3_EXECUTABLE='+str(root/'.venv/bin/python')]
r=process.run(config,cwd=root,env=env,log=out/'configure.raw',timeout=180,stage='f407-tsan-red-configure');assert r.returncode==0
provenance.capture(root,build,r.receipt_path,action='configure',expected_command=config,expected_cwd=root)
r=process.run(['cmake','--build',str(build),'--target','nexus_f407_i2s2_slave_tx_test','--parallel','1'],cwd=root,env=env,log=out/'red-build.raw',timeout=300,stage='f407-tsan-real-compiler-RED')
assert r.returncode!=0 and 'atomic_thread_fence' in r.stdout+r.stderr and '-Werror=tsan' in r.stdout+r.stderr
(out/'local-red.json').write_text(json.dumps({'status':'expected_compile_RED','exit':r.returncode,'receipt':str(r.receipt_path),'reason':'atomic_thread_fence unsupported under maintained -fsanitize=thread/-Werror','test_execution':False},indent=2)+'\n');print('Actual TSan compiler RED reproduced')
