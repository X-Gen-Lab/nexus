import json,os,pathlib,sys,xml.etree.ElementTree as ET
root=pathlib.Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(root))
from tools.dev import process,provenance
out=pathlib.Path(__file__).parent;tsan=pathlib.Path('/dev/shm/nexus-f407-tsan-fix-build-20261021');env=process.execution_environment(dict(os.environ,PYTHONDONTWRITEBYTECODE='1',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1'))
rows=[]
for label,build in [('tsan-green-build',tsan),('normal-build',root/'build/native-debug')]:
 args=['cmake','--build',str(build),'--target','nexus_f407_i2s2_slave_tx_test','--parallel','1']
 r=process.run(args,cwd=root,env=env,log=out/(label+'.raw'),timeout=300,stage='f407-'+label);rows.append(str(r.receipt_path));assert r.returncode==0
 provenance.capture(root,build,r.receipt_path,action='build',expected_command=args,expected_cwd=root)
r=process.run([str(root/'build/native-debug/bin/nexus_f407_i2s2_slave_tx_test'),'--gtest_output=xml:'+str(out/'normal.xml')],cwd=root,env=env,log=out/'normal-execute.raw',timeout=120,stage='f407-model-normal-green');rows.append(str(r.receipt_path));assert r.returncode==0
j=ET.parse(out/'normal.xml').getroot();assert int(j.attrib['tests'])==35 and not any(int(j.attrib.get(k,0)) for k in ['failures','errors','disabled'])
r=process.run([str(tsan/'bin/nexus_f407_i2s2_slave_tx_test'),'--gtest_output=xml:'+str(out/'tsan.xml')],cwd=root,env=env,log=out/'tsan-execute.raw',timeout=120,stage='f407-model-tsan-runtime-observation');rows.append(str(r.receipt_path))
record={'status':'compiler_green_and_normal_35_passed','commands':rows,'normal_tests':35,'tsan_runtime_exit':r.returncode,'tsan_runtime_qualified':False,'production_changed':False}
if r.returncode==0:
 j=ET.parse(out/'tsan.xml').getroot();assert int(j.attrib['tests'])==35 and not any(int(j.attrib.get(k,0)) for k in ['failures','errors','disabled']);record.update(tsan_tests=35,tsan_runtime_qualified=True)
else:record['tsan_runtime_diagnostic']=(r.stdout+r.stderr)[-1800:]
(out/'local-green.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
