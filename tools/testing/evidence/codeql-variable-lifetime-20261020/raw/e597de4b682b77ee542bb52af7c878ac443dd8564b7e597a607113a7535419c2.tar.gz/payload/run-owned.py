"""Execute actual changed modules against read-only facts in a sparse overlay."""
import importlib
import importlib.util
import inspect
from pathlib import Path
import sys
import unittest

PRIMARY = Path('/tmp/nexus-quality-20261019')
OWNED = Path(__file__).resolve().parent
sys.path.insert(0, str(PRIMARY))


def load_owned(name, relative):
    parent = importlib.import_module(name.rpartition('.')[0])
    source = OWNED / 'final' / relative
    spec = importlib.util.spec_from_file_location(name, source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    setattr(parent, name.rpartition('.')[2], module)
    spec.loader.exec_module(module)
    if hasattr(module, 'ROOT'):
        original_root = module.ROOT
        module.ROOT = PRIMARY
        # The API already accepts root. A sparse file lives outside the facts
        # tree, so bind only omitted root arguments to the real read-only tree.
        # Explicit test roots and all resolver/auditor behavior remain intact.
        for value in vars(module).values():
            if not inspect.isfunction(value) or value.__module__ != name:
                continue
            parameters = list(inspect.signature(value).parameters.values())
            positional = [p for p in parameters if p.kind in
                          (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)]
            defaults = list(value.__defaults__ or ())
            for index, parameter in enumerate(positional[-len(defaults):]
                                               if defaults else []):
                if parameter.name == 'root' and defaults[index] == original_root:
                    defaults[index] = PRIMARY
            if defaults:
                value.__defaults__ = tuple(defaults)
            if value.__kwdefaults__ and value.__kwdefaults__.get('root') == original_root:
                value.__kwdefaults__ = {**value.__kwdefaults__, 'root': PRIMARY}
    return module


if sys.argv[1] == 'adc':
    load_owned('tools.configure.configure', 'tools/configure/configure.py')
    target = load_owned('tools.configure.test_g474_adc_group_configuration',
                        'tools/configure/test_g474_adc_group_configuration.py')
    suite = unittest.defaultTestLoader.loadTestsFromModule(target)
elif sys.argv[1] == 'retention':
    load_owned('tools.measurement.retention', 'tools/measurement/retention.py')
    suite = unittest.defaultTestLoader.loadTestsFromNames([
        'tools.testing.test_resolved_abi',
        'tools.testing.test_provider_retention'])
else:
    raise ValueError('Unknown complete test module group')
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
