# CodeQL variable lifetime correction

The G474 ADC resolver pre-scanned only authored_kind metadata to load the review.
A valid schema-1 JSON ADC group has no authored_kind, so its validated route could
reach adc_group_digest before initialization. The new whole-resolver regression
uses a real ADC1 route, public typed result and the actual review input bytes.
It fails with UnboundLocalError before the fix; all 13 prior cases remain unchanged.
The complete module then passes 14/14 after the fix.

The resolver now loads the review only when the validated selected route is an
ADC group. One cached tuple keeps review, digest of the read snapshot and its
input path together. The maintained G474 family restriction and normal provider
validation remain; the same snapshot path still enters declared input binding.
No placeholder digest, missing-review fallback or authored observation is added.

Retention's resolved_identity API returns a validated dictionary or raises. Its
config/inputs were consequently defined on every reachable resolved report path,
but two later guards tested a different variable than their initialization guard.
Both now use the same unchanged resolved_path predicate. Legacy reports stay
hard-only without new fields. Strict resolved CPU, input and ELF validation retain
their call order and fail-closed behavior. This is a flow clarification, not a
new runtime defect; no mirror test was added.

The complete existing ABI and provider-retention modules pass 90/90 using the
pinned ARM compiler under shared flock/jobs1. An earlier missing compiler environment
failure (63 cases plus ABI setup error) is preserved separately and is not the
production RED. No cases were removed; no skips, filters or shards were used for acceptance.

run-owned.py loads only the changed actual files from this sparse regular-file
overlay and binds omitted existing root arguments to read-only primary facts.
Explicit test roots and implementation bodies stay unchanged. Python bytecode
writes were disabled; no primary, index or frozen packet was modified.

The original three CodeQL annotations are retained by identity and excerpt.
Source repair and executed tests do not establish CodeQL alert removal; a real
query or remote scan must do that. Other warning/note alerts are outside scope.
Qualification and physical execution remain false/not_executed.
