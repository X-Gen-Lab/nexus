#!/usr/bin/env python3
"""Preserve the completed MPU ordinary gate once; never run the gate."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PRIMARY = Path('/tmp/nexus-quality-20261019')
TDD = PRIMARY / 'build/native-debug/tdd'
PAYLOAD = ROOT / 'payload'
COMMIT = '6032222cb099d7f5b4410b18f57f375126e87d7d'
TREE = 'd170028a50bf8907fb85b957a3ff962c449c45fb'
LOWER = 1792537696952824791
COPIED = {}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write(name, data):
    p = PAYLOAD / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)

def put(name, data):
    write(name, (json.dumps(data, indent=2) + '\n').encode())

def copy(path, name):
    p = Path(path)
    assert p.is_file() and not p.is_symlink() and not any(q.is_symlink() for q in p.parents), p
    h = sha(p)
    target = PAYLOAD / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert sha(target) == h
    else:
        shutil.copyfile(p, target)
    assert sha(target) == h == sha(p), p
    COPIED[str(p)] = {'payload': name, 'sha256': h, 'bytes': target.stat().st_size}
    return h

def capture_receipt(path, label, fresh=True):
    p = Path(path)
    d = json.loads(p.read_text())
    assert d['finished_ns'] >= d['started_ns'] and d['withdrawal_stable'] and d['withdrawal_complete']
    if fresh:
        assert d['started_ns'] >= LOWER and d['outcome'] == 'completed' and d['exit_code'] == 0
    copy(p, label + '/receipt.json')
    for key in ('stdout', 'stderr'):
        row = d[key]
        raw = Path(row['path'])
        assert sha(raw) == row['sha256'] and raw.stat().st_size == row['bytes']
        copy(raw, 'raw-blobs/' + row['sha256'])
    return d

def capture_native():
    assert not (ROOT / 'native-frozen.json').exists()
    canonical = {}
    for p in sorted(TDD.glob('*.command.json')):
        d = json.loads(p.read_text())
        if d.get('started_ns', 0) < LOWER:
            continue
        label = p.name.removesuffix('.command.json')
        attempt = capture_receipt(d['attempt_receipt'], 'gate/r2/attempts/' + label)
        assert {k:v for k,v in d.items() if k != 'attempt_receipt'} == attempt
        copy(p, 'gate/r2/commands/' + p.name)
        canonical[label] = d
    expected = {'configure', 'build', 'tools-testing', 'tools-configure', 'tools-ci', 'tools-workflows'} | {f'{phase}-{i}' for phase in ('discovery','execution') for i in range(347)}
    assert len(canonical) == 700 and set(canonical) == expected
    summary = json.loads((TDD / 'execution.json').read_text())
    assert summary['passed'] == 6253 and len(summary['suites']) == 347
    suites = {s['binary']:s for s in summary['suites']}
    google = []
    for i in range(347):
        cmd = canonical[f'execution-{i}']; argv = cmd['command']; binary = Path(argv[0]).name
        assert argv[1:4] == ['--gtest_filter=*','--gtest_repeat=1','--gtest_also_run_disabled_tests'] and len(argv) == 5
        assert canonical[f'discovery-{i}']['command'] == [argv[0], '--gtest_filter=*', '--gtest_list_tests']
        p = TDD / f'google-{i}.xml'; assert cmd['started_ns'] <= p.stat().st_mtime_ns <= cmd['finished_ns']
        x = ET.parse(p).getroot(); n = int(x.get('tests'))
        assert all(int(x.get(k,0)) == 0 for k in ('failures','errors','disabled')) and not x.findall('.//skipped') and len(x.findall('.//testcase')) == n
        s = suites[binary]; assert s['tests'] == s['passed'] == n and all(s[k] == 0 for k in ('failures','errors','skipped')) and sha(p) == s['report_sha256']
        copy(p, 'gate/r2/google/' + p.name)
        google.append({'index':i,'binary':binary,'tests':n,'xml_sha256':s['report_sha256'],'started_ns':cmd['started_ns'],'finished_ns':cmd['finished_ns']})
    assert sum(g['tests'] for g in google) == 6253
    tools = {'testing':1349,'configure':950,'ci':485,'workflows':125}
    for name, n in tools.items():
        p = TDD / f'tools-{name}.json'; d = json.loads(p.read_text()); cmd = canonical['tools-' + name]
        assert cmd['started_ns'] <= p.stat().st_mtime_ns <= cmd['finished_ns'] and d['status'] == 'passed' and d['discovered'] == d['executed'] == n
        assert all(d[k] == 0 for k in ('skipped','failures','errors','expected_failures','unexpected_successes')) and d == next(s for s in summary['tool_suites'] if s['suite'] == name)
        copy(p, 'gate/r2/tools/' + p.name)
    copy(TDD / 'execution.json', 'gate/r2/execution.json')
    catalogue = PRIMARY / 'build/native-debug/google-contracts.json'; assert len(json.loads(catalogue.read_text())['executables']) == 347
    copy(catalogue, 'gate/r2/google-contracts.json')
    for name in ('io-property-inputs.json','io-property-report.json'):
        p = TDD / name; assert LOWER <= p.stat().st_mtime_ns
        if name == 'io-property-report.json':
            audit = json.loads(p.read_text())
            assert audit['execution_summary_sha256'] == sha(TDD / 'execution.json')
            assert audit['inputs'] == json.loads((TDD / 'io-property-inputs.json').read_text())
        copy(p, 'gate/r2/' + name)
    result = {'commit':COMMIT,'tree':TREE,'minimum_started_ns':LOWER,'fresh_commands':700,'first_started_ns':min(d['started_ns'] for d in canonical.values()),'last_finished_ns':max(d['finished_ns'] for d in canonical.values()),'google_executables':347,'google_tests':6253,'tools':tools,'tool_total':sum(tools.values()),'all_failures_errors_skips':0,'google':google,'gate_rerun':False,'deduplication':'Immutable stdout/stderr stored once by SHA256 in raw-blobs; original receipts and input map retain original locations.'}
    put('gate/r2/admission-summary.json', result)
    put('archive-input-map.json', COPIED)
    (ROOT / 'native-frozen.json').write_text(json.dumps({'status':'actual_fresh_native_evidence_frozen','commit':COMMIT,'commands':700,'google':6253,'binaries':347,'tools':2909,'minimum_started_ns':LOWER,'payload':str(PAYLOAD)},indent=2)+'\n')
    print('NATIVE_FROZEN', flush=True)

def git(*args):
    return subprocess.check_output(['git','-C',str(PRIMARY),*args])

def capture_context():
    COPIED.update(json.loads((PAYLOAD / 'archive-input-map.json').read_text()))
    freeze_path = Path('/tmp/nexus-u575-mpu-final-source-freeze-r2-20261020.json'); freeze=json.loads(freeze_path.read_text())
    assert git('rev-parse',COMMIT+'^{tree}').decode().strip() == TREE == freeze['index_tree']
    parent=git('rev-parse',COMMIT+'^').decode().strip(); assert parent == freeze['head']
    changed=set(git('diff-tree','--no-commit-id','--name-only','-r',COMMIT).decode().splitlines()); assert changed == set(freeze['files'])
    bindings=[]
    for name,expected in freeze['files'].items():
        data=git('show',COMMIT+':'+name); h=hashlib.sha256(data).hexdigest(); assert h==expected,name
        bindings.append({'path':name,'sha256':h,'bytes':len(data),'blob':git('rev-parse',COMMIT+':'+name).decode().strip()})
    put('source/committed-bindings.json',{'commit':COMMIT,'tree':TREE,'parent':parent,'files':bindings,'method':'Only frozen R2 source map versus git show exact committed blobs; current dirty working tree/index is excluded.'})
    write('source/commit.raw.txt',git('cat-file','commit',COMMIT))
    fixed={'/tmp/nexus-u575-mpu-final-source-freeze-r2-20261020.json':'source/r2-freeze.json','/tmp/nexus-u575-mpu-final-source-freeze-20261020.json':'source/first-freeze-historical.json','/tmp/nexus-u575-mpu-final-ordinary-acceptance-20261020.json':'gate/ordinary-acceptance.json','/tmp/nexus-u575-mpu-final-commit-r2-20261020.log':'gate/r2-ordinary-commit.log','/tmp/nexus-u575-mpu-final-docs-r2-20261020.log':'documentation/r2-full-site.log'}
    for src,dst in fixed.items():copy(src,dst)
    failed=Path('/tmp/nexus-u575-mpu-first-hook-failure-20261020')
    for p in failed.iterdir():
        if p.is_file():copy(p,'gate/first-failed/' + p.name)
    first=json.loads((failed/'tools-testing.command.json').read_text()); assert first['started_ns'] < LOWER and first['exit_code']==1
    capture_receipt(first['attempt_receipt'],'gate/first-failed/actual-attempt',fresh=False)
    timing=Path('/tmp/nexus-u575-mpu-gate-timing-20261020')
    for p in timing.iterdir():
        if p.is_file():copy(p,'gate/first-failed/timing/' + p.name)
    caps=Path('/tmp/nexus-capabilities-mpu-catalog-20261020');final=json.loads((caps/'final.json').read_text())
    for n in ('candidate.json','final.json','final.patch','command.json','gettext.stdout.txt','gettext.stderr.txt'):
        copy(caps/n,'capability-catalog/' + n)
    copy('/tmp/nexus-capabilities-mpu-independent-review-20261020/review.json','capability-catalog/peer-review.json')
    copy(caps/'gettext/delivery/capabilities.pot','capability-catalog/focused-exit1-capabilities.pot')
    for row in final['files']:
        actual=row['reviewed_final']; assert sha(actual['path'])==actual['sha256']==freeze['files'][row['path']]
        copy(actual['path'],'capability-catalog/final/' + row['path'])
    retirement=Path('/tmp/nexus-u575-mpu-final-doc-retirement-r2-20261020')
    for p in retirement.iterdir():
        if p.is_file():copy(p,'documentation/retirement/' + p.name)
    selected=[]
    for p in sorted(retirement.glob('package-*.json')):
        package=json.loads(p.read_text()); archive=Path(package['archive']['path']);assert sha(archive)==package['archive']['sha256']
        with tarfile.open(archive,'r:gz') as t:
            for m in t:
                if m.isfile() and m.name.endswith(('documentation-build.json','source-check.json','delivery/capabilities.pot')):
                    assert m.size <= 4*1024*1024
                    data=t.extractfile(m).read(); dest='documentation/critical-from-archive/' + p.stem + '/' + m.name
                    write(dest,data);selected.append({'archive':package['archive'],'member':m.name,'payload':dest,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    put('documentation/critical-member-bindings.json',selected)
    put('archive-input-map.json',COPIED)
    put('collection-scope.json',{'commit':COMMIT,'tree':TREE,'frozen_source_paths':len(bindings),'native_started_ns_cutoff':LOWER,'first_failed_attempt':'Preserved NOT accepted:1349 testing with1error caused by stale derived capabilities. Historical freeze/timing kept, later R2 after literal catalog closure is distinct.','site':'Original completed full bilingual staged/dirty87-path build, historical parent head '+parent+'; existing independently byte-verified retirement archives referenced, never relabelled as a clean formal source build. Only compact critical JSON/POT extracted; entire sites are not duplicated.','no_gate_bypass_or_rerun':True,'physical_status':'not_executed','formal_main_or_complete_sdk_matrix_qualification':False})
    print('CONTEXT_FROZEN',flush=True)

def seal():
    sys.path.insert(0,str(PRIMARY))
    from tools.evidence.store import export_tree,verify_package
    assert not (ROOT/'package.json').exists()
    package=export_tree(PAYLOAD,ROOT/'store')
    (ROOT/'package.json').write_text(json.dumps(package,indent=2)+'\n')
    verified=verify_package(package)
    (ROOT/'verified.json').write_text(json.dumps(verified,indent=2)+'\n')
    print(json.dumps({'package':str(ROOT/'package.json'),'verified':str(ROOT/'verified.json'),'archive':package['archive'],'files':package['files'],'bytes':package['bytes']}),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='native':capture_native()
    elif sys.argv[1]=='context':capture_context()
    elif sys.argv[1]=='seal':seal()
    else:raise SystemExit('expected native, context, or seal')
