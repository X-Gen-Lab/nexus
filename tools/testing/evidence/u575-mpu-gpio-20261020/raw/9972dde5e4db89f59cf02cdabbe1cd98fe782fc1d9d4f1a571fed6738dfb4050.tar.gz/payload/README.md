# MPU ordinary gate evidence

This package preserves the completed ordinary commit gate for `6032222cb099d7f5b4410b18f57f375126e87d7d`, tree `d170028a50bf8907fb85b957a3ff962c449c45fb`. It does not rerun a gate or establish formal main, the complete SDK matrix, or physical HIL.

`source/committed-bindings.json` compares all 87 R2 frozen source hashes with exact committed Git blobs. The current working tree and index are excluded, including later F407 drafts.

`gate/r2` contains only the 700 current Native command receipts started at or after `1792537696952824791`, their actual immutable attempt receipts, 347 Google XML reports (6253 passed cases), four tool summaries (1349 testing + 950 configure + 485 CI + 125 workflows = 2909 passed), execution/catalogue and the bounded IO-property audit. Every executed test is present, including disabled-test discovery; none were skipped. The audit report binds the exact execution-summary hash and preexecution inputs. It is produced after the final Google child, so freshness uses its lower timestamp and content bindings, not the last child's finish time as an upper bound.

Immutable stdout and stderr are deduplicated by SHA256 under `raw-blobs/`. `archive-input-map.json` maps all original regular-file locations to package paths. Original command receipts retain their original paths; archive maps and blobs make them independently readable after Native outputs change.

`gate/first-failed` preserves the rejected first 1349-test attempt, its actual command streams, timing and historical source freeze. It had one tool error because the derived capability page was stale. Its failure remains NOT accepted; it is not relabeled as R2 success.

`capability-catalog` retains the reviewed literal-path patch, final EN/ZH catalogs, meaning review and the focused extraction's original exit1 for its isolated missing support.md target. `documentation` references the existing byte-verified retired full-site archives without duplicating either site. Only critical original JSON/POT and four actual command receipts/streams are copied. The separate complete bilingual staged/dirty-source build passed 126 source pages; its parent source identity and qualification=false remain unchanged. Its 506 capability messages match the focused POT exactly.

The evidence was captured without configure, compiler, tests, source/index mutation, vendor/framework/SDK payloads or build objects. `collect.py` is a one-shot archive collector using maintained `tools.evidence.store`; it is not a gate or new evidence framework.
