from pathlib import Path
import datetime
import hashlib
import json
import os
import time
import xml.etree.ElementTree as ET

ROOT = Path('/tmp/nexus-quality-20261019')
TDD = ROOT / 'build/native-debug/tdd'
OUT = Path(__file__).resolve().parent
COMMIT_PID = 182962
FIRST = json.loads((TDD / 'tools-testing.command.json').read_text())['started_ns']
TICKS = os.sysconf('SC_CLK_TCK')
STAGES = ('tools-testing', 'tools-configure', 'tools-ci', 'tools-workflows', 'configure', 'build')


def proc(pid):
    p = Path('/proc') / str(pid)
    try:
        text = (p / 'stat').read_text()
        fields = text[text.rindex(')') + 2:].split()
        if fields[0] == 'Z':
            return None
        command = (p / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace').strip()
        data = {'pid': pid, 'state': fields[0], 'cpu_seconds': (int(fields[11]) + int(fields[12])) / TICKS,
                'wait_channel': (p / 'wchan').read_text().strip(), 'command': command[:700]}
        if pid == 185313:
            data['io'] = dict(line.split(': ', 1) for line in (p / 'io').read_text().splitlines())
        return data
    except (FileNotFoundError, ProcessLookupError):
        return None


def descendants(pid):
    result = []
    queue = [pid]
    while queue and len(result) < 35:
        current = queue.pop(0)
        record = proc(current)
        if record:
            result.append(record)
        p = Path('/proc') / str(current) / 'task' / str(current) / 'children'
        try:
            queue.extend(map(int, p.read_text().split()))
        except (FileNotFoundError, ProcessLookupError):
            pass
    return result


def receipt(path, now):
    try:
        data = json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return None
    if data.get('started_ns', 0) < FIRST:
        return None
    keys = ('stage', 'started_ns', 'finished_ns', 'duration_seconds', 'outcome', 'exit_code',
            'build_parallelism', 'attempt_receipt', 'stdout_path', 'stderr_path')
    result = {k: data[k] for k in keys if k in data}
    result['path'] = str(path)
    result['mtime_ns'] = path.stat().st_mtime_ns
    result['sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    result['observed_elapsed_seconds'] = (now - data['started_ns']) / 1e9
    if data.get('outcome') == 'running':
        for name in ('stdout_path', 'stderr_path'):
            raw = Path(data[name])
            if raw.exists():
                result[name.replace('_path', '_observation')] = {'size': raw.stat().st_size,
                    'mtime_ns': raw.stat().st_mtime_ns, 'tail': raw.read_bytes()[-140:].decode(errors='replace')}
    return result


def capture():
    now = time.time_ns()
    stages = [r for n in STAGES if (r := receipt(TDD / (n + '.command.json'), now))]
    google = []
    for pattern, kind in [('discovery-*.command.json', 'discovery'), ('execution-*.command.json', 'execution')]:
        for p in TDD.glob(pattern):
            if p.stat().st_mtime_ns < FIRST:
                continue
            r = receipt(p, now)
            if r:
                r['kind'] = kind
                google.append(r)
    xml_count = 0
    case_count = 0
    xml_seconds = 0.0
    for p in TDD.glob('google-*.xml'):
        if p.stat().st_mtime_ns < FIRST:
            continue
        try:
            root = ET.parse(p).getroot()
        except ET.ParseError:
            continue
        xml_count += 1
        case_count += int(root.attrib.get('tests', 0))
        xml_seconds += float(root.attrib.get('time', 0))
    snapshot = {'observed_ns': now, 'observed_utc': datetime.datetime.fromtimestamp(now / 1e9, datetime.UTC).isoformat(),
                'first_current_command_ns': FIRST, 'stages': stages,
                'google': {'fresh_xml_files': xml_count, 'fresh_xml_cases': case_count,
                           'xml_reported_seconds_sum': xml_seconds,
                           'discovery_commands': sum(r['kind'] == 'discovery' for r in google),
                           'execution_commands': sum(r['kind'] == 'execution' for r in google),
                           'discovery_wall_seconds_sum': sum(r.get('duration_seconds', 0) for r in google if r['kind'] == 'discovery'),
                           'execution_wall_seconds_sum': sum(r.get('duration_seconds', 0) for r in google if r['kind'] == 'execution'),
                           'slowest_five_commands': sorted(google, key=lambda r: r.get('duration_seconds', 0), reverse=True)[:5]},
                'processes': descendants(COMMIT_PID)}
    (OUT / 'latest.json').write_text(json.dumps(snapshot, indent=2) + '\n')
    with (OUT / 'snapshots.jsonl').open('a') as stream:
        stream.write(json.dumps(snapshot, separators=(',', ':')) + '\n')
    return snapshot


for iteration in range(35):
    snapshot = capture()
    print(json.dumps({'observed_utc': snapshot['observed_utc'],
                      'current_stages': [(r['stage'], r['outcome'], round(r.get('duration_seconds', r['observed_elapsed_seconds']), 3)) for r in snapshot['stages']],
                      'fresh_google_executions': snapshot['google']['execution_commands'],
                      'active_processes': len(snapshot['processes'])}), flush=True)
    if not snapshot['processes']:
        break
    time.sleep(20)
