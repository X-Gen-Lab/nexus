本轮不是停滞：`tools-testing` 在 22:44:47Z 启动，实际 351.417 秒后正常退出 1。1349/1349 用例已执行，0 skip，0 assertion failures，1 error；唯一错误是 `test_maintenance.CapabilityDocumentationTests.test_checked_document_matches_facts_and_selected_implementation` 检出 `docs/delivery/capabilities.md` 派生块过期。

本轮可以确认的主要耗时只有完整 testing：unittest 本体 350.717 秒，外层约 0.700 秒。configure / CI / workflows / Native configure/build / Google 尚未执行；其现存报告均早于本轮，不能填充第二、第三名。本 runner 没有 per-case 时长，因此不能可靠归因到三个 test class。

运行中 stderr 持续更新，约第291秒累计 CPU121秒；随后观测到进程正在 clone 子进程，累计 syscall read 约104GB、storage read仅12KB。这支持持续执行/缓存内数据读取，不能据此断言某个 fixture 或磁盘是瓶颈。

- 先更新现有 capability 派生块，再从头执行完整普通门禁；后续用真实回归把 maintained capability check 纳入已有廉价 docs preflight，减少已知派生错误消耗整轮351秒。
- 若要找真实前三开销，先给既有 unittest result 记录各用例 elapsed 与最慢少量条目，所有用例照常执行。
- 定位后再审重复输入 fixture：`test_maintenance.py` 五次完整 collect，`test_provider_sources.py` 多个独立 CMake configure 是可调查候选，当前没有逐例时长，不能称它们已证明是主要瓶颈。

全过程仅只读 primary/process/receipt/JUnit 元数据；未运行测试、未取编译锁、未改 primary 或索引。
