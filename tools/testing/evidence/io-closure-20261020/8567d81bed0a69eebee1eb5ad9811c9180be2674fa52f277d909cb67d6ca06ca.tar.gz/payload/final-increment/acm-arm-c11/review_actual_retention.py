#!/usr/bin/env python3
"""Read-only independent review of existing actual ARM artifacts; no builds."""
import datetime, hashlib, json, pathlib, re, resource, subprocess, sys
R=pathlib.Path('/tmp/nexus-quality-20261019');A=pathlib.Path('/tmp/nexus-usb-acm-execute-20261020/arm-c11');M=A/'matrix/report.json';U=pathlib.Path('/tmp/nexus-io15-execute-20261020/arm-c11')
sys.path.insert(0,str(R));from tools.measurement.elf import Elf32
errors=[];limitations=[];cache={}
def identity(p):
    p=pathlib.Path(p);s=p.stat();key=(str(p),s.st_size,s.st_mtime_ns,s.st_ino)
    if key not in cache:
        h=hashlib.sha256()
        with p.open('rb') as f:
            for b in iter(lambda:f.read(256*1024),b''):h.update(b)
        cache[key]={'path':str(p),'size':s.st_size,'sha256':h.hexdigest()}
    return cache[key]
def check(record,where,err=True):
    try:
        actual=identity(record['path']);ok=actual['size']==record.get('size',record.get('bytes')) and actual['sha256']==record['sha256']
    except (OSError,KeyError) as e:
        actual={'path':record.get('path'),'error':str(e)};ok=False
    if not ok and err:errors.append({'code':'identity_mismatch','where':where,'expected':record,'actual':actual})
    return ok,actual
m=json.loads(M.read_text());matrix_identity=identity(M)
if m.get('status')!='passed' or m.get('fixture_count')!=6 or len(m.get('fixtures',[]))!=6:errors.append({'code':'matrix_not_six_passes'})
if not m.get('source_inputs_stable') or not m.get('tools_stable') or m.get('source_before')!=m.get('source_after'):errors.append({'code':'matrix_source_tools_unstable'})
acm=['nx_usb_acm_initialize','nx_usb_acm_begin','nx_usb_acm_step','nx_usb_acm_pending','nx_usb_acm_approve','nx_usb_acm_cancel','nx_usb_acm_snapshot']
control=['nx_usb_control_in_prepare','nx_usb_control_out_prepare','nx_usb_control_status_prepare','nx_usb_control_initialize','nx_usb_control_begin','nx_usb_control_step','nx_usb_control_cancel','nx_usb_control_out_view','nx_usb_control_approve','nx_usb_control_snapshot']
descriptor=['nx_usb_descriptor_validate'];nm=pathlib.Path(m['tools']['nm']['path']);check(m['tools']['nm'],'nm binary')
results=[]
for i,row in enumerate(m['fixtures']):
    artifacts={}
    for k,v in row['artifacts'].items():
        ok,actual=check(v,f'fixture{i}.{k}');artifacts[k]={**actual,'matches_matrix_identity':ok}
    elf_path=pathlib.Path(row['artifacts']['elf']['path']);elf=Elf32(elf_path.read_bytes());symbols={x['name']:x for x in elf.defined_symbols}
    retained={}
    for name in acm+control+descriptor:
        s=symbols.get(name)
        valid=s is not None and s['type']==2 and s['binding'] in (1,2) and s['size']>0
        if valid:
            sec=elf.sections[s['section']];start=s['value']&~1;valid=bool(sec['flags']&4) and sec['address']<=start<sec['address']+sec['size']
        retained[name]={'symbol':s,'valid_defined_executable_function':valid}
        if not valid:errors.append({'code':'required_function_not_retained','fixture':i,'symbol':name})
    context=symbols.get('s_nx_acm');valid_context=context is not None and context['type']==1 and context['binding']==0 and context['size']>0
    if valid_context:valid_context=elf.sections[context['section']]['flags']&3==3 and context.get('file')=='controller_main.c'
    if not valid_context:errors.append({'code':'caller_context_not_retained','fixture':i,'symbol':context})
    p=subprocess.run([str(nm),'--defined-only','--print-size',str(elf_path)],capture_output=True,text=True)
    if p.returncode:errors.append({'code':'nm_failed','fixture':i,'returncode':p.returncode})
    nm_rows={line.split()[-1]:line.split()[2] for line in p.stdout.splitlines() if len(line.split())==4}
    for name in acm+control+descriptor:
        if nm_rows.get(name) not in ('T','t'):errors.append({'code':'nm_function_not_text','fixture':i,'symbol':name,'kind':nm_rows.get(name)})
    if nm_rows.get('s_nx_acm') not in ('B','b','D','d'):errors.append({'code':'nm_context_not_data','fixture':i})
    dep_mismatches=[]
    for inp in row['compile_sources']+row['compiler_dependencies']:
        ok,actual=check(inp,f'fixture{i}.compiler_input',err=False)
        if not ok:dep_mismatches.append({'expected':inp,'actual':actual})
    if dep_mismatches:limitations.append({'code':'current_compiler_inputs_differ_from_recorded_execution','fixture':i,'mismatches':dep_mismatches})
    cc=json.loads(pathlib.Path(row['artifacts']['compile_commands']['path']).read_text())
    c_units=[x for x in cc if x['file'].endswith('.c')]
    c11_failures=[x for x in c_units if re.findall(r'(?:^|\s)-std=([^\s]+)',x['command'])!=['c11']]
    if c11_failures:errors.append({'code':'usb_translation_units_not_c11','fixture':i,'commands':c11_failures})
    selected=[x for x in cc if x['file'].endswith('/usb_acm.c') or x['file'].endswith('/controller_main.c')]
    standards={pathlib.Path(x['file']).name:(re.findall(r'(?:^|\s)-std=([^\s]+)',x['command']) or ['compiler_default'])[-1] for x in selected}
    cmake_compiler=next(elf_path.parent.parent.glob('CMakeFiles/*/CMakeCCompiler.cmake'));compiler_text=cmake_compiler.read_text()
    defaults={'standard':re.search(r'set\(CMAKE_C_STANDARD_COMPUTED_DEFAULT "([^"]+)"\)',compiler_text).group(1),'extensions':re.search(r'set\(CMAKE_C_EXTENSIONS_COMPUTED_DEFAULT "([^"]+)"\)',compiler_text).group(1)}
    if standards.get('usb_acm.c')!='c11':errors.append({'code':'acm_not_explicit_c11','fixture':i,'standards':standards})
    if standards.get('controller_main.c')!='c11':errors.append({'code':'fixture_main_not_explicit_c11','severity':'contract_gap','fixture':i,'standards':standards,'actual_default':defaults,'evidence':identity(cmake_compiler)})
    res=json.loads(pathlib.Path(row['artifacts']['resources']['path']).read_text());bud=json.loads(pathlib.Path(row['artifacts']['budget']['path']).read_text());ret=json.loads(pathlib.Path(row['artifacts']['retention']['path']).read_text())
    if res.get('status')!='passed' or res.get('violations'):errors.append({'code':'resource_budget_not_passed','fixture':i})
    results.append({'assembly':row['assembly'],'part':row['part'],'backend':row['backend'],'artifacts':artifacts,'required_functions':retained,'caller_owned_context':context,'context_is_defined_static_writable_storage':bool(valid_context),'nm':{'argv':[str(nm),'--defined-only','--print-size',str(elf_path)],'returncode':p.returncode,'stdout':p.stdout,'stdout_sha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'stderr':p.stderr},'compile_commands_for_acm_and_main':selected,'standards':standards,'all_c_translation_units_explicit_c11':not c11_failures,'c_translation_unit_count':len(c_units),'recorded_compiler_source_count':len(row['compile_sources']),'recorded_compiler_dependency_count':len(row['compiler_dependencies']),'current_recorded_compiler_inputs_match':not dep_mismatches,'absolute_whole_fixture_resources':{'flash_loaded':res['metrics']['flash']['loaded_bytes'],'ram_reserved':{k:v['reserved_bytes'] for k,v in res['metrics']['ram'].items()},'msp':res['metrics']['reservations']['msp']['bytes'],'heap':res['metrics']['reservations']['heap']['bytes']},'authored_budget':bud,'provider_retention_face_count':row['face_count'],'provider_retention_method_count':row['method_count']})
# Fresh actual UART reference and instrumented images share the USB source freeze.
u=json.loads((U/'execution.json').read_text());excluded=[]
source_equal=m['source_before']==u['platform_source_before']
if u.get('status')!='passed' or len(u.get('images',[]))!=4:errors.append({'code':'fresh_uart_not_four_passes'})
if not source_equal:errors.append({'code':'usb_uart_full_source_identity_differs'})
if {(x['family'],x['variant']) for x in u['images']}!={('h743','reference'),('h743','instrumented'),('u575','reference'),('u575','instrumented')}:errors.append({'code':'uart_variant_inventory_differs'})
for row in u['images']:
    for k in ['elf','bin','map','compiler_inputs']:check(row[k],'fresh_uart.'+row['family']+'.'+row['variant']+'.'+k)
    elf_path=pathlib.Path(row['elf']['path']);elf=Elf32(elf_path.read_bytes());forbidden=[s for s in elf.defined_symbols if s['name'].startswith('nx_usb_acm_') or s['name']=='s_nx_acm']
    if forbidden:errors.append({'code':'acm_present_in_uart_image','family':row['family'],'variant':row['variant'],'symbols':forbidden})
    p=subprocess.run([str(nm),'--defined-only','--print-size',str(elf_path)],capture_output=True,text=True)
    if p.returncode or re.search(r'\b(?:nx_usb_acm_\w+|s_nx_acm)\b',p.stdout):errors.append({'code':'uart_nm_exclusion_failed','family':row['family'],'variant':row['variant'],'returncode':p.returncode})
    c=pathlib.Path(row['compiler_inputs']['path']);inputs=json.loads(c.read_text());diff=[]
    for inp in inputs:
        ok,actual=check(inp,'fresh_uart.compiler_input',err=False)
        if not ok:diff.append({'expected':inp,'actual':actual})
    if diff:errors.append({'code':'fresh_uart_current_compiler_input_mismatch','family':row['family'],'variant':row['variant'],'mismatches':diff})
    commands=elf_path.parent.parent/'compile_commands.json';cc=json.loads(commands.read_text());acm_units=[x for x in cc if x['file'].endswith('/usb_acm.c')]
    c_units=[x for x in cc if x['file'].endswith('.c')];c11_failures=[x for x in c_units if re.findall(r'(?:^|\s)-std=([^\s]+)',x['command'])!=['c11']]
    variant_main=[x for x in cc if x['file'].endswith('/main.c') and 'fifo_acquisition_'+row['variant']+'.dir/' in x.get('output','')]
    if c11_failures or len(variant_main)!=1:errors.append({'code':'uart_main_or_units_not_c11','family':row['family'],'variant':row['variant'],'main_commands':variant_main,'non_c11_commands':c11_failures})
    res=row['resources']
    if res.get('status')!='passed' or res.get('violations'):errors.append({'code':'uart_resource_budget_failed','family':row['family'],'variant':row['variant']})
    excluded.append({'family':row['family'],'variant':row['variant'],'elf':identity(elf_path),'bin':identity(pathlib.Path(row['bin']['path'])),'map':identity(pathlib.Path(row['map']['path'])),'compiler_inputs_manifest':identity(c),'compile_commands':identity(commands),'recorded_compiler_input_count':len(inputs),'current_recorded_compiler_inputs_match':not diff,'current_input_mismatches':diff,'forbidden_defined_acm_symbols':forbidden,'usb_acm_translation_units_listed_in_cmake_graph':acm_units,'c_translation_unit_count':len(c_units),'all_c_translation_units_explicit_c11':not c11_failures,'variant_main_commands':variant_main,'nm':{'argv':[str(nm),'--defined-only','--print-size',str(elf_path)],'returncode':p.returncode,'stdout':p.stdout,'stdout_sha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'stderr':p.stderr},'absolute_whole_fixture_resources':{'flash_loaded':res['metrics']['flash']['loaded_bytes'],'ram_reserved':{k:v['reserved_bytes'] for k,v in res['metrics']['ram'].items()},'msp':res['metrics']['reservations']['msp']['bytes'],'heap':res['metrics']['reservations']['heap']['bytes']},'scope':'Fresh actual IO15 UART reference/instrumented ELF with the same complete recorded platform before-source identity as the six explicit-C11 USB links. Optional archive listed in CMake compile_commands does not imply its symbols are retained in the UART ELF.'})
limitations.append({'code':'development_source_scope','detail':'All10 images bind recorded baseHEAD7c0d7775 dirty/sourcefreeze659ea6d0; no clean committed candidate, ordinary empty-firmware image, runtime USB enumeration, physical HIL, timing or dynamic stack qualification is claimed.'})
report={'schema_version':1,'kind':'independent_usb_acm_arm_retention_review','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'matrix':matrix_identity,'matrix_source':m['source_before'],'matrix_source_inputs_stable':m['source_inputs_stable'],'matrix_tools_stable':m['tools_stable'],'reviewed_nm_tool':identity(nm),'six_fixture_retention_status':'passed' if not any(x['code'] in ['required_function_not_retained','caller_context_not_retained','nm_failed','nm_function_not_text','nm_context_not_data'] for x in errors) else 'failed','whole_fixture_exact_c11_status':'failed' if any(x['code']=='fixture_main_not_explicit_c11' or x['code'] in ['usb_translation_units_not_c11','uart_main_or_units_not_c11','acm_not_explicit_c11'] for x in errors) else 'passed','fixtures':results,'existing_uart_execution':identity(U/'execution.json'),'existing_uart_source':u['platform_source_before'],'existing_uart_exclusion':excluded,'usb_uart_recorded_platform_source_identity_equal':source_equal,'four_uart_c11_and_acm_exclusion_status':'passed' if len(excluded)==4 and not any(x['code'].startswith(('uart_','fresh_uart_','acm_present_in_uart','usb_uart_')) for x in errors) else 'failed','resource_interpretation':'These are absolute full USB fixture costs, including provider/OS/startup, Control, Descriptors, ACM/context and main scratch values. No isolated ACM size/stack/timing delta is inferred. No runtime enumeration/HIL/clean-candidate qualification is established.','limitations':limitations,'errors':errors,'primary_or_index_modified':False,'compilation_or_test_suite_executed':False,'reviewer_peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
with (A/'independent-retention-review.json').open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'report':identity(A/'independent-retention-review.json'),'retention_status':report['six_fixture_retention_status'],'exact_c11_status':report['whole_fixture_exact_c11_status'],'errors':len(errors),'uart_references':len(excluded),'contexts':[r['caller_owned_context']['size'] for r in results],'resource_totals':[r['absolute_whole_fixture_resources'] for r in results]},sort_keys=True))
