from pathlib import Path
import ast, difflib, hashlib, json, re, sys, textwrap
sys.dont_write_bytecode = True
root = Path('/tmp/nexus-quality-20261019')
out = Path('/tmp/nexus-io-next-docs-20261020/ack-po')
potroot = Path('/tmp/nexus-io-next-ack-pot-20261020/gettext')
sys.path.insert(0, str(root))
from tools.documentation.sphinx_ext import read_catalog

def identity(p):
    return {'path': str(p), 'size': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}

def mid(block):
    value = None
    for line in block.splitlines():
        if line.startswith('msgid '):
            value = ast.literal_eval(line[6:])
        elif line.startswith('msgstr '):
            return value
        elif value is not None and line.startswith('"'):
            value += ast.literal_eval(line)
    return value

def quote(value):
    parts = textwrap.wrap(value, width=72, replace_whitespace=False,
                          drop_whitespace=False, break_long_words=False,
                          break_on_hyphens=False)
    return '""\n' + '\n'.join(json.dumps(v, ensure_ascii=False) for v in parts)

execution = json.loads((potroot.parent / 'execution.json').read_text())
assert {x['name']: x['exit_code'] for x in execution['steps']} == {
    'doxygen': 0, 'gettext': 0}
delta = json.loads((out / 'actual-delta.json').read_text())
english_usb = (
    'Only after the matching outer acquire SUCCESS, meaning a real STATUS ACK, '
    'does the component commit approved software intent and update '
    '`committed_epoch`. New SETUP/reset/cancel drains under the existing '
    'packetizer rules without revoking borrows; a terminal outcome without '
    'outer SUCCESS does not commit. Successful cancellation only requests '
    'drain: if the matching STATUS still receives a real ACK before endpoint '
    'withdrawal, outer acquire SUCCESS still commits the approved original '
    'epoch intent. An already acquired STATUS ACK is not revoked by later '
    'SETUP/reset, closing or a failed state read; an immediately following '
    'GET returns the newly committed line coding. Whether reset restores '
    'initial class state is separate external owner policy. Each '
    '`nx_usb_acm_step` advances the existing packetizer at most once, '
    'preserving the per-step bounds of one service, one state read and one '
    'packet action. The external executor must continue progress and retain '
    'all storage during cancellation, timeout, suspend and shutdown. OUT0 '
    'quarantine still requires the external controller owner to authorize '
    'real complete stop; the component does not stop it automatically.'
)
chinese_api = (
    'SUCCESS 请求排空，或丢弃尚未准入的零数据意图；身份过期返回 STATE。'
    '取消仅请求排空。在取消前或取消期间 acquire 到的匹配 STATUS ACK '
    '仍由 packetizer 优先处理；step 在 acquire 返回 outer SUCCESS '
    '时提交已批准的原 epoch 意图，后续 epoch 不撤销该提交。'
)
rows = []
pairs = []
patches = []
for doclang, expected in delta.items():
    lang, doc = doclang.split('/', 1)
    rel = f'docs/locale/{lang}/LC_MESSAGES/{doc}.po'
    before = out / 'before' / lang / (doc + '.po')
    current = root / rel
    assert current.read_bytes() == before.read_bytes(), rel
    assert identity(before)['sha256'] == expected['before_sha256']
    old = before.read_text()
    oldheader, oldmessages, oldfuzzy = read_catalog(before)
    assert not oldfuzzy and all(oldmessages.values())
    pot = potroot / (doc + '.pot')
    _, required, _ = read_catalog(pot)
    added = [k for k in required if k not in oldmessages]
    removed = [k for k in oldmessages if k not in required]
    assert added == expected['added'] and removed == expected['removed']
    assert len(added) == len(removed) == 1
    source = root / 'docs' / (doc + '.md')
    sourcehash = identity(source)['sha256']
    assert sourcehash == expected['source_sha256']
    value = (english_usb if doc == 'design/usb-device' else
             added[0] if lang == 'en' else chinese_api)
    blocks = old.split('\n\n')
    replaced = 0
    for index, block in enumerate(blocks):
        key = mid(block)
        if key == removed[0]:
            trailing = '\n' if block.endswith('\n') else ''
            blocks[index] = ('msgid ' + quote(added[0]) + '\nmsgstr ' +
                             quote(value) + trailing)
            replaced += 1
        elif key == '':
            block = re.sub(r'X-Nexus-Source-SHA256: [0-9a-f]{64}',
                           'X-Nexus-Source-SHA256: ' + sourcehash, block)
            blocks[index] = block.replace('X-Nexus-Reviewed: true',
                                          'X-Nexus-Reviewed: false')
    assert replaced == 1
    text = '\n\n'.join(blocks)
    target = out / 'files' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
    header, messages, fuzzy = read_catalog(target)
    assert set(messages) == set(required)
    assert all(messages.values()) and not fuzzy
    assert header['X-Nexus-Reviewed'] == 'false'
    assert header['X-Nexus-Source-SHA256'] == sourcehash
    stable = set(oldmessages) & set(messages)
    assert all(oldmessages[k] == messages[k] for k in stable)
    oldblocks = {mid(b): b for b in old.split('\n\n') if mid(b)}
    newblocks = {mid(b): b for b in text.split('\n\n') if mid(b)}
    assert all(oldblocks[k] == newblocks[k] for k in stable)
    patches += list(difflib.unified_diff(old.splitlines(True),
                                       text.splitlines(True),
                                       fromfile='a/' + rel,
                                       tofile='b/' + rel))
    pairs.append({'path': rel, 'language': lang,
                  'msgid': added[0], 'msgstr': value,
                  'supersedes_msgid': removed[0]})
    rows.append({'path': rel, 'source': identity(source),
                 'POT': identity(pot), 'before': identity(before),
                 'draft': identity(target), 'required_messages': len(required),
                 'added': 1, 'removed': 1,
                 'unchanged_message_blocks': len(stable),
                 'unchanged_message_blocks_byte_identical': True,
                 'exact_required_keyset': True, 'no_empty_or_fuzzy': True,
                 'review_flag': 'false'})
other = []
for doc in ['design/uart-fifo', 'design/h743-flash-ram']:
    p = root / 'docs/locale/zh_CN/LC_MESSAGES' / (doc + '.po')
    pot = potroot / (doc + '.pot')
    source = root / 'docs' / (doc + '.md')
    header, messages, fuzzy = read_catalog(p)
    _, required, _ = read_catalog(pot)
    assert set(messages) == set(required) and all(messages.values()) and not fuzzy
    assert header['X-Nexus-Source-SHA256'] == identity(source)['sha256']
    other.append({'path': str(p.relative_to(root)), 'catalog': identity(p),
                  'source': identity(source), 'POT': identity(pot),
                  'required_messages': len(required),
                  'review_flag': header['X-Nexus-Reviewed'],
                  'exact_required_keyset': True, 'no_empty_or_fuzzy': True,
                  'read_only': True})
(out / 'actual-pairs.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')
(out / 'ack-po.patch').write_text(''.join(patches))
report = {
    'scope': 'Three external-only PO drafts. No primary, index, HEAD or review-flag admission writes.',
    'actual_POT_execution': identity(potroot.parent / 'execution.json'),
    'source_snapshot': execution['source'],
    'catalogues': rows, 'other_two_design_catalogs_read_only': other,
    'pairs': identity(out / 'actual-pairs.json'),
    'patch': identity(out / 'ack-po.patch'),
    'errors': [],
    'pending': ['Independent actual-POT bilingual semantics review',
                'Root patch application and review-flag admission'],
    'qualification': False,
}
(out / 'prepared-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
