import hashlib,json,os,resource,sys,time
from pathlib import Path
root=Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(root))
from tools.dev.process import run
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
names=['tests/contracts/test_source_sdk.py','cmake/package/package_source_sdk.py']
source=[]
for name in names:
 p=root/name;d=out/'source'/name;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(p.read_bytes());source.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
command=[str(root/'.venv/bin/python'),'-B','-m','unittest','-v','tests.contracts.test_source_sdk.SourceSDKSelectionTests']
start=time.monotonic();r=run(command,cwd=root,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=300,log=out/'complete.raw',stage='SDK-required-source-omissions')
report={'command':command,'source':source,'exit_code':r.returncode,'duration_s':time.monotonic()-start,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'source_stable':all(hashlib.sha256((root/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in source),'physical_status':'not_executed','qualification':False}
(out/'execution.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));print(r.stderr[-5000:]);raise SystemExit(r.returncode)
