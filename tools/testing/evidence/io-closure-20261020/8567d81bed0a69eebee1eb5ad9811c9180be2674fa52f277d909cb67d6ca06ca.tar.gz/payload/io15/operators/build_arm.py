"""Run the two real fixture graphs, retaining all commands and actual bytes."""
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path('/tmp/nexus-quality-20261019')
APP = Path('/tmp/nexus-examples-completion-20261020/apps/uart_fifo_acquisition')
sys.path.insert(0, str(ROOT))
from scripts.ci.provider_assemblies import (Recorder, dependency_paths,
    source_inputs, verify_inputs)
from tools.configure.configure import resolve_ir
from tools.evidence.common import atomic_json, file_identity, verify_file_identity
from tools.evidence.identity import git_source

# Qualification guards reject inherited Git overrides; this external operator
# selects a clean child execution environment without changing that guard.
for name in list(os.environ):
    if name.startswith(('GIT_', 'GTEST_', 'CTEST_')):
        os.environ.pop(name)

def examples_development_source():
    """Describe WIP bytes, without admitting an unpinned SDK consumer."""
    repository = APP.parent.parent
    def git(*arguments):
        return subprocess.check_output(['git', '-C', str(repository),
            *arguments], text=True).strip()
    return {'commit':git('rev-parse','HEAD'),
        'tree':git('rev-parse','HEAD^{tree}'),
        'status':git('status','--porcelain','--untracked-files=all'),
        'actual_external_sdk':git('-C',str(repository/'external/nexus'),
                                  'rev-parse','HEAD'),
        'declared_lock':json.loads((repository/'dependencies/nexus.lock.json').read_text()),
        'scope':'uncommitted public-only app linked against explicit primary source; '
                'not an admitted pinned or installed SDK consumer'}

output = Path('/tmp/nexus-io15-execute-20261020/arm')
continuing = '--continue-existing' in sys.argv
previous = None
if continuing:
    previous = json.loads((output/'execution.json').read_text())
    assert previous['status']=='failed' and len(previous['images'])==2
    assert {r['family'] for r in previous['images']}=={'h743'}
    saved=output/'execution-failed-r5.json'
    saved.write_bytes((output/'execution.json').read_bytes())
else:
    output.mkdir(exist_ok=False)
environment = dict(os.environ)
environment.update(PATH='/tmp/nexus-quality-20261019/.venv/bin:/tmp/nexus-quality-arm/bin:/usr/local/bin:/usr/bin:/bin',
    PYTHONDONTWRITEBYTECODE='1', NEXUS_BUILD_JOBS='1', CMAKE_BUILD_PARALLEL_LEVEL='1')
recorder = Recorder(output/'commands', ROOT, timeout=300, env=environment)
if previous:
    recorder.commands=previous['commands']
fixtures = []
project = ROOT/'tests/contracts/uart_fifo_acquisition'
for family in ('h743','u575'):
    assembly = ROOT/f'cmake/package/verification/io_evolution/{family}-uart-fifo.toml'
    navigation = {}
    resolved = resolve_ir(assembly, ROOT, input_paths=navigation).to_dict()
    fixtures.append({'assembly': str(assembly), 'project': str(project),
        'resolved': resolved,
        'inputs': [file_identity(Path(p)) for p in navigation.values()]})
frozen = source_inputs(ROOT, fixtures)
frozen += [file_identity(p) for p in sorted(APP.iterdir()) if p.is_file()]
def verify_actual_inputs(rows):
    # These two existing identity APIs have deliberately distinct size keys.
    # Never rewrite the original evidence record to force equality.
    for row in rows:
        if 'size' in row:
            verify_file_identity(row)
        else:
            verify_inputs([row])
report = {'kind':'io15_actual_fixture_ARM_execution','status':'running',
    'platform_source_before':git_source(ROOT),
    'examples_source_before':examples_development_source(),
    'inputs':frozen, 'commands':recorder.commands,
    'software_qualified':False,'physical_status':'not_executed','images':[]}
if previous:
    assert previous['inputs']==frozen
    assert previous['platform_source_before']==report['platform_source_before']
    assert previous['examples_source_before']==report['examples_source_before']
    for row in previous['images']:
        for key in ('elf','bin','map','compiler_inputs'):
            verify_file_identity(row[key])
        verify_actual_inputs(json.loads(Path(row['compiler_inputs']['path']).read_text()))
    verify_actual_inputs(previous['inputs'])
    report['images']=previous['images']
    report['continuation']={'original_attempt':file_identity(output/'execution-failed-r5.json'),
        'reason':'External operator used arch bytes identity comparison on common size identities; '
                 'actual H743 source/artifact bytes unchanged and independently revalidated; '
                 'no H743 compilation repeated solely for metadata correction.'}
atomic_json(output/'execution.json',report)
started=time.monotonic()
try:
    for fixture,family in zip(fixtures,('h743','u575')):
        if previous and family=='h743':
            continue
        build=output/family
        recorder.execute(['cmake','-S',str(project),'-B',str(build),'-G','Ninja',
            '-DCMAKE_TOOLCHAIN_FILE='+str(ROOT/'cmake/toolchains/arm-gcc.cmake'),
            '-DCMAKE_BUILD_TYPE=Release','-DNEXUS_SOURCE='+str(ROOT),
            '-DNEXUS_ASSEMBLY_FILE='+fixture['assembly'],
            '-DFIFO_ACQUISITION_APP_DIR='+str(APP),
            '-DPython3_EXECUTABLE='+sys.executable,
            '-DNEXUS_COMPILER_CACHE=OFF'],family+'-configure')
        recorder.execute(['flock','/tmp/nexus-platform-compiler.lock',
            'cmake','--build',str(build),'--target','fifo_acquisition_reference',
            'fifo_acquisition_instrumented','--parallel','1'],family+'-build')
        dependencies=recorder.execute(['ninja','-C',str(build),'-t','deps'],
                                      family+'-dependencies')
        graph=[file_identity(p) for p in dependency_paths(dependencies,build)]
        atomic_json(build/'compiler-inputs.json',graph)
        for variant in ('reference','instrumented'):
            elf=build/f'bin/fifo_acquisition_{variant}.elf'
            recorder.execute(['arm-none-eabi-objdump','-drwC',str(elf)],
                             family+'-'+variant+'-objdump')
            recorder.execute([sys.executable,'-B','tools/measurement/retention.py',
                '--elf',str(elf),'--bindings',str(build/'nexus/generated/bindings.c'),
                '--resolved',str(build/'nexus/generated/resolved.json'),
                '--output',str(build/f'{variant}-retention.json')],
                family+'-'+variant+'-retention')
            facts=json.loads(elf.with_suffix('.resources.json').read_text())
            assert facts['status']=='passed' and not facts['violations']
            report['images'].append({'family':family,'variant':variant,
                'elf':file_identity(elf),'bin':file_identity(elf.with_suffix('.bin')),
                'map':file_identity(elf.with_suffix('.map')),
                'resources':facts,'compiler_inputs':file_identity(build/'compiler-inputs.json')})
        verify_actual_inputs(graph)
        verify_actual_inputs(frozen)
        atomic_json(output/'execution.json',report)
    assert report['platform_source_before']==git_source(ROOT)
    assert report['examples_source_before']==examples_development_source()
    report['status']='passed'
except Exception as error:
    report['status']='failed'
    report['failure']=str(error)
finally:
    report['duration_s']=time.monotonic()-started
    report['peak_child_rss_kib']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    atomic_json(output/'execution.json',report)
print(json.dumps({key:report[key] for key in ('status','duration_s','peak_child_rss_kib')},indent=2))
if report.get('failure'): print(report['failure'])
raise SystemExit(report['status']!='passed')
