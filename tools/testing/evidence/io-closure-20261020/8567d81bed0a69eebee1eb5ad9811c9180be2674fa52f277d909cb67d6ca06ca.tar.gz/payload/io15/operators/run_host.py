"""Execute actual draft production C and full Google cases; never qualify HIL."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/tmp/nexus-quality-20261019')
sys.path.insert(0, str(ROOT))
from tools.dev.process import run


def identity(path):
    path = Path(path)
    return {'path': str(path), 'size': path.stat().st_size,
            'sha256': hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--test', required=True, type=Path)
    parser.add_argument('--header', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    source = args.source.absolute()
    test = args.test.absolute()
    include = (args.header.absolute().parent if args.header else source.parent)
    libs = ROOT / 'build/native-debug/lib'
    google = ROOT / 'ext/googletest'
    common = ['-I' + str(include)]
    common += ['-I' + str(ROOT / name / 'include')
               for name in ('core', 'arch', 'io')]
    inputs = [source, test, include / 'workload.h']
    names = ['gmock_main', 'gmock', 'gtest', 'nexus_io', 'nexus_core',
             'nexus_arch']
    inputs += [libs / ('lib' + name + '.a') for name in names]
    frozen = [identity(path) for path in inputs]
    (args.output / 'inputs.json').write_text(json.dumps(frozen, indent=2) + '\n')
    (args.output / 'workload.c').write_bytes(source.read_bytes())
    (args.output / 'workload.h').write_bytes((include / 'workload.h').read_bytes())
    (args.output / 'test.cpp').write_bytes(test.read_bytes())
    environment = os.environ.copy()
    environment.update(PYTHONDONTWRITEBYTECODE='1', NEXUS_BUILD_JOBS='1',
                       CMAKE_BUILD_PARALLEL_LEVEL='1')
    steps = []

    def execute(name, command, timeout=300):
        before = time.monotonic()
        result = run(command, cwd=args.output, env=environment,
                     timeout=timeout, stage=name,
                     log=args.output / (name + '.raw'))
        steps.append({'name': name, 'argv': command,
                      'exit_code': result.returncode,
                      'duration_s': time.monotonic() - before})
        if result.returncode:
            print(result.stderr[-8000:])
        return result.returncode

    commands = [
        ('compile-c', ['cc', '-std=c11', '-O0', '-g', '-Wall', '-Wextra',
                       '-Werror', *common, '-c', str(source), '-o', 'workload.o']),
        ('compile-test', ['c++', '-std=c++17', '-O0', '-g', '-Wall', '-Wextra',
                          '-Werror', *common,
                          '-isystem', str(google / 'googletest/include'),
                          '-isystem', str(google / 'googlemock/include'),
                          '-c', str(test), '-o', 'test.o']),
        ('link', ['c++', 'workload.o', 'test.o', '-Wl,--start-group',
                  *[str(path) for path in inputs[3:]], '-Wl,--end-group',
                  '-pthread', '-o', 'contract']),
    ]
    for name, command in commands:
        # The external flock serializes every C/C++ compiler invocation.
        if execute(name, ['flock', '/tmp/nexus-platform-compiler.lock',
                          *command]):
            break
    else:
        execute('google-discovery', [str(args.output / 'contract'),
                                     '--gtest_list_tests'])
        execute('google-complete', [str(args.output / 'contract'),
            '--gtest_output=xml:' + str(args.output / 'google.xml')])
    report = {'kind': 'io15_actual_draft_host_execution', 'steps': steps,
              'source_head': subprocess.check_output(['git', '-C', str(ROOT),
                  'rev-parse', 'HEAD'], text=True).strip(),
              'inputs_stable': frozen == [identity(path) for path in inputs],
              'peak_child_rss_kib': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
              'software_qualified': False, 'physical_status': 'not_executed'}
    xml = args.output / 'google.xml'
    if xml.is_file():
        node = ET.parse(xml).getroot()
        report['google'] = {key: node.attrib.get(key)
                            for key in ('tests', 'failures', 'errors', 'disabled')}
        report['google']['actual_cases'] = len(node.findall('.//testcase'))
    (args.output / 'execution.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
    return int(any(step['exit_code'] for step in steps) or not report['inputs_stable'])


if __name__ == '__main__':
    raise SystemExit(main())
