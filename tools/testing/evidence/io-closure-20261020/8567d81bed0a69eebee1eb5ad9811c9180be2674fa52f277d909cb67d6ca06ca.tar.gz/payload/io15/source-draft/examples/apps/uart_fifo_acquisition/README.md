# UART FIFO acquisition / UART FIFO 采集

This opt-in example supplies actual bounded traffic to an already selected byte
UART. The standalone Nexus test fixture builds these same public-only sources
for the exact H743 USART3 and U575 USART1 FIFO references. It is independent of
the normal `platform_reference` application. No private provider or vendor header
is copied into this repository, and no scheduler or worker is created.

本示例显式选入后，在已选定的 byte UART 上产生真实、有界的收发负载。Nexus 的
独立测试工程直接编译这里的公开 API 源码，面向精确的 H743 USART3、U575 USART1
FIFO 参考装配；它不替代普通 `platform_reference`。不复制私有 provider 或厂商头，
也不创建 scheduler 或 worker。

## Execution and ownership / 执行与所有权

One privileged unmasked task calls each step. A step performs at most one UART
service, one bounded RX read and one TX submission. RX continues during an
ACTIVE TX loan. Each accepted 32-byte TX block has a session and sequence number;
the next payload is prepared only after acquire-observed SETTLED and result
consumption. OVERFLOW retains its valid RX prefix and diagnostic while traffic
continues. Other fatal RX errors close admission without releasing the TX loan.

单个未屏蔽中断的特权任务调用每一步。每步至多执行一次 UART service、一次有界
RX read、一次 TX submit；TX ACTIVE 借用期间仍读 RX。每个已准入的 32 字节 TX
块带 session 和 sequence；只有 acquire 观察到 SETTLED 并取得结果后，才准备下一
payload。OVERFLOW 保留有效 RX 前缀和诊断并继续采集；其他致命 RX 错误关闭准入，
但不释放 TX 借用。

Window completion, cancel and timeout never revoke accepted bytes. The owner
continues bounded drain steps; late wire completion may permit a retained session
to close. Broken monotonic order prevents further task provider calls. A closed
UART is followed by explicit Platform cleanup, with at most 64 attempts and no
clock reads after cleanup starts. Only successful cleanup publishes
`g_fifo_platform_closed=1`; BUSY/IO exhaustion keeps static state alive. This
bounds calls per step and cleanup attempts, not total close time or WCET.

窗口结束、取消和超时都不撤销借用。owner 继续执行有界排空步骤，晚到的 wire
完成可能让保留中的会话关闭。单调时间倒退后不再调用 task provider。UART 关闭后
显式清理 Platform，最多尝试 64 次，清理开始后不再读取可能已被撤回的时钟。
只有清理成功才发布 `g_fifo_platform_closed=1`；BUSY／IO 耗尽后仍保留静态存储。
这里只限制每步调用及清理尝试次数，不证明整体关闭时间或 WCET。

## Arming and capture / 启动与采集

The station halts after BSS and Platform startup, while
`g_fifo_waiting_for_arm=1`. It writes a fresh nonzero
`g_fifo_station_control.session`, then `arm=0x46514631`, prepares the complete raw
capture and resumes. It must not halt or rewrite control while measuring.
Arming has both a nominal ten-second deadline and a one-million-poll cap; neither
poll counts nor nominal target ticks establish SI time. Invalid/stalled time
retains storage instead of attempting cleanup with a broken clock assumption.
There is no printf, second UART console, semihosting or implicit GPIO marker.

站点在 BSS 和 Platform 启动之后、`g_fifo_waiting_for_arm=1` 时 halt，先写 fresh
非零 `g_fifo_station_control.session`，再写 `arm=0x46514631`，准备完整原始采集后
resume。测量中不得 halt 或改控制。等待同时受名义十秒 deadline 和一百万次轮询
上限限制；轮询数及目标名义 tick 都不证明 SI 时间。时间无效或停滞时保留存储，
不使用损坏的时钟假设清理。没有 printf、第二 UART console、semihosting 或隐式
GPIO marker。

After provider and Platform join, the station exports exact ELF/DWARF-addressed
state and full timestamped bidirectional capture. Service times are task-step
boundary samples, not atomic provider-entry timestamps. The platform parser
`tools/hil/uart_fifo.py` binds device/raw/artifact identities but does not operate
equipment or qualify hardware. Four-column IRQ CSV values remain unverified
arithmetic candidates; wire edges, raw DWT and dispatch markers cannot supply an
unobserved IRQ assertion. Use the complete existing SOC-55 acquisition/admission
contract for a real measurement. Software-reference Board fixtures remain
unadmittable and physical HIL stays `not_executed`.

provider 与 Platform 都 join 后，站点按精确 ELF／DWARF 导出状态并保留完整、带时间
的双向采集。service 时间是任务 step 边界，不能冒充原子的 provider-entry 时间。
平台 `tools/hil/uart_fifo.py` 绑定设备、原始文件和产物身份，但不操作设备或建立
硬件资格。四列 IRQ CSV 仍只是未验证的算术候选；wire edge、raw DWT、dispatch
marker 都不能替代未观测的 IRQ assertion。真实测量使用既有完整 SOC-55 采集／准入
合同。software-reference Board 仍不能通过物理准入，实板 HIL 保持 `not_executed`。

The examples SDK Gitlink and lock must be updated together with real integration
evidence. A standalone developer compile or this application's tests cannot
qualify a different SDK source or an unexecuted physical setup.

examples 的 SDK Gitlink 和 lock 必须随真实集成证据一同更新。独立开发构建或这里
的测试不能为其他 SDK 源码或未执行的实板配置建立资格。
