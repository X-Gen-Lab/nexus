# UART FIFO raw parser integration draft

The generic station raw parser is a proposed platform tool at
`tools/hil/uart_fifo.py`. It does not read equipment, arm a target, flash, halt,
resume or establish station admission. The external workload and target snapshot
remain owned by the examples/station. No separate station repository is needed.

The reviewed 23 software-fixture contracts are retained. One new end-to-end CLI
contract runs the platform entry point with fresh valid fixture inputs, verifies
that IRQ capture remains unverified, and rejects a second write to the same
report without altering its bytes. Its first actual execution failed because the
old external-station `--nexus-source` parameter remained mandatory. The migrated
CLI locates the platform tools using the same script bootstrap as other HIL
commands, and the normal test import is `from tools.hil import uart_fifo`.

```sh
python tools/hil/uart_fifo.py \
    --context station/soc55-context.json \
    --device station/device-snapshot.json --irq-csv station/irq.csv \
    --rx-wire station/peer-wire.bin --tx-wire station/device-wire.bin \
    --elf build/exact/bin/fifo_acquisition_instrumented.elf \
    --resolved build/exact/nexus/generated/resolved.json \
    --wire-session 7 --ticks-per-second 1000000 \
    --first-tick 1 --last-tick 1000000 --origin external-capture \
    --report station/fresh-fifo-parse.json
```

Use each actual configuration report for artifact paths. Session, conversion rate
and capture endpoints above illustrate syntax. They are retained caller facts,
not observed calibration. A report destination must be fresh.

The four-column CSV supplies only arithmetic candidate intervals. Both
`software-fixture` and `external-capture` keep `irq_capture.status=unverified`
and `irq_capture.measurement_status=not_executed`. The result retains exact
rate/window, raw CSV identity, declared method and candidate intervals;
`samples` contains no `irq_latency`. Raw DWT pairs, wire edges and dispatch GPIO
markers cannot supply an unobserved IRQ assertion boundary. Actual assertion,
deterministic selected-dispatch association, complete capture/session/window
and loss facts still need the existing full SOC-55 acquisition and admission.

The device snapshot requires exact integer session identity, consumed request
counts, a joined provider/Platform and valid observed end. Its fixed 32-byte TX
sequence permits only one final partial or empty completed request. OVERFLOW is
retained as a diagnostic; an overflow-event count does not quantify lost bytes.
Service timestamps are task-step boundary timestamps in the target nominal
monotonic domain; independently calibrated SI timing is not established. The two
raw byte files alone do not prove that TX and RX overlapped in time.

Every result keeps software/hardware qualification false. This parser result is
not a physical_soc_hil record, a measure.py trace, complete SOC-55 acceptance,
clean candidate qualification or a physical measurement. Existing software-only
Board references remain unadmittable. IO15 implementation/qualification status
must stay open until its full original obligations are actually satisfied.

This draft modifies only external `/tmp` files. Final execution used the new
normal `tools.testing.test_uart_fifo` module: 24 passing stdlib tests, no skip.
The authored C workload and its actual ARM vector/wrapper/provider links were not
compiled or executed by this parser task. All such checks remain for root.
