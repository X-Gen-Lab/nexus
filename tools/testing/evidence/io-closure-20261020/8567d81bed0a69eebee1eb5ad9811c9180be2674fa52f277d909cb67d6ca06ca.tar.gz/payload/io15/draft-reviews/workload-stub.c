/**
 * \file            workload-stub.c
 * \brief           Linkable no-I/O RED baseline, never production behavior.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-20
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "workload.h"
#include <string.h>

nx_result_t fifo_acquisition_initialize(fifo_acquisition_t* state,
                                        const nx_uart_port_t* port,
                                        const fifo_acquisition_config_t* config,
                                        nx_time_us_t now) {
    if (state == NULL || config == NULL) {
        return NX_ERROR_INVALID;
    }
    memset(state, 0, sizeof(*state));
    state->port = port;
    state->config = *config;
    state->started = now;
    state->phase = FIFO_ACQUISITION_RUNNING;
    nx_request_initialize(&state->request.base);
    return NX_SUCCESS;
}

nx_result_t fifo_acquisition_close(fifo_acquisition_t* state,
                                   nx_time_us_t now) {
    (void)state;
    (void)now;
    return NX_SUCCESS;
}

nx_result_t fifo_acquisition_step(fifo_acquisition_t* state, nx_time_us_t now) {
    (void)state;
    (void)now;
    return NX_SUCCESS;
}

nx_result_t fifo_acquisition_join_platform(const fifo_acquisition_t* state,
                                           nx_result_t (*stop_platform)(void),
                                           uint32_t attempt_budget,
                                           uint32_t* attempts) {
    (void)state;
    (void)stop_platform;
    (void)attempt_budget;
    if (attempts != NULL) {
        *attempts = 0U;
    }
    return NX_SUCCESS;
}
