#!/usr/bin/env python3
"""Narrow operator check for actual no-marker FIFO IRQ fixture ELF links.

Uses maintained ELF-byte/Thumb decoders; unknown encodings/flows fail closed.
This checks a call boundary under AAPCS, not callee memory safety or execution.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
REVIEW = Path('/tmp/nexus-io15-execute-20261020/review')
LIMIT = 16 * 1024 * 1024
RETURN = 'incoming-LR'
FAMILIES = {
    'h743': ('stm32h743', 'h7', 'stm32h743xx.h', 'USART3', 39, 220),
    'u575': ('stm32u575', 'u5', 'stm32u575xx.h', 'USART1', 61, 308),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity(path):
    path = Path(path).resolve(strict=True)
    require(path.is_file() and 0 < path.stat().st_size <= LIMIT,
            'bounded nonempty regular input required: ' + str(path))
    data = path.read_bytes()
    return {'path': str(path), 'size': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def bytes_at(elf, address, size, *, readonly=False):
    rows = [row for row in elf.sections if row['kind'] != 8 and
            row['flags'] & 2 and row['address'] <= address <
            address + size <= row['address'] + row['size']]
    require(len(rows) == 1 and (not readonly or not rows[0]['flags'] & 1),
            'unique allocated file-backed bytes required')
    row = rows[0]
    offset = row['offset'] + address - row['address']
    return elf.data[offset:offset + size]


def symbol(elf, name, *, function=False, strong=False):
    rows = [(i, row) for i, row in enumerate(elf.defined_symbols)
            if row['name'] == name]
    require(len(rows) == 1, 'unique actual ELF symbol required: ' + name)
    index, row = rows[0]
    require(row['size'] > 0, 'nonempty symbol required: ' + name)
    if function:
        require(row['type'] == 2 and row['value'] & 1,
                'nonempty Thumb function required: ' + name)
    if strong:
        require(row['binding'] == 1, 'strong global required: ' + name)
    return index, row


def decoded_function(elf, name, raw, decode_symbol):
    index, row = symbol(elf, name, function=True, strong=True)
    first = row['value'] & ~1
    last = first + row['size']
    selected = []
    for line in raw.splitlines(keepends=True):
        match = re.match(rb'\s*([0-9a-f]+):', line)
        if match and first <= int(match[1], 16) < last:
            selected.append(line)
    result = decode_symbol(elf, index, b''.join(selected))
    require(len(result['instructions']) <= 256, 'function scope too large')
    return result


def walk(elf, decoded, initial_r0, expected_events, targets, probe_address,
         thumb_decode, constant_effect, *, entry_r0=None):
    """Finite acyclic CFG + exact argument constants, with ABI call clobbers.

    PUSH save slots are retained across calls under the stated AAPCS boundary.
    Other local spill slots become Unknown at calls, not inferred preserved.
    """
    code = {row['address']: row for row in decoded['instructions']}
    entry = [None] * 16
    entry[0], entry[14] = entry_r0, RETURN
    for register in range(4, 12):
        entry[register] = 'incoming-r' + str(register)
    pending = [(decoded['address'], tuple(entry), 0, {}, set(), (), ())]
    returns, observations, visits = [], {}, 0
    while pending:
        pc, values, depth, stack, saves, events, path = pending.pop()
        visits += 1
        require(visits <= 2048, 'CFG exploration bound exceeded')
        require(pc in code and pc not in path,
                'unknown target, literal execution or CFG loop')
        row = code[pc]
        encoded = bytes.fromhex(row['encoding'])
        op = thumb_decode(pc, encoded, bridge=False)
        require(op.it_count == 0, 'predicated IT scope needs separate review')
        new_values = list(values)
        new_stack, new_saves = dict(stack), set(saves)
        new_depth = depth
        next_pc = pc + len(encoded)
        targets_next = [next_pc]
        event = None
        terminal = False

        if op.kind == 'push':
            new_depth += op.delta
            require(0 <= new_depth <= 4096, 'invalid static push depth')
            for i, register in enumerate(op.registers):
                slot = -new_depth + 4 * i
                new_stack[slot] = values[register]
                if register in tuple(range(4, 12)) + (14,):
                    new_saves.add(slot)
        elif op.kind == 'pop':
            for i, register in enumerate(op.registers):
                slot = -depth + 4 * i
                require(slot in new_stack, 'pop has no matched saved slot')
                value = new_stack.pop(slot)
                new_saves.discard(slot)
                if register == 15:
                    require(value == RETURN, 'return PC is not saved incoming LR')
                    terminal = True
                else:
                    new_values[register] = value
            new_depth += op.delta
        elif op.kind == 'return':
            require(values[14] == RETURN, 'BX return LR provenance missing')
            terminal = True
        elif op.kind in ('call', 'branch') and op.target not in code:
            require(op.target in targets, 'unreviewed external transfer')
            event, name = targets[op.target]
            require(len(events) < len(expected_events) and
                    event == expected_events[len(events)],
                    'skipped/repeated/out-of-order probe or real transfer')
            expected_r0 = initial_r0 if event == 'real' else probe_address
            require(values[0] == expected_r0,
                    'selected state or probe argument was rebound/unknown')
            events += (event,)
            if op.kind == 'branch':
                require(depth == 0 and values[14] == RETURN,
                        'tail transfer has unclosed frame or wrong LR')
                terminal = True
            else:
                # AAPCS guarantees only these caller-saved registers clobbered.
                for register in (0, 1, 2, 3, 12, 14):
                    new_values[register] = None
                for slot in set(new_stack) - new_saves:
                    new_stack[slot] = None
            name = str(name)
        elif op.kind == 'branch':
            require(op.target > pc, 'backward transfer outside small CFG scope')
            targets_next = [op.target]
        elif op.kind == 'conditional':
            require(op.target > pc, 'backward conditional outside small scope')
            targets_next.append(op.target)
        else:
            require(op.kind == 'plain', 'unsupported control instruction')
            require(not op.store_bases,
                    'non-stack store outside this wrapper scope')
            # This maintained rule derives constants from the admitted bytes,
            # never from objdump's printed register operands or mnemonics.
            new_values, _ = constant_effect(
                pc, encoded, op, values,
                lambda address, size: int.from_bytes(
                    bytes_at(elf, address, size, readonly=True), 'little'))
            new_values = list(new_values)
            if op.stack_store:
                offset, size = op.stack_store
                first = -depth + offset
                require(-depth <= first and first + size <= 0,
                        'store leaves the current frame')
                for slot in list(new_stack):
                    if first < slot + 4 and slot < first + size:
                        require(slot not in new_saves,
                                'local store overwrites a saved ABI register')
                        new_stack[slot] = None
                if size == 4 * len(op.stack_values):
                    for i, register in enumerate(op.stack_values):
                        new_stack[first + 4 * i] = values[register]
            if op.stack_load:
                offset, size, registers = op.stack_load
                first = -depth + offset
                require(-depth <= first and first + size <= 0,
                        'load leaves the current frame')
                require(size == 4 * len(registers),
                        'non-word state stack load outside scope')
                for i, register in enumerate(registers):
                    new_values[register] = new_stack.get(first + 4 * i)
            new_depth += op.delta
            if op.delta < 0:
                for slot in list(new_stack):
                    if slot < -new_depth:
                        del new_stack[slot]
                        new_saves.discard(slot)
        require(0 <= new_depth <= 4096, 'invalid frame depth')
        observations[pc] = {'address': pc, 'encoding': row['encoding'],
                            'kind': op.kind, 'target': op.target,
                            'r0_before': values[0], 'event': event}
        if terminal:
            require(new_depth == 0 and events == expected_events,
                    'return/tail path lacks exactly the required transfers')
            require(all(new_values[r] == entry[r] for r in range(4, 12)),
                    'callee-saved wrapper/stub register not restored')
            returns.append({'terminal_address': pc, 'events': list(events)})
        else:
            for destination in targets_next:
                pending.append((destination, tuple(new_values), new_depth,
                                dict(new_stack), set(new_saves), events,
                                path + (pc,)))
    require(returns, 'no real return/tail path proved')
    return {'symbol': decoded['symbol'], 'decoded_bytes': decoded['size'],
            'return_paths': returns, 'exploration_visits': visits,
            'instructions': [observations[k] for k in sorted(observations)]}


def inspect(args):
    source = args.nexus_source.resolve(strict=True)
    sys.path.insert(0, str(source))
    from tools.measurement.elf import Elf32
    from tools.measurement.soc_costs import decode_symbol
    from tools.measurement.flash_ram_static import _decode, _constant_effect
    from tools.measurement.retention import selected_faces
    from tools.measurement.resources import (resolved_float_abi,
                                             validate_elf_configuration)
    family, sdk, header, controller, irq, vector_offset = FAMILIES[args.family]
    cmsis = source / f'vendors/st/cmsis_device_{sdk}/Include' / header
    resolved = json.loads(args.resolved.read_text())
    require(resolved['soc_family'] == family and
            resolved['backend'] == 'baremetal', 'exact family/backend required')
    inputs = [args.elf, args.objdump, args.resolved, args.bindings, cmsis,
              Path(__file__), source / 'tools/measurement/elf.py',
              source / 'tools/measurement/soc_costs.py',
              source / 'tools/measurement/flash_ram_static.py',
              source / 'tools/measurement/retention.py',
              source / 'tools/measurement/resources.py']
    before = [identity(p) for p in inputs]
    enum = re.search(r'\b' + controller + r'_IRQn\s*=\s*(\d+)\s*,',
                     cmsis.read_text())
    require(enum and int(enum[1]) == irq and (16 + irq) * 4 == vector_offset,
            'locked CMSIS enum differs from scoped vector offset')
    elf = Elf32(args.elf.read_bytes(),
                float_abi=resolved_float_abi(resolved, require_cpu=True))
    validate_elf_configuration(elf, resolved)
    raw = args.objdump.read_bytes()
    real = f'nx_{family}_uart_fifo_irq'
    wrapper = '__wrap_' + real
    foreign = '__wrap_nx_' + ('stm32u575' if args.family == 'h743' else
                              'stm32h743') + '_uart_fifo_irq'
    names = {row['name'] for row in elf.defined_symbols}
    require(foreign not in names, 'foreign-family wrapper retained')
    require(not any(name.startswith('fifo_station_dispatch_') for name in names),
            'default no-marker operator rejects optional station leaves')
    probe_prefixes = ('nx_io_cycle_probe_', 'nx_io_observation_',
                      'nx_factory_uart_cycle_probe', 'g_fifo_fixture_irq_probe')
    if args.image_kind == 'reference':
        require(not any(name.startswith(probe_prefixes) or
                        name.startswith('__wrap_nx_') for name in names),
                'reference retains observer/probe/wrapper instrumentation')
    else:
        symbol(elf, wrapper, function=True, strong=True)
    _, real_symbol = symbol(elf, real, function=True, strong=True)
    _, handler = symbol(elf, controller + '_IRQHandler',
                        function=True, strong=True)
    vector = [row for row in elf.sections if row['name'] == '.isr_vector']
    require(len(vector) == 1, 'unique actual vector section required')
    word = int.from_bytes(bytes_at(elf, vector[0]['address'] + vector_offset,
                                    4, readonly=True), 'little')
    require(word & 1 and word == handler['value'],
            'actual vector word does not name the strong Thumb handler')
    default = elf.symbols.get('Default_Handler')
    require(default is None or word != default, 'vector reaches default alias')
    faces = [row for row in selected_faces(args.bindings.read_text())
             if row[0] == 'nx_uart_port_t' and
             row[2] == f'nx_{family}_uart_fifo_ops']
    require(len(faces) == 1, 'one selected exact FIFO face required')
    _, face = symbol(elf, faces[0][1])
    _, state = symbol(elf, faces[0][3])
    _, ops = symbol(elf, faces[0][2])
    require(face['size'] == 8, 'selected face is not the two-pointer ABI')
    face_ops = int.from_bytes(bytes_at(elf, face['value'], 4, readonly=True),
                              'little')
    context = int.from_bytes(bytes_at(elf, face['value'] + 4, 4, readonly=True),
                             'little')
    require(face_ops == ops['value'] and context == state['value'],
            'actual immutable face does not bind selected ops/state')
    callee = wrapper if args.image_kind == 'instrumented' else real
    _, callee_symbol = symbol(elf, callee, function=True, strong=True)
    handler_decoded = decoded_function(elf, controller + '_IRQHandler', raw,
                                       decode_symbol)
    handler_flow = walk(elf, handler_decoded, context, ('real',),
                        {callee_symbol['value'] & ~1: ('real', callee)}, None,
                        _decode, _constant_effect)
    wrapper_flow = None
    if args.image_kind == 'instrumented':
        _, probe = symbol(elf, 'g_fifo_fixture_irq_probe')
        calls = {real_symbol['value'] & ~1: ('real', real)}
        for event, name in [('begin', 'nx_io_cycle_probe_begin'),
                            ('end', 'nx_io_cycle_probe_end')]:
            _, row = symbol(elf, name, function=True, strong=True)
            require(row['value'] & ~1 not in calls, 'aliased audited call target')
            calls[row['value'] & ~1] = (event, name)
        wrapper_flow = walk(
            elf, decoded_function(elf, wrapper, raw, decode_symbol), context,
            ('begin', 'real', 'end'), calls, probe['value'], _decode,
            _constant_effect, entry_r0=context)
    require(before == [identity(p) for p in inputs], 'inputs changed during audit')
    return {'status': 'passed_scoped_static_link_check', 'family': args.family,
            'image_kind': args.image_kind, 'inputs': before,
            'locked_irq_enum': {'name': controller + '_IRQn', 'value': irq,
                                'header': identity(cmsis)},
            'vector': {'section_address': vector[0]['address'],
                       'byte_offset': vector_offset, 'actual_word': word,
                       'strong_handler': controller + '_IRQHandler'},
            'selected_face': faces[0][1], 'selected_state': faces[0][3],
            'actual_context': context, 'handler_flow': handler_flow,
            'wrapper_flow': wrapper_flow,
            'software_qualified': False, 'hardware_qualified': False,
            'physical_status': 'not_executed',
            'review_obligations': [
                'AAPCS callee-saved registers/save slots and canonical return '
                'semantics remain assumptions; no arbitrary-C pointer proof.',
                'Probe APIs must respect their token/sidecar bounds and return '
                'normally. Callee bodies and MMIO/drain behavior are not proved.',
                'No marker leaves are selected. Optional marker images require '
                'a separate exact review and are rejected by this operator.',
                'Static CFG and linked bytes are not CPU execution, IRQ arrival, '
                'elapsed cycles, stack high-water, WCET, HIL or release evidence.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('nexus-source', 'elf', 'objdump', 'resolved', 'bindings', 'report'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--family', choices=FAMILIES, required=True)
    parser.add_argument('--image-kind', choices=('reference', 'instrumented'),
                        required=True)
    args = parser.parse_args()
    output = args.report.resolve()
    require(output.is_relative_to(REVIEW) and not output.exists(),
            'fresh output inside authorized external review directory required')
    protected = {p.resolve() for p in [args.elf, args.objdump, args.resolved,
                                      args.bindings, Path(__file__)]}
    require(output not in protected, 'report must not overwrite an input')
    try:
        result = inspect(args)
        code = 0
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        result = {'status': 'failed_scoped_static_link_check',
                  'error': str(error), 'software_qualified': False,
                  'hardware_qualified': False, 'physical_status': 'not_executed'}
        code = 1
    output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation never replaces either a prior failure or an input.
    with output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'report': str(output)}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
