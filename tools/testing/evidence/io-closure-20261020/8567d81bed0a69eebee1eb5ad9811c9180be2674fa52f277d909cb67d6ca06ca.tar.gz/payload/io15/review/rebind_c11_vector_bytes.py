#!/usr/bin/env python3
"""Exact existing-byte proof mapping; no compilation or operator rerun."""
from pathlib import Path
import datetime, hashlib, json, resource
B=Path('/tmp/nexus-io15-execute-20261020');R=B/'review';errors=[]
def identity(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(256*1024),b''):h.update(b)
 return {'path':str(p),'size':p.stat().st_size,'sha256':h.hexdigest()}
def verify(v,label):
 a=identity(v['path']);ok=a['size']==v.get('size',v.get('bytes')) and a['sha256']==v['sha256']
 if not ok:errors.append({'code':'identity_mismatch','label':label,'expected':v,'actual':a})
 return a
def same(a,b):
 with Path(a).open('rb') as x,Path(b).open('rb') as y:
  while True:
   p=x.read(256*1024);q=y.read(256*1024)
   if p!=q:return False
   if not p:return True
old=json.loads((B/'arm/execution.json').read_text());new=json.loads((B/'arm-c11/execution.json').read_text())
normal=json.loads((R/'operator-execution-r1.json').read_text());negative=json.loads((R/'actual-elf-negative-summary.json').read_text());delivery=json.loads((R/'delivery.json').read_text())
operator=verify(delivery['operator'],'unchanged operator source');proofs={(x['family'],x['image_kind']):x for x in normal['results']};previous={(x['family'],x['variant']):x for x in old['images']};maps=[]
for row in new['images']:
 key=(row['family'],row['variant']);before=previous[key];pairs={}
 for kind in ['elf','bin']:
  a=verify(before[kind],'old image '+kind);b=verify(row[kind],'new image '+kind);eq=same(a['path'],b['path'])
  pairs[kind]={'old':a,'new':b,'complete_bytes_equal':eq,'sha_and_size_equal':(a['sha256'],a['size'])==(b['sha256'],b['size'])}
  if not eq:errors.append({'code':'new_old_image_bytes_differ','family':key[0],'variant':key[1],'kind':kind})
 p=proofs[key];report=Path(p['report']);v=json.loads(report.read_text());rid=identity(report)
 if rid['sha256']!=p['report_sha256'] or p['exit_code']!=0 or v.get('status')!='passed_scoped_static_link_check':errors.append({'code':'old_normal_report_not_admitted','key':key})
 receipt=Path(p['receipt']);rc=json.loads(receipt.read_text())
 if rc.get('exit_code')!=0 or rc.get('child_returncode')!=0 or rc.get('outcome')!='completed':errors.append({'code':'old_normal_receipt_not_completed','key':key})
 for field in ['stdout','stderr']:verify(rc[field],'normal raw '+field)
 admitted_inputs=[verify(x,'old operator input') for x in v['inputs']]
 metadata=[]
 for kind in ['resolved.json','bindings.c']:
  a=B/'arm'/row['family']/'nexus/generated'/kind;b=B/'arm-c11'/row['family']/'nexus/generated'/kind;eq=same(a,b)
  metadata.append({'old':identity(a),'new':identity(b),'complete_bytes_equal':eq})
  if not eq:errors.append({'code':'selection_metadata_bytes_differ','key':key,'kind':kind})
 maps.append({'family':key[0],'variant':key[1],'image_identity_pairs':pairs,'old_operator_report':rid,'old_actual_operator_receipt':identity(receipt),'old_operator_inputs_still_exact':admitted_inputs,'selection_metadata_pairs':metadata,'rebound_static_facts':{'locked_irq_enum':v['locked_irq_enum'],'vector':v['vector'],'selected_face':v['selected_face'],'selected_state':v['selected_state'],'actual_context':v['actual_context'],'handler_flow':v['handler_flow'],'wrapper_flow':v.get('wrapper_flow')},'claim':'Exact byte-identical new ELF/BIN and selected bindings/resolved metadata admit mapping of the existing bounded static vector/normal-return observations to the new paths. No new operator execution, source, runtime/VTOR, IRQ arrival, latency, loan or HIL proof is claimed.'})
negatives=[]
if len(negative['results'])!=6 or not negative.get('all_expected_semantic_rejections'):errors.append({'code':'old_six_negatives_not_admitted'})
for n in negative['results']:
 failure=Path(n['failure_report']);f=json.loads(failure.read_text());receipt=Path(n['receipt']);rc=json.loads(receipt.read_text());folder=failure.parent
 for field in ['stdout','stderr']:verify(rc[field],'negative actual raw '+field)
 mutated=identity(folder/'mutant.elf');raw=identity(folder/'mutant.objdump')
 if mutated['sha256']!=n['elf_sha256'] or raw['sha256']!=n['raw_sha256'] or n['actual_exit']!=1 or rc.get('exit_code')!=1 or rc.get('child_returncode')!=1 or rc.get('outcome')!='completed' or f.get('error')!=n['expected_semantic_rejection'] or not n['passed']:
  errors.append({'code':'old_negative_evidence_mismatch','family':n['family'],'mutation':n['mutation']})
 negatives.append({'family':n['family'],'mutation':n['mutation'],'old_actual_exit':rc['exit_code'],'expected_semantic_rejection':n['expected_semantic_rejection'],'actual_failure':f,'failure_report':identity(failure),'actual_receipt':identity(receipt),'mutated_elf':mutated,'mutated_objdump':raw,'unchanged_checker':operator,'base_new_instrumented_elf':next(x['image_identity_pairs']['elf']['new'] for x in maps if x['family']==n['family'] and x['variant']=='instrumented'),'scope':'Existing six negative executions retained once; same admitted base instrumented ELF bytes and unchanged checker version. No additional negative execution is counted.'})
report={'schema_version':1,'kind':'exact_uart_fifo_vector_c11_byte_rebinding','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed_exact_byte_rebinding' if not errors else 'failed','old_execution':identity(B/'arm/execution.json'),'new_execution':identity(B/'arm-c11/execution.json'),'old_recorded_source':old['platform_source_before'],'new_recorded_source':new['platform_source_before'],'old_operator_execution_summary':identity(R/'operator-execution-r1.json'),'old_negative_summary':identity(R/'actual-elf-negative-summary.json'),'old_operator_source_review':verify(delivery['operator_source_review'],'old source review'),'old_execution_independent_review':verify(delivery['actual_execution_independent_review'],'old execution review'),'unchanged_operator':operator,'all_four_elf_and_bin_bytes_equal':all(x['image_identity_pairs'][k]['complete_bytes_equal'] for x in maps for k in ['elf','bin']),'normal_proof_mappings':maps,'existing_negative_mappings':negatives,'reused_proof_scope':'Only existing static observations over identical ARM ELF bytes and identical selected metadata are mapped to fresh C11 paths. Fresh build/compiler/source/ACM exclusion evidence comes from arm-c11 execution and independent-retention-review, not inheritance of older qualification.','source_and_execution_inheritance':False,'new_operator_invocations':0,'new_negative_executions':0,'compilation_executed':False,'physical_status':'not_executed','hardware_qualified':False,'software_candidate_qualified':False,'primary_or_index_modified':False,'errors':errors,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
P=R/'vector-c11-rebinding.json'
with P.open('x') as f:json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'report':identity(P),'status':report['status'],'same_elf_and_bin_pairs':8,'mapped_old_normal_reports':len(maps),'preserved_old_negative_executions':len(negatives),'new_operator_or_negative_executions':0,'errors':errors},sort_keys=True))
