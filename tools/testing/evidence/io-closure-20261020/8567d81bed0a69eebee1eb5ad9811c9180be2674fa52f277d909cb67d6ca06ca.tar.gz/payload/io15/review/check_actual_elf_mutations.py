#!/usr/bin/env python3
"""Execute narrow negative checks on copied actual fixture ELF/raw bytes."""
from pathlib import Path
import hashlib
import json
import os
import re
import resource
import sys
sys.dont_write_bytecode = True
ROOT = Path('/tmp/nexus-io15-execute-20261020/review')
SOURCE = Path('/tmp/nexus-quality-20261019')
sys.path.insert(0, str(SOURCE))
from tools.dev.process import run
from tools.measurement.elf import Elf32
from tools.measurement.flash_ram_static import _decode


def offset(elf, address, width):
    rows = [s for s in elf.sections if s['kind'] != 8 and
            s['address'] <= address < address + width <= s['address'] + s['size']]
    assert len(rows) == 1
    return rows[0]['offset'] + address - rows[0]['address']


def rewrite_line(raw, address, replacement):
    result, matched = [], 0
    for line in raw.splitlines(keepends=True):
        m = re.match(rb'\s*([0-9a-f]+):', line)
        if m and int(m[1], 16) == address:
            result.append(replacement)
            matched += 1
        else:
            result.append(line)
    assert matched == 1
    return b''.join(result)


results = []
env = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
env['PYTHONDONTWRITEBYTECODE'] = '1'
for family in ('h743', 'u575'):
    admitted = json.loads((ROOT / (family + '-instrumented-r1.json')).read_text())
    names = {Path(x['path']).name: Path(x['path']) for x in admitted['inputs']}
    elf_path = names['fifo_acquisition_instrumented.elf']
    raw_path = next(Path(x['path']) for x in admitted['inputs']
                    if x['path'].endswith('-objdump.stdout'))
    original_elf, original_raw = elf_path.read_bytes(), raw_path.read_bytes()
    original_ids = [hashlib.sha256(x).hexdigest()
                    for x in (original_elf, original_raw)]
    elf = Elf32(original_elf)
    for mutation in ('nonthumb-vector', 'rebound-state', 'omitted-real'):
        folder = ROOT / 'mutations' / family / mutation
        folder.mkdir(parents=True, exist_ok=True)
        altered = bytearray(original_elf)
        raw = original_raw
        if mutation == 'nonthumb-vector':
            address = (admitted['vector']['section_address'] +
                       admitted['vector']['byte_offset'])
            changed = admitted['vector']['actual_word'] & ~1
            expected = 'actual vector word does not name the strong Thumb handler'
            width = 4
            replacement = changed.to_bytes(width, 'little')
        elif mutation == 'rebound-state':
            row = next(row for row in admitted['handler_flow']['instructions']
                       if int.from_bytes(bytes.fromhex(row['encoding'])[:2],
                                         'little') & 0xf800 == 0x4800)
            op = _decode(row['address'], bytes.fromhex(row['encoding']),
                         bridge=False)
            address, width = op.literal
            changed = admitted['actual_context'] + 4
            replacement = changed.to_bytes(width, 'little')
            raw = rewrite_line(raw, address,
                               f' {address:x}:\t{changed:08x}\t.word\t0x{changed:08x}\n'.encode())
            expected = 'selected state or probe argument was rebound/unknown'
        else:
            row = next(x for x in admitted['wrapper_flow']['instructions']
                       if x['event'] == 'real')
            address, width = row['address'], 4
            assert len(bytes.fromhex(row['encoding'])) == width
            replacement = b'\x00\xbf\x00\xbf'
            raw = rewrite_line(raw, address,
                               (f' {address:x}:\tbf00\tnop\n'
                                f' {address + 2:x}:\tbf00\tnop\n').encode())
            expected = 'skipped/repeated/out-of-order probe or real transfer'
        start = offset(elf, address, width)
        altered[start:start + width] = replacement
        mutant_elf, mutant_raw = folder / 'mutant.elf', folder / 'mutant.objdump'
        mutant_elf.write_bytes(altered)
        mutant_raw.write_bytes(raw)
        output = folder / 'actual-failure.json'
        command = [sys.executable, '-B', str(ROOT / 'verify_fifo_elf.py'),
                   '--nexus-source', str(SOURCE), '--family', family,
                   '--image-kind', 'instrumented', '--elf', str(mutant_elf),
                   '--objdump', str(mutant_raw), '--resolved', str(names['resolved.json']),
                   '--bindings', str(names['bindings.c']), '--report', str(output)]
        completed = run(command, cwd=SOURCE, env=env,
                        log=folder / 'operator.log', timeout=30,
                        stage='io15-actual-elf-negative-' + family + '-' + mutation)
        failure = json.loads(output.read_text())
        passed = (completed.returncode == 1 and
                  failure['status'] == 'failed_scoped_static_link_check' and
                  expected in failure['error'])
        results.append({'family': family, 'mutation': mutation,
                        'expected_exit': 1, 'actual_exit': completed.returncode,
                        'expected_semantic_rejection': expected,
                        'actual_error': failure.get('error'), 'passed': passed,
                        'actual_mutated_address': address,
                        'elf_sha256': hashlib.sha256(altered).hexdigest(),
                        'raw_sha256': hashlib.sha256(raw).hexdigest(),
                        'failure_report': str(output),
                        'receipt': str(folder / 'operator.command.json')})
    assert original_ids == [hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in (elf_path, raw_path)]
summary = {'kind': 'actual_ELF_copied_mutation_negative_checks',
           'results': results, 'all_expected_semantic_rejections':
           all(x['passed'] for x in results),
           'child_max_rss_kib': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
           'scope': 'Six deliberate copies of the actual two instrumented ARM ELFs '
           'and byte-consistent raw disassemblies; no source edit or compilation. '
           'Original normal artifacts unchanged. These are negative static checks, '
           'not target execution or physical measurements.',
           'software_qualified': False, 'hardware_qualified': False,
           'physical_status': 'not_executed'}
(ROOT / 'actual-elf-negative-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
raise SystemExit(0 if summary['all_expected_semantic_rejections'] else 1)
