from pathlib import Path
import hashlib,json,os,resource,sys
sys.dont_write_bytecode=True
repo=Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(repo))
from tools.dev.process import run
base=Path('/tmp/nexus-io15-execute-20261020');out=base/'review';arm=base/'arm'
execution=json.loads((arm/'execution.json').read_text())
print('ARM execution fields:',list(execution))
specs=[('h743','reference','003-h743-reference-objdump.stdout'),('h743','instrumented','005-h743-instrumented-objdump.stdout'),('u575','reference','010-u575-reference-objdump.stdout'),('u575','instrumented','012-u575-instrumented-objdump.stdout')]
results=[];env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env['PYTHONDONTWRITEBYTECODE']='1'
for family,variant,raw in specs:
 name=family+'-'+variant;report=out/(name+'-r1.json');command=[sys.executable,'-B',str(out/'verify_fifo_elf.py'),'--nexus-source',str(repo),'--family',family,'--image-kind',variant,'--elf',str(arm/family/'bin'/('fifo_acquisition_'+variant+'.elf')),'--objdump',str(arm/'commands'/raw),'--resolved',str(arm/family/'nexus/generated/resolved.json'),'--bindings',str(arm/family/'nexus/generated/bindings.c'),'--report',str(report)]
 completed=run(command,cwd=repo,env=env,log=out/'commands'/(name+'-r1.log'),timeout=30,stage='io15-actual-elf-'+name)
 row={'family':family,'image_kind':variant,'exit_code':completed.returncode,'report':str(report),'receipt':str(out/'commands'/(name+'-r1.command.json'))}
 if report.exists():row['status']=json.loads(report.read_text())['status'];row['report_sha256']=hashlib.sha256(report.read_bytes()).hexdigest()
 results.append(row)
summary={'kind':'actual_four_FIFO_ELF_operator_execution','results':results,'child_max_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'software_qualified':False,'hardware_qualified':False,'physical_status':'not_executed','source_scope':'Development-only explicit platform source and currently unpinned examples app; not clean SDK consumer qualification.'};(out/'operator-execution-r1.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
