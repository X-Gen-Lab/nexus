# IO15 / IO24 / USB ACM development evidence

This archive preserves exact development sources, original RED/GREEN output,
command receipts, GoogleTest XML, selected ARM artifacts, static audits and
independent bilingual documentation review. The selection proposals and
materialization records map every stored path to its original size/SHA/mode.
Byte-identical aliases are explicit; immutable Nexus/GMock/CMSIS dependencies
are referenced by their actual recorded identity rather than copied wholesale.

The initial failing host/model/metadata commands and all six actual ARM ELF
mutation rejections remain present. Historical GNU17 and final explicit-C11
ARM matrices retain separate source snapshots and reports. The final ACK-aware
ACM contract preserves a real matching STATUS ACK during cancellation. Strict
English/Chinese documentation completed successfully, with 238 reviewed
translation records; exact execution and original raw receipts are included.

These are software development and scoped static-link checks. They establish
no physical IRQ latency, WCET, silicon execution, clean installed-SDK
qualification or current whole-tree release qualification. IO15, IO24 and the
full IO35 task remain open according to their original scope. Physical status
is not_executed. All inner reports retain their own narrower limits. The
portable outer archive is unsigned and does not promote a product.

## 中文范围

归档保留实际开发源码、最初失败与后续通过的原始日志、命令回执、GoogleTest
XML、选定 ARM 产物、静态审查及双语文档独立审查。相同字节的别名和未复制的
固定依赖均由原始身份索引说明，不用后来修改的源码替换历史字节。

这些软件和静态链接检查不证明物理 IRQ 延迟、WCET、芯片实际运行、干净 SDK
消费或整个候选版本的发布资格。IO15、IO24 和完整 IO35 原始任务仍开放，
硬件执行状态仍为 not_executed。外层归档为未签名证物容器，不授予产品资格。
