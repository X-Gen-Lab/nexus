"""Actual complete H743 production-C model execution with original receipts."""
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

root = Path('/tmp/nexus-quality-20261019')
sys.path.insert(0, str(root))
from tools.dev.process import run

output = Path(sys.argv[1]).absolute()
output.mkdir(parents=True, exist_ok=False)
target = sys.argv[2] if len(sys.argv)>2 else 'nexus_h743_flash_ram_closure_test'
inputs = ['soc/stm32h743/drivers/flash_ram_transaction.c',
          'soc/stm32h743/private/stm32h743_flash_ram.h',
          'tests/google/h743_flash_ram_closure_test.cpp',
          'tests/google/h743_flash_ram_closure_model.h']
if target == 'nexus_usb_acm_test':
    inputs = ['components/usb_control/src/usb_acm.c',
              'components/usb_control/include/nexus/components/usb_acm.h',
              'tests/google/usb_acm_test.cpp',
              'components/usb_control/src/usb_control.c',
              'components/usb_control/include/nexus/components/usb_control.h',
              'components/usb_control/CMakeLists.txt','tests/google/usb_device.cmake']
elif target in ('nexus_h743_fifo_acquisition_probe_test',
                'nexus_u575_fifo_acquisition_probe_test'):
    family='stm32h743' if 'h743' in target else 'stm32u575'
    inputs=['tests/contracts/uart_fifo_acquisition/irq_probe.c',
            'tests/google/uart_fifo_acquisition_probe_test.cpp',
            'tests/google/uart_fifo_acquisition_probe.cmake',
            'soc/'+family+'/private/'+family+'_uart_fifo.h']

def freeze():
    return [{'path': name, 'sha256': hashlib.sha256((root/name).read_bytes()).hexdigest()}
            for name in inputs]

before = freeze()
for name in inputs:
    destination = output/'source'/name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((root/name).read_bytes())
environment = os.environ.copy()
environment.update(NEXUS_BUILD_JOBS='1', CMAKE_BUILD_PARALLEL_LEVEL='1',
                   PYTHONDONTWRITEBYTECODE='1')
steps = []
commands = [('build', ['flock', '/tmp/nexus-platform-compiler.lock',
    str(root/'.venv/bin/cmake'), '--build', 'build/native-debug', '--target',
    target, '--parallel', '1']),
    ('discovery', [str(root/'build/native-debug/bin'/target), '--gtest_list_tests']),
    ('complete', [str(root/'build/native-debug/bin'/target),
                  '--gtest_output=xml:' + str(output/'google.xml')])]
for name, argv in commands:
    started = time.monotonic()
    execution = run(argv, cwd=root, env=environment, timeout=600,
                    log=output/(name+'.raw'), stage=target+'-'+name)
    steps.append({'name': name, 'argv': argv, 'exit_code': execution.returncode,
                  'duration_s': time.monotonic()-started})
    if execution.returncode:
        print(execution.stderr[-8000:])
        if name != 'complete': break
report = {'kind': 'actual_production_C_Google_execution', 'target':target, 'steps': steps,
          'source': before, 'source_stable': before == freeze(),
          'source_head': subprocess.check_output(['git','rev-parse','HEAD'],
              cwd=root,text=True).strip(), 'software_qualified': False,
          'physical_status': 'not_executed',
          'peak_child_rss_kib': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}
if (output/'google.xml').is_file():
    node = ET.parse(output/'google.xml').getroot()
    report['google'] = {key:node.get(key) for key in ['tests','failures','errors','disabled']}
    report['google']['actual_cases'] = len(node.findall('.//testcase'))
(output/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(int(any(step['exit_code'] for step in steps) or not report['source_stable']))
