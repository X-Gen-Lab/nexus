/* Initial unsupported implementation retained only for executed TDD RED. */
#include "stm32u575_lpdma_copy_internal.h"
const nx_stm32u575_lpdma_copy_ops_t nx_stm32u575_lpdma_copy_ops = {0};
nx_result_t nx_stm32u575_lpdma_copy_initialize(nx_stm32u575_lpdma_copy_storage_t* a, const nx_stm32u575_lpdma_copy_config_t* b, nx_stm32u575_lpdma_copy_t* c) { (void)a;(void)b;(void)c;return NX_ERROR_UNSUPPORTED; }
nx_result_t nx_stm32u575_lpdma_copy_request_prepare(nx_stm32u575_lpdma_copy_request_t* a,const nx_stm32u575_retained_time_snapshot_t* b,const void* c,void* d,size_t e,nx_stm32u575_lpdma_copy_workspace_t* f,nx_time_us_t g) { (void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;return NX_ERROR_UNSUPPORTED; }
nx_result_t nx_stm32u575_lpdma_copy_arm(const nx_stm32u575_lpdma_copy_t* a,nx_stm32u575_lpdma_copy_request_t* b) { (void)a;(void)b;return NX_ERROR_UNSUPPORTED; }
nx_result_t nx_stm32u575_lpdma_copy_validate_sleep(const nx_stm32u575_lpdma_copy_t* a,nx_stm32u575_lpdma_copy_request_t* b,nx_stm32u575_retained_time_storage_t* c,const void* d,uint64_t e) { (void)a;(void)b;(void)c;(void)d;(void)e;return NX_ERROR_UNSUPPORTED; }
nx_result_t nx_stm32u575_lpdma_copy_drain(const nx_stm32u575_lpdma_copy_t* a,nx_result_t b,uint32_t c) { (void)a;(void)b;(void)c;return NX_ERROR_UNSUPPORTED; }
nx_result_t nx_stm32u575_lpdma_copy_release(const nx_stm32u575_lpdma_copy_t* a,nx_stm32u575_lpdma_copy_request_t* b,nx_result_t c) { (void)a;(void)b;(void)c;return NX_ERROR_UNSUPPORTED; }
nx_result_t nx_stm32u575_lpdma_copy_cancel(const nx_stm32u575_lpdma_copy_t* a,nx_stm32u575_lpdma_copy_request_t* b) { (void)a;(void)b;return NX_ERROR_UNSUPPORTED; }
nx_result_t nx_stm32u575_lpdma_copy_service(const nx_stm32u575_lpdma_copy_t* a,uint32_t b) { (void)a;(void)b;return NX_ERROR_UNSUPPORTED; }
nx_result_t nx_stm32u575_lpdma_copy_stop(const nx_stm32u575_lpdma_copy_t* a,uint32_t b) { (void)a;(void)b;return NX_ERROR_UNSUPPORTED; }
