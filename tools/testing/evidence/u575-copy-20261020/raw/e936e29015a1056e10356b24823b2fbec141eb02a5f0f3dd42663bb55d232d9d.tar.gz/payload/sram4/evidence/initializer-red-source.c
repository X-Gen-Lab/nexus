/**
 * \file            memory_init.c
 * \brief           Selected SRAM4 pre-RAM initialization
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-20
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "private/stm32u575_memory_init.h"
bool nx_stm32u575_memory_initialize(const nx_stm32u575_memory_region_t* region,
                                    uintptr_t flash_start,
                                    uintptr_t flash_end) {
    (void)region;
    (void)flash_start;
    (void)flash_end;
    return false;
}
