set(CMAKE_HOST_SYSTEM "Linux-6.18.55")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "6.18.55")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/dev/shm/nexus-h743-flash-closure-20261020/sdk-prefix/share/nexus/src/cmake/toolchains/arm-gcc.cmake")

set(CMAKE_SYSTEM "Generic")
set(CMAKE_SYSTEM_NAME "Generic")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "arm")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
