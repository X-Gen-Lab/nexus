# H743 bounded constant-join correction

This delivery fixes one software defect in the existing H743 RAM ELF checker. Finite may-value sets retain known constants and Unknown through register, stack and call joins; a recoverable Flash-read alternative cannot disappear because another incoming value differs. Alternative/product exhaustion rejects the image. Firmware C/assembly and the public Flash API are unchanged. Full IO-24 remains open.

`final.patch` applies to `48299637535c09cff92b99f89306d13b2768d37d`; `final-source.json` binds all four final files and actual executions. Root independently reviewed the complete algorithm and regressions in `root-final-review.json`. The separate one-paragraph EN/ZH contract correction was reviewed against exact source/catalog/message hashes in `/tmp/nexus-h743-joins-doc-review-20261020/independent-semantic-review.json`.

Executed evidence:

- Initial actual ARM/static module: 33 cases, exactly 2 intended failures, then 33/33 GREEN. Raw `red-static.raw` and `green-static.raw`; baseline checker and initial test/fixture identities are retained in the evidence package's `source-red/` snapshot.
- Supplemental requested Unknown+Flash join and growing-loop coverage: 36/36 GREEN, no skips. This is supplemental coverage after the original RED/GREEN, not a fabricated earlier RED. Raw `green-static-supplemental.raw` and source identities in `supplemental-coverage.json`.
- Complete ordinary H743 build-gate module: 15/15 GREEN, no skips; real HSI32, HSI64 and PLL384 cache-off selected builds plus unselected. All selected images have an observed conservative bound of 368B and 122 unresolved read sites. Raw actual commands and retained ELF/BIN/map/object/SU/reports are in archive `production/`.
- Maintained `package_source_sdk.py --development-fixture` from the actual dirty primary checkout: 5957 files, nonpublishable, snapshot 655d61b0bfdd48a4d1f25634faa461a7ac132a3d25850797f6d54309905f8c13. Existing installed public C11 H743-high consumer configured and linked through the normal graph; audit passed with checker 76661ebd9bc58bb7befb6c8879a661411445868827ca91bbcc8f1a8875939172. No SDK manifest was edited manually.

Compiler/configure executions acquired the shared nonblocking flock and ran jobs1. Initial isolated-source CMake attempts correctly rejected symlink/copy Git identity; `isolated-canonical-vendor-rejection.raw` retains the final setup failure. Passing ordinary-graph evidence comes from the root-applied exact checker in the actual primary checkout and from the maintained SDK fixture, not those rejected setups.

Two concrete production ELF mutations are retained in `production/remaining-obligations.json`: a return gate that only returns its outcome, and a terminal that reads Flash through `workspace.destination`. Both are accepted by the currently limited checker. Its `all_data_operands` and return-gate device protocol remain `not_proved`; original VTOR argument integrity also remains open. No C-model execution count, hardware measurement or software-candidate qualification is claimed by this checker-only increment.

The complete unique execution tree, including the exact SDK fixture and original redistribution notices, is sealed once by the existing evidence store:

- Package: `evidence-package.json`.
- Archive: `evidence-store/99d680e0e56fb07be00e92cee573ca084a5a1f182c89441e234614acab5cb86a.tar.gz` (33194313 bytes).
- Separate member-by-member verification: `evidence-verify.json`, 6616 files /124861722 source bytes.

The disposable 126MB SDK prefix was removed only after export's built-in verification and a separate successful verification. Restore with the existing `tools/evidence/store.py restore --package <package> --destination <new-empty-directory> --report <report>`; no new framework is needed. The final supplemental test sources are recoverable by applying `final.patch` to the recorded Git base, and their exact identities are in `final-source.json`.

The next full-closure construction and unresolved obligations are analyzed in `../full-closure-feasibility.md`, bound to `../full-closure-analysis-source.json`. That analysis changes no firmware and does not promote IO-24.
