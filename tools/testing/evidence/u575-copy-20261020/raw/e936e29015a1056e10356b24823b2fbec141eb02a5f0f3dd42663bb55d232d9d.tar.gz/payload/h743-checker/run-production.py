"""Retain normal unittest/CMake outputs and observe explicitly unproved checks."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import time
import unittest

ROOT = Path('/tmp/nexus-quality-20261019')
OUT = Path('/dev/shm/nexus-h743-flash-closure-20261020/production')
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location(
    'h743_actual_normal_graph', ROOT / 'tools/testing/test_h743_ram_build_gate.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
case = module.H743RamBuildGateTests
commands = []

def run_command(cls, arguments, *, success=True):
    started = time.time_ns()
    result = subprocess.run(arguments, cwd=ROOT, capture_output=True,
                            check=False, timeout=180)
    number = len(commands)
    for label, value in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (OUT / f'{number:03d}.{label}.raw').write_bytes(value)
    commands.append({'argv': list(map(str, arguments)), 'cwd': str(ROOT),
                     'started_ns': started, 'finished_ns': time.time_ns(),
                     'exit_code': result.returncode})
    (OUT / 'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    if success and result.returncode:
        raise AssertionError(repr((arguments, result.returncode,
                                   result.stdout, result.stderr)))
    return result

case.run_command = classmethod(run_command)
original_cleanup = case.tearDownClass.__func__

def retain_and_cleanup(cls):
    try:
        examples = []
        observer = cls('test_normal_selected_builds_audit_all_three_cache_off_profiles')
        for label, name, prefix, obligation in [
            ('unproved-return-gate', 'nx_stm32h743_flash_ram_return',
             '10467047', 'gate MMIO/drain/LOCK/MPU/VTOR protocol'),
            ('unproved-loaded-destination', 'nx_stm32h743_flash_ram_terminal',
             'd0f8a0361a68fee7', 'loaded workspace destination points to Flash')]:
            result, report = observer.mutate_function(name, bytes.fromhex(prefix), label)
            examples.append({'label': label, 'obligation': obligation,
                             'exit_code': result.returncode,
                             'report': json.loads(report.read_text())})
        (OUT/'remaining-obligations.json').write_text(json.dumps(examples, indent=2)+'\n')
        retained = []
        for source in cls.root.rglob('*'):
            if not source.is_file() or source.is_symlink():
                continue
            relative = source.relative_to(cls.root)
            if 'CMakeFiles' in relative.parts:
                if source.suffix not in {'.su', '.obj'}:
                    continue
            elif source.suffix not in {'.elf', '.bin', '.map', '.json', '.raw', '.toml'}:
                continue
            target = OUT/'retained'/relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            retained.append({'original': str(source), 'retained': str(target),
                             'sha256': hashlib.sha256(target.read_bytes()).hexdigest()})
        (OUT/'retained-files.json').write_text(json.dumps(retained, indent=2)+'\n')
    finally:
        original_cleanup(cls)

case.tearDownClass = classmethod(retain_and_cleanup)
suite = unittest.defaultTestLoader.loadTestsFromModule(module)
result = unittest.TextTestRunner(verbosity=2).run(suite)
summary = {'tests': result.testsRun, 'failures': len(result.failures),
           'errors': len(result.errors), 'skipped': len(result.skipped),
           'exit_code': 0 if result.wasSuccessful() else 1}
(OUT/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
raise SystemExit(summary['exit_code'])
