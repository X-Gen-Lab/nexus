"""Execute the existing installed selected H743 public consumer template."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

ROOT = Path('/tmp/nexus-quality-20261019')
ART = Path('/dev/shm/nexus-h743-flash-closure-20261020')
PREFIX = ART/'sdk-prefix'
OUT = ART/'sdk-consumer'
OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('h743_existing_sdk_consumer',ROOT/'cmake/package/verify_consumers.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
commands=[]
def run(argv):
    started=time.time_ns()
    result=subprocess.run(argv,capture_output=True,cwd=ROOT,timeout=180)
    n=len(commands)
    for label,value in [('stdout',result.stdout),('stderr',result.stderr)]:
        (OUT/f'{n:03d}.{label}.raw').write_bytes(value)
    commands.append({'argv':list(map(str,argv)),'started_ns':started,'finished_ns':time.time_ns(),'exit_code':result.returncode})
    (OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if result.returncode:
        raise RuntimeError((argv,result.returncode,result.stdout,result.stderr))
    return result
source,build,command=module.prepare_selected_consumer(
    PREFIX,OUT,'h743 high',
    'cmake/package/verification/io_evolution/h743-high-peripherals.toml',
    'h743-high',run,expected_revision='48299637535c09cff92b99f89306d13b2768d37d')
command.append('-DNEXUS_ALLOW_SOURCE_SDK_FIXTURE=ON')
run(command)
run(['cmake','--build',str(build),'--target','installed_selected','--parallel','1'])
report=build/'bin/installed_selected.h743-flash-ram.json'
data=json.loads(report.read_text())
if data['status']!='passed' or data['qualification'] or data['physical_execution']!='not_executed':
    raise RuntimeError('Unexpected selected audit result')
manifest=PREFIX/'share/nexus/src/.nexus-source-sdk.json'
result={'status':'passed','source_sdk':json.loads(manifest.read_text()),'report':str(report),
        'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),
        'checker_sha256':hashlib.sha256((PREFIX/'share/nexus/src/tools/measurement/flash_ram_static.py').read_bytes()).hexdigest(),
        'physical_execution':'not_executed','qualification':False}
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='source_sdk'},indent=2))
