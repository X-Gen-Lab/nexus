from pathlib import Path
import importlib.util,json,sys,time,unittest
P=Path('/tmp/nexus-quality-20261019');W=Path('/tmp/nexus-doc-ledger-admission-20261020')
sys.path.insert(0,str(P))
import tools.documentation
for name in ('cli','test_cli'):
 spec=importlib.util.spec_from_file_location('tools.documentation.'+name,W/'final/tools/documentation'/f'{name}.py')
 module=importlib.util.module_from_spec(spec)
 sys.modules[spec.name]=module
 setattr(tools.documentation,name,module)
 spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromName(sys.argv[1] if len(sys.argv)>1 else 'tools.documentation.test_cli')
start=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'duration_seconds':time.monotonic()-start}))
raise SystemExit(0 if result.wasSuccessful() else 1)
