#include <stddef.h>
#include "nexus/components/frame_dma2d.h"
#include "nexus_bindings.h"
#if __has_include("stm32h743xx.h") || __has_include("stm32h7xx.h") || __has_include("stm32h743_provider.h")
#error Private provider or vendor headers leaked into the public consumer
#endif
_Static_assert(__STDC_VERSION__ == 201112L,"public C11");
_Static_assert(sizeof(nx_frame_blit_request_t)==64,"exact request ABI");
_Static_assert(offsetof(nx_frame_blit_request_t,format)==60,"format in natural tail padding");
_Static_assert(sizeof(nx_h743_frame_dma2d_storage_t)==64,"exact owner ABI");
_Static_assert(sizeof(nx_frame_blitter_ops_t)==16,"four readonly operations");
