#include <stddef.h>
#include "nexus/components/frame_dma2d.h"
const unsigned char request_size[sizeof(nx_frame_blit_request_t)] = {0};
const unsigned char request_alignment[_Alignof(nx_frame_blit_request_t)] = {0};
const unsigned char owner_size[sizeof(nx_h743_frame_dma2d_storage_t)] = {0};
const unsigned char owner_alignment[_Alignof(nx_h743_frame_dma2d_storage_t)] = {0};
const unsigned char format_offset_plus_one[offsetof(nx_frame_blit_request_t,format)+1] = {0};
