#!/usr/bin/env python3
"""Read actual normal-graph ELF/commands and attribute this exact increment."""
from pathlib import Path
import hashlib
import json
import re
import struct
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PRIMARY = Path('/tmp/nexus-quality-20261019')
sys.path.insert(0, str(PRIMARY))
from tools.measurement.elf import Elf32


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def unique(items):
    assert len(items) == 1, items
    return items[0]
def main():
    out = ROOT / 'arm-results'
    report = {'scope': 'Actual same-path development normal-graph links; not installed SDK, execution, throughput, latency or HIL.', 'variants': {}}
    for variant in ('baseline', 'pfc'):
        build = out / (variant + '-build')
        elfpath = build / 'bin/h743_frame_public.elf'
        elf = Elf32(elfpath.read_bytes())
        methods = unique([s for s in elf.defined_symbols if s['name'] == 'nx_h743_frame_dma2d_ops'])
        section = elf.sections[methods['section']]
        assert methods['size'] == 16 and not section['flags'] & 1
        offset = section['offset'] + methods['value'] - section['address']
        addresses = struct.unpack_from('<IIII', elf.data, offset)
        functions = {s['name']: s for s in elf.defined_symbols
                     if (s['file'] == 'h743_frame_dma2d.c' or s['name'] == 'nx_h743_frame_dma2d_initialize') and s['type'] == 2}
        assert tuple(functions[n]['value'] for n in ('submit', 'service', 'cancel', 'stop')) == addresses
        assert all(s['size'] > 0 for s in functions.values())
        consumer = {s['name']: s for s in elf.defined_symbols if s['file'] == 'consumer.c'}
        assert consumer['storage']['size'] == 64 and consumer['request']['size'] == 64
        assert consumer['pixels']['size'] == 96 and consumer['output']['size'] == 96
        for name in ('storage', 'request', 'pixels', 'output'):
            s = consumer[name]
            assert 0x24000000 <= s['value'] < s['value'] + s['size'] <= 0x24080000
        rows = json.loads((build / 'compile_commands.json').read_text())
        command = unique([r for r in rows if r['file'].endswith('/tests/contracts/h743_frame_dma2d/consumer.c')])
        assert '-std=c11' in command['command'] and '-Wpedantic' in command['command'] and '-Werror' in command['command']
        assert '/vendors/' not in command['command'] and '/soc/' not in command['command']
        sourcepaths = []
        for load in elf.loads:
            data = elf.data[load['offset']:load['offset']+load['files']]
            sourcepaths.extend(s[:-1].decode() for s in re.findall(rb'[ -~]{12,}\x00',data)
                               if b'/tmp/' in s)
        resources = json.loads((build / 'bin/h743_frame_public.resources.json').read_text())
        assert resources['status'] == 'passed' and not resources['violations']
        assert resources['physical_status'] == 'not_executed'
        stack = {}
        for line in (out / (variant + '-driver.su')).read_text().splitlines():
            name, size, kind = line.split('\t')
            assert kind == 'static'
            stack[name.rsplit(':', 1)[1]] = int(size)
        abi = {}
        for architecture in ('arm','host'):
            abi[architecture] = {parts[-1]:int(parts[1]) for line in (out / (variant + '-abi-' + architecture + '-nm.log')).read_text().splitlines() if (parts:=line.split())}
        assert abi['arm']['request_size'] == 64 and abi['arm']['owner_size'] == 64
        assert abi['host']['owner_size'] == 96
        assert abi['host']['request_size'] == (96 if variant == 'baseline' else 104)
        report['variants'][variant] = {
            'elf_sha256':sha(elfpath), 'flash_loaded_bytes':resources['metrics']['flash']['loaded_bytes'],
            'axi_reserved_bytes':resources['metrics']['ram']['axi-sram']['reserved_bytes'],
            'driver_function_bytes':sum(s['size'] for s in functions.values()),
            'driver_functions':{n:s['size'] for n,s in functions.items()},
            'main_bytes':unique([s for s in elf.defined_symbols if s['name']=='main'])['size'],
            'readonly_ops_bytes':methods['size'], 'ops_exact_function_addresses':list(addresses),
            'abi':abi,'local_stack_bytes':stack,'allocated_source_path_strings':sourcepaths,
            'public_consumer_command':command}
    old,new=(report['variants'][n] for n in ('baseline','pfc'))
    assert old['allocated_source_path_strings'] == new['allocated_source_path_strings']
    assert old['local_stack_bytes'] == new['local_stack_bytes']
    assert old['axi_reserved_bytes'] == new['axi_reserved_bytes']
    report['delta'] = {'flash_loaded_bytes':new['flash_loaded_bytes']-old['flash_loaded_bytes'],
        'driver_function_bytes':new['driver_function_bytes']-old['driver_function_bytes'],
        'main_bytes':new['main_bytes']-old['main_bytes'],
        'linker_padding_and_other_allocated_bytes':(new['flash_loaded_bytes']-old['flash_loaded_bytes'])-(new['driver_function_bytes']-old['driver_function_bytes'])-(new['main_bytes']-old['main_bytes']),
        'axi_reserved_bytes':0,'owner_storage_bytes':{'arm':0,'host':0},'request_storage_bytes':{'arm':0,'host':8},'per_function_local_stack_bytes':0}
    report['limits'] = ['.su values are compiler local frames, not transitive stack or measured high water.',
        'Additional format checks and bounded seven-controls-per-slot alias checks are not measured timing; admission remains O(n) with no heap or new owner fields.',
        'Firmware enum uses ordinary maintained -fshort-enums; format occupies existing ARM tail padding. No packed, bitfield or union layout trick.',
        'Baseline uses the final public consumer geometry/storage/lifecycle and removes only the new format assignment; it does not compare the former NULL-only SDK smoke.']
    target=out/'resource-comparison.json';target.write_text(json.dumps(report,indent=2)+'\n')
    print(sha(target),json.dumps(report['delta']))

if __name__=='__main__':main()
