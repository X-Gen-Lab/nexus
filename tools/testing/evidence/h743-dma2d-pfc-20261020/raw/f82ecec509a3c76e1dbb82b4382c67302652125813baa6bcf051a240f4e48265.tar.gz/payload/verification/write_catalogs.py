#!/usr/bin/env python3
"""Refresh exactly two existing page catalogs, retaining unchanged messages."""
from pathlib import Path
import hashlib
import json
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PRIMARY = Path('/tmp/nexus-quality-20261019')
sys.path.insert(0, str(PRIMARY))
from tools.documentation.sphinx_ext import read_catalog

ZH = {
'design/io-extension-boundaries': [
'公共帧合同；精确 H743 V、D-Cache 关闭，在 AXI SRAM 中执行 RGB565 复制或固定 ARGB8888 到 RGB565 PFC',
'完整帧与固定 H743 DMA2D 格式',
'[DMA2D 组件](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/components/frame_dma2d/include/nexus/components/frame_dma2d.h) 使用调用方拥有的单个执行者，不设队列。它仅接纳精确 H743 V ID `0x20030450`、D-Cache 关闭且独占冷态 DMA2D 的情况。两种请求格式为 RGB565 复制（枚举零值）和固定 ARGB8888 到 RGB565 像素格式转换（PFC）。未知格式会被拒绝；CLUT、混合、其他格式和 IRQ 操作仍不受支持。两个表面都必须位于 AXI SRAM `[0x24000000,0x24080000)`。这不推断任何 Board 连接或物理结果。',
'`x` 和 `width_bytes` 始终以源字节计数。RGB565 的源地址、x、宽度和步幅按两字节对齐，ARGB8888 则按四字节对齐。在此小端 MCU 上，ARGB8888 输入按 B、G、R、A 字节存储；RGB565 丢弃 alpha，不交换通道或字节。输出地址和步幅按两字节对齐；输出行字节数为 `width_bytes / source_pixel_bytes * 2`。目标步幅和容量仍以字节计。`LOM=0` 时，前景与输出偏移分别按各自格式的像素计数：PFC 的源填充除以四，复制的源填充除以二，输出填充除以二。每侧像素间隙最多为 `0x3fff`；尽管寄存器字段为 16 位，像素模式仍忽略位 15:14（RM0433 Rev9 第 18.5.5 和 18.5.20 节）。宽度最多为 `0x3fff` 像素，高度最多为 `0xffff` 行。成功请求报告输出字节数，不含步幅填充。接纳前检查算术、AXI 区间与硬件界限。',
'目标写入区间及每个所有权控制体都必须与源池每个槽的完整容量互不重叠，包括帧尾部与其他空闲槽。接纳以 O(n) 扫描有界池，每槽比较七个固定控制体。接纳借用请求、精确的有效源帧借用及输出；选中的源槽直到最终访问结束都保持不可变。拒绝时，原源借用仍归调用方。提交返回 `SUCCESS` 表示 ACCEPTED，包括随后发生设置／读回失败的情况；这种失败保留全部借用，直到 service 证明排空。最先观察到的失败在取消及可恢复 cache／IRQ 守卫恢复后仍被锁存。',
'成功完成要求 TC 和 START 清零。取消／错误排空要求 START／CLUT／IRQ 撤离，不要求 TC。写 START 和 ABORT 时保留所选模式。START 是可读置位位：写零无效。ABORT 请求硬件撤离，不重新置位已清除的 START。提供者只有在硬件证明成立并清除 FGMAR／OMAR／NLR 后才释放借用。证明失败会将全部借用保留在隔离状态；继续 service 可在实际排空后恢复。若活动 owner 观察到其必需 RCC 时钟门关闭或 DMA2D 复位被置位，传输历史即不确定，隔离将永久保持：把寄存器恢复为零不能撤销借用，service、stop 或重新初始化都不能回收它。未被观察到的复位脉冲无法检测；独占时钟门／复位所有权仍是强制前提。系统级恢复由外部负责。Stop 关闭接纳，对活动工作返回 `BUSY`；只有全部借用结算后才复位控制器并撤回其拥有的时钟门。这些软件与 ELF 检查不建立 PFC 吞吐量、延迟或 HIL 结果。',
],
'reference/api/extension-components': [
'显式可选的 H743 RGB565 复制与固定 PFC owner。',
'精确的源到 RGB565 操作；未知值不受支持。',
'源和输出均为 RGB565；零值保留复制操作。',
'ARGB8888 到 RGB565；在此小端 MCU 上输入字节顺序为 B、G、R、A。',
'丢弃 alpha；不进行混合、通道／字节交换或 CLUT 加载。',
'在未屏蔽中断的特权任务中，由单个执行者串行调用。调用方明确排除所有其他 DMA2D owner，包括 HAL、IRQ 处理器及组件外的资源选择。stop 前不得改变 Cache／RCC／复位／MPU 或时钟域。所有载荷必须完整位于 AXI SRAM [0x24000000, 0x24080000)；拒绝源／目标重叠。仅支持 RGB565 M2M 或固定 ARGB8888 到 RGB565 PFC。偏移按每侧自身的像素计数（LOM=0），不按字节计数。不支持 CLUT／混合／其他格式／IRQ。不创建引脚、Board 路由、调度器、队列或工作线程。初始化 IO 错误保留清理所有权；应调用 stop。成功 stop 会脱离每个源，随后仅撤回自己的 RCC 时钟门。重复 stop 不访问硬件。',
'使用普通请求辅助函数初始化／准备 base。ACCEPTED 借用本对象、精确源借用控制体与目标区间，直到 acquire 观察到 SETTLED。接纳时源借用所有权转移给此 owner；只有最终 DMA 访问结束后才释放。拒绝时原借用仍归调用方。不得单独释放、修改或复用已接纳的控制体、源或目标。x／width_bytes 是源字节数，不是输出字节数或像素数。RGB565 的源地址／x／宽度／步幅按 2 字节对齐，ARGB8888 则按 4 字节对齐。目标为 RGB565，按 2 字节对齐。目标行字节数为 width_bytes/source_pixel_bytes*2；destination_stride/capacity 以字节计。LOM=0 时每侧像素间隙最多为 0x3fff；宽度最多为 0x3fff 像素，高度最多为 0xffff 行。成功时通过 nx_request_result 报告输出字节数，不含步幅填充。目标不能与源池槽的完整容量重叠。每个控制体必须与每个槽的完整容量互不重叠。选中的源槽直到最终访问结束都保持不可变。仅限任务的接纳以 O(n) 检查已知池区间。',
'Submit 返回 SUCCESS 表示 ACCEPTED，包括后续设置／读回错误。已接纳的失败保留全部借用，直到 service 证明最终排空。最先观察到的失败在取消／守卫恢复后仍被保留。',
'abort_observations 限定进入隔离前 service 失败观察的次数。它是软件进展预算，不是实测的总线／DMA 时间界限。同一执行者在可恢复隔离后继续 service；实际排空可使请求结算。若观察到活动期间 RCC 时钟门丢失或复位被置位，则永久保留全部借用。恢复寄存器不能证明已丢失的传输历史；没有 API 能回收它。未被观察到的复位脉冲无法检测，因此仍必须独占 RCC 所有权。系统恢复由外部负责。',
]}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    extraction = json.loads((ROOT / 'docs-extraction/messages.json').read_text())
    pairs = []
    catalogs = []
    for page, data in extraction.items():
        assert len(data['new']) == len(ZH[page])
        new = dict(zip(data['new'], ZH[page]))
        source = ROOT / ('docs/' + page + '.md')
        if not source.exists(): source = PRIMARY / ('docs/' + page + '.md')
        source_sha = digest(source)
        for locale in ('en', 'zh_CN'):
            path = Path('docs/locale') / locale / 'LC_MESSAGES' / (page + '.po')
            metadata, old, fuzzy = read_catalog(PRIMARY / path)
            assert not fuzzy
            values = {message: old[message] if message in old else
                      (message if locale == 'en' else new[message]) for message in data['messages']}
            assert all(old[m] == values[m] for m in old.keys() & values.keys())
            assert all(values.values())
            header = ('Project-Id-Version: Nexus source documentation\nLanguage: ' + locale +
                '\nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\n'
                'X-Nexus-Reviewed: false\nX-Nexus-Source-SHA256: ' + source_sha + '\n')
            text = '# Exact extracted messages; unchanged translations preserved.\nmsgid ""\nmsgstr ' + json.dumps(header, ensure_ascii=False) + '\n\n'
            for message, translation in values.items():
                text += 'msgid ' + json.dumps(message, ensure_ascii=False) + '\nmsgstr ' + json.dumps(translation, ensure_ascii=False) + '\n\n'
            target = ROOT / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text)
            parsed = read_catalog(target)
            assert parsed[1] == values and not parsed[2]
            catalogs.append({'path': str(path), 'sha256': digest(target), 'messages': len(values),
                             'unchanged': len(old.keys() & values.keys()), 'new': len(new), 'removed': len(data['removed']), 'reviewed': False})
        for message in data['new']:
            pairs.append({'page': page, 'msgid': message, 'en': message, 'zh_CN': new[message],
                'msgid_sha256': hashlib.sha256(message.encode()).hexdigest(),
                'zh_CN_sha256': hashlib.sha256(new[message].encode()).hexdigest(),
                'canonical_source_sha256': source_sha, 'pot_sha256': data['pot_sha256']})
    packet = {'scope': 'Only new exact messages require new semantic review; every unchanged translation is retained exactly.',
              'catalogs': catalogs, 'pairs': pairs,
              'extraction_inputs': json.loads((ROOT / 'docs-extraction/inputs.json').read_text())}
    target = ROOT / 'docs-extraction/translation-pairs.json'
    target.write_text(json.dumps(packet, ensure_ascii=False, indent=2) + '\n')
    print(digest(target))

if __name__ == '__main__':
    main()
