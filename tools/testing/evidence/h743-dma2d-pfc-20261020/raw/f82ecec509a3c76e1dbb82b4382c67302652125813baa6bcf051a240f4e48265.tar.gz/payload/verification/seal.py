#!/usr/bin/env python3
"""Seal one compact development evidence closure with the maintained store."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sys
sys.dont_write_bytecode = True
ROOT=Path(__file__).resolve().parents[1]
PRIMARY=Path('/tmp/nexus-quality-20261019')
sys.path.insert(0,str(PRIMARY))
from tools.evidence.store import export_tree,verify_package


def sha(path):
    value=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1024*1024),b''):value.update(block)
    return value.hexdigest()


def main():
    payload=ROOT/'delivery/payload'
    assert not payload.exists(),'Freeze once; do not overwrite a sealed payload'
    payload.mkdir()
    def copy(source,destination):
        source=Path(source);target=payload/destination
        assert source.is_file() and not source.is_symlink()
        assert all(not p.is_symlink() for p in source.parents)
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        assert sha(source)==sha(target)
    manifest=json.loads((ROOT/'delivery/integration-manifest.json').read_text())
    for item in manifest['paths']:
        assert sha(PRIMARY/item['path'])==item['before_sha256']
        assert sha(ROOT/item['path'])==item['final_sha256']
        copy(ROOT/item['path'],'final/'+item['path'])
    for name in ('integration.patch','integration-manifest.json','patch-application-check-final.json','README.md'):
        copy(ROOT/'delivery'/name,'integration/'+name)
    for source in (ROOT/'evidence').iterdir():
        if source.is_file():copy(source,'tdd/'+source.name)
    copy(ROOT/'build/nexus_h743_frame_dma2d_test','tdd/final-test-executable')
    for source in (ROOT/'verification').rglob('*'):
        if source.is_file() and '__pycache__' not in source.parts:
            copy(source,'verification/'+source.relative_to(ROOT/'verification').as_posix())
    for source in (ROOT/'arm-results').iterdir():
        if source.is_file():copy(source,'arm/'+source.name)
    for variant in ('baseline','pfc'):
        build=ROOT/'arm-results'/(variant+'-build')
        copy(build/'compile_commands.json','arm/'+variant+'/compile_commands.json')
        for name in ('h743_frame_public.elf','h743_frame_public.map','h743_frame_public.bin','h743_frame_public.resources.json'):
            copy(build/'bin'/name,'arm/'+variant+'/'+name)
        for name in ('resolved.json','resource-budget.json','memory.ld'):
            copy(build/'nexus/generated'/name,'arm/'+variant+'/generated/'+name)
    for source in (ROOT/'arm-setup-failure').iterdir():
        if source.is_file():copy(source,'setup-failures/arm/'+source.name)
    for directory in ('docs-extraction','docs-extraction-cross-reference-setup-failure'):
        prefix='gettext' if directory=='docs-extraction' else 'setup-failures/gettext'
        base=ROOT/directory
        for source in base.iterdir():
            if source.is_file():copy(source,prefix+'/'+source.name)
        for source in (base/'gettext').rglob('*.pot'):
            copy(source,prefix+'/pot/'+source.relative_to(base/'gettext').as_posix())
    xml=ROOT/'docs-extraction/api/xml'
    for source in xml.glob('*.xml'):
        if ('frame__dma2d' in source.name or 'frame__blit' in source.name):
            copy(source,'gettext/frame-public-xml/'+source.name)
    reviewer=Path('/tmp/nexus-h743-pfc-independent-review-20261020')
    for name in ('initial-review.json','initial-review-v2.json','final-source-approved.json','meaning-approved.json'):
        copy(reviewer/name,'independent-review/'+name)
    for name in ('facts.json','official-excerpts.txt'):
        copy(Path('/tmp/nexus-h743-pfc-facts-20261020')/name,'manual/'+name)
    spec=importlib.util.spec_from_file_location('sdk_closure',PRIMARY/'cmake/package/package_source_sdk.py')
    sdk=importlib.util.module_from_spec(spec);spec.loader.exec_module(sdk)
    required=('components/frame_dma2d/CMakeLists.txt','components/frame_dma2d/include/nexus/components/frame_dma2d.h','components/frame_dma2d/src/h743_frame_dma2d.c','cmake/package/verify_consumers.py')
    assert all(path in sdk.REQUIRED_FILES and sdk.selected(path) for path in required)
    framework=Path('/tmp/nexus-googletest-tdd-20261019/hal-reference/lib')
    inputs={str(path):sha(path) for path in [PRIMARY/'core/src/request.c',PRIMARY/'io/src/frame_stream.c',PRIMARY/'io/src/stream.c',PRIMARY/'io/src/dma.c',PRIMARY/'arch/native/nx_arch_native.c',PRIMARY/'cmake/package/package_source_sdk.py',framework/'libgmock_main.a',framework/'libgmock.a',framework/'libgtest.a']}
    summary={'kind':'bounded_h743_dma2d_pfc_development','production_sha256':manifest['paths'][1]['final_sha256'],'inputs':inputs,
             'sdk_closure':{'already_required_and_exported':list(required),'new_paths':[]},
             'tests':{'final_full_cases':32,'failures':0,'skipped':0,'history_red_exact_final_tests':{'cases':32,'failures':2}},
             'manual_pdf_not_duplicated':'Unique original research PDF/text remain at /tmp/nexus-h743-pfc-facts-20261020/research; compact exact quotes and source hashes are included.',
             'excluded':'No pinned framework libraries, whole source checkout, repeated full build trees or relocated SDK snapshot is copied into this evidence closure.',
             'physical_status':'not_executed','full_v8_matrix':'not_executed_here','installed_sdk_rerun':'not_executed_here'}
    (payload/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    before={str(p.relative_to(payload)):sha(p) for p in payload.rglob('*') if p.is_file()}
    package=export_tree(payload,ROOT/'evidence-store')
    (ROOT/'delivery/evidence-package.json').write_text(json.dumps(package,indent=2)+'\n')
    verified=verify_package(package)
    (ROOT/'delivery/evidence-verification.json').write_text(json.dumps(verified,indent=2)+'\n')
    assert before=={str(p.relative_to(payload)):sha(p) for p in payload.rglob('*') if p.is_file()}
    assert all(sha(ROOT/item['path'])==item['final_sha256'] and sha(PRIMARY/item['path'])==item['before_sha256'] for item in manifest['paths'])
    print(json.dumps({'files':package['files'],'bytes':package['bytes'],'archive':package['archive']}))

if __name__=='__main__':main()
