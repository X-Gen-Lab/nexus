#!/usr/bin/env python3
"""Two serial normal-graph ARM links with identical owned source paths."""
from pathlib import Path
import fcntl
import hashlib
import json
import os
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
PRIMARY = Path('/tmp/nexus-quality-20261019')
OUT = ROOT / 'arm-results'
SOURCE = OUT / 'source'
CM = PRIMARY / '.venv/bin/cmake'
ARM = Path('/tmp/nexus-quality-arm/bin')
PATHS = ('components/frame_dma2d/src/h743_frame_dma2d.c',
         'components/frame_dma2d/include/nexus/components/frame_dma2d.h',
         'tests/contracts/h743_frame_dma2d/consumer.c')
ENV = dict(os.environ, PATH=str(PRIMARY / '.venv/bin') + ':' + str(ARM) + ':' + os.environ['PATH'],
           PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    assert not OUT.exists(), 'Fresh evidence directory required'
    OUT.mkdir()
    commands = []
    before = {p: sha(PRIMARY / p) for p in PATHS}
    final = {p: sha(ROOT / p) for p in PATHS}
    def run(name, args, cwd=OUT):
        args = list(map(str, args))
        with (OUT / (name + '.log')).open('wb') as log:
            result = subprocess.run(args, cwd=cwd, env=ENV, stdout=log, stderr=subprocess.STDOUT)
        commands.append({'name': name, 'argv': args, 'returncode': result.returncode})
        (OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        if result.returncode:
            raise SystemExit(name + ' failed: ' + str(result.returncode))
    with open('/tmp/nexus-platform-compiler.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for variant in ('baseline', 'pfc'):
            for p in PATHS:
                target = SOURCE / p
                target.parent.mkdir(parents=True, exist_ok=True)
                if variant == 'baseline' and not p.endswith('consumer.c'):
                    target.write_bytes((PRIMARY / p).read_bytes())
                else:
                    data = (ROOT / p).read_text()
                    if variant == 'baseline':
                        data = data.replace('    request.format = NX_FRAME_BLIT_ARGB8888_TO_RGB565;\n', '')
                    target.write_text(data)
            snapshot = {p: sha(SOURCE / p) for p in PATHS}
            (OUT / (variant + '-sources.json')).write_text(json.dumps(snapshot, indent=2) + '\n')
            build = OUT / (variant + '-build')
            run(variant + '-configure', [CM, '-S', ROOT / 'verification/arm', '-B', build,
                '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', '-DNEXUS_COMPILER_CACHE=OFF',
                '-DCMAKE_TOOLCHAIN_FILE=' + str(PRIMARY / 'cmake/toolchains/arm-gcc.cmake'),
                '-DPython3_EXECUTABLE=' + str(PRIMARY / '.venv/bin/python'),
                '-DNEXUS_FRAME_REFERENCE_SOURCE=' + str(SOURCE)])
            run(variant + '-build', [CM, '--build', build, '--target', 'h743_frame_public', '--parallel', '1'])
            abi = OUT / 'abi.c'
            abi.write_text('#include <stddef.h>\n#include "nexus/components/frame_dma2d.h"\n'
                'const unsigned char request_size[sizeof(nx_frame_blit_request_t)] = {0};\n'
                'const unsigned char request_alignment[_Alignof(nx_frame_blit_request_t)] = {0};\n'
                'const unsigned char owner_size[sizeof(nx_h743_frame_dma2d_storage_t)] = {0};\n'
                'const unsigned char owner_alignment[_Alignof(nx_h743_frame_dma2d_storage_t)] = {0};\n' +
                ('const unsigned char format_offset_plus_one[offsetof(nx_frame_blit_request_t,format)+1] = {0};\n'
                 if variant == 'pfc' else ''))
            includes = ['-I' + str(SOURCE / 'components/frame_dma2d/include'),
                        '-I' + str(PRIMARY / 'core/include'), '-I' + str(PRIMARY / 'io/include')]
            common = ['-std=c11', '-Wall', '-Wextra', '-Wpedantic', '-Wconversion', '-Werror', *includes, '-c', abi]
            run(variant + '-abi-arm', [ARM / 'arm-none-eabi-gcc', '-mcpu=cortex-m7', '-mthumb',
                '-mfpu=fpv5-d16', '-mfloat-abi=hard', '-fshort-enums', *common, '-o', OUT / (variant + '-abi-arm.o')])
            run(variant + '-abi-host', ['/usr/bin/cc', *common, '-o', OUT / (variant + '-abi-host.o')])
            for architecture in ('arm', 'host'):
                nm = ARM / 'arm-none-eabi-nm' if architecture == 'arm' else Path('/usr/bin/nm')
                run(variant + '-abi-' + architecture + '-nm', [nm, '-S', '--radix=d', OUT / (variant + '-abi-' + architecture + '.o')])
            objects = list(build.glob('**/h743_frame_dma2d.c.obj'))
            assert len(objects) == 1, objects
            shutil.copyfile(objects[0], OUT / (variant + '-driver.o'))
            for suffix in ('.su',):
                candidates = list(build.glob('**/h743_frame_dma2d.c' + suffix))
                for candidate in candidates:
                    shutil.copyfile(candidate, OUT / (variant + '-driver' + suffix))
            run(variant + '-driver-size', [ARM / 'arm-none-eabi-size', '-A', objects[0]])
            run(variant + '-driver-nm', [ARM / 'arm-none-eabi-nm', '-S', '--size-sort', objects[0]])
            elf = build / 'bin/h743_frame_public.elf'
            assert elf.is_file(), str(elf)
            run(variant + '-elf-size', [ARM / 'arm-none-eabi-size', '-A', elf])
            run(variant + '-elf-symbols', [ARM / 'arm-none-eabi-nm', '-S', '--size-sort', elf])
            assert snapshot == {p: sha(SOURCE / p) for p in PATHS}
    assert before == {p: sha(PRIMARY / p) for p in PATHS}
    assert final == {p: sha(ROOT / p) for p in PATHS}
    (OUT / 'source-bindings.json').write_text(json.dumps({'baseline_primary': before,
        'final_overlay': final, 'compiler_lock': '/tmp/nexus-platform-compiler.lock', 'jobs': 1,
        'same_source_paths': str(SOURCE), 'baseline_consumer_delta': 'Only the new format assignment is removed; all other consumer bytes match the final public fixture.',
        'scope': 'Development source substitution in the same maintained target graph; not a relocated installed SDK or hardware execution.'}, indent=2) + '\n')
    print('Both normal public ARM links and ABI compiles completed.')

if __name__ == '__main__':
    main()
