#!/usr/bin/env python3
"""One focused maintained gettext extraction; run only in an agreed lock slot."""
from pathlib import Path
import fcntl
import hashlib
import json
import os
import re
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
PRIMARY = Path('/tmp/nexus-quality-20261019')
PREFIX = Path('/tmp/nexus-quality-doc-tools')
OUT = ROOT / 'docs-extraction'
REPO = OUT / 'repository'
PAGES = ('design/io-extension-boundaries', 'reference/api/extension-components')
sys.path.insert(0, str(PRIMARY))
from tools.documentation.sphinx_ext import read_catalog, rewrite_local_links


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not OUT.exists(), 'Preserve prior raw extraction; do not overwrite it'
    inputs = {}
    for name in PAGES:
        relative = 'docs/' + name + '.md'
        origin = ROOT / relative
        if not origin.exists():
            origin = PRIMARY / relative
        assert origin.resolve() == origin and not origin.is_symlink()
        inputs[str(origin)] = digest(origin)
        destination = REPO / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        text = origin.read_text()
        for target in re.findall(r'\]\(([^)]+)\)', text):
            if '://' in target:
                continue
            path = (destination.parent / target.split('#', 1)[0]).resolve()
            if path.is_relative_to(REPO):
                path.parent.mkdir(parents=True, exist_ok=True)
                if path != destination:
                    path.touch()
        destination.write_text(rewrite_local_links(text, destination, REPO / 'docs',
                                                   REPO, 'NEXUS-DOCUMENTATION-SOURCE'))
    (REPO / 'docs/index.md').write_text('# Focused extraction\n\n```{toctree}\n' +
                                       '\n'.join(PAGES) + '\n```\n')
    for linked in (REPO / 'docs').rglob('*.md'):
        if not linked.read_text():
            linked.write_text('---\norphan: true\n---\n# Focused link target\n')
    configuration = OUT / 'configuration'
    configuration.mkdir()
    excluded = [p.relative_to(REPO / 'docs').as_posix()
                for p in (REPO / 'docs').rglob('*.md')
                if p.relative_to(REPO / 'docs').as_posix() not in
                {'index.md', *(name + '.md' for name in PAGES)}]
    (configuration / 'conf.py').write_text(
        'import sys\nfrom pathlib import Path\n'
        'sys.dont_write_bytecode = True\n'
        f'sys.path.insert(0, {str(PRIMARY)!r})\n'
        'from tools.documentation.breathe_i18n import SourcedDoxygenFileDirective\n'
        'extensions = ["myst_parser", "breathe"]\n'
        'source_suffix = {".md":"markdown"}\nroot_doc="index"\n'
        'myst_heading_anchors=5\nmyst_enable_extensions=["colon_fence"]\n'
        'gettext_compact=False\ngettext_location=False\ngettext_uuid=False\n'
        f'breathe_projects={{"nexus": {str(OUT / "api/xml")!r}}}\n'
        'breathe_default_project="nexus"\nbreathe_domain_by_extension={"h":"c"}\n'
        'exclude_patterns=["**/*.csv"]\n'
        'def setup(app):\n'
        '    app.add_directive("doxygenfile", SourcedDoxygenFileDirective, override=True)\n')
    template = (PRIMARY / 'Doxyfile').read_text()
    old_inputs = re.search(r'^INPUT\s*=([^\n]*)', template, re.M)[1].split()
    headers = []
    for item in old_inputs:
        path = ROOT / item if item == 'components/frame_dma2d/include/nexus' else PRIMARY / item
        headers.append(path)
        for header in path.rglob('*.h'):
            inputs[str(header)] = digest(header)
    doxy = OUT / 'Doxyfile'
    doxy.write_text('@INCLUDE = ' + str(PRIMARY / 'Doxyfile') + '\n' +
                    'GENERATE_HTML = NO\nOUTPUT_DIRECTORY = ' + str(OUT / 'api') +
                    '\nINPUT = ' + ' '.join(map(str, headers)) + '\n')
    inputs[str(PRIMARY / 'Doxyfile')] = digest(PRIMARY / 'Doxyfile')
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')
    rows = []
    with open('/tmp/nexus-platform-compiler.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        for label, argv in (
            ('doxygen', [str(PREFIX / 'bin/doxygen'), str(doxy)]),
            ('gettext', [str(PREFIX / 'venv/bin/python'), '-B', '-m', 'sphinx',
                         '-q', '-E', '-W', '--keep-going', '-c', str(configuration),
                         '-b', 'gettext', str(REPO / 'docs'), str(OUT / 'gettext')]),
        ):
            with (OUT / (label + '.log')).open('wb') as log:
                proc = subprocess.run(argv, cwd=PRIMARY, env=env, stdout=log,
                                      stderr=subprocess.STDOUT, timeout=180)
            rows.append({'label': label, 'argv': argv, 'returncode': proc.returncode})
            if proc.returncode:
                (OUT / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
                raise SystemExit(proc.returncode)
    messages = {}
    for name in PAGES:
        pot = OUT / 'gettext' / (name + '.pot')
        values = read_catalog(pot)[1]
        baseline = read_catalog(PRIMARY / 'docs/locale/zh_CN/LC_MESSAGES' / (name + '.po'))[1]
        messages[name] = {'pot_sha256': digest(pot), 'messages': list(values),
                          'new': [m for m in values if m not in baseline],
                          'removed': [m for m in baseline if m not in values]}
    assert all(digest(Path(path)) == sha for path, sha in inputs.items())
    (OUT / 'commands.json').write_text(json.dumps(rows, indent=2) + '\n')
    (OUT / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
    (OUT / 'messages.json').write_text(json.dumps(messages, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({name: {'messages': len(value['messages']), 'new': len(value['new']),
                            'removed': len(value['removed'])} for name, value in messages.items()}))


if __name__ == '__main__':
    main()
