# b031 CodeQL annotation follow-up

The exact aggregate118899613236 at commit `b031911584800898f1cdc29a7d96afd0f8335b2b`
returned86 annotations:14 warnings,72 notices and no errors. The raw public GET
response is retained in `annotations.json` (SHA256
`8bb430a4a7e65c4192ac4b3b314ef4d6208429657731032cb15298ad953a1b8e`).
MCP fetch rejected this endpoint family400; the parent authorized an ordinary
exact public HTTPS GET with no explicit Authorization header. No endpoint
encoding workaround, credential inspection or repository mutation occurred.

Compared with the prior84 annotations,81 semantic findings remain, three
uninitialized-local failures are absent, and five findings were added:

- `soc/stm32u575/stop2.c:648`: caller request retained after ACCEPTED admission.
  This is the documented borrow, not escape of an internal automatic object.
  Actual drain clears the global reference before final release-publication;
  failed drain/release retains or restores responsibility.
- `tools/configure/test_g474_adc_group_configuration.py:137`: `assertTrue(set <=
  keys)` is a correct subset assertion; `assertLessEqual` only improves diagnosis.
- `tests/google/h743_frame_dma2d_test.cpp:191`: long Google death-test macro
  expansion; the child deliberately exits without reclaiming a quarantined loan.
- `soc/stm32u575/stop2.c:169,181`: Native extraction reachability notes.
  Both hardware guard helpers are explicitly called in normal/selected source
  paths; these notes do not justify deleting the guards or demonstrate a bug.

The13 previous warnings retain their reviewed meaning. The two whose files
changed (LPDMA caller-storage capture and the Result test adapter) were re-read
at b031. No new functional counterexample was confirmed and no suppression,
style sweep, compile or test was performed. `triage.json` retains all86 current
annotations, prior correspondence, decisions and source blob identities.
This is finding triage only, not new software or physical qualification.
