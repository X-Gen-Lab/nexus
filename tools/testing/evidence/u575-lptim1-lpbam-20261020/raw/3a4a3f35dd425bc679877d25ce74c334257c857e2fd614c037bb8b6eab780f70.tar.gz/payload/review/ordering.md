# Independent ES0499 synchronization addendum (test-first)

Frozen parent: `/tmp/nexus-u575-lptim1-lpbam-20261020`. No parent bytes are changed.

ES0499 Rev12, section 2.17.3, page29: “Interrupt status flag is cleared by hardware upon writing its corresponding bit in LPTIM_DIER register”. Description: “When any interrupt bit of the LPTIM_DIER register is modified, the corresponding flag of the LPTIM_ISR register is cleared by hardware.” Workaround: “None.” The test conservatively allows every DIER write, including writing the existing zero interrupt-enable bits, to clear CMP1OK/REPOK/ARROK. This is a software robustness envelope, not a claim that the manual specifies every same-value write must clear every flag.

## Intended invariant

A successful request requires the final finite DMA register/state proof and the three fresh kernel write acknowledgements, captured before producer withdrawal writes DIER. The caller tuple has exactly one write per register, fresh flags were cleared before arming, and full finite DMA completion prevents later descriptor writes. A saved proof survives DIER flag loss. It does not survive the next admission or controller reset. The extra bool fits unused padding in the existing 16-byte LPTIM profile ledger; owner ARM104/host136 and legacy memory-copy ARM88/host120 remain exact.

## Branches

* No terminal DMA state, no prior error: bounded service returns BUSY, keeps UEDE set and every loan. It cannot withdraw a request that has not yet occurred. A later update, deadline, WUT escape, cancellation or concrete Stop2 recovery determines progress.
* Finite DMA completion, no error: wait boundedly for fresh CMP1OK/REPOK/ARROK and latch the proof, then withdraw UEDE and await fresh DIEROK. Missing OK latches IO and retains the producer and loan on this call. A subsequent public service or explicit concrete Stop2 recover takes the error drain path before withdrawing; the concrete owner also records IO. Poll exhaustion does not manufacture a clock deadline or hardware acknowledgement.
* Prior WUT/deadline/cancel/error: feed the first failure to the peripheral owner before producer withdrawal. No acknowledgement is required for writes that were never issued. Withdraw UEDE/DIEROK, suspend/reset/join DMA, then own RCC reset of LPTIM1. A DMA TC arriving during DIER withdrawal is recorded only as a transfer prefix and never upgrades the terminal result to success.

All branches preserve the existing producer withdrawal → DMA SUSP/SUSPF+IDLE → full-word RESET/CCR0 and final MMIO/IRQ references detach → owned peripheral reset/restore → concrete Stop2 restore → SETTLED order. Unknown access or observed foreign reset still quarantines; this addendum does not weaken those domains.

## Test-first scope

The complete production-C/GoogleTest model suite gains conservative normal and deferred DIER flag loss, early service before any update, WUT-lateTC, cancel-lateTC, and a second admission with missing write-OK after a prior success. Existing partial/cancel, missing OK, producer-ack hold, owned reset recovery, external reset quarantine, and unknown-access cases remain. Compiler execution is not yet started: the parent full commit holds the shared flock.
