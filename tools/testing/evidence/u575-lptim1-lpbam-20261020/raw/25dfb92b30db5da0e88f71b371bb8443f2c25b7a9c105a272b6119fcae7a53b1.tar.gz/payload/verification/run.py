from pathlib import Path
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import unittest

work = Path('/tmp/nexus-u575-lptim-selection-addendum-20261020')
primary = Path('/tmp/nexus-quality-20261019')
frozen = Path('/tmp/nexus-u575-lptim1-lpbam-20261020')
phase = sys.argv[1]
assert phase in ('red', 'green')
label = sys.argv[2] if len(sys.argv) > 2 else phase
output = work / 'evidence' / label
output.mkdir(exist_ok=False)
os.environ['PATH'] = str(primary / '.venv/bin') + os.pathsep + os.environ['PATH']
os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] = '1'

def identity(path):
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'bytes': path.stat().st_size}

context = primary
copied = []
if phase == 'green':
    context = work / 'verification' / ('u575-source-view-' + label)
    context.mkdir(exist_ok=False)
    files = [
        'components/stm32u575_stop2/CMakeLists.txt',
        'components/stm32u575_lpdma_copy/CMakeLists.txt',
        'components/stm32u575_lpdma_lptim1/CMakeLists.txt',
        'soc/stm32u575/stop2.c',
        'soc/stm32u575/drivers/lpdma_copy.c',
        'soc/stm32u575/drivers/lpdma_lptim1.c',
        'soc/stm32u575/private/stm32u575_lptim1_profile.h',
        'components/stm32u575_lpdma_copy/include/nexus/components/stm32u575_lpdma_copy.h',
        'components/stm32u575_lpdma_copy/private/stm32u575_lpdma_copy_internal.h',
        'components/stm32u575_lpdma_lptim1/include/nexus/components/stm32u575_lpdma_lptim1.h',
        'components/stm32u575_lpdma_lptim1/private/stm32u575_lpdma_lptim1_internal.h',
        'components/stm32u575_stop2/include/nexus/components/stm32u575_stop2.h',
        'components/stm32u575_stop2/include/nexus/components/stm32u575_stop2_copy.h',
        'components/stm32u575_stop2/include/nexus/components/stm32u575_stop2_lptim1.h',
    ]
    for relative in files:
        origin = frozen / relative
        if not origin.is_file():
            origin = primary / relative
        destination = context / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, destination)
        copied.append({'relative': relative, 'input': identity(origin),
                       'copy': identity(destination),
                       'before_primary': identity(primary / relative)
                       if (primary / relative).is_file() else None})

path = work / 'tools/testing/test_soc_sleep_selection.py'
spec = importlib.util.spec_from_file_location('sleep_selection_addendum', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.ROOT = primary
module.SocSleepSelectionTests.u575_root = context
actual_run = subprocess.run
commands = []

def record(*args, **kwargs):
    process = actual_run(*args, **kwargs)
    command = list(args[0])
    properties = None
    if '-B' in command:
        properties_path = Path(command[command.index('-B') + 1]) / 'properties.txt'
        if properties_path.is_file():
            properties = properties_path.read_text()
    commands.append({'command': command, 'returncode': process.returncode,
                     'stdout': process.stdout, 'stderr': process.stderr,
                     'properties': properties})
    return process

module.subprocess.run = record
stream = io.StringIO()
suite = unittest.defaultTestLoader.loadTestsFromModule(module)
result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
subprocess.run = actual_run
raw = stream.getvalue()
(output / 'unittest.log').write_text(raw)
(output / 'cmake-runs.json').write_text(json.dumps(commands, indent=2) + '\n')
report = {
    'phase': phase, 'test_file': identity(path), 'tests_run': result.testsRun,
    'failures': len(result.failures), 'errors': len(result.errors),
    'skipped': len(result.skipped), 'successful': result.wasSuccessful(),
    'fixture_roots': {'old_soc_helpers': str(primary),
                      'u575_helpers': str(context),
                      'ordinary_repository_default': 'ROOT; no override'},
    'copied_inputs': copied,
    'scope': 'Actual CMake configure/generate; no firmware target build, no ARM or HIL qualification. Host compiler identification is part of CMake project configuration.',
}
(output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print(raw)
raise SystemExit(0 if result.wasSuccessful() else 1)
