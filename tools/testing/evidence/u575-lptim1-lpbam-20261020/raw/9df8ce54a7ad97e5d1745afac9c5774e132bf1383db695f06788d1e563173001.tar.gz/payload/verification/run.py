from pathlib import Path
import collections
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import unittest

work = Path('/tmp/nexus-u575-lptim-workflow-addendum-20261020')
primary = Path('/tmp/nexus-quality-20261019')
context = work / 'verification/context'
phase = sys.argv[1]
assert phase in ('red', 'green')
output = work / 'evidence' / phase
output.mkdir(exist_ok=False)
sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['PYTHONPATH'] = str(context) + os.pathsep + str(primary)
sys.path[:0] = [str(context), str(primary)]
source = work / '.github/workflows/test_release.py'
shutil.copyfile(source, context / '.github/workflows/test_release.py')
if phase == 'green':
    for command in (['git', 'add', '.github/workflows/test_release.py'],
                    ['git', '-c', 'user.name=Workflow Fixture', '-c',
                     'user.email=fixture@example.invalid', 'commit', '--quiet',
                     '-m', 'Current v8 release test fixture']):
        subprocess.run(command, cwd=context, check=True, capture_output=True)
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=context,
                                 text=True).strip()
spec = importlib.util.spec_from_file_location(
    'release_workflow_addendum', context / '.github/workflows/test_release.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
actual_run = subprocess.run
counts = collections.Counter()
failures = []
non_git = []

def record(*args, **kwargs):
    command = args[0]
    if isinstance(command, (tuple, list)):
        executable = Path(command[0]).name
        if executable in ('cmake', 'ninja', 'make', 'gcc', 'g++', 'cc', 'c++') or \
                executable.startswith('arm-none-eabi-'):
            raise AssertionError('Unexpected compiler/configure call: ' +
                                 repr(command))
    else:
        executable = 'shell-string'
    result = actual_run(*args, **kwargs)
    counts[executable] += 1
    if result.returncode or executable != 'git':
        item = {'command': command, 'cwd': str(kwargs.get('cwd', '')),
                'returncode': result.returncode,
                'stdout': result.stdout.decode(errors='replace')
                if isinstance(result.stdout, bytes) else result.stdout,
                'stderr': result.stderr.decode(errors='replace')
                if isinstance(result.stderr, bytes) else result.stderr}
        (failures if result.returncode else non_git).append(item)
    return result

subprocess.run = record
stream = io.StringIO()
result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
    unittest.defaultTestLoader.loadTestsFromModule(module))
subprocess.run = actual_run
raw = stream.getvalue()
(output / 'unittest.log').write_text(raw)
(output / 'processes.json').write_text(json.dumps(
    {'counts': dict(counts), 'failed': failures, 'successful_non_git': non_git},
    indent=2) + '\n')
inputs = json.loads((work / 'review/context-inputs.json').read_text())
report = {'phase': phase, 'command': [sys.executable, str(Path(__file__)), phase],
          'tests_run': result.testsRun, 'failures': len(result.failures),
          'errors': len(result.errors), 'skipped': len(result.skipped),
          'successful': result.wasSuccessful(),
          'test_file': {'path': str(source),
                        'sha256': hashlib.sha256(source.read_bytes()).hexdigest()},
          'context_git_commit': commit,
          'context_inputs': inputs,
          'physical_status': 'not_executed',
          'scope': 'Complete release workflow Python module; real transport/Git/archive/identity boundaries, firmware and external API ports remain fixtures. No compiler/configure executed.'}
(output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print(raw)
raise SystemExit(0 if result.wasSuccessful() else 1)
