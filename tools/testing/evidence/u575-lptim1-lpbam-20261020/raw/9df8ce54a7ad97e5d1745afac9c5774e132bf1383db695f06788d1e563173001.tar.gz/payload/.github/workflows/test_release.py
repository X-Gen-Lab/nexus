"""Execute release workflow preparation and fail-closed publication boundaries."""

import ast
from datetime import datetime, timedelta, timezone
import gzip
import hashlib
import io
import importlib.util
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import tarfile
import unittest.mock

import yaml

from tools.configure.metadata import load_policy

ROOT = Path(__file__).resolve().parents[2]
COMMIT = "a" * 40


def workflow():
    return yaml.load((ROOT / ".github/workflows/release.yml").read_text(),
                     Loader=yaml.BaseLoader)


def write_policy(source, version="0.1.0"):
    policy = json.loads((ROOT / "dependencies/platform-compatibility.json").read_text())
    policy["semantic_version"] = version
    destination = Path(source) / "dependencies/platform-compatibility.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(policy))
    return destination


def consumer_module():
    specification = importlib.util.spec_from_file_location(
        "release_consumer_fixture", ROOT / "cmake/package/verify_consumers.py")
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


class SDKWorkflowExecutionTests(unittest.TestCase):
    def test_actual_workflow_prepares_outside_checkout_then_stages_verified_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            source, temporary = base / "checkout", base / "runner temporary"
            (source / "cmake/package").mkdir(parents=True)
            (source / ".venv/bin").mkdir(parents=True)
            temporary.mkdir()
            (source / ".venv/bin/python").write_text(
                "#!/bin/sh\nexec " + shlex.quote(sys.executable) + ' "$@"\n')
            (source / ".venv/bin/python").chmod(0o755)
            # Package/consumer commands are external ports. The real staging
            # implementation, workflow shell and copied byte inventory execute.
            (source / "cmake/package/package_source_sdk.py").write_text(
                "import argparse,json\nfrom pathlib import Path\n"
                "p=argparse.ArgumentParser();p.add_argument('--source');"
                "p.add_argument('--output');p.add_argument('--verify');a=p.parse_args()\n"
                "if a.output:\n"
                " s=Path(a.source).resolve();o=Path(a.output).resolve()\n"
                " if o.is_relative_to(s):raise SystemExit('SDK output inside checkout')\n"
                " d=o/'share/nexus/src';d.mkdir(parents=True)\n"
                " (d/'payload').write_bytes(b'approved source bytes')\n"
                f" (d/'.nexus-source-sdk.json').write_text(json.dumps({{'source_revision': {COMMIT!r}, 'publishable': True, 'source_dirty': False}}))\n"
                "if a.verify:\n"
                " d=Path(a.verify)\n"
                " if (d/'payload').read_bytes()!=b'approved source bytes':raise SystemExit('changed payload')\n"
                " print((d/'.nexus-source-sdk.json').read_text())\n")
            (source / "cmake/package/verify_consumers.py").write_text(
                "import argparse,importlib.util,json,subprocess,sys\nfrom pathlib import Path\n"
                f"sys.path.insert(0, {str(ROOT)!r})\n"
                f"s=importlib.util.spec_from_file_location('consumer_fixture', {str(ROOT / 'cmake/package/verify_consumers.py')!r})\n"
                "m=importlib.util.module_from_spec(s);s.loader.exec_module(m)\n"
                "p=argparse.ArgumentParser();p.add_argument('--prefix');"
                "p.add_argument('--output');a=p.parse_args();o=Path(a.output)\n"
                "o.mkdir(parents=True)\n"
                "(o/'.nexus-sdk-consumer-check').write_text('owned SDK consumer verification\\n')\n"
                "from tools.release.transport import consumer_layout\n"
                "for source,build,images in consumer_layout():\n"
                " m.prepare_consumer(Path(a.prefix),o,source.removesuffix(' source'),lambda c: subprocess.run(c,check=True,capture_output=True),version='0.1.0')\n"
                " for image in images:\n"
                "  p=o/image;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'ELF external build port fixture')\n"
                "(o/'command-00.log').write_text('passed consumer command\\n')\n"
                f"(o/'verification.json').write_text(json.dumps({{'kind': 'source_sdk_consumer_verification', 'status': 'passed', 'source_revision': {COMMIT!r}, 'physical_status': 'not_executed', 'commands': [{{'argv': ['git','init'], 'exit_code': 0, 'log': 'command-00.log'}}]}}))\n")
            (source / "tools").mkdir()
            shutil.copytree(ROOT / "tools/release", source / "tools/release")
            (source / "tools/configure").mkdir()
            shutil.copyfile(ROOT / "tools/configure/metadata.py",
                            source / "tools/configure/metadata.py")
            for command in (["git", "init", "--quiet"],
                            ["git", "add", "tools/release/transport.py"],
                            ["git", "-c", "user.name=Fixture", "-c",
                             "user.email=fixture@example.invalid", "commit",
                             "--quiet", "-m", "Versioned transport builder"]):
                subprocess.run(command, cwd=source, check=True,
                               capture_output=True)
            builder = subprocess.check_output(["git", "rev-parse", "HEAD"],
                                              cwd=source, text=True).strip()
            environment = {**os.environ, "GITHUB_WORKSPACE": str(source),
                           "RUNNER_TEMP": str(temporary), "GITHUB_SHA": builder,
                           "NEXUS_EXPECTED_COMMIT": COMMIT}
            steps = workflow()["jobs"]["source-sdk"]["steps"]
            selected = [step for step in steps if step.get("run") and any(
                value in step["run"] for value in
                ("package_source_sdk.py", "verify_consumers.py",
                 "nexus-consumer-transport.py", "tools/release/delivery.py stage"))]
            self.assertGreaterEqual(len(selected), 3)
            for step in selected:
                result = subprocess.run(["bash", "-e", "-o", "pipefail", "-c", step["run"]],
                    cwd=source, env=environment, capture_output=True, text=True,
                    check=False, timeout=20)
                self.assertEqual(result.returncode, 0,
                                 step["name"] + ": " + result.stdout + result.stderr)
            staged = source / "build/delivery/source-sdk/share/nexus/src/payload"
            self.assertEqual(staged.read_bytes(), b"approved source bytes")
            self.assertTrue((source / "build/delivery/staging-copy.json").is_file())

    def test_workflow_keeps_source_checkout_and_names_separate_from_builder_signer(self):
        document = workflow()
        for job_name in ("guard", "source-sdk", "publish"):
            checkout = document["jobs"][job_name]["steps"][0]
            self.assertEqual(checkout["with"]["ref"],
                             "${{ inputs.expected_commit }}")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            calls = root / "calls.jsonl"
            gh = root / "gh"
            gh.write_text("#!" + sys.executable + "\nimport json,os,sys\n"
                "with open(os.environ['CALLS'],'a') as f: f.write(json.dumps(sys.argv[1:])+'\\n')\n"
                "print(json.dumps({'run_attempt':1}))\n")
            gh.chmod(0o755)
            environment = {**os.environ, "PATH": str(root) + os.pathsep + os.environ["PATH"],
                "CALLS": str(calls), "RUNNER_TEMP": str(root),
                "NEXUS_EXPECTED_COMMIT": COMMIT, "GITHUB_SHA": "b" * 40,
                "GITHUB_REF": "refs/heads/main", "GITHUB_RUN_ID": "321",
                "NEXUS_CI_RUN_ID": "123", "GH_REPO": "X-Gen-Lab/nexus"}
            steps = document["jobs"]["publish"]["steps"]
            for step in steps:
                if step.get("name", "").startswith(("Download this run", "Verify the actual GitHub")):
                    subprocess.run(["bash", "-e", "-o", "pipefail", "-c", step["run"]],
                        cwd=ROOT, env=environment, capture_output=True, check=True)
            observed = [json.loads(line) for line in calls.read_text().splitlines()]
            downloads = [call for call in observed if call[:2] == ["run", "download"]
                         and "--name" in call]
            self.assertEqual({call[call.index("--name") + 1] for call in downloads},
                {"nexus-source-sdk-" + COMMIT, "nexus-source-sdk-attestation-" + COMMIT,
                 "nexus-documentation-" + COMMIT})
            verify = next(call for call in observed if call[:2] == ["attestation", "verify"])
            self.assertEqual(verify[verify.index("--signer-digest") + 1], "b" * 40)
            self.assertEqual(verify[verify.index("--source-digest") + 1], "b" * 40)
            self.assertEqual(verify[verify.index("--source-ref") + 1],
                             "refs/heads/main")

    def test_workflow_guard_rejects_arbitrary_dispatch_refs(self):
        step = workflow()["jobs"]["guard"]["steps"][1]
        actual = subprocess.check_output(["git", "rev-parse", "HEAD"],
                                         cwd=ROOT, text=True).strip()
        for ref in ("refs/heads/main", "refs/heads/delivery/0.1.0",
                    "refs/heads/unreviewed", "refs/tags/v0.1.0",
                    "refs/heads/main/extra", "refs/heads/main-extra"):
            result = subprocess.run(["bash", "-e", "-o", "pipefail", "-c", step["run"]],
                cwd=ROOT, env={**os.environ, "GITHUB_REF": ref,
                    "NEXUS_EXPECTED_COMMIT": actual, "NEXUS_PUBLISH": "true",
                    "GITHUB_SHA": actual},
                capture_output=True, text=True)
            self.assertEqual(result.returncode == 0,
                             ref == "refs/heads/main")
        result = subprocess.run(["bash", "-e", "-o", "pipefail", "-c", step["run"]],
            cwd=ROOT, env={**os.environ, "GITHUB_REF": "refs/heads/main",
                "NEXUS_EXPECTED_COMMIT": actual, "NEXUS_PUBLISH": "false",
                "GITHUB_SHA": "b" * 40}, capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("exact workflow source commit", result.stderr)

    def test_guard_admits_only_exact_main_workflow_commit_before_source_code(self):
        step = workflow()["jobs"]["guard"]["steps"][1]
        actual = subprocess.check_output(["git", "rev-parse", "HEAD"],
                                         cwd=ROOT, text=True).strip()
        with tempfile.TemporaryDirectory() as directory:
            temporary = Path(directory)
            marker = temporary / "source-tool-called"
            python = temporary / "python3"
            python.write_text("#!/bin/sh\n" +
                'touch "$SOURCE_TOOL_MARKER"\nexec ' +
                shlex.quote(sys.executable) + ' "$@"\n')
            python.chmod(0o755)
            for publishing in ("true", "false"):
                for expected, builder, accepted in (
                        (actual, actual, True), (actual, "b" * 40, False),
                        ("", "", False), ("malformed", "malformed", False),
                        ("A" * 40, "A" * 40, False)):
                    marker.unlink(missing_ok=True)
                    result = subprocess.run(["bash", "-e", "-o", "pipefail", "-c", step["run"]],
                        cwd=ROOT, env={**os.environ, "GITHUB_REF": "refs/heads/main",
                            "PATH": str(temporary) + os.pathsep + os.environ["PATH"],
                            "SOURCE_TOOL_MARKER": str(marker), "GITHUB_SHA": builder,
                            "NEXUS_EXPECTED_COMMIT": expected, "NEXUS_PUBLISH": publishing},
                        capture_output=True, text=True, check=False, timeout=10)
                    with self.subTest(publish=publishing, expected=expected, builder=builder):
                        self.assertEqual(result.returncode == 0, accepted, result.stderr)
                        self.assertEqual(marker.exists(), accepted,
                                         "Untrusted source code ran before source admission")

    def test_source_sdk_admits_qualified_inputs_but_rejects_cancellation(self):
        condition = workflow()["jobs"]["source-sdk"]["if"]

        def admitted(publishing, results, cancelled=False):
            if not re.search(r"\b(?:always|success|failure|cancelled)\s*\(", condition):
                if any(result != "success" for result in results.values()):
                    return False
            expression = condition.replace("!cancelled()", str(not cancelled))
            expression = expression.replace("always()", "True")
            expression = expression.replace("inputs.publish", str(publishing))
            expression = re.sub(r"needs\.([\w-]+)\.result == '([\w]+)'",
                lambda match: str(results[match[1]] == match[2]), expression)
            expression = expression.replace("&&", "and").replace("||", "or")
            parsed = ast.parse(expression.strip(), mode="eval")
            self.assertTrue(all(isinstance(node, (ast.Expression, ast.BoolOp,
                ast.And, ast.Or, ast.Constant)) for node in ast.walk(parsed)))
            return eval(compile(parsed, "<workflow condition>", "eval"),
                        {"__builtins__": {}})

        qualified = {"guard": "success", "platform": "success", "contracts": "success"}
        reused = {**qualified, "platform": "skipped", "contracts": "skipped"}
        self.assertTrue(admitted(False, qualified))
        self.assertTrue(admitted(True, reused))
        self.assertFalse(admitted(False, reused))
        for publishing, results in ((False, qualified), (True, reused)):
            self.assertFalse(admitted(publishing, results, cancelled=True))
            for failure in ("failure", "cancelled", "skipped"):
                self.assertFalse(admitted(publishing, {**results, "guard": failure}))
        for job in ("platform", "contracts"):
            for failure in ("failure", "cancelled", "skipped"):
                self.assertFalse(admitted(False, {**qualified, job: failure}))

    def test_publisher_runs_after_qualified_sdk_with_skipped_transitive_jobs(self):
        document = workflow()["jobs"]
        condition = document["publish"]["if"].strip()
        condition = condition.removeprefix("${{").removesuffix("}}").strip()
        ancestors = set()

        def visit(job):
            dependencies = document[job].get("needs", [])
            if isinstance(dependencies, str):
                dependencies = [dependencies]
            for dependency in dependencies:
                if dependency not in ancestors:
                    ancestors.add(dependency)
                    visit(dependency)

        visit("publish")
        # Actual run 38686564636: direct dependencies succeeded, while reusable
        # qualification ancestors were deliberately skipped after full CI.
        observed = {job: "success" for job in ancestors}
        observed.update(platform="skipped", contracts="skipped")

        def admitted(publishing, results, cancelled=False):
            # GitHub adds success() when an expression has no status function;
            # skipped transitive dependencies then short-circuit the job.
            if not re.search(r"\b(?:always|success|failure|cancelled)\s*\(", condition):
                if any(results[job] != "success" for job in ancestors):
                    return False
            for term in re.split(r"\s*&&\s*", condition.strip()):
                if term == "always()":
                    continue
                if term == "!cancelled()":
                    if cancelled:
                        return False
                    continue
                if term == "inputs.publish":
                    if not publishing:
                        return False
                    continue
                comparison = re.fullmatch(r"needs\.([\w-]+)\.result == '([\w]+)'", term)
                self.assertIsNotNone(comparison, "Unsupported workflow condition")
                job, expected = comparison.groups()
                if results[job] != expected:
                    return False
            return True

        self.assertTrue(admitted(True, observed),
                        "Qualified SDK must reach publication despite skipped ancestors")
        self.assertFalse(admitted(False, observed))
        self.assertFalse(admitted(True, observed, cancelled=True),
                         "Manual cancellation must prevent publication")
        for job in ("guard", "source-sdk"):
            for result in ("failure", "cancelled", "skipped"):
                with self.subTest(job=job, result=result):
                    self.assertFalse(admitted(True, {**observed, job: result}))


class ConsumerTransportTests(unittest.TestCase):
    def test_lpdma_copy_identity_survives_current_policy(self):
        from tools.release import transport
        row = ("u575 lpdma copy",
               "tools/configure/assemblies/u575-lpdma-copy-stop2.toml",
               "u575-lpdma-copy")
        self.assertEqual(transport.CONSUMER_POLICY, "nexus-sdk-consumers-v8")
        self.assertIn(row, transport.SELECTED_CONSUMERS)
        self.assertEqual(transport.SELECTED_CONSUMERS.count(row), 1)
        self.assertIn("selected u575 lpdma copy source/.git", transport.FIXTURES)
        self.assertIn("selected u575 lpdma copy build/bin/installed_selected.elf",
                      transport.IMAGES)

    def test_lptim1_lpbam_has_exact_current_v8_consumer_identity(self):
        from tools.release import transport
        row = ("u575 lptim1 lpbam",
               "tools/configure/assemblies/u575-lptim1-lpbam-stop2.toml",
               "u575-lptim1-lpbam")
        self.assertEqual(transport.CONSUMER_POLICY, "nexus-sdk-consumers-v8")
        self.assertEqual(transport.SELECTED_CONSUMERS[-1], row)
        self.assertEqual(transport.SELECTED_CONSUMERS.count(row), 1)
        self.assertEqual(consumer_module().SELECTED_CONSUMERS[-1], row)
        self.assertIn("selected u575 lptim1 lpbam source/.git",
                      transport.FIXTURES)
        self.assertIn("selected u575 lptim1 lpbam "
                      "build/bin/installed_selected.elf", transport.IMAGES)

    def test_lptim1_selected_template_preserves_public_c11_source(self):
        module = consumer_module()
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            prefix = base / "prefix"
            sdk = prefix / "share/nexus/src"
            assembly = "tools/configure/assemblies/" \
                       "u575-lptim1-lpbam-stop2.toml"
            smoke = "cmake/package/verification/io_evolution/consumers/" \
                    "u575-lptim1-lpbam.c"
            for relative in (assembly, smoke):
                destination = sdk / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(ROOT / relative, destination)
            write_policy(sdk)
            source, _, command = module.prepare_selected_consumer(
                prefix, base, "u575 lptim1 lpbam", assembly,
                "u575-lptim1-lpbam", lambda argv: subprocess.run(
                    argv, check=True, capture_output=True),
                expected_revision=COMMIT)
            self.assertEqual((source / "main.c").read_bytes(),
                             (ROOT / smoke).read_bytes())
            cmake = (source / "CMakeLists.txt").read_text()
            self.assertIn("set(CMAKE_C_STANDARD 11)", cmake)
            self.assertIn("Nexus::U575Stop2Lptim1", cmake)
            self.assertIn("stm32u575_lpdma_lptim1_internal.h",
                          (source / "private_headers.c").read_text())
            # Preparing an actual template returns a configure command;
            # this transport boundary test never executes that command.
            self.assertIn("-DNEXUS_ASSEMBLY_FILE=" + str(sdk / assembly),
                          command)

    def test_missing_lptim1_raw_consumer_root_is_rejected(self):
        from tools.release import transport
        base, raw = self.fixture()
        shutil.rmtree(raw / "selected u575 lptim1 lpbam source")
        with self.assertRaisesRegex(ValueError, "Exact current consumer"):
            transport.pack(raw, base / "transport", COMMIT)

    def test_rehashed_transport_missing_lptim1_image_is_rejected(self):
        from tools.release import transport
        base, raw = self.fixture()
        output = base / "transport"
        transport.pack(raw, output, COMMIT)
        image = "selected u575 lptim1 lpbam " \
                "build/bin/installed_selected.elf"
        original = output / transport.ARCHIVE
        rewritten = base / "without-lptim1.tar.gz"
        removed = False
        with tarfile.open(original) as source:
            with tarfile.open(rewritten, "w:gz") as archive:
                for member in source:
                    if member.name == image:
                        removed = True
                        continue
                    archive.addfile(member, source.extractfile(member)
                                    if member.isfile() else None)
        self.assertTrue(removed)
        rewritten.replace(original)
        manifest_path = output / transport.MANIFEST
        manifest = json.loads(manifest_path.read_text())
        del manifest["files"][image]
        manifest["archive"] = transport.byte_identity(original)
        manifest_path.write_text(json.dumps(manifest))
        with self.assertRaisesRegex(ValueError,
                                    "Exact current consumer roots and images"):
            transport.verify(output, COMMIT)

    def test_complete_previous_v7_matrix_is_not_a_current_v8_fallback(self):
        from tools.release import transport
        base, raw = self.fixture()
        for suffix in ("source", "build"):
            shutil.rmtree(raw / ("selected u575 lptim1 lpbam " + suffix))
        self.assertEqual(len(list(raw.rglob(".git"))), 47)
        self.assertEqual(sum((raw / image).is_file()
                             for image in transport.IMAGES), 50)
        with self.assertRaisesRegex(ValueError, "Exact current consumer"):
            transport.pack(raw, base / "transport", COMMIT)

    def test_h743_duplex_modes_have_exact_independent_consumer_identities(self):
        from tools.release import transport
        expected = {
            ("h743 uart duplex continuous",
             "tools/configure/assemblies/h743-uart-duplex-continuous.toml",
             "h743-uart-duplex-continuous"),
            ("h743 uart duplex continuous cache on",
             "tools/configure/assemblies/h743-uart-duplex-continuous-cache-on.toml",
             "h743-uart-duplex-continuous"),
        }
        self.assertTrue(expected.issubset(set(transport.SELECTED_CONSUMERS)),
                        expected - set(transport.SELECTED_CONSUMERS))
        self.assertEqual(transport.CONSUMER_POLICY, "nexus-sdk-consumers-v8")
        for name, _, _ in expected:
            self.assertIn("selected " + name + " source/.git",
                          transport.FIXTURES)
            self.assertIn("selected " + name +
                          " build/bin/installed_selected.elf", transport.IMAGES)

    def fixture(self):
        prepare_consumer = consumer_module().prepare_consumer
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        base = Path(temporary.name)
        raw = base / "raw consumers"
        raw.mkdir()
        (raw / ".nexus-sdk-consumer-check").write_text(
            "owned SDK consumer verification\n")
        from tools.release.transport import consumer_layout
        for source, _, images in consumer_layout():
            prepare_consumer(base / "prefix", raw,
                source.removesuffix(" source"), lambda command: subprocess.run(
                    command, check=True, capture_output=True), version="0.1.0")
            # Only Git/transport execute here; firmware bytes are external ports.
            for image in images:
                target = raw / image
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(b"\x7fELF synthetic transport image\n")
        # Inventoried auxiliary outputs are not additional executable images.
        for name in ("stm32 build/bin/installed_c.bin",
                     "stm32 build/bin/installed_c.map",
                     "stm32 build/bin/installed_c.resources.json",
                     "selected h743 high build/bin/installed_selected.h743-flash-ram.compiler.raw",
                     "selected h743 high build/bin/installed_selected.h743-flash-ram.json"):
            (raw / name).write_bytes(b"auxiliary fixture; not SDK evidence\n")
        (raw / "command-00.log").write_bytes(b"actual consumer output\n")
        (raw / "verification.json").write_text(json.dumps({
            "kind": "source_sdk_consumer_verification", "status": "passed",
            "source_revision": COMMIT, "physical_status": "not_executed",
            "commands": [{"argv": ["git", "init"], "exit_code": 0,
                          "log": "command-00.log"}]}))
        return base, raw

    def test_real_consumer_git_metadata_survives_transport_and_identity_boundary(self):
        from tools.maintenance.job_identity import _inventory
        from tools.release import transport
        from tools.release.delivery import stage
        base, raw = self.fixture()
        (raw / "verification.json").chmod(0o600)
        (raw / "consumer.elf").write_bytes(b"\x7fELF consumer bytes")
        (raw / "consumer.elf").chmod(0o755)
        source = base / "checkout"
        source.mkdir()
        prefix = base / "prefix"
        payload = prefix / "share/nexus/src"
        payload.mkdir(parents=True)
        (payload / "payload").write_bytes(b"verified SDK")
        # SDK verification is an external port; the real stage and identity
        # inventory execute against the actual git-init consumer fixtures.
        with unittest.mock.patch("tools.release.delivery.verify_sdk"):
            stage(source, prefix, raw, source / "build/raw", COMMIT)
            with self.assertRaisesRegex(ValueError,
                    "artifact must remain inside the checkout"):
                _inventory(source, [source / "build/raw"],
                           source / "build/job-identities/raw")
            packed = base / "transport"
            transport.pack(raw, packed, COMMIT)
            # Actions normalizes outer artifact file permissions to 0644.
            # Original raw modes are evidence inside the immutable archive.
            for item in packed.iterdir():
                item.chmod(0o644)
            transport.verify(packed, COMMIT)
            stage(source, prefix, packed, source / "build/packed", COMMIT)
        selected, missing = _inventory(source, [source / "build/packed"],
                                      source / "build/job-identities/packed")
        self.assertTrue(selected)
        self.assertEqual(missing, [])
        transport.verify(packed, COMMIT)
        self.assertEqual((packed / "verification.json").read_bytes(),
                         (raw / "verification.json").read_bytes())
        with tarfile.open(packed / "consumer-raw.tar.gz") as archive:
            self.assertEqual(archive.getmember("verification.json").mode, 0o600)
            self.assertEqual(archive.getmember("consumer.elf").mode, 0o755)
            restored = {member.name: archive.extractfile(member).read()
                        for member in archive if member.isfile()}
        original = {path.relative_to(raw).as_posix(): path.read_bytes()
                    for path in raw.rglob("*") if path.is_file()}
        self.assertEqual(restored, original)
        self.assertEqual(len(list(raw.rglob(".git"))), 48)
        manifest = json.loads((packed / "consumer-raw-manifest.json").read_text())
        self.assertEqual(manifest["git_metadata"], "current_unborn_init_fixtures")
        self.assertEqual(manifest["consumer_roots"], sorted(transport.FIXTURES))
        self.assertEqual(manifest["consumer_images"], sorted(transport.IMAGES))

    def test_complete_current_consumer_matrix_crosses_transport(self):
        from tools.release import transport
        base, raw = self.fixture()
        manifest = transport.pack(raw, base / "transport", COMMIT)
        self.assertEqual(manifest["schema_version"], 2)
        self.assertEqual(transport.CONSUMER_POLICY, "nexus-sdk-consumers-v8")
        self.assertEqual(manifest["consumer_policy"], "nexus-sdk-consumers-v8")
        self.assertEqual(len(list(raw.rglob(".git"))), 48)
        self.assertEqual(len(manifest["consumer_images"]), 51)
        auxiliary = "stm32 build/bin/installed_c.bin"
        self.assertIn(auxiliary, manifest["files"])
        self.assertNotIn(auxiliary, manifest["consumer_images"])
        transport.verify(base / "transport", COMMIT)

    def test_each_current_root_and_image_is_required(self):
        from tools.release import transport
        base, raw = self.fixture()
        for name in sorted(transport.FIXTURES | transport.IMAGES):
            with self.subTest(name=name):
                target = raw / name
                saved = base / "withdrawn"
                target.rename(saved)
                try:
                    with self.assertRaisesRegex(ValueError, "Exact current"):
                        transport.pack(raw, base / "transport", COMMIT)
                finally:
                    saved.rename(target)

    def test_equal_count_root_substitution_and_report_claim_cannot_authorize_it(self):
        from tools.release import transport
        for change in ("replace", "extra", "zero-image", "extra-image"):
            with self.subTest(change=change):
                base, raw = self.fixture()
                if change == "zero-image":
                    (raw / "selected native time pair build/bin/installed_selected").write_bytes(b"")
                elif change == "extra-image":
                    (raw / "stm32 build/bin/unreviewed.elf").write_bytes(
                        b"\x7fELF unreviewed fixture")
                else:
                    original = raw / "selected g474 shared pwm source"
                    if change == "replace":
                        original.rename(raw / "unreviewed source")
                    else:
                        consumer_module().prepare_consumer(base / "prefix", raw,
                            "unreviewed", lambda command: subprocess.run(
                                command, check=True, capture_output=True),
                            version="0.1.0")
                report_path = raw / "verification.json"
                report = json.loads(report_path.read_text())
                report["consumer_roots"] = ["unreviewed source/.git"]
                report["consumer_images"] = ["unreviewed build/bin/image"]
                report_path.write_text(json.dumps(report))
                with self.assertRaisesRegex(ValueError, "Exact current"):
                    transport.pack(raw, base / "transport", COMMIT)

    def test_old_thirteen_roots_are_not_a_current_fallback(self):
        from tools.release import transport
        base, raw = self.fixture()
        for name, _, _ in consumer_module().SELECTED_CONSUMERS:
            shutil.rmtree(raw / ("selected " + name + " source"))
            shutil.rmtree(raw / ("selected " + name + " build"))
        self.assertEqual(len(list(raw.rglob(".git"))), 13)
        with self.assertRaisesRegex(ValueError, "Exact current"):
            transport.pack(raw, base / "transport", COMMIT)

    def test_schema_and_manifest_claims_cannot_reduce_or_expand_the_plan(self):
        from tools.release import transport
        for change in ("legacy", "missing-schema", "float-schema", "policy",
                       "roots", "images"):
            with self.subTest(change=change):
                base, raw = self.fixture()
                output = base / "transport"
                transport.pack(raw, output, COMMIT)
                path = output / "consumer-raw-manifest.json"
                manifest = json.loads(path.read_text())
                if change == "legacy":
                    manifest["schema_version"] = 1
                    manifest["git_metadata"] = "thirteen_unborn_init_fixtures"
                elif change == "missing-schema":
                    del manifest["schema_version"]
                elif change == "float-schema":
                    manifest["schema_version"] = 2.0
                else:
                    key = "consumer_" + change
                    manifest[key] = "invented" if change == "policy" else []
                path.write_text(json.dumps(manifest))
                with self.assertRaisesRegex(ValueError, "policy claim"):
                    transport.verify(output, COMMIT)

    def test_standalone_extracted_transport_has_no_checkout_import_dependency(self):
        from tools.release import transport
        base, raw = self.fixture()
        helper = base / "standalone.py"
        helper.write_bytes((ROOT / "tools/release/transport.py").read_bytes())
        environment = dict(os.environ)
        environment.pop("PYTHONPATH", None)
        result = subprocess.run([sys.executable, "-B", str(helper), "pack",
            "--raw", str(raw), "--output", str(base / "transport"),
            "--expected-commit", COMMIT], cwd=base, env=environment,
            capture_output=True, text=True, timeout=20)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        transport.verify(base / "transport", COMMIT)

    def test_rehashed_archive_git_state_and_missing_image_are_still_rejected(self):
        from tools.release import transport
        contamination = (("config", b"[remote \"origin\"]\nurl=secret\n"),
                         ("index", b"tracked index"),
                         ("objects/ab/object", b"history"),
                         ("refs/heads/main", b"a" * 40),
                         ("logs/HEAD", b"history"),
                         ("commondir", b"../foreign"),
                         ("hooks/pre-commit", b"active hook"),
                         ("image", None))
        for relative, data in contamination:
            with self.subTest(relative=relative):
                base, raw = self.fixture()
                output = base / "transport"
                transport.pack(raw, output, COMMIT)
                name = ("selected native time empty build/bin/installed_selected"
                        if relative == "image" else "native source/.git/" + relative)
                manifest_path = output / "consumer-raw-manifest.json"
                manifest = json.loads(manifest_path.read_text())
                original = output / "consumer-raw.tar.gz"
                rewritten = base / "changed.tar.gz"
                replaced = False
                with tarfile.open(original) as source:
                    with tarfile.open(rewritten, "w:gz") as archive:
                        for member in source:
                            if member.name == name:
                                replaced = True
                                if data is None:
                                    continue
                                member.size = len(data)
                                archive.addfile(member, io.BytesIO(data))
                            else:
                                archive.addfile(member, source.extractfile(member)
                                                if member.isfile() else None)
                        if not replaced:
                            member = tarfile.TarInfo(name)
                            member.size, member.mode = len(data), 0o600
                            archive.addfile(member, io.BytesIO(data))
                rewritten.replace(original)
                if data is None:
                    del manifest["files"][name]
                else:
                    manifest["files"][name] = {"size": len(data),
                        "sha256": hashlib.sha256(data).hexdigest(),
                        "mode": manifest["files"].get(name, {}).get("mode", 0o600)}
                manifest["archive"] = transport.byte_identity(original)
                manifest_path.write_text(json.dumps(manifest))
                with self.assertRaises(ValueError):
                    transport.verify(output, COMMIT)

    def test_gzip_trailer_is_verified_even_with_rehashed_archive_identity(self):
        from tools.release import transport
        for change in ("crc", "size", "truncated", "trailing", "concatenated",
                       "tar-tail", "second-tar", "invalid-end-header",
                       "short-end-header"):
            with self.subTest(change=change):
                base, raw = self.fixture()
                output = base / "transport"
                transport.pack(raw, output, COMMIT)
                archive = output / "consumer-raw.tar.gz"
                data = bytearray(archive.read_bytes())
                if change == "truncated":
                    data = data[:-5]
                elif change == "trailing":
                    data += b"unexpected compressed tail"
                elif change == "concatenated":
                    data += gzip.compress(b"second member")
                elif change in {"invalid-end-header", "short-end-header"}:
                    plain = gzip.decompress(data)
                    with tarfile.open(fileobj=io.BytesIO(plain)) as parsed:
                        end = max(member.offset_data +
                                  ((member.size + 511) // 512) * 512
                                  for member in parsed)
                    self.assertEqual(plain[end:end + 512], b"\0" * 512)
                    if change == "invalid-end-header":
                        plain = plain[:end] + b"x" * 512 + plain[end + 512:]
                    else:
                        plain = plain[:end] + b"truncated nonzero header"
                    data = gzip.compress(plain)
                elif change in {"tar-tail", "second-tar"}:
                    tail = b"unregistered payload"
                    if change == "second-tar":
                        stream = io.BytesIO()
                        with tarfile.open(fileobj=stream, mode="w") as following:
                            member = tarfile.TarInfo("unregistered")
                            member.size = len(tail)
                            following.addfile(member, io.BytesIO(tail))
                        tail = stream.getvalue()
                    data = gzip.compress(gzip.decompress(data) + tail)
                else:
                    data[-8 if change == "crc" else -4] ^= 1
                archive.write_bytes(data)
                manifest_path = output / "consumer-raw-manifest.json"
                manifest = json.loads(manifest_path.read_text())
                manifest["archive"] = transport.byte_identity(archive)
                manifest_path.write_text(json.dumps(manifest))
                with self.assertRaises((ValueError, OSError, EOFError)):
                    transport.verify(output, COMMIT)

    def test_zero_tar_padding_is_valid_but_gzip_expansion_is_bounded(self):
        from tools.release import transport
        base, raw = self.fixture()
        output = base / "transport"
        transport.pack(raw, output, COMMIT)
        archive = output / "consumer-raw.tar.gz"
        archive.write_bytes(gzip.compress(
            gzip.decompress(archive.read_bytes()) + b"\0" * 1024))
        path = output / "consumer-raw-manifest.json"
        manifest = json.loads(path.read_text())
        manifest["archive"] = transport.byte_identity(archive)
        path.write_text(json.dumps(manifest))
        transport.verify(output, COMMIT)
        compressed = base / "expanded.gz"
        compressed.write_bytes(gzip.compress(b"\0" * 16384))
        with unittest.mock.patch.multiple(transport, MAX_BYTES=1, MAX_FILES=1):
            with self.assertRaisesRegex(ValueError, "Expanded transport archive"):
                transport.verify_gzip(compressed)

    def test_missing_each_new_consumer_fixture_is_rejected(self):
        from tools.release import transport
        for family in ("f103", "gd303", "g474"):
            for backend in ("baremetal", "freertos"):
                with self.subTest(family=family, backend=backend):
                    base, raw = self.fixture()
                    shutil.rmtree(raw / (family + " " + backend + " source"))
                    with self.assertRaisesRegex(ValueError, "Exact current consumer"):
                        transport.pack(raw, base / "transport", COMMIT)

    def test_legacy_seven_consumer_set_is_not_a_current_transport_fallback(self):
        from tools.release import transport
        base, raw = self.fixture()
        for family in ("f103", "gd303", "g474"):
            for backend in ("baremetal", "freertos"):
                shutil.rmtree(raw / (family + " " + backend + " source"))
        for name, _, _ in consumer_module().SELECTED_CONSUMERS:
            shutil.rmtree(raw / ("selected " + name + " source"))
        with self.assertRaisesRegex(ValueError, "Exact current consumer"):
            transport.pack(raw, base / "transport", COMMIT)

    def test_previous_thirty_one_roots_cannot_replace_the_current_plan(self):
        from tools.release import transport
        base, raw = self.fixture()
        for label in ("h743 spi dma", "h743 spi dma uart tx",
                      "h743 spi dma uart rx",
                      "h743 runtime clock", "g474 pin states",
                      "h743 spi dma cache on", "u575 uart chain",
                      "u575 lptim run",
                      "h743 uart continuous", "h743 uart continuous cache on",
                      "h743 uart duplex continuous",
                      "h743 uart duplex continuous cache on", "u575 rtc run",
                      "u575 retained time", "u575 stop2", "u575 lpdma copy",
                      "u575 lptim1 lpbam"):
            shutil.rmtree(raw / ("selected " + label + " source"))
            shutil.rmtree(raw / ("selected " + label + " build"))
        self.assertEqual(len(list(raw.rglob(".git"))), 31)
        with self.assertRaisesRegex(ValueError, "Exact current consumer"):
            transport.pack(raw, base / "transport", COMMIT)

    def test_previous_thirty_six_roots_cannot_replace_the_current_plan(self):
        from tools.release import transport
        base, raw = self.fixture()
        for label in ("h743 spi dma cache on", "u575 uart chain",
                      "u575 lptim run",
                      "h743 uart continuous", "h743 uart continuous cache on",
                      "h743 uart duplex continuous",
                      "h743 uart duplex continuous cache on", "u575 rtc run",
                      "u575 retained time", "u575 stop2", "u575 lpdma copy",
                      "u575 lptim1 lpbam"):
            shutil.rmtree(raw / ("selected " + label + " source"))
            shutil.rmtree(raw / ("selected " + label + " build"))
        self.assertEqual(len(list(raw.rglob(".git"))), 36)
        with self.assertRaisesRegex(ValueError, "Exact current consumer"):
            transport.pack(raw, base / "transport", COMMIT)

    def test_schema_two_previous_policy_is_not_a_current_fallback(self):
        from tools.release import transport
        for policy in ("nexus-sdk-consumers-v2", "nexus-sdk-consumers-v3",
                       "nexus-sdk-consumers-v4", "nexus-sdk-consumers-v5",
                       "nexus-sdk-consumers-v6", "nexus-sdk-consumers-v7"):
            with self.subTest(policy=policy):
                base, raw = self.fixture()
                packed = base / "transport"
                transport.pack(raw, packed, COMMIT)
                path = packed / transport.MANIFEST
                manifest = json.loads(path.read_text())
                self.assertEqual(manifest["schema_version"], 2)
                archive = packed / transport.ARCHIVE
                archive.write_bytes(gzip.compress(
                    gzip.decompress(archive.read_bytes()), mtime=1))
                self.assertNotEqual(manifest["archive"],
                                    transport.byte_identity(archive))
                # Rehashing valid raw bytes cannot authorize an old plan policy.
                manifest["archive"] = transport.byte_identity(archive)
                manifest["consumer_policy"] = policy
                path.write_text(json.dumps(manifest))
                with self.assertRaisesRegex(ValueError,
                                            "current consumer policy"):
                    transport.verify(packed, COMMIT)

    def test_unreviewed_consumer_root_is_rejected(self):
        from tools.release import transport
        base, raw = self.fixture()
        consumer_module().prepare_consumer(base / "prefix", raw,
            "unreviewed baremetal", lambda command: subprocess.run(command,
                check=True, capture_output=True), version="0.1.0")
        with self.assertRaisesRegex(ValueError, "Exact current consumer"):
            transport.pack(raw, base / "transport", COMMIT)

    def test_manifest_cannot_describe_seven_fixtures_for_current_raw_bytes(self):
        from tools.release import transport
        base, raw = self.fixture()
        output = base / "transport"
        transport.pack(raw, output, COMMIT)
        manifest_path = output / "consumer-raw-manifest.json"
        manifest = json.loads(manifest_path.read_text())
        manifest["git_metadata"] = "seven_unborn_init_fixtures"
        manifest_path.write_text(json.dumps(manifest))
        with self.assertRaises(ValueError):
            transport.verify(output, COMMIT)

    def test_rejects_links_overlap_existing_output_and_unowned_raw(self):
        from tools.release import transport
        for change in ("symlink", "overlap", "existing", "unowned", "hardlink"):
            with self.subTest(change=change):
                base, raw = self.fixture()
                output = base / "transport"
                if change == "symlink":
                    (raw / "linked").symlink_to(raw / "verification.json")
                elif change == "overlap":
                    output = raw / "transport"
                elif change == "existing":
                    output.mkdir()
                elif change == "unowned":
                    (raw / ".nexus-sdk-consumer-check").unlink()
                else:
                    os.link(raw / "verification.json", raw / "hardlinked")
                with self.assertRaises(ValueError):
                    transport.pack(raw, output, COMMIT)

    def test_git_metadata_must_remain_empty_init_fixture(self):
        from tools.release import transport
        for name, contents in (("config", "[remote \"origin\"]\nurl=secret\n"),
                               ("index", "tracked index"),
                               ("objects/ab/object", "history"),
                               ("hooks/pre-commit", "active hook")):
            with self.subTest(name=name):
                base, raw = self.fixture()
                path = raw / "native source/.git" / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(contents)
                with self.assertRaises(ValueError):
                    transport.pack(raw, base / "transport", COMMIT)

    def test_modified_report_archive_traversal_and_duplicate_entries_are_rejected(self):
        from tools.release import transport
        for change in ("report", "traversal", "duplicate", "archive-link", "mode"):
            with self.subTest(change=change):
                base, raw = self.fixture()
                output = base / "transport"
                transport.pack(raw, output, COMMIT)
                if change == "report":
                    (output / "verification.json").write_text("{}")
                elif change == "mode":
                    rewritten = base / "modified.tar.gz"
                    with tarfile.open(output / "consumer-raw.tar.gz") as original:
                        with tarfile.open(rewritten, "w:gz") as archive:
                            for entry in original:
                                if entry.name == "verification.json":
                                    entry.mode ^= 1
                                archive.addfile(entry, original.extractfile(entry)
                                                if entry.isfile() else None)
                    rewritten.replace(output / "consumer-raw.tar.gz")
                else:
                    with tarfile.open(output / "consumer-raw.tar.gz", "w:gz") as archive:
                        for _ in range(2 if change == "duplicate" else 1):
                            entry = tarfile.TarInfo("../escape" if
                                change == "traversal" else "verification.json")
                            if change == "archive-link":
                                entry.type, entry.linkname = tarfile.SYMTYPE, "../escape"
                                archive.addfile(entry)
                            elif change == "duplicate":
                                entry.size = (raw / "verification.json").stat().st_size
                                with (raw / "verification.json").open("rb") as stream:
                                    archive.addfile(entry, stream)
                            else:
                                archive.addfile(entry)
                if change != "report":
                    manifest = json.loads((output / "consumer-raw-manifest.json").read_text())
                    manifest["archive"] = {key: value for key, value in
                        transport.identity(output / "consumer-raw.tar.gz").items()
                        if key in {"sha256", "size"}}
                    (output / "consumer-raw-manifest.json").write_text(json.dumps(manifest))
                expected = {"report": "report|Passed strict", "traversal": "Unsafe transport member",
                            "duplicate": "Duplicate", "archive-link": "nonregular",
                            "mode": "complete raw inventory"}[change]
                with self.assertRaisesRegex(ValueError, expected):
                    transport.verify(output, COMMIT)

    def test_failed_source_mismatched_or_unbounded_raw_evidence_is_rejected(self):
        from tools.release import transport
        for change in ("source", "command", "count", "bytes"):
            with self.subTest(change=change):
                base, raw = self.fixture()
                report = json.loads((raw / "verification.json").read_text())
                if change == "source":
                    report["source_revision"] = "b" * 40
                elif change == "command":
                    report["commands"][0]["exit_code"] = 1
                (raw / "verification.json").write_text(json.dumps(report))
                limits = {"MAX_FILES": 2 if change == "count" else transport.MAX_FILES,
                          "MAX_BYTES": 2 if change == "bytes" else transport.MAX_BYTES}
                with unittest.mock.patch.multiple(transport, **limits):
                    with self.assertRaises(ValueError):
                        transport.pack(raw, base / "transport", COMMIT)

    def builder_fixture(self, version="0.1.0"):
        from tools.release import transport
        base, raw = self.fixture()
        source = base / "source"
        write_policy(source, version)
        inputs = base / "inputs"
        packed = inputs / "sdk/delivery/sdk-consumers"
        transport.pack(raw, packed, COMMIT)
        sdk_source = inputs / "sdk/delivery/source-sdk/share/nexus/src"
        write_policy(sdk_source, version)
        output = base / "assets"
        output.mkdir()
        evidence = output / "source-sdk-identity.json"
        evidence.write_bytes(b"original C identity")
        manifest = {"source_commit": COMMIT, "tag": "v" + version,
            "source_sdk_run_id": 321, "assets": [{"name": evidence.name,
                "size": evidence.stat().st_size,
                "sha256": hashlib.sha256(evidence.read_bytes()).hexdigest()}]}
        (output / "release-manifest.json").write_text(json.dumps(manifest))
        return source, inputs, output

    def test_builder_receipt_extends_exact_release_closure_without_rewriting_source(self):
        from tools.release import transport
        for version in ("0.1.0", "0.2.0"):
            source, inputs, output = self.builder_fixture(version)
            workflow_ref = "X-Gen-Lab/nexus/.github/workflows/release.yml@refs/heads/main"
            with unittest.mock.patch.object(Path, "cwd", return_value=source):
                transport.attach(output, inputs, COMMIT, "b" * 40,
                                 workflow_ref, 321, 1)
            receipt = json.loads((output / "delivery-workflow.json").read_text())
            self.assertEqual(receipt["source_commit"], COMMIT)
            self.assertEqual(receipt["builder_commit"], "b" * 40)
            self.assertEqual(receipt["builder_workflow_ref"], workflow_ref)
            self.assertEqual(receipt["release_run_id"], 321)
            self.assertFalse("original_failed_run_id" in receipt)
            evidence = output / "source-sdk-identity.json"
            self.assertEqual(evidence.read_bytes(), b"original C identity")
            extended = json.loads((output / "release-manifest.json").read_text())
            self.assertEqual({item["name"] for item in extended["assets"]},
                             {"delivery-workflow.json", evidence.name})

    def test_actual_workflow_attaches_versioned_helper_from_separate_builder(self):
        source, inputs, output = self.builder_fixture("0.2.0")
        temporary = inputs.parent / "runner temporary"
        temporary.mkdir()
        inputs.rename(temporary / "release-inputs")
        output.rename(temporary / "release-assets")
        for relative in ("tools/release/transport.py", "tools/configure/metadata.py"):
            destination = source / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / relative, destination)
        for command in (["git", "init", "--quiet"], ["git", "add", "tools"],
                        ["git", "-c", "user.name=Fixture", "-c",
                         "user.email=fixture@example.invalid", "commit", "--quiet",
                         "-m", "Versioned source policy and transport builder"]):
            subprocess.run(command, cwd=source, check=True, capture_output=True)
        builder = subprocess.check_output(["git", "rev-parse", "HEAD"],
                                          cwd=source, text=True).strip()
        workflow_ref = "X-Gen-Lab/nexus/.github/workflows/release.yml@refs/heads/main"
        step = next(step for step in workflow()["jobs"]["publish"]["steps"]
                    if step.get("name", "").startswith("Disclose the separate"))
        result = subprocess.run(["bash", "-e", "-o", "pipefail", "-c", step["run"]],
            cwd=source, env={**os.environ, "GITHUB_WORKSPACE": str(source),
                "RUNNER_TEMP": str(temporary), "NEXUS_EXPECTED_COMMIT": COMMIT,
                "GITHUB_SHA": builder, "GITHUB_WORKFLOW_REF": workflow_ref,
                "GITHUB_RUN_ID": "321", "GITHUB_RUN_ATTEMPT": "1"},
            capture_output=True, text=True, check=False, timeout=20)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        receipt = json.loads((temporary / "release-assets/delivery-workflow.json").read_text())
        self.assertEqual(receipt["source_commit"], COMMIT)
        self.assertEqual(receipt["builder_commit"], builder)
        self.assertEqual(receipt["builder_workflow_ref"], workflow_ref)
        helper = temporary / "nexus-consumer-transport.py"
        self.assertEqual(receipt["transport_helper_sha256"],
                         hashlib.sha256(helper.read_bytes()).hexdigest())

    def test_receipt_rejects_unauthorized_refs_and_policy_tag_or_sdk_mismatch(self):
        from tools.release import transport
        for change in ("delivery-ref", "arbitrary-ref", "tag-ref", "near-main",
                       "manifest-tag", "source", "run", "sdk", "duplicate-policy"):
            source, inputs, output = self.builder_fixture()
            workflow_ref = "X-Gen-Lab/nexus/.github/workflows/release.yml@refs/heads/main"
            source_commit, run_id = COMMIT, 321
            if change.endswith("ref") or change == "near-main":
                workflow_ref = workflow_ref.removesuffix("refs/heads/main") + {
                    "delivery-ref": "refs/heads/delivery/0.1.0",
                    "arbitrary-ref": "refs/heads/unreviewed",
                    "tag-ref": "refs/tags/v0.1.0",
                    "near-main": "refs/heads/main/extra"}[change]
            elif change == "manifest-tag":
                path = output / "release-manifest.json"
                manifest = json.loads(path.read_text())
                manifest["tag"] = "v0.2.0"
                path.write_text(json.dumps(manifest))
            elif change == "source":
                source_commit = "c" * 40
            elif change == "run":
                run_id = 322
            elif change == "sdk":
                write_policy(inputs / "sdk/delivery/source-sdk/share/nexus/src", "0.2.0")
            else:
                policy = source / "dependencies/platform-compatibility.json"
                policy.write_text(policy.read_text().replace(
                    '{', '{"semantic_version":"0.1.0",', 1))
            original = (output / "release-manifest.json").read_bytes()
            with self.subTest(change=change):
                with unittest.mock.patch.object(Path, "cwd", return_value=source), \
                        self.assertRaises(ValueError):
                    transport.attach(output, inputs, source_commit, "b" * 40,
                                     workflow_ref, run_id, 1)
                self.assertEqual((output / "release-manifest.json").read_bytes(), original)
                self.assertFalse((output / "delivery-workflow.json").exists())


class ReleaseVersionTests(unittest.TestCase):
    def run_record(self):
        return ReleaseAdmissionTests.run_record(self)

    def jobs_record(self):
        return ReleaseAdmissionTests.jobs_record(self)

    def fixture(self, version="0.2.0"):
        from tools.evidence.identity import canonical_digest
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        source, inputs, output = root / "source", root / "inputs", root / "assets"
        write_policy(source, version)
        sdk_source = inputs / "sdk/delivery/source-sdk/share/nexus/src"
        write_policy(sdk_source, version)
        (sdk_source / ".nexus-source-sdk.json").write_text(json.dumps({
            "source_revision": COMMIT, "publishable": True, "source_dirty": False}))
        checks = inputs / "sdk/delivery/sdk-consumers"
        checks.mkdir(parents=True)
        (checks / "verification.json").write_text(json.dumps({
            "kind": "source_sdk_consumer_verification", "status": "passed",
            "source_revision": COMMIT, "physical_status": "not_executed"}))
        (checks / "raw.log").write_bytes(b"actual raw consumer bytes")
        (inputs / "sdk/delivery/staging-copy.json").write_text("{}")
        for name in ("ci-evidence", "attestation/delivery/attestation"):
            (inputs / name).mkdir(parents=True)
            (inputs / name / "bundle.json").write_text("{}")
        admission = ReleaseAdmissionTests()
        (inputs / "ci-run.json").write_text(json.dumps(admission.run_record()))
        (inputs / "ci-jobs.json").write_text(json.dumps(admission.jobs_record()))
        docs = inputs / "docs/documentation-package"
        docs.mkdir(parents=True)
        (docs / "documentation.tar.gz").write_bytes(b"verified documentation archive")
        payload = docs / "release-documentation"
        payload.mkdir()
        (payload / "manifest.json").write_text("{}")
        for job, run_id, relative in (("source-sdk", 321,
                "sdk/job-identities/source-sdk/identity.json"),
                ("documentation", 123, "docs/docs-job-identity/identity.json")):
            record = {"kind": "ci_job_identity", "job": job,
                "job_result": "success", "source": {"dirty": False, "commit": COMMIT},
                "run": {"GITHUB_RUN_ID": str(run_id), "GITHUB_RUN_ATTEMPT": "1"},
                "missing_artifacts": [], "artifacts": []}
            artifact = (inputs / "sdk/delivery/staging-copy.json" if job == "source-sdk"
                        else docs / "documentation.tar.gz")
            record["artifacts"] = [{"relative_path": "build/" + (
                "delivery/staging-copy.json" if job == "source-sdk" else
                "documentation-package/documentation.tar.gz"),
                "size": artifact.stat().st_size,
                "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest()}]
            record["record_sha256"] = canonical_digest(record)
            path = inputs / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(record))
        documentation = {"documentation_source": {"commit": COMMIT},
            "code_source": {"commit": COMMIT}, "version": version,
            "release_id": payload.name}
        return source, inputs, output, documentation

    def run_bundle(self, source, inputs, output, documentation):
        from tools.release.delivery import bundle
        from tools.documentation import delivery as documentation_delivery
        # Source SDK/package and documentation verification are external tool
        # ports. Release admission, identities, archive bytes and closure run.
        with unittest.mock.patch("tools.release.delivery.verify_sdk"), \
                unittest.mock.patch.object(documentation_delivery, "verify",
                                            return_value=documentation), \
                unittest.mock.patch.object(documentation_delivery, "MANIFEST",
                                            "manifest.json"):
            bundle(source, inputs, output, COMMIT, 123, 321, 1)

    def test_bundle_uses_policy_version_for_tag_archives_and_preserved_bytes(self):
        source, inputs, output, documentation = self.fixture()
        self.run_bundle(source, inputs, output, documentation)
        manifest = json.loads((output / "release-manifest.json").read_text())
        self.assertEqual(manifest["tag"], "v0.2.0")
        self.assertEqual(manifest["evidence_layout"]["sdk_archive_root"],
                         "nexus-source-sdk-0.2.0")
        self.assertEqual(manifest["evidence_layout"]["raw_records"],
                         "nexus-verification-evidence-0.2.0.tar.gz")
        with tarfile.open(output / "nexus-source-sdk-0.2.0.tar.gz") as archive:
            policy = archive.extractfile("nexus-source-sdk-0.2.0/share/nexus/src/"
                                         "dependencies/platform-compatibility.json").read()
            self.assertEqual(policy, (inputs / "sdk/delivery/source-sdk/share/nexus/src/"
                                     "dependencies/platform-compatibility.json").read_bytes())
        with tarfile.open(output / manifest["evidence_layout"]["raw_records"]) as archive:
            self.assertEqual(archive.extractfile("sdk/delivery/sdk-consumers/raw.log").read(),
                             b"actual raw consumer bytes")

    def test_bundle_rejects_documentation_or_sdk_version_mismatch_before_output(self):
        for change in ("documentation", "sdk"):
            source, inputs, output, documentation = self.fixture()
            if change == "documentation":
                documentation["version"] = "0.1.0"
            else:
                write_policy(inputs / "sdk/delivery/source-sdk/share/nexus/src")
            with self.subTest(change=change), self.assertRaisesRegex(ValueError, "version"):
                self.run_bundle(source, inputs, output, documentation)
            self.assertFalse(output.exists())

    def test_publisher_uses_source_policy_for_tag_title_and_body(self):
        from tools.release import delivery
        source, inputs, output, documentation = self.fixture()
        root, api = ReleaseAdmissionTests.publisher_fixture(self, "0.2.0")
        delivery.publish(root, COMMIT, 123, api=api, source=source)
        created = api.create.call_args.args[0]
        self.assertEqual(created["tag_name"], "v0.2.0")
        self.assertEqual(created["name"], "Nexus 0.2.0 software preview")
        self.assertIn("Nexus 0.2.0", created["body"])
        paths = [call.args[0] for call in api.get.call_args_list]
        self.assertIn("/git/ref/tags/v0.2.0", paths)
        self.assertIn("/releases/tags/v0.2.0", paths)
        api.publish.assert_called_once_with(5)

    def test_source_policy_tag_mismatch_prevents_any_publisher_api(self):
        from tools.release import delivery
        source, inputs, output, documentation = self.fixture()
        root, api = ReleaseAdmissionTests.publisher_fixture(self, "0.1.0")
        with self.assertRaisesRegex(ValueError, "source/tag mismatch"):
            delivery.publish(root, COMMIT, 123, api=api, source=source)
        self.assertEqual(api.mock_calls, [])

    def test_malformed_policy_prevents_bundling_or_any_publisher_api(self):
        from tools.release import delivery
        for change in ("duplicate", "unknown", "version", "schema", "symlink"):
            source, inputs, output, documentation = self.fixture("0.1.0")
            policy = source / "dependencies/platform-compatibility.json"
            contents = policy.read_text()
            if change == "duplicate":
                policy.write_text(contents.replace('{', '{"semantic_version":"0.1.0",', 1))
            elif change == "symlink":
                policy.rename(policy.with_suffix(".real"))
                policy.symlink_to(policy.with_suffix(".real"))
            else:
                value = json.loads(contents)
                value.update({"unknown": True} if change == "unknown" else
                             {"semantic_version": "01.2.0"} if change == "version" else
                             {"schema_version": True})
                policy.write_text(json.dumps(value))
            with self.subTest(change=change, operation="bundle"):
                with self.assertRaises(ValueError):
                    self.run_bundle(source, inputs, output, documentation)
                self.assertFalse(output.exists())
            root, api = ReleaseAdmissionTests.publisher_fixture(self, "0.1.0")
            with self.subTest(change=change, operation="publish"):
                with self.assertRaises(ValueError):
                    delivery.publish(root, COMMIT, 123, api=api, source=source)
                self.assertEqual(api.mock_calls, [])


class ReleaseAdmissionTests(unittest.TestCase):
    def run_record(self):
        return {"id": 123, "run_attempt": 1, "path": ".github/workflows/ci.yml",
                "event": "workflow_dispatch", "head_sha": COMMIT,
                "status": "completed", "conclusion": "success",
                "head_branch": "main", "created_at": datetime.now(
                    timezone.utc).isoformat(), "html_url": "https://example.invalid/run/123"}

    def jobs_record(self):
        document = yaml.load((ROOT / ".github/workflows/ci.yml").read_text(),
                             Loader=yaml.BaseLoader)
        names = []
        for job in document["jobs"].values():
            if "uses" not in job:
                names.append(job["name"])
                continue
            called = yaml.load((ROOT / job["uses"]).read_text(),
                               Loader=yaml.BaseLoader)
            for item in called["jobs"].values():
                matrix = item.get("strategy", {}).get("matrix", {})
                if matrix:
                    key, values = next(iter(matrix.items()))
                    names.extend(item["name"].replace("${{ matrix." + key + " }}", value)
                                 for value in values)
                else:
                    names.append(item["name"])
        return {"total_count": len(names), "jobs": [{"name": name,
                "status": "completed", "conclusion": "success"} for name in names]}

    def test_ci_requires_complete_successful_domains_and_matrix(self):
        from tools.release.delivery import require_jobs
        valid = self.jobs_record()
        require_jobs(valid)
        for name in ("Build Docs", "Native contracts (native-tsan)",
                     "ARM link and budgets (stm32-sky-baremetal)",
                     "Provider assembly audits (h743_assembly)",
                     "Provider assembly audits (mainstream_assembly)"):
            jobs = [job for job in valid["jobs"] if job["name"] != name]
            with self.subTest(name=name), self.assertRaises(ValueError):
                require_jobs({"total_count": len(jobs), "jobs": jobs})
        substituted = self.jobs_record()
        for job in substituted["jobs"]:
            if job["name"] == "Native contracts (native-tsan)":
                job["name"] = "Native contracts (fabricated-substitute)"
        with self.assertRaisesRegex(ValueError, "matrix identities differ"):
            require_jobs(substituted)
        valid["jobs"][0]["conclusion"] = "skipped"
        with self.assertRaises(ValueError):
            require_jobs(valid)

    def test_guard_executes_exact_source_rejection(self):
        result = subprocess.run([sys.executable, "tools/release/delivery.py", "guard",
            "--expected-commit", COMMIT, "--actual-commit", "b" * 40], cwd=ROOT,
            capture_output=True, text=True, check=False, timeout=10)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("Expected commit differs", result.stderr)

    def test_requires_fresh_full_ci_for_exact_source(self):
        from tools.release.delivery import require_ci
        require_ci(self.run_record(), COMMIT)
        require_ci({**self.run_record(), "event": "push"}, COMMIT)
        for changed in ({"head_sha": "b" * 40}, {"event": "pull_request"},
                        {"conclusion": "failure"}, {"status": "in_progress"},
                        {"path": ".github/workflows/release.yml"},
                        {"created_at": (datetime.now(timezone.utc) -
                                        timedelta(days=2)).isoformat()}):
            with self.subTest(changed=changed), self.assertRaises(ValueError):
                require_ci({**self.run_record(), **changed}, COMMIT)

    def test_publisher_verifies_all_uploaded_bytes_before_publishing(self):
        from tools.release.delivery import publish
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "asset.tar.gz").write_bytes(b"verified archive")
            manifest = {"tag": "v" + load_policy(ROOT)["semantic_version"],
                        "source_commit": COMMIT,
                        "assets": [{"name": "asset.tar.gz", "size": 16,
                                    "sha256": hashlib.sha256(
                                        b"verified archive").hexdigest()}]}
            (root / "release-manifest.json").write_text(json.dumps(manifest))
            api = unittest.mock.Mock()
            api.get.side_effect = [self.run_record(), self.jobs_record(), {"object": {"sha": COMMIT,
                "type": "commit"}}, {"object": {"sha": COMMIT, "type": "commit"}},
                None, []]
            api.create.return_value = {"id": 5, "upload_url": "upload"}
            api.upload.return_value = {"id": 7, "name": "asset.tar.gz", "size": 16}
            api.asset_bytes.return_value = b"changed bytes"
            with self.assertRaisesRegex(ValueError, "[Uu]ploaded release asset"):
                publish(root, COMMIT, 123, api=api)
            api.publish.assert_not_called()

    def publisher_fixture(self, version=None):
        version = load_policy(ROOT)["semantic_version"] if version is None else version
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        root = Path(temporary.name)
        (root / "asset.tar.gz").write_bytes(b"verified archive")
        (root / "release-manifest.json").write_text(json.dumps({
            "tag": "v" + version, "source_commit": COMMIT,
            "assets": [{"name": "asset.tar.gz", "size": 16,
                        "sha256": hashlib.sha256(b"verified archive").hexdigest()}]}))
        api = unittest.mock.Mock()
        uploaded = []

        def get(path):
            if path == "/actions/runs/123":
                return self.run_record()
            if "/jobs?" in path:
                return self.jobs_record()
            if path.startswith("/git/ref/"):
                return {"object": {"type": "commit", "sha": COMMIT}}
            if path.startswith("/releases/tags/"):
                return None
            if path.startswith("/releases/5/assets?"):
                return uploaded
            raise AssertionError("Unexpected external API request: " + path)

        def upload(release, path):
            asset = {"id": len(uploaded) + 1, "name": path.name,
                     "size": path.stat().st_size}
            uploaded.append(asset)
            return asset

        api.get.side_effect = get
        api.create.return_value = {"id": 5, "upload_url": "upload"}
        api.upload.side_effect = upload
        api.asset_bytes.side_effect = lambda asset: (root / asset["name"]).read_bytes()
        return root, api

    def test_complete_immutable_assets_are_verified_then_preview_is_published(self):
        from tools.release.delivery import publish
        root, api = self.publisher_fixture()
        publish(root, COMMIT, 123, api=api)
        self.assertEqual(api.asset_bytes.call_count, 2)
        self.assertTrue(api.create.call_args.args[0]["draft"])
        self.assertTrue(api.create.call_args.args[0]["prerelease"])
        api.publish.assert_called_once_with(5)

    def test_tag_mismatch_or_existing_release_cannot_create_or_upload(self):
        from tools.release.delivery import publish
        tag = "v" + load_policy(ROOT)["semantic_version"]
        for bad_path, response in (("/git/ref/tags/" + tag,
                {"object": {"type": "commit", "sha": "b" * 40}}),
                ("/releases/tags/" + tag, {"id": 4, "draft": True})):
            root, api = self.publisher_fixture()
            original = api.get.side_effect
            api.get.side_effect = lambda path: response if path == bad_path else original(path)
            with self.subTest(path=bad_path), self.assertRaises(ValueError):
                publish(root, COMMIT, 123, api=api)
            api.create.assert_not_called()
            api.upload.assert_not_called()

    def test_tag_move_during_upload_leaves_the_release_draft(self):
        from tools.release.delivery import publish
        root, api = self.publisher_fixture()
        original = api.get.side_effect
        calls = 0

        def get(path):
            nonlocal calls
            if path == "/git/ref/tags/v" + load_policy(ROOT)["semantic_version"]:
                calls += 1
                if calls == 2:
                    return {"object": {"type": "commit", "sha": "b" * 40}}
            return original(path)

        api.get.side_effect = get
        with self.assertRaisesRegex(ValueError, "release tag differs"):
            publish(root, COMMIT, 123, api=api)
        self.assertEqual(api.upload.call_count, 2)
        api.publish.assert_not_called()

    def test_hidden_documentation_bytes_must_survive_the_real_upload_contract(self):
        from tools.evidence.identity import canonical_digest
        from tools.release.delivery import verify_identity
        docs = yaml.load((ROOT / ".github/workflows/docs-build.yml").read_text(),
                         Loader=yaml.BaseLoader)
        upload = next(step for step in docs["jobs"]["build"]["steps"]
                      if step.get("uses", "").startswith("actions/upload-artifact@"))
        self.assertEqual(upload["with"].get("include-hidden-files"), "true")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            hidden = root / "documentation/en/.buildinfo"
            hidden.parent.mkdir(parents=True)
            payload = b"observed Sphinx build identity"
            record = {"kind": "ci_job_identity", "job": "documentation",
                "job_result": "success", "source": {"dirty": False, "commit": COMMIT},
                "run": {"GITHUB_RUN_ID": "123", "GITHUB_RUN_ATTEMPT": "1"},
                "missing_artifacts": [], "artifacts": [{
                    "relative_path": "build/documentation/en/.buildinfo",
                    "size": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}]}
            record["record_sha256"] = canonical_digest(record)
            identity = root / "identity.json"
            identity.write_text(json.dumps(record))
            with self.assertRaisesRegex(ValueError, "Job artifact bytes changed"):
                verify_identity(identity, root, COMMIT, "documentation", 123, 1)
            hidden.write_bytes(payload)
            verify_identity(identity, root, COMMIT, "documentation", 123, 1)

    def test_evidence_archive_retains_raw_logs_hidden_docs_and_identity_paths(self):
        from tools.release.delivery import archive_evidence
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            inputs = root / "inputs"
            paths = ("sdk/delivery/sdk-consumers/raw-build.log",
                     "sdk/delivery/sdk-consumers/firmware/image.elf",
                     "sdk/delivery/staging-copy.json",
                     "sdk/job-identities/source-sdk/identity.json",
                     "sdk/job-identities/source-sdk/python-version.log",
                     "docs/documentation/en/.buildinfo",
                     "docs/docs-job-identity/identity.json",
                     "attestation/delivery/attestation/bundle.json",
                     "ci-evidence/native-native-tsan/contracts.log",
                     "ci-run.json", "ci-jobs.json")
            for name in paths:
                path = inputs / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("observed " + name)
            archive = root / "evidence.tar.gz"
            archive_evidence(inputs, archive)
            with tarfile.open(archive) as stream:
                for name in paths:
                    self.assertEqual(stream.extractfile(name).read(),
                                     (inputs / name).read_bytes())

    def test_contents_write_is_confined_to_publisher(self):
        document = workflow()
        self.assertEqual(document["permissions"]["contents"], "read")
        self.assertIn("expected_commit", document["on"]["workflow_dispatch"]["inputs"])
        for name, job in document["jobs"].items():
            self.assertEqual(job.get("permissions", {}).get("contents", "read"),
                             "write" if name == "publish" else "read")


if __name__ == "__main__":
    unittest.main()
