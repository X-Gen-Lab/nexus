#!/usr/bin/env python3
"""Future execution only: maintained SDK preparation, relocation and normal link.

This script has not been executed by the prepare-only delivery. It never changes
the primary checkout/index, uses one new owned output directory, and holds the
shared compiler flock across all actual configure/compiler descendants.
"""
from __future__ import annotations

import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path("/tmp/nexus-quality-20261019")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def regular(path):
    require(path.is_file() and not path.is_symlink() and path.resolve() == path,
            "Expected a regular canonical file: " + str(path))
    return path


def clean_environment(arm):
    env = os.environ.copy()
    for key in ("CPATH", "C_INCLUDE_PATH", "CPLUS_INCLUDE_PATH", "OBJC_INCLUDE_PATH",
                "CMAKE_INCLUDE_PATH", "CMAKE_LIBRARY_PATH", "LIBRARY_PATH",
                "CMAKE_PREFIX_PATH", "CFLAGS", "CXXFLAGS", "CPPFLAGS", "ASFLAGS",
                "LDFLAGS", "CC", "CXX", "ASM", "PYTHONPATH", "PYTHONHOME"):
        env.pop(key, None)
    env["PATH"] = os.pathsep.join((str(SOURCE / ".venv/bin"), str(arm),
                                     env.get("PATH", "")))
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["GIT_OPTIONAL_LOCKS"] = "0"
    env["CMAKE_BUILD_PARALLEL_LEVEL"] = "1"
    return env


def source_snapshot(expected, revision, env):
    require(SOURCE.resolve() == SOURCE, "Primary source path is aliased")
    read_git = lambda *argv: subprocess.check_output(
        ["git", "-C", str(SOURCE), *argv], env=env)
    require(read_git("rev-parse", "HEAD").decode().strip() == revision,
            "Future primary HEAD differs from the explicitly supplied revision")
    for path, wanted in expected["files"].items():
        require(digest(regular(SOURCE / path)) == wanted,
                "Approved integration bytes not present: " + path)
    index = read_git("ls-files", "--stage", "-z")
    return {"head": revision, "index_records_sha256": hashlib.sha256(index).hexdigest(),
            "status_porcelain": read_git("status", "--porcelain",
                                         "--untracked-files=normal").decode(),
            "bound_primary_source_files": expected["files"]}


def check_headroom(minimum_mib):
    current = int(Path("/sys/fs/cgroup/memory.current").read_text())
    raw_max = Path("/sys/fs/cgroup/memory.max").read_text().strip()
    maximum = None if raw_max == "max" else int(raw_max)
    require(maximum is None or maximum - current >= minimum_mib * 1024 * 1024,
            "Insufficient measured cgroup headroom for the bounded SDK run")
    require(shutil.disk_usage(ROOT).free >= 220 * 1024 * 1024,
            "Need 220 MiB free output space for SDK/build/raws")
    return {"memory_current": current, "memory_max": maximum,
            "required_headroom_mib": minimum_mib,
            "disk_free_bytes": shutil.disk_usage(ROOT).free}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-revision", required=True)
    parser.add_argument("--run-name", default=datetime.datetime.now(
        datetime.timezone.utc).strftime("%Y%m%d-%H%M%S"))
    parser.add_argument("--arm-bin", type=Path,
                        default=Path("/tmp/nexus-quality-arm/bin"))
    parser.add_argument("--cmake", type=Path,
                        default=SOURCE / ".venv/bin/cmake")
    parser.add_argument("--minimum-headroom-mib", type=int, default=384)
    args = parser.parse_args()
    require(re.fullmatch(r"[0-9a-f]{40}", args.expected_revision), "Exact Git revision required")
    require(re.fullmatch(r"[a-z0-9][a-z0-9-]{0,48}", args.run_name), "Unsafe run name")
    require(args.minimum_headroom_mib >= 256, "Headroom bound below reviewed estimate")
    require(ROOT.resolve() == ROOT and not any(p.is_symlink() for p in ROOT.rglob("*")),
            "Owned preparation directory must contain only regular paths")
    prepared = json.loads((ROOT / "preparation.json").read_text())
    require(prepared["status"] == "prepared_not_executed", "Not a frozen preparation")
    for name, wanted in prepared["files"].items():
        require(digest(regular(ROOT / name)) == wanted, "Prepared recipe differs: " + name)
    expected = json.loads((ROOT / "expected-source.json").read_text())
    env = clean_environment(args.arm_bin.resolve())
    source_snapshot(expected, args.expected_revision, env)
    run = ROOT / "runs" / args.run_name
    require(not run.exists(), "Never overwrite a prior execution")
    run.mkdir(parents=True)
    evidence = run / "evidence"
    evidence.mkdir()
    commands = []
    def command(label, argv, *, cwd=run, timeout=600):
        row = {"label": label, "argv": [str(x) for x in argv], "cwd": str(cwd),
               "started_ns": time.time_ns()}
        commands.append(row)
        stdout, stderr = evidence / (label + ".stdout.raw"), evidence / (label + ".stderr.raw")
        process = None
        try:
            with stdout.open("wb") as out, stderr.open("wb") as err:
                process = subprocess.Popen(row["argv"], cwd=cwd, env=env,
                                           stdout=out, stderr=err, start_new_session=True)
                row["exit_code"] = process.wait(timeout=timeout)
            require(row["exit_code"] == 0, "Command failed: " + label)
        except BaseException:
            if process is not None and process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
            if process is not None:
                row["exit_code"] = process.returncode
            raise
        finally:
            row["finished_ns"] = time.time_ns()
            row["stdout"] = str(stdout)
            row["stderr"] = str(stderr)
            (evidence / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
    result = {"status": "failed", "scope": "One development-fixture installed U575 LPTIM1 public C11 link",
              "physical_execution": "not_executed", "qualification": False}
    try:
        with Path("/tmp/nexus-platform-compiler.lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            before = source_snapshot(expected, args.expected_revision, env)
            result["headroom_before"] = check_headroom(args.minimum_headroom_mib)
            (evidence / "source-before.json").write_text(json.dumps(before, indent=2) + "\n")
            for name, wanted in expected["host_tool_sha256"].items():
                tool = args.arm_bin / name
                require(digest(regular(tool)) == wanted, "Pinned ARM tool differs: " + name)
            require(digest(regular(args.cmake)) == expected["cmake_launcher_sha256"],
                    "Prepared CMake launcher differs")
            require(digest(regular(SOURCE / ".venv/bin/ninja")) == expected["ninja_sha256"],
                    "Prepared Ninja executable differs")
            command("cmake-version", [args.cmake, "--version"])
            command("ninja-version", [SOURCE / ".venv/bin/ninja", "--version"])
            command("compiler-version", [args.arm_bin / "arm-none-eabi-gcc", "--version"])
            packager = SOURCE / "cmake/package/package_source_sdk.py"
            command("prepare", [sys.executable, "-B", packager, "--source", SOURCE,
                                 "--output", run / "sdk original", "--development-fixture"])
            original, relocated = run / "sdk original", run / "sdk relocated"
            old_manifest = digest(original / "share/nexus/src/.nexus-source-sdk.json")
            original.rename(relocated)
            sdk = relocated / "share/nexus/src"
            require(old_manifest == digest(sdk / ".nexus-source-sdk.json"),
                    "Relocation changed the installed manifest")
            command("verify-relocated", [sys.executable, "-B",
                sdk / "cmake/package/package_source_sdk.py", "--verify", sdk])
            consumer = run / "consumer source"
            consumer.mkdir()
            for name in ("CMakeLists.txt", "u575-lptim1-lpbam.c", "private_headers.c"):
                shutil.copyfile(regular(ROOT / "consumer" / name), consumer / name)
            command("configure", [args.cmake, "-S", consumer, "-B", run / "build", "-G", "Ninja",
                "-DCMAKE_BUILD_TYPE=Release", "-DNEXUS_COMPILER_CACHE=OFF",
                "-DNEXUS_BUILD_TESTS=OFF", "-DNEXUS_BUILD_WORKLOAD=OFF",
                "-DNEXUS_ALLOW_SOURCE_SDK_FIXTURE=ON",
                "-DNEXUS_ASSEMBLY_FILE=" + str(sdk /
                    "tools/configure/assemblies/u575-lptim1-lpbam-stop2.toml"),
                "-DNEXUS_EXPECTED_SOURCE_REVISION=" + args.expected_revision,
                "-DPython3_EXECUTABLE=" + sys.executable,
                "-DNexus_DIR=" + str(relocated / "lib/cmake/Nexus"),
                "-DCMAKE_TOOLCHAIN_FILE=" + str(sdk / "cmake/toolchains/arm-gcc.cmake")])
            command("build", [args.cmake, "--build", run / "build", "--target", "u575_lptim1_sdk",
                              "--parallel", "1"])
            command("inspect", [sys.executable, "-B", ROOT / "inspect_result.py",
                "--run", run, "--revision", args.expected_revision,
                "--expected", ROOT / "expected-source.json", "--report", evidence / "installed-proof.json",
                "--objdump", args.arm_bin / "arm-none-eabi-objdump"])
            command("verify-after-build", [sys.executable, "-B",
                sdk / "cmake/package/package_source_sdk.py", "--verify", sdk])
            after = source_snapshot(expected, args.expected_revision, env)
            require(before == after, "Primary/index changed during actual SDK execution")
            (evidence / "source-after.json").write_text(json.dumps(after, indent=2) + "\n")
            result.update(status="passed", proof=str(evidence / "installed-proof.json"),
                          source_revision=args.expected_revision, sdk_publishable=False)
    except BaseException as error:
        result["failure"] = str(error)
        raise
    finally:
        (evidence / "execution.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
