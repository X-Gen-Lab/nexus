/**
 * \file            private_headers.c
 * \brief           Reject vendor and private provider include leakage
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-20
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#if __has_include("stm32u5xx.h") || __has_include("stm32u575xx.h") || \
    __has_include("core_cm33.h") || __has_include("stm32u5xx_ll_dma.h")
#error Vendor headers leaked into the public consumer
#endif
#if __has_include("stm32u575_lpdma_lptim1_internal.h") || \
    __has_include("stm32u575_lptim1_profile.h") || \
    __has_include("stm32u575_lpdma_copy_hw.h") || \
    __has_include("stm32u575_memory_init.h") || __has_include("retained_time.h")
#error Private provider headers leaked into the public consumer
#endif
_Static_assert(__STDC_VERSION__ == 201112L, "Strict public C11 include scope");
