#!/usr/bin/env python3
"""Inspect this one normal installed U575 link; no alternative build graph."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import struct
import subprocess
import sys

CONSUMER = "cmake/package/verification/io_evolution/consumers/u575-lptim1-lpbam.c"
TARGET = "u575_lptim1_sdk"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data)}


def inspect(run, revision, expected, objdump):
    sdk = run / "sdk relocated/share/nexus/src"
    build, consumer = run / "build", run / "consumer source"
    sys.path.insert(0, str(sdk))
    from tools.measurement.elf import Elf32
    package = json.loads((sdk / ".nexus-source-sdk.json").read_text())
    require(package["publishable"] is False and package["source_revision"] == revision,
            "Wrong development fixture identity")
    bindings = []
    for name in expected["required_sdk_paths"]:
        item = identity(sdk / name)
        require(item["sha256"] == expected["files"][name] == package["files_sha256"][name],
                "Installed required source differs: " + name)
        bindings.append(item)
    require(identity(consumer / "u575-lptim1-lpbam.c")["sha256"] ==
            package["files_sha256"][CONSUMER], "Consumer differs from canonical SDK source")
    require((build / "installed-source.txt").read_text() == str(sdk),
            "find_package escaped the relocated SDK")
    config = Path((build / "installed-config.txt").read_text())
    require(config.is_relative_to(build) and config.resolve() == config,
            "Generated inputs escaped the normal build")
    resolved = json.loads((config / "resolved.json").read_text())
    require(resolved["soc_family"] == "stm32u575" and resolved["backend"] == "baremetal"
            and resolved["clock_profile"] == "msis4" and
            resolved["part"] == "STM32U575ZIT6Q", "Wrong exact software profile")
    rows = json.loads((build / "compile_commands.json").read_text())
    public_sources = {consumer / "u575-lptim1-lpbam.c", consumer / "private_headers.c"}
    public_rows, startup_rows = [], []
    for row in rows:
        source = Path(row["file"]).resolve()
        require(source.is_relative_to(sdk) or source in public_sources or
                source == config / "bindings.c", "Foreign source entered the installed graph")
        argv = row.get("arguments") or shlex.split(row["command"])
        if source == sdk / "soc/stm32u575/system.c" and TARGET + "_nexus_startup" in row["command"]:
            require("-DNEXUS_MEMORY_SRAM4=1" in argv, "Startup lacks the selected SRAM4 boot")
            startup_rows.append(row)
        if source not in public_sources:
            continue
        require("-std=c11" in argv and "-std=gnu11" not in argv and
                all(flag in argv for flag in ("-Werror", "-Wpedantic", "-Wconversion")),
                "Public C11/strict flags missing")
        includes = []
        for index, arg in enumerate(argv):
            if arg in {"-I", "-isystem", "-iquote"}:
                includes.append(Path(argv[index + 1]))
            elif arg.startswith("-I"):
                includes.append(Path(arg[2:]))
            elif arg.startswith("-isystem"):
                includes.append(Path(arg[len("-isystem"):]))
        for path in includes:
            require(not any(part in {"vendors", "ext", "soc", "private"} for part in path.parts),
                    "Vendor/private include scope leaked to public source")
            require(path.is_relative_to(sdk) or path == config or path == consumer,
                    "Unreviewed public include directory")
        public_rows.append(row)
    require(len(startup_rows) == 1 and len(public_rows) == 2 and
            {Path(r["file"]).name for r in public_rows} ==
            {"u575-lptim1-lpbam.c", "private_headers.c"}, "Missing exact public/startup rows")
    binary = build / "bin"
    elf_path = binary / (TARGET + ".elf")
    image = Elf32(elf_path.read_bytes())
    symbols = image.defined_symbols

    def symbol(name, size=None, kind=None):
        matches = [r for r in symbols if r["name"] == name]
        require(len(matches) == 1, "Missing or ambiguous symbol: " + name)
        row = matches[0]
        require((size is None or row["size"] == size) and
                (kind is None or row["type"] == kind), "Unexpected symbol ABI: " + name)
        return row

    def file_bytes(address, size):
        matches = [r for r in image.loads if r["virtual"] <= address and
                   address + size <= r["virtual"] + r["files"]]
        require(len(matches) == 1, "Expected one file-backed LOAD")
        load = matches[0]
        offset = load["offset"] + address - load["virtual"]
        return image.data[offset:offset + size], load

    required = ("Reset_Handler", "SystemInit", "nx_stm32u575_memory_boot", "main",
                "nx_platform_start", "nx_platform_stop", "nx_stm32u575_stop2_identity",
                "nx_stm32u575_stop2_initialize", "nx_stm32u575_stop2_lptim1_enter",
                "nx_stm32u575_stop2_recover", "nx_stm32u575_lpdma_lptim1_initialize",
                "nx_stm32u575_lpdma_lptim1_start", "nx_stm32u575_lpdma_lptim1_stop",
                "nx_stm32u575_lpdma_lptim1_request_prepare",
                "nx_stm32u575_lpdma_lptim1_producer_start",
                "nx_stm32u575_lpdma_lptim1_producer_withdraw")
    for name in required:
        symbol(name, kind=2)
    require(not any(r["name"].startswith("nx_stm32u575_lpdma_copy_") or
                    r["name"] == "nx_stm32u575_stop2_copy_enter" for r in symbols),
            "Old memory-copy implementation entered this image")
    receiver = symbol("s_receiver", 104, 1)
    stop2_owner = symbol("s_owner", kind=1)
    require(stop2_owner["file"] == "stop2.c", "Compound owner identity is ambiguous")
    tuple_row, workspace = symbol("s_tuple", 12, 1), symbol("s_workspace", 48, 1)
    require(0x20000000 <= receiver["value"] < receiver["value"] + 104 <= 0x20030000,
            "Receiver control escaped SRAM1")
    for row in (tuple_row, workspace):
        require(0x28000000 <= row["value"] < row["value"] + row["size"] <= 0x28004000
                and row["value"] % 4 == 0, "Tuple/LLI escaped exact SRAM4")
    require(tuple_row["value"] + 12 <= workspace["value"] or
            workspace["value"] + 48 <= tuple_row["value"], "Tuple aliases its LLI workspace")
    tuple_section = image.sections[tuple_row["section"]]
    lli_section = image.sections[workspace["section"]]
    require(tuple_section["kind"] == 1 and lli_section["kind"] == 8,
            "Tuple must have Flash LMA; LLI must be NOLOAD")
    data, load = file_bytes(tuple_row["value"], 12)
    require(struct.unpack("<3I", data) == (37, 0, 2047) and
            0x08000000 <= load["physical"] < 0x08200000,
            "SRAM4 initialized tuple lost its exact Flash initializer")
    ops = symbol("nx_stm32u575_lpdma_lptim1_ops", 16, 1)
    table, load = file_bytes(ops["value"], 16)
    require(load["flags"] & 2 == 0, "Operations table is writable")
    methods = []
    for name, address in zip(("cancel", "service", "stop", "start"), struct.unpack("<4I", table)):
        matches = [r for r in symbols if r["type"] == 2 and r["size"] > 0 and
                   r["value"] & ~1 == address & ~1 and r["file"] == "lpdma_copy.c" and
                   (r["name"] == name or r["name"].startswith(name + "."))]
        require(address & 1 and matches, "Real immutable method lost: " + name)
        methods.append({"method": name, "address": address, "symbols": matches})
    map_path = binary / (TARGET + ".map")
    map_text = map_path.read_text()
    require("libnexus_stm32u575_stop2_lptim1.a(" in map_text and
            "libnexus_stm32u575_lpdma_lptim1.a(" in map_text,
            "Selected maintained LPTIM1 archives missing")
    require(not re.search(r"libnexus_stm32u575_(?:stop2(?:_copy)?|lpdma_copy)\.a\(", map_text),
            "Old WUT/copy owner archive entered this image")
    disassembly = subprocess.check_output([str(objdump), "-d", "--no-show-raw-insn", str(elf_path)],
                                          text=True)
    dump_path = run / "evidence/installed-disassembly.txt"
    dump_path.write_text(disassembly)
    instructions = []
    for line in disassembly.splitlines():
        match = re.match(r"\s*([0-9a-f]+):\s+(\S+)\s*(.*)", line)
        if match:
            instructions.append((int(match[1], 16), match[2], match[3]))
    functions = {r["name"]: r for r in symbols if r["type"] == 2 and r["size"] > 0}
    starts = {r["value"] & ~1: name for name, r in functions.items()}
    edges = {}
    for name, row in functions.items():
        begin = row["value"] & ~1
        edges[name] = []
        for address, opcode, operands in instructions:
            target = re.match(r"([0-9a-f]+)\s+<", operands)
            if begin <= address < begin + row["size"] and opcode in {"bl", "blx", "b.w", "b"} and target:
                callee = starts.get(int(target[1], 16) & ~1)
                if callee:
                    edges[name].append({"address": address, "callee": callee})

    def reaches(start, destination):
        pending, seen = [start], set()
        while pending:
            name = pending.pop()
            if name == destination:
                return True
            if name not in seen:
                seen.add(name)
                pending.extend(e["callee"] for e in edges.get(name, []))
        return False

    reset_calls = edges["Reset_Handler"]
    system_call = [r["address"] for r in reset_calls if r["callee"] == "SystemInit"]
    main_call = [r["address"] for r in reset_calls if r["callee"] == "main"]
    require(image.entry == symbol("Reset_Handler")["value"] and
            len(system_call) == len(main_call) == 1 and system_call[0] < main_call[0]
            and reaches("SystemInit", "nx_stm32u575_memory_boot"),
            "Actual Reset/SystemInit/SRAM4 boot/main chain missing")
    vectors = symbol("g_pfnVectors")
    vector, _ = file_bytes(vectors["value"], 8)
    require(struct.unpack("<2I", vector)[1] == symbol("Reset_Handler")["value"],
            "Real reset vector does not enter the checked startup")
    for helper in ("nx_stm32u575_lpdma_lptim1_producer_start",
                   "nx_stm32u575_lpdma_lptim1_producer_withdraw"):
        require(reaches("nx_stm32u575_stop2_lptim1_enter", helper),
                "Compound Stop2 does not actually link its producer helper")
    resources_path = binary / (TARGET + ".resources.json")
    resources = json.loads(resources_path.read_text())
    require(resources["status"] == "passed" and resources["elf"]["sha256"] ==
            identity(elf_path)["sha256"] and resources["part"] == "STM32U575ZIT6Q" and
            resources["physical_status"] == "not_executed", "Wrong normal resource proof")
    budget = json.loads((config / "resource-budget.json").read_text())
    require(budget["heap_max"] == 0 and budget["msp_max"] == 2048 and
            budget["ram_reserved_max"] == {"sram1": 4096, "sram4": 512},
            "Canonical resource budgets changed")
    return {"status": "passed", "scope": "One relocated normal public C11 U575 LPTIM1 link",
            "source_revision": revision, "sdk_publishable": False,
            "sdk_snapshot_sha256": package["snapshot_sha256"],
            "required_source_bindings": bindings, "public_compile_rows": public_rows,
            "startup_compile_rows": startup_rows, "ops": ops, "methods": methods,
            "owner_storage": receiver, "compound_owner": stop2_owner,
            "sram4_tuple": tuple_row, "sram4_lli": workspace,
            "actual_direct_call_graph": edges,
            "artifacts": [identity(p) for p in (elf_path, binary / (TARGET + ".bin"),
                map_path, resources_path, dump_path, config / "resolved.json",
                config / "bindings.c", config / "memory.ld")],
            "qualification": False, "physical_execution": "not_executed",
            "whole_v8_matrix": "not_executed_by_this_single_consumer"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--expected", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--objdump", required=True, type=Path)
    args = parser.parse_args()
    result = inspect(args.run.resolve(), args.revision,
                     json.loads(args.expected.read_text()), args.objdump)
    args.report.write_text(json.dumps(result, indent=2) + "\n")
