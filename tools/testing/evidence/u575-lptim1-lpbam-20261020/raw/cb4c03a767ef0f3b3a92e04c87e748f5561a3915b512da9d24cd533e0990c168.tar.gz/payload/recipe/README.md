# One relocated U575 LPTIM1 installed-SDK consumer

Status: **prepared, not executed**. This directory contains no SDK, build tree or
successful execution report. Primary source/index are read-only. Root supplies
the exact future primary HEAD after integrating the frozen 30-file source,
five-file errata, one-file selection and 33-file documentation packages, followed
by the one-file workflow and six-file visual addenda. `expected-source.json`
records those manifest hashes, their ordered entries and 98 final unique source
hashes. Its 53 required SDK paths also bind
startup, the selected component and maintained packaging/configuration tools.

After root authorizes execution and the matching primary is ready:

```sh
python3 -B /tmp/nexus-u575-lptim1-installed-sdk-20261020/run.py \
    --expected-revision EXACT_FUTURE_40_HEX_HEAD --run-name integrated-one
```

The script rejects a mismatched HEAD, file, recipe, compiler, Ninja or CMake
launcher. It records the primary index-record hash and porcelain status before
and after the run; it never stages or modifies primary files. It takes the
shared compiler flock before package/configure/build, uses one compiler job,
and prepends both primary `.venv/bin` (including Ninja) and the pinned ARM bin
directory to PATH. It removes inherited compiler/include/library search paths.
No compiler/configure command has run during this preparation.

The single execution uses maintained `package_source_sdk.py --development-fixture`
once for the complete SDK, renames `sdk original` to `sdk relocated`, runs the
relocated maintained `--verify`, then uses normal `find_package(Nexus)` and
`nexus_add_firmware` with the SDK's authored
`tools/configure/assemblies/u575-lptim1-lpbam-stop2.toml`. The selected profile is
STM32U575ZIT6Q, TZEN0, baremetal MSIS4, MSP 2048, no heap, SRAM1 budget 4096 and
SRAM4 budget 512 bytes. The external boot owner must establish the public
Range4/MSIS4/MSIK4/retained-LSE prerequisites; the fixture invents no boot setup.

The public C source is an unchanged copy of the frozen canonical
`cmake/package/verification/io_evolution/consumers/u575-lptim1-lpbam.c`; the
inspector verifies it against the installed manifest. The only extra C source
is a public include-isolation assertion. There are no private/runtime/vendor
includes, overlay targets, alternate source graphs, manually compiled provider
objects or forwarding helpers. Public base APIs remain legal.

The future inspector checks actual strict C11 compile rows, normal resource
postlink output and exact installed source bindings. In the final ELF it checks
the vector/entry and direct Reset → SystemInit → SRAM4 memory-boot → main
link chain, selected startup definition, 104-byte receiver owner, four concrete
methods behind the 16-byte read-only ops table, the initialized 12-byte SRAM4
tuple with Flash LMA and separate 48-byte NOLOAD LLI workspace. It checks the
same Stop2 implementation reaches the new producer start/withdraw helpers and
that old WUT/copy owner archives and old copy symbols are absent. Compile inputs
are restricted to the relocated SDK, the two public consumer files and **only**
that normal configuration's exact `bindings.c`. Compile database entries for
unbuilt EXCLUDE_FROM_ALL targets do not establish their inclusion; the linked
map/ELF decide which implementations entered the image.

Every future command records argv, cwd, return code and raw stdout/stderr in a
new run directory. Failure retains its files. The installed SDK is verified
again after the build. No external audit can replace a failed normal link gate.

Allow roughly 120–135 MiB for the one complete SDK and under 15 MiB for the
consumer/build/raw reports. The script requires 220 MiB free disk and measured
384 MiB cgroup headroom by default. It makes no clone or sparse SDK. Root can
archive the relocated prefix once with the existing maintained CAS tool:

```sh
python3 -B /tmp/nexus-quality-20261019/tools/evidence/store.py export \
    --source '/tmp/nexus-u575-lptim1-installed-sdk-20261020/runs/integrated-one/sdk relocated' \
    --store /tmp/nexus-u575-lptim1-installed-sdk-20261020/sdk-store \
    --report /tmp/nexus-u575-lptim1-installed-sdk-20261020/runs/integrated-one/evidence/sdk-package.json
python3 -B /tmp/nexus-quality-20261019/tools/evidence/store.py verify \
    --package /tmp/nexus-u575-lptim1-installed-sdk-20261020/runs/integrated-one/evidence/sdk-package.json \
    --report /tmp/nexus-u575-lptim1-installed-sdk-20261020/runs/integrated-one/evidence/sdk-archive-verified.json
```

Archive space is approximately 30–40 MiB. No recipe deletes the SDK; root decides
reclamation only after checking the archive. This one development-fixture link
does not execute the whole v8 matrix. HIL remains **not executed**; physical
Stop2, timing, current, oscillator/PCB routes and the complete LPBAM exit stay
open. A successful ELF/startup inspection establishes linking, not execution of
the reset or peripheral sequence on silicon.
