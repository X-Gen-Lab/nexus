# U575 LPTIM1 development SDK and root preflight evidence

This collection preserves one real relocated installed SDK consumer and the
subsequent root primary preflight. It does not establish a release, a complete
v8 matrix, a clean-source whole-index result, reproducibility or physical HIL.
Qualification and SDK publication remain false. IO-32/SOC-35 exits stay open.

The SDK compile database declares 96 entries: 93 SDK, two public strict C11 and
one generated binding. The actual 80-step build log records 69 compilation actions:
68 C plus one ASM. These are 66 SDK actions (65 C plus startup ASM), two public C
actions and one generated C binding; 27 declared entries were not compiled.
The database is not an execution count. Its ELF occupies 17,964 Flash bytes,
2,400 SRAM1 bytes including a 2,048-byte MSP, and 60 SRAM4 bytes. The selected
receiver owner is 104 bytes, its shared readonly operations table 16 bytes, the
fixed tuple 12 bytes and the two continuation descriptors 48 bytes. The old copy
owner remains 88 bytes; the extra 16-byte lifecycle ledger belongs only to the
selected LPTIM1 profile. See the executed inspection and independent review.

The primary preflight ran 75 selected Python tests, 52 release workflow tests and
135 Google tests in six binaries, all passing without skips. Its default Native
prebuild was incremental, jobs1. It is distinct from the final ordinary hook.
The maintained receipts identify commands and raw bytes; they contain no full
Git/index/binary snapshot. XML case counts are listed in preflight/summary.json.

Source phases remain explicit. The SDK before/after records bind 98 files and
cover 65 of the 66 integrated paths. The release README is separately bound as
documentation. After that SDK run, root corrected only the prepare_test.cpp file
header. Original failed style, corrected passing style and the exact change
receipt remain separate. Do not assign the later test-header hash to the earlier
SDK snapshot. source-binding-phases.json records the complete distinction.

The completed SDK prefix was inventoried, archived once with the existing
store.py in the existing global CAS, independently verified, re-inventoried
unchanged and then reclaimed at its exact owned path. See sdk-prefix/package.json,
verified.json, inventory-before.json and reclaim.json. The complete prefix is
recoverable using store.py restore with that package and a new destination. The
31MB archive is referenced, not nested here; this is not an offsite durability
claim. All configuration, source manifests, SDK run/inspect/preparation/expected
recipes, raw execution records and final ELF/BIN/map/budgets remain here.

references.json identifies the seven immutable source/documentation packets,
original RED/GREEN runs and independent reviews. Six existing canonical packet
archives retain their unique development evidence; the seventh one-file release
README package is compacted here. No whole source/tool/SDK trees or earlier
archives are copied into this collection.

Byte-identical copied data is stored once. source-locations.json maps original
SDK/root paths to stored members. content-aliases.json maps deduplicated logical
members. preflight/roles.json maps every original preflight raw/receipt/XML/result
and top-log alias to its unique stored bytes. Receipt contents are unmodified.
The final archive member manifest is generated and verified by existing
Nexus tools/evidence/store.py; these maps are only archival references.

The initial collection summary is retained under review/initial-collection-summary.json.
The count correction and independent addendum distinguish the database from
executed build actions; original SDK inspection/raw/recipe/prefix bytes are intact.
