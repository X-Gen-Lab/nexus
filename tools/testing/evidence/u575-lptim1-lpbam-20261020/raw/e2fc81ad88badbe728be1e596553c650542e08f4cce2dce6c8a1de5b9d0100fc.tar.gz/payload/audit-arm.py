from pathlib import Path
import sys,json
base=Path('/tmp/nexus-quality-20261019');root=Path('/tmp/nexus-u575-lptim1-lpbam-20261020')
sys.path.insert(0,str(base))
from tools.measurement.retention import source_contracts,linked_object,object_words,concrete_method
from tools.measurement.elf import Elf32
from tools.evidence.common import file_identity
faces,layouts,providers,inputs=source_contracts(root)
p=root/'verification/arm-build/bin/u575_lptim1_public.elf';elf=Elf32(p.read_bytes())
name='nx_stm32u575_lpdma_lptim1_ops';provider=providers[name];slots=layouts[provider['type']]
table,section=linked_object(elf,name,'operations');words=object_words(elf,table,section)
assert table['size']==len(slots)*4==16
methods=[]
for slot,pointer in zip(slots,words):
 method=concrete_method(elf,pointer);expected=provider['fields'][slot]
 assert expected in method['symbols'],(slot,method)
 assert any(d['name']==expected and (d['binding']==1 or d['file'] is not None and Path(d['file']).name==Path(provider['source']['path']).name) for d in method['definitions']),(slot,method)
 methods.append({'slot':slot,'expected':expected,**method})
for absent in ['nx_stm32u575_lpdma_copy_ops','nx_stm32u575_stop2_copy_enter']:
 assert absent not in elf.symbols
objects={}
for name,size in [('s_receiver',104),('s_tuple',12),('s_workspace',48)]:
 symbol,section=linked_object(elf,name,'storage',writable=True);assert symbol['size']==size,(name,symbol)
 objects[name]={'symbol':symbol,'section':section}
assert objects['s_tuple']['symbol']['value']>=0x28000000
assert objects['s_workspace']['symbol']['value']>=0x28000000
assert objects['s_tuple']['section']['kind']==1
assert objects['s_workspace']['section']['kind']==8
report={'status':'passed','elf':file_identity(p),'source':provider['source'],'public_contracts':inputs,'verifier':file_identity(base/'tools/measurement/retention.py'),'table':table,'slots':slots,'methods':methods,'objects':objects,'physical_status':'not_executed','scope':'selected development overlay link, no installed SDK or hardware execution'}
(root/'evidence/arm-ops-abi-source-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('Source/public table ABI, four local method provenance, 104B owner, 12B tuple and 48B LLI: passed')
for name,item in objects.items():print(name,item['section']['name'],item['symbol']['size'])
p=root/'verification/arm-build/bin/u575_lptim1_default_absence.elf';elf=Elf32(p.read_bytes())
assert not any(name.startswith(('nx_stm32u575_lpdma_lptim1','nx_stm32u575_stop2_lptim1','nx_stm32u575_lpdma_copy','nx_stm32u575_stop2_copy')) for name in elf.symbols)
print('Optional target unselected in SRAM4 assembly: all receiver/compound symbols absent')
