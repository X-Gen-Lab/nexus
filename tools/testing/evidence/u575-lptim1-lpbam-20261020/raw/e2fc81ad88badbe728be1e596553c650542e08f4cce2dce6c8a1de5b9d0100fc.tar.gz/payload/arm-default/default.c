/** \file default.c
 * \brief Public ordinary platform consumer with no optional LPTIM1 owner.
 * \author Nexus Team
 * \version 1.0.0
 * \date 2026-10-20
 * \copyright Copyright (c) 2026 Nexus Team
 */
#include "nexus_bindings.h"
int main(void) {
    if (nx_platform_start().primary != NX_SUCCESS)
        return 1;
    return nx_platform_stop() == NX_SUCCESS ? 0 : 2;
}
