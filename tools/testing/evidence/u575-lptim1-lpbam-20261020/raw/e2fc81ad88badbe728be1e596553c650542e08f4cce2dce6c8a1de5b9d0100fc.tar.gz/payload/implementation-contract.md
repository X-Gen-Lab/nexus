# Exact STM32U575 LPTIM1 single-tuple reference

This proposed software increment targets STM32U575ZIT6Q TZEN0 baremetal with
selected SRAM4 and the existing retained-LSE RTC/MSIS4/Range4 Stop2 profile. It
is one fixed peripheral LPBAM program, not a generic LPBAM facility. PCB output
routing is unknown. Physical retention, residency, timing, power and waveform
validation are `not_executed`. Software execution results will be bound
separately to final source and command hashes; this draft establishes no test
qualification.

`Nexus::U575Stop2Lptim1` selects the same concrete static Stop2 owner and RUN
ClockDomain as the existing WUT/copy alternatives. Compile alternatives reject
coexistence. `Nexus::U575LpdmaLptim1` and the existing SRAM4 memory-copy
receiver also reject simultaneous selection of their single physical LPDMA0
role. Public requests and immutable operation tables remain distinct. No heap,
task, queue, callback plan, dynamic MMIO instruction, new factory or second
controller owner is introduced. Default images do not select these targets.

The public API takes exactly one immutable twelve-byte tuple `{CCR1, RCR, ARR}`
and exactly one four-byte-aligned 48-byte workspace for two generated LLIs.
Both full extents must be nonsecure SRAM4 and disjoint from one another and all
request, face, owner, clock and snapshot/control storage. `RCR=0`,
`1023<=ARR<=65535` and `CCR1<ARR`. Prepared metadata does not borrow, write or
inspect the tuple. The admission path checks tuple values before ACCEPTED. No
destination or tuple count is public. Rejection changes no request byte and
retains no new reference.

Initialize ordinary retained time with
`wake_owner=nx_stm32u575_stop2_identity()`, initialize Stop2 and the dedicated
receiver, then call public receiver `start`. Start requires an exclusive cold
LPTIM1 controller, initially disabled access gate and reset kernel mux. It
acquires LPTIM1EN, LPTIM1SEL=LSE and only a needed LSESYSEN; it observes
LSESYSRDY without altering LSE oscillator/calendar provenance. Start writes no
timer register. Partial preparation retains its explicit source, gate and mux
ledger until public stop proves restoration. Products need no private RCC
writes to satisfy the new preparation. SRAM4/LPDMA1 startup and the existing
retained RTC boot provenance remain the established platform prerequisites.

RUN LPTIM2 must already be disabled and joined; it is never the Stop2 producer.
Close/join the exact RUN domain and stop Platform before entering at privileged
MSP Thread CONTROL0, PRIMASK1, BASEPRI/FAULTMASK0. The concrete owner validates
actual clocks, gates, reset state and quiet IRQs. ACCEPTED borrows the request,
tuple and complete workspace until acquire-observed SETTLED and external
observer joins. Cancel/deadline request withdrawal; neither revokes storage.

The selected LPTIM1 mode uses LSE, PRELOAD1 and one CCMR1 CC1E write. After
ENABLE is observed, an independently successful retained sample anchors a
bounded wait for at least two additional RTC ticks. Even an arbitrarily short
first tick then includes a complete 128-LSE-cycle interval, exceeding the
required two counter cycles. The absolute request deadline is checked during
this wait. Poll counts do not establish elapsed cycles. Initial CCR1=0, RCR=0
and ARR=1023 writes need fresh CMP1OK/REPOK/ARROK; those flags are then cleared
and observed clear before DMA.

LPDMA1 channel0's first four-byte source transfer waits for hardware request13
`lptim1_ue_dma` with BREQ1, SWREQ0 and reserved DREQ0. Two full generated LLIs
continue with software requests to RCR and ARR. All widths are 32 bits, source
increments, destination never increments, and the final link is zero.
CCR1+0x14, RCR+0x28 and ARR+0x18 are not contiguous: three fixed destinations
are necessary. ARR is last and its acknowledged APB write clears UE.
Completion/IRQ114 occurs only at the final LLI. WUT independently escapes; no
AlarmA register is written.

There is no two-tuple mode. A large ARR alone cannot prove completion of
previous asynchronous writes before another UE under an unbounded bridge/bus
delay. Every repeated write needs the preceding register's write-OK; the
single-tuple bound avoids inventing a hardware synchronization premise. Future
repetition needs a separate proof and tests. The success result means the
finite APB writes and fresh kernel write-OK acknowledgements completed. It does
not mean that PRELOAD values played for any complete PWM period; no output pin
is configured.

After wake, invalid RUN/access profile permits core deep-bit/vector withdrawal
only and retains the entire compound loan. Valid recovery withdraws UEDE and
observes fresh DIEROK before another DIER write and before DMA drain. It proves
DMA suspend/SUSPF/idle, accepts full-word RESET and complete CCR0, clears
address/ link/flags/NVIC references, then resets the exclusively owned LPTIM1
through RCC. It never clears CR.ENABLE, per ES0499. Full successful tuple
completion additionally requires all three fresh write-OK flags before reset. A
partial cancelled program has no flag requirement for unissued writes; master
isolation plus owned RCC reset can terminate it with error.

Owned reset assertion/deassertion failures remain retryable and retain storage.
A private pure state query authorizes that exception only after DMA's
final-access proof; observed external LPDMA or LPTIM reset during an active
loan permanently quarantines it. Quiet reset defaults or deassertion do not
release the loan.

Only after peripheral, DMA, IRQ, loan gates, RTC/WUT, power and clock
restoration are proved does Stop2 detach its references and perform the final
release store. Any failed proof retains ownership, including an already idle
DMA. Public start access claims remain reserved even if stop was requested
during an active loan; a final joined public stop restores them before
releasing the physical role. Recovery never executes another WFI. Old Core TIM2
deadlines remain invalid.

Independent manual source: RM0456 Rev7 PDF SHA256
`6edaaaae0c5d57c58ffc3a576d44e7b62e8d9cd0e495e8f61bab688226fc327c`. Normative
anchors: §18.3.3 Table148 request13; §18.3.4 Table149 BREQ; §18.4.11 and
§18.8.11 request/block semantics and reserved DREQ; §58.4.11 write-OK; §58.4.13
enable delay; §58.4.20–21 CCR1/RCR/ARR and UEDE; §58.5 LPTIM1/3 Stop2 (LPTIM2
disabled); §58.7.8 DIEROK; §11.8.48 LPTIM1SEL and §11.8.49 LSESYS. ES0499 Rev12
§2.17.1 requires RCC reset shutdown; §2.17.2's odd-repeat/APB-slower condition
is excluded by RCR0/LSE<=APB; §2.17.3 forbids assuming flags survive DIER
changes. Exact pinned CMSIS/LL hashes and the independent review are retained
in `manual-contract.json`.
