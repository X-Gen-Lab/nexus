from pathlib import Path
import subprocess,json,hashlib,time
root=Path('/tmp/nexus-u575-lptim1-lpbam-20261020'); base=Path('/tmp/nexus-quality-20261019')
build=root/'verification'/'red-build'; build.mkdir(exist_ok=True)
incs=['components/stm32u575_lpdma_copy/include','components/stm32u575_lpdma_copy/private','components/stm32u575_retained_time/include','soc/stm32u575/private','core/include','arch/include','io/include']
sysincs=['vendors/st/cmsis_device_u5/Include','vendors/arm/CMSIS_5/CMSIS/Core/Include','vendors/st/stm32u5_hal/Inc']
opts=['-std=c11','-Wall','-Wextra','-Werror','-Wconversion','-Wshadow','-pedantic','-ffunction-sections','-fdata-sections','-DSTM32U575xx','-DNX_U575_LPDMA_COPY_MODEL','-D_POSIX_C_SOURCE=200809L']
for p in incs: opts+=['-I',str(base/p)]
for p in sysincs: opts+=['-isystem',str(base/p)]
commands=[]
def run(args):
 commands.append(args)
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 with (root/'evidence'/'red.log').open('a') as f:f.write('$ '+repr(args)+'\n'+p.stdout)
 if p.returncode:raise SystemExit(p.returncode)
objects=[]
for rel in ['soc/stm32u575/drivers/lpdma_copy.c','core/src/request.c','io/src/dma.c','arch/native/nx_arch_native.c']:
 obj=build/(Path(rel).stem+'.o'); run(['gcc',*opts,'-c',str(base/rel),'-o',str(obj)]); objects.append(str(obj))
google=Path('/tmp/nexus-googletest-tdd-20261019/smoke-build/lib')
run(['g++','-std=c++17','-Wall','-Wextra','-Werror','-Wconversion','-Wshadow','-pedantic',*opts[9:],' -Wl,--gc-sections'.strip(),'-isystem',str(base/'ext/googletest/googletest/include'),str(root/'verification/red_contract.cpp'),*objects,str(google/'libgmock_main.a'),str(google/'libgmock.a'),str(google/'libgtest.a'),'-pthread','-o',str(build/'red-test')])
args=[str(build/'red-test'),'--gtest_output=xml:'+str(root/'evidence/red.xml')]
commands.append(args); p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(root/'evidence/red.log').open('a').write(p.stdout)
(root/'evidence/red-commands.json').write_text(json.dumps({'commands':commands,'runtime_exit':p.returncode},indent=2)+'\n')
print(p.stdout); print('runtime_exit',p.returncode)
raise SystemExit(0 if p.returncode==1 else 2)
