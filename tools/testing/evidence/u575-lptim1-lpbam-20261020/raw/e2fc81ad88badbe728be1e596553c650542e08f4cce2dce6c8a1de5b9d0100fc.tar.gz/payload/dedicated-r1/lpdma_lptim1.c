/**
 * \file            lpdma_lptim1.c
 * \brief           Exact finite LPTIM1 request preparation
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-20
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus/components/stm32u575_lpdma_lptim1.h"
#include "nexus/arch/arch.h"
#include "nexus/io/dma.h"
nx_result_t nx_stm32u575_lpdma_lptim1_request_prepare(
    nx_stm32u575_lpdma_lptim1_request_t* request,
    const nx_stm32u575_retained_time_snapshot_t* domain,
    const nx_stm32u575_lptim1_tuple_t* tuple,
    nx_stm32u575_lpdma_lptim1_workspace_t* workspace, nx_time_us_t deadline) {
    (void)deadline;
    if (!nx_arch_is_privileged() || nx_arch_exception_number() != 0U)
        return NX_ERROR_CONTEXT;
    if (request == NULL || domain == NULL || tuple == NULL ||
        workspace == NULL)
        return NX_ERROR_INVALID;
    static const nx_dma_memory_region_t region = {
        UINT32_C(0x28000000), 16384U, NX_DMA_MEMORY_READ};
    nx_result_t result = nx_dma_buffer_validate(
        &region, 1U, tuple, sizeof(*tuple), 4U, NX_DMA_TO_DEVICE);
    if (result != NX_SUCCESS)
        return result;
    result = nx_dma_buffer_validate(&region, 1U, workspace, sizeof(*workspace),
                                   4U, NX_DMA_TO_DEVICE);
    return result == NX_SUCCESS ? NX_ERROR_UNSUPPORTED : result;
}
