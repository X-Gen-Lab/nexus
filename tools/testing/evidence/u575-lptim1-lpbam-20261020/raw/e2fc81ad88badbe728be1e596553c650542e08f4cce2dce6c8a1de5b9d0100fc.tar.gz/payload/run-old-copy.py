from pathlib import Path
import subprocess,json,sys,hashlib
root=Path('/tmp/nexus-u575-lptim1-lpbam-20261020');base=Path('/tmp/nexus-quality-20261019')
label=sys.argv[1] if len(sys.argv)>1 else 'native-green-r1'
mode=sys.argv[2] if len(sys.argv)>2 else 'debug'
build=root/'verification'/label;build.mkdir(exist_ok=False)
ev=root/'evidence'/label;ev.mkdir(exist_ok=False)
def source(rel): return root/rel if (root/rel).is_file() else base/rel
incs=['components/stm32u575_stop2/include','components/stm32u575_lpdma_copy/include','components/stm32u575_lpdma_copy/private','components/stm32u575_retained_time/include','components/stm32u575_retained_time/private','components/clock_domain/include','components/clock_domain/private','soc/stm32u575/private','io/private','core/include','arch/include','io/include','tests/google/u575_lpdma_copy']
opts=['-Wall','-Wextra','-Werror','-Wconversion','-Wshadow','-pedantic','-DSTM32U575xx','-DNX_U575_LPDMA_COPY_MODEL','-DNX_U575_STOP2_MODEL','-DNEXUS_U575_STOP2_COPY','-D_POSIX_C_SOURCE=200809L','-ffunction-sections','-fdata-sections']
opts+=['-Os','-DNDEBUG'] if mode=='release' else ['-O0','-g']
for p in incs:
 if (root/p).is_dir():opts+=['-I',str(root/p)]
 if (base/p).is_dir():opts+=['-I',str(base/p)]
for p in ['vendors/st/cmsis_device_u5/Include','vendors/arm/CMSIS_5/CMSIS/Core/Include','vendors/st/stm32u5_hal/Inc','ext/googletest/googletest/include','ext/googletest/googlemock/include']:opts+=['-isystem',str(base/p)]
commands=[];identities=[]
def run(args):
 commands.append(args)
 p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 with (ev/'raw.log').open('a') as f:f.write('$ '+repr(args)+'\n'+p.stdout)
 (ev/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if p.returncode:
  print(p.stdout);print('failed_exit',p.returncode);raise SystemExit(p.returncode)
objects=[]
for rel in ['soc/stm32u575/drivers/lpdma_copy.c','soc/stm32u575/stop2.c','components/stm32u575_retained_time/src/stm32u575_retained_time.c','components/clock_domain/src/clock_domain.c','core/src/request.c','core/src/time.c','core/src/fault.c','io/src/rtc.c','io/src/dma.c','arch/native/nx_arch_native.c','tests/google/u575_lpdma_copy/model.cpp','tests/google/u575_stop2_copy/test.cpp']:
 src=source(rel);identities.append({'path':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest()});obj=build/(src.stem+'.o');extra=[]
 if src.name=='stm32u575_retained_time.c':extra=['-include',str(base/'tests/google/u575_stop2_copy/clock_port.h')]
 if src.name=='model.cpp':extra=['-Dnx_u575_lpdma_copy_read=nx_u575_lpdma_copy_bus_read','-Dnx_u575_lpdma_copy_write=nx_u575_lpdma_copy_bus_write']
 run(['g++' if src.suffix=='.cpp' else 'gcc','-std=c++17' if src.suffix=='.cpp' else '-std=c11',*opts,*extra,'-c',str(src),'-o',str(obj)]);objects.append(str(obj))
google=Path('/tmp/nexus-googletest-tdd-20261019/smoke-build/lib')
run(['g++','-Wl,--gc-sections',*objects,str(google/'libgmock_main.a'),str(google/'libgmock.a'),str(google/'libgtest.a'),'-pthread','-o',str(build/'test')])
(ev/'source-hashes.json').write_text(json.dumps(identities,indent=2)+'\n')
args=[str(build/'test'),'--gtest_output=xml:'+str(ev/'result.xml')];commands.append(args)
p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(ev/'raw.log').open('a').write(p.stdout);(ev/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(ev/'exit.json').write_text(json.dumps({'runtime_exit':p.returncode,'mode':mode})+'\n');print(p.stdout)
raise SystemExit(p.returncode)
