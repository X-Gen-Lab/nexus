import importlib.util, sys, unittest
from pathlib import Path
sys.dont_write_bytecode=True
base=Path("/tmp/nexus-quality-20261019")
over=Path("/tmp/nexus-u575-lptim1-lpbam-20261020")
sys.path.insert(0,str(base))
import tools.configure.providers as package
name="tools.configure.providers.descriptor"
spec=importlib.util.spec_from_file_location(name,over/"tools/configure/providers/descriptor.py")
descriptor=importlib.util.module_from_spec(spec)
sys.modules[name]=descriptor
spec.loader.exec_module(descriptor)
package.descriptor=descriptor
spec=importlib.util.spec_from_file_location("nexus_u575_provider_overlay",over/"tools/configure/providers/stm32u575/test_provider.py")
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.ROOT=base
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
