# Exact U575 LPTIM1 ordinary gate preservation

This is a read-only preservation of the actual ordinary gate whose first
`tools-testing.started_ns` is `1792528706455749772`. The native execution report
and 346 original GoogleTest XML files contain 6207 passed cases, zero failures,
errors or skips. The complete tool domains contain testing1335, configure925,
ci485 and workflows122: 2867 passed tool cases. Original current reports,
immutable attempt receipts and stdout/stderr are preserved without filtering.
Zero-byte streams are valid and are checked by exact bytes and SHA256.

The ordinary commit is `578235b2`, tree
`32d61a7035478f3afe50d4bca9abb0a97a2225fe`, parent
`71bd3c32d459e18e034c15c54a6b00e372526513`. The original 94-file freeze and an
independent read-only comparison of every frozen SHA256 against `git show`
committed blobs are included. No Git index, source, vendor tree or build object
was modified or copied wholesale. No earlier evidence archive is nested here.

The full documentation report retains its actual identity: parent `71bd3c32`,
dirty=true, source tree `840c81d0c3776032bc6bd364df4bef33849d3a21`, working source
SHA256 `5fedb2e8a262c208923cfb55195cda2bac78ce465b51b979b3063279fc9251fe`.
It is not relabeled as a clean build of `578235b2`. Its original four command
attempt receipts and raw streams, source check, 250 translation records, and
the selected source, FIG28, bilingual and one installed-consumer reports are
preserved with their original scopes. Historical report claims are not promoted
by copying them.

`capture-inventory.json` maps original paths to preserved regular files and
records their exact hashes. `review/gate-stream-case-audit.json` verifies the
case totals and 2808 raw-stream references across 1404 alias/immutable command
receipts. `review/independent-source-binding.json` binds the 94 committed blobs
and the original documentation phase. Compiler, configure, tests and renderer
were not rerun. This package establishes no hardware/HIL, complete SDK or
release-candidate qualification. All original logs and diagnostics remain as
captured; preservation does not convert failures into successes.
