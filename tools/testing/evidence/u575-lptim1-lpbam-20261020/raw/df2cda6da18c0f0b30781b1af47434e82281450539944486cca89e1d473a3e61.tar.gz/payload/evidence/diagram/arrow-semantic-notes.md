# FIG-28 semantic and render receipt

Scope is one exact software reference: STM32U575ZIT6Q, TZEN0, baremetal,
nonsecure SRAM4, LPDMA1 channel0, one fixed LPTIM1 CCR1/RCR0/ARR tuple.
The registry remains `not_reviewed`: corrected-source/hash conformance for the
approved DIER/write-OK addendum is pending. The frozen implementation's former
post-DIER success check is not silently treated as correct. This receipt makes
no firmware, hardware, PWM playback, physical Stop2 or HIL claim.

The diagram answers one question: which ordered proofs permit final SETTLED?
There are 13 nodes, 18 labelled edges and one invisible layout edge. All solid
edges carry required order or a named branch; dashed edges retain responsibility
or retry a proof. Neither colour nor a success-looking reset state conveys
ownership release.

1. Pure initialization precedes explicit public start. Start claims LPTIM1EN,
   the LSE kernel mux and only needed LSESYSEN, observing LSESYSRDY. Its partial
   effects remain in the start ledger until joined public stop. The separate
   partial-start branch has no tuple loan and may not adopt/reset a foreign
   controller. The README records ARM owner 104 B, added ledger 16 B, old copy
   owner 88 B; these are separate profile costs.
2. Only ACCEPTED starts the request/12 B tuple/complete 48 B LLI loan. RUN is
   closed and joined, LPTIM2 disabled, Platform stopped, privileged masked MSP
   Thread context. Both faces use the same concrete Stop2/ClockDomain owner.
3. The enable wait is bounded and uses at least two additional retained RTC
   ticks after ENABLE. It neither invents a hardware READY bit nor substitutes
   polling counts for elapsed counter clocks. Bootstrap write-OK flags must be
   fresh and cleared before the peripheral DMA program. WUT is the independent
   escape; AlarmA is not configured.
4. Hardware request13 is REQSEL lptim1_ue_dma, not trigger13 and not LPTIM3
   request16. BREQ1 and reserved DREQ0 are explicit. Two SWREQ continuations
   select distinct fixed destinations RCR then ARR; the graph does not suggest
   incrementing through adjacent peripheral registers. ARR's APB write ACK
   clears UE. There is no repeated-tuple mode.
5. The success branch first observes full finite DMA completion and captures all
   three fresh write-OKs before a DIER change can erase them (ES0499 2.17.3).
   Earlier cause-SUCCESS service remains BUSY. A first incomplete-OK attempt
   retains producer and loan; valid-profile recovery carries the latched failure
   before withdrawal. Later completion cannot upgrade an already latched error.
   The cancel/deadline/error branch still enters the complete drain; it cannot
   return storage directly. Partial error needs no flag for an unissued write.
6. The cleanup cluster's four steps are ordered: UEDE0/fresh DIEROK, then WUT
   withdrawal; DMA suspend/SUSPF/idle and full-word RESET/complete CCR0 plus
   address/link/flag/NVIC detachment; exclusively owned LPTIM1 RCC reset and
   quiet IRQ67/loan sleep gates; remaining loan gates, RTC, power, clocks and
   request/Stop2 references. ES0499 2.17.1 forbids clearing ENABLE for shutdown.
7. A failed proof points from the compound cluster to retained responsibility.
   Unknown access profile forbids RTC/DMA/LPTIM MMIO (core vector withdrawal is
   still permitted). Recover retains masks and executes no new WFI. An owned
   LPTIM RCC-reset retry is allowed only after DMA final-access proof. An
   observed external DMA/LPTIM reset during a loan instead permanently
   quarantines it; there is no outgoing release/retry edge from that node.
8. Final release SETTLED is after every compound proof and reference detach.
   Acquire observation plus outside observer joins is separate. Joined public
   stop then returns start-level gate/mux/LSESYS claims and the physical role.

Existing source bindings are in `frozen-source-read-binding.json`; they bind
what was read without certifying the pending corrected order. Manual anchors
are RM0456 Rev7 18.3.3/Table148, 18.3.4/Table149, 58.4.11, 58.4.13,
58.4.20–21, 58.5, 58.7.8 and 11.8.48–49; ES0499 Rev12 2.17.1–3.

`render-report.json` records actual pinned `tools.documentation.diagrams` and
`diagram_localization` execution for exactly canonical, EN and zh_CN FIG-28
assets. It validates safe local Cairo glyph SVG, accessible title/description,
and no external resources. The complete label-key set was checked in memory
using primary canonical files, H743 future-base replacements and FIG-28; no
other diagrams were copied. Existing H743 future-base mapping values remain
unchanged. Canonical and EN DOT/SVG are byte-identical by design.

The EN and zh_CN PNG previews from the same pinned DOT renderer were visually
inspected: labels, arrowheads, proof ordering and glyphs are legible and do not
overlap node text. Browser desktop/narrow/zoom/print and offline-site checks
were not executed here. Original complete IO-32/SOC-35 exits remain open.

Independent agent review `/root/u575_lptim_lpbam/diagram_doc/bilingual_arrow_review`
approved intended diagram semantics and all 33 EN/ZH labels plus nine README
prose pairs. Its source/hash/GREEN approval remains explicitly pending. Parent
owns the final corrected-source review and README PO generation.
