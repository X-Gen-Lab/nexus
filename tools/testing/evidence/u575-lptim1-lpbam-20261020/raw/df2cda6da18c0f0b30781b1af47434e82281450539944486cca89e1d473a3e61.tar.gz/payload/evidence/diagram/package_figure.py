"""Package only the nine owned diagram files against the declared future base."""

from pathlib import Path
import difflib
import hashlib
import json

OWNED = Path('/tmp/nexus-u575-lptim1-docs-20261020')
PRIMARY = Path('/tmp/nexus-quality-20261019')
FUTURE = Path('/tmp/nexus-h743-full-window-diagrams-20261020/delivery/final')
FOLDER = OWNED / 'final/docs/assets/diagrams'
EVIDENCE = OWNED / 'evidence/diagram'
BEFORE = json.loads((EVIDENCE / 'metadata-before.json').read_text())
files = []
patch = []
for path in sorted(FOLDER.rglob('*')):
    if path.is_symlink():
        raise ValueError('symlink in owned final diagram delta')
    if not path.is_file():
        continue
    rel = path.relative_to(OWNED / 'final').as_posix()
    old_path = FUTURE / rel if path.name in BEFORE and path.parent == FOLDER else PRIMARY / rel
    old = old_path.read_bytes() if old_path.is_file() else None
    if path.name in BEFORE and path.parent == FOLDER:
        if old is None or hashlib.sha256(old).hexdigest() != BEFORE[path.name]['sha256']:
            raise ValueError('future-base metadata changed')
    final = path.read_bytes()
    if old == final:
        raise ValueError('unchanged file in diagram delta')
    patch.append('diff --git a/' + rel + ' b/' + rel + '\n')
    if old is None:
        patch.append('new file mode 100644\n')
    patch.extend(difflib.unified_diff(
        (old or b'').decode().splitlines(keepends=True),
        final.decode().splitlines(keepends=True),
        fromfile='a/' + rel if old is not None else '/dev/null',
        tofile='b/' + rel))
    files.append({'path': rel,
                  'before_sha256': hashlib.sha256(old).hexdigest() if old is not None else None,
                  'before_source': str(old_path) if old is not None else None,
                  'final_sha256': hashlib.sha256(final).hexdigest(),
                  'bytes': len(final)})
if len(files) != 9:
    raise ValueError('diagram delta must contain exactly nine files')
(EVIDENCE / 'diagram.patch').write_text(''.join(patch))
manifest = {
    'schema_version': 1,
    'scope': 'FIG-28 diagram-only sparse documentation delta',
    'metadata_future_base': str(FUTURE),
    'preservation': 'H743 future-base README/registry/labels are retained; only FIG-28 is added. Other graph sources are read in place, never copied.',
    'files': files,
    'review_status': 'intended semantics and bilingual review approved; corrected addendum source/hash binding pending',
    'primary_written': False,
    'frozen_source_written': False,
    'compiler_or_configure_executed': False,
}
(EVIDENCE / 'diagram-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'files': len(files),
                  'patch_bytes': (EVIDENCE / 'diagram.patch').stat().st_size,
                  'patch_sha256': hashlib.sha256((EVIDENCE / 'diagram.patch').read_bytes()).hexdigest(),
                  'manifest_sha256': hashlib.sha256((EVIDENCE / 'diagram-manifest.json').read_bytes()).hexdigest()}, indent=2))
