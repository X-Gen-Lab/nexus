"""Write only the FIG-28 owned sparse documentation delta; no compiler work."""

from pathlib import Path
import csv
import hashlib
import io
import json
import sys

PRIMARY = Path('/tmp/nexus-quality-20261019')
OWNED = Path('/tmp/nexus-u575-lptim1-docs-20261020')
FINAL = OWNED / 'final/docs/assets/diagrams'
EVIDENCE = OWNED / 'evidence/diagram'
NAME = 'u575-lptim1-lpbam'

for path in (OWNED, FINAL, EVIDENCE):
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('owned path contains symlink')
FINAL.mkdir(parents=True, exist_ok=True)
EVIDENCE.mkdir(parents=True, exist_ok=True)

labels = {}


def label(en, zh):
    raw = json.dumps(en, ensure_ascii=False)[1:-1]
    if raw in labels and labels[raw] != (en, zh):
        raise ValueError('conflicting figure label')
    labels[raw] = (en, zh)
    return json.dumps(en, ensure_ascii=False)


title = label(
    'FIG-28 reference: one LPTIM1 tuple, one Stop2 owner, ordered final-access proof\n'
    'STM32U575ZIT6Q / TZEN0 / baremetal / SRAM4_NS / LPDMA1 channel0\n'
    'Solid: required order or named branch. Dashed: retained responsibility / recovery.\n'
    'No pin route, PWM playback or HIL claim; complete IO-32 / SOC-35 exits remain open.',
    'FIG-28 reference：单组 LPTIM1 tuple、唯一 Stop2 owner、有序最终访问证明\n'
    'STM32U575ZIT6Q / TZEN0 / baremetal / SRAM4_NS / LPDMA1 channel0\n'
    '实线：必要顺序或标明的分支。虚线：保留责任／恢复。\n'
    '不声明引脚路由、PWM 播放或 HIL；IO-32 / SOC-35 完整退出仍开放。')

nodes = [
    ('prepare',
     'Pure initialize → explicit public start\nCold / exclusive: LPTIM1EN + LSE mux + needed LSESYSEN\nObserve LSESYSRDY; effects owned until joined public stop',
     '纯 initialize → 显式公共 start\n冷态／独占：LPTIM1EN + LSE mux + 按需 LSESYSEN\n观察 LSESYSRDY；效果保留至 joined 公共 stop', '#eff6ff'),
    ('loan',
     'Closed / joined RUN; LPTIM2 disabled; Platform stopped\nPrivileged masked MSP Thread; same Stop2 owner / ClockDomain\nACCEPTED borrows request + tuple 12 B + LLI workspace 48 B',
     'RUN 已关闭／join；LPTIM2 已禁用；Platform 已停\nprivileged masked MSP Thread；同一 Stop2 owner / ClockDomain\nACCEPTED 借用 request + 12 B tuple + 48 B LLI 工作区', '#eff6ff'),
    ('arm',
     'Bounded: after ENABLE, at least 2 more retained RTC ticks\nFresh bootstrap CMP1OK / REPOK / ARROK, then clear\nIndependent WUT escape; no AlarmA writes',
     '有界等待：ENABLE 后至少再过 2 个保留 RTC tick\n初始 CMP1OK / REPOK / ARROK 新鲜证明后清旗\n独立 WUT 退出；不写 AlarmA', '#eff6ff'),
    ('writes',
     'HW REQ13 / BREQ1 / reserved DREQ0 → CCR1\nTwo SWREQ continuation LLIs → RCR0 → ARR last\nARR acknowledged APB write clears UE',
     'HW REQ13 / BREQ1 / 保留位 DREQ0 → CCR1\n两个 SWREQ continuation LLI → RCR0 → 最后 ARR\nARR 的 APB 写应答清除 UE', '#ecfdf5'),
    ('writeok',
     'Success: observe finite DMA completion + latch fresh three write-OK\nKeep this proof before DIER can clear the flags',
     '成功：观察有限 DMA 完成 + 锁存三个新鲜 write-OK\n在 DIER 可能清旗前保留此证明', '#ecfdf5'),
    ('withdraw',
     '1. Withdraw producer: UEDE0 + fresh DIEROK\nThen withdraw WUT',
     '1. 撤回生产源：UEDE0 + 新鲜 DIEROK\n随后撤回 WUT', '#f0fdf4'),
    ('master',
     '2. DMA suspend / SUSPF / idle\nFull-word CCR RESET, then complete CCR0\nDetach address / link / flags / NVIC references',
     '2. DMA suspend / SUSPF / idle\n整字 CCR RESET，再证明完整 CCR0\n撤除地址／link／flags／NVIC 引用', '#f0fdf4'),
    ('timer',
     '3. Owned LPTIM1 RCC reset; never ENABLE0 (ES0499)\nProve cold controller / quiet IRQ67\nRestore loan SMEN / AMEN',
     '3. 自有 LPTIM1 RCC reset；绝不 ENABLE0（ES0499）\n证明控制器冷态／IRQ67 安静\n恢复本次借用的 SMEN / AMEN', '#f0fdf4'),
    ('settled',
     '4. Restore remaining loan gates / RTC / power / clocks\nDetach Stop2 and request references\nFinal release store: SETTLED',
     '4. 恢复其余借用 gate／RTC／电源／时钟\n撤除 Stop2 与 request 引用\n最后 release store：SETTLED', '#dcfce7'),
    ('stop',
     'Acquire-observe SETTLED + external observer joins\nJoined public stop restores start gate / mux / LSESYS\nOnly then release the physical role',
     'acquire 观察 SETTLED + 外部观察者 join\njoined 公共 stop 恢复启动 gate／mux／LSESYS\n随后才释放物理角色', '#dcfce7'),
    ('partial',
     'Partial start failure: no tuple loan\nPublic stop retries start-ledger restoration\nNever adopt or reset a foreign controller',
     'start 部分失败：尚无 tuple 借用\n公共 stop 重试启动账本恢复\n不接管或复位外部控制器', '#fff7ed'),
    ('held',
     'Failed proof retains the loan and all storage\nLatched error stays error despite later completion\nUnknown profile: no RTC / DMA / LPTIM MMIO\nRecover keeps masks; never another WFI\nOwned-reset retry only after DMA final-access proof',
     '证明失败保留借用与全部存储\n后续完成不得将已锁存错误升级为成功\nprofile 未知：不访问 RTC / DMA / LPTIM MMIO\nrecover 保持 mask；绝不再次 WFI\n自有复位仅在 DMA 最终访问证明后可重试', '#fff7ed'),
    ('foreign',
     'Observed external DMA or LPTIM reset during a loan\nPermanent quarantine; storage remains borrowed\nQuiet reset defaults do not prove a join',
     '借用期间观察到外部 DMA 或 LPTIM reset\n永久隔离；存储仍被借用\n安静的复位默认值不能证明 join', '#fef2f2'),
]

edges = [
    ('prepare', 'loan', 'start succeeds', 'start 成功', ''),
    ('prepare', 'partial', 'start fails with effects', 'start 失败且保留效果', ''),
    ('loan', 'arm', 'ACCEPTED', 'ACCEPTED', ''),
    ('arm', 'writes', 'start producer / masked WFI', '启动生产源／masked WFI', ''),
    ('writes', 'writeok', 'finite DMA observed\nearlier service stays BUSY',
     '已观察有限 DMA\n此前 service 保持 BUSY', ''),
    ('writeok', 'withdraw', 'success proof retained', '保留成功证明', ''),
    ('writes', 'withdraw', 'cancel / deadline / error\nstorage stays borrowed',
     'cancel／deadline／error\n存储仍被借用', 'constraint=false'),
    ('arm', 'withdraw', 'accepted setup fails', '已接受后准备失败',
     'constraint=false,tailport=w,headport=w'),
    ('withdraw', 'master', 'producer withdrawn and acknowledged', '生产源已撤回并应答', ''),
    ('master', 'timer', 'DMA final access proved', 'DMA 最终访问已证明', ''),
    ('timer', 'settled', 'peripheral and IRQ proof', '外设与 IRQ 已证明', ''),
    ('settled', 'stop', 'final SETTLED only', '仅最终 SETTLED', ''),
    ('partial', 'partial', 'public stop retry; ledger stays owned',
     '公共 stop 重试；账本仍保留', 'style=dashed'),
    ('writes', 'held', 'access profile lost', '访问 profile 失效',
     'style=dashed,constraint=false,tailport=e,headport=n'),
    ('writeok', 'held', 'missing write-OK:\nfirst keep producer + loan',
     'write-OK 未全：\n首轮保留生产源 + 借用',
     'style=dashed,constraint=false,tailport=e,headport=w'),
    ('master', 'held', 'any compound proof fails', '任一复合证明失败',
     'style=dashed,constraint=false,ltail=cluster_exit'),
    ('held', 'withdraw', 'valid profile; recover\ncarry failure before withdrawal',
     'profile 有效后 recover\n撤源前先带入失败',
     'style=dashed,constraint=false,lhead=cluster_exit'),
    ('held', 'foreign', 'external reset observed at any active-loan phase',
     '任何活动借用阶段观察到外部复位', 'style=dashed'),
]

lines = [
    'digraph u575Lptim1Lpbam {',
    '  graph [label=' + title + ', rankdir=TB, labelloc=t,',
    '    fontname="Noto Sans CJK SC", fontsize=16, bgcolor="white",',
    '    pad=0.25, nodesep=0.30, ranksep=0.44, splines=polyline, compound=true];',
    '  node [shape=box, style="rounded,filled", color="#475569",',
    '    fontcolor="#0f172a", fontname="Noto Sans CJK SC", fontsize=12,',
    '    margin="0.13,0.09"];',
    '  edge [color="#475569", fontcolor="#0f172a",',
    '    fontname="Noto Sans CJK SC", fontsize=10, arrowsize=0.75];',
]
for name, en, zh, color in nodes:
    group = 'side' if name in {'partial', 'held', 'foreign'} else 'main'
    lines.append(f'  {name} [label={label(en, zh)}, fillcolor="{color}", group="{group}"];')
lines.append('  subgraph cluster_exit {')
lines.append('    label=' + label('Compound exit: all four proofs are required',
                                '复合退出：四项证明缺一不可') + ';')
lines.append('    color="#86a2b8"; style=rounded; fontsize=12;')
lines.append('    withdraw; master; timer; settled;')
lines.append('  }')
for source, target, en, zh, attributes in edges:
    extra = ', ' + attributes if attributes else ''
    weight = 1 if 'constraint=false' in attributes or target == 'partial' else 20
    lines.append(f'  {source} -> {target} [label={label(en, zh)}, weight={weight}{extra}];')
lines.extend([
    '  { rank=same; loan; partial; }',
    '  { rank=same; writeok; held; }',
    '  { rank=same; stop; foreign; }',
    '  partial -> held [style=invis, weight=20];',
    '}',
])
source = '\n'.join(lines) + '\n'
(EVIDENCE / (NAME + '.draft.dot')).write_text(source, encoding='utf-8')
(EVIDENCE / 'new-labels.json').write_text(json.dumps({
    'schema_version': 1,
    'en': {key: value[0] for key, value in labels.items()},
    'zh_CN': {key: value[1] for key, value in labels.items()},
}, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

print(json.dumps({'draft_labels': len(labels), 'draft_nodes': len(nodes),
                  'draft_edges': len(edges), 'source': str(EVIDENCE / (NAME + '.draft.dot'))}))
