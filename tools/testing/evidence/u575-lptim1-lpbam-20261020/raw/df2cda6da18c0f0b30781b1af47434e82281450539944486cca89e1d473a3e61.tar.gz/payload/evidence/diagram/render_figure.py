"""Render only FIG-28's three DOTs with the existing pinned docs renderer."""

from pathlib import Path
import hashlib
import json
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
PRIMARY = Path('/tmp/nexus-quality-20261019')
METADATA_BASE = Path('/tmp/nexus-h743-full-window-diagrams-20261020/delivery/final/docs/assets/diagrams')
OWNED = Path('/tmp/nexus-u575-lptim1-docs-20261020')
FINAL = OWNED / 'final/docs/assets/diagrams'
EVIDENCE = OWNED / 'evidence/diagram'
PREFIX = Path('/tmp/nexus-quality-doc-tools')
NAME = 'u575-lptim1-lpbam'
sys.path.insert(0, str(PRIMARY))
from tools.documentation import diagrams, diagram_localization, install


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for path in (FINAL, EVIDENCE):
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('owned path contains symlink')

env = install.environment(PREFIX)
source = (EVIDENCE / (NAME + '.draft.dot')).read_text()
canonical = FINAL / (NAME + '.dot')
canonical.write_text(source)
mapping = json.loads((FINAL / 'labels.json').read_text())
old_mapping = json.loads((METADATA_BASE / 'labels.json').read_text())
fragment = json.loads((EVIDENCE / 'new-labels.json').read_text())
required = set(diagrams.LABEL.findall(source))
all_labels = set(required)
for existing in (PRIMARY / 'docs/assets/diagrams').glob('*.dot'):
    replacement = METADATA_BASE / existing.name
    canonical_base = replacement if replacement.is_file() else existing
    all_labels.update(diagrams.LABEL.findall(diagrams._regular(canonical_base).read_text()))
for language in diagram_localization.LANGUAGES:
    if set(mapping[language]) != all_labels:
        raise ValueError('virtual full canonical label closure differs')
    if set(fragment[language]) != required:
        raise ValueError('changed-label fragment differs from FIG-28')
    if any(mapping[language][key] != value for key, value in old_mapping[language].items()):
        raise ValueError('existing translation changed')

rows = diagrams._registry(FINAL)
row = next(row for row in rows if row['diagram_id'] == 'FIG-28')
if row['source_dot'] != canonical.name or row['rendered_svg'] != canonical.with_suffix('.svg').name:
    raise ValueError('FIG-28 registry source/output mismatch')

results = []
sources = [('canonical', canonical)]
for language in diagram_localization.LANGUAGES:
    path = FINAL / 'localized' / language / canonical.name
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('localized symlink path')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(diagram_localization.localize(source, mapping, language))
    sources.append((language, path))

for language, path in sources:
    output = path.with_suffix('.svg')
    output.write_bytes(diagrams.render(path, env))
    tree = diagrams.validate_svg(output.read_bytes())
    if tree.get('role') != 'img' or not tree.get('aria-labelledby'):
        raise ValueError('SVG accessibility labels absent')
    if any(element.tag.split('}')[-1] == 'text' for element in tree.iter()):
        raise ValueError('SVG font dependency remains')
    results.append({'language': language,
                    'dot': path.relative_to(OWNED / 'final').as_posix(),
                    'dot_sha256': digest(path),
                    'svg': output.relative_to(OWNED / 'final').as_posix(),
                    'svg_sha256': digest(output),
                    'svg_bytes': output.stat().st_size,
                    'viewBox': tree.get('viewBox'),
                    'renderer': 'tools.documentation.diagrams.render(dot, install.environment(prefix))',
                    'status': 'rendered_and_validated'})

for language, path in sources[1:]:
    preview = EVIDENCE / ('preview-' + language + '.png')
    result = subprocess.run([str(PREFIX / 'bin/dot'), '-Tpng:cairo'],
                            input=path.read_bytes(), env=env,
                            capture_output=True, timeout=30)
    (EVIDENCE / ('preview-' + language + '.stderr')).write_bytes(result.stderr)
    if result.returncode or result.stderr:
        raise ValueError('PNG visual preview failed')
    preview.write_bytes(result.stdout)

report = {
    'schema_version': 1,
    'scope': 'FIG-28 changed-only render and read-only virtual full label closure',
    'command': 'PYTHONDONTWRITEBYTECODE=1 python ' + str(EVIDENCE / 'render_figure.py'),
    'compiler_or_configure_executed': False,
    'primary_or_frozen_source_written': False,
    'tool_prefix': str(PREFIX),
    'tool_installation_receipt_sha256': digest(PREFIX / 'installation.json'),
    'tool_lock_sha256': digest(PRIMARY / 'dependencies/docs-tools.lock.json'),
    'renderer_source_sha256': digest(PRIMARY / 'tools/documentation/diagrams.py'),
    'localization_source_sha256': digest(PRIMARY / 'tools/documentation/diagram_localization.py'),
    'canonical_fig28_labels': len(required),
    'virtual_canonical_label_set': len(all_labels),
    'existing_mapping_values_preserved': True,
    'virtual_full_mapping_key_closure': True,
    'metadata_future_base': str(METADATA_BASE),
    'full_repo_docs_check_executed': False,
    'sparse_check_note': 'Existing canonical DOTs were read in place, H743 future-base canonical sources replaced same-name primary sources in memory, and FIG-28 was added in memory; no other diagrams were copied. Only the three new DOTs were rendered.',
    'results': results,
    'source_semantic_review': 'pending final fresh-write-OK-before-DIER source binding',
    'browser_desktop_narrow_zoom_print': 'not_executed',
    'physical_HIL': 'not_executed',
}
(EVIDENCE / 'render-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
