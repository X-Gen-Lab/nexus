"""Prepare the individually copied FIG-28 metadata and exact PO prose pairs."""

from pathlib import Path
import csv
import hashlib
import io
import json

PRIMARY = Path('/tmp/nexus-h743-full-window-diagrams-20261020/delivery/final/docs/assets/diagrams')
OWNED = Path('/tmp/nexus-u575-lptim1-docs-20261020')
FINAL = OWNED / 'final/docs/assets/diagrams'
EVIDENCE = OWNED / 'evidence/diagram'
new = json.loads((EVIDENCE / 'new-labels.json').read_text())
for path in (FINAL, EVIDENCE):
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('owned path contains symlink')

pairs = [
    ('FIG-28 另述单组 LPTIM1 tuple 的选定 LPBAM 参考，以及同一 Stop2 owner 的有序最终访问证明。',
     'FIG-28 adds the selected single-tuple LPTIM1 LPBAM reference and the ordered final-access proof of the same Stop2 owner.'),
    ('## FIG-28 U575 LPTIM1 单 tuple 与 Stop2 有序退出',
     '## FIG-28 U575 LPTIM1 single tuple and ordered Stop2 exit'),
    ('**身份：reference。范围：STM32U575ZIT6Q／TZEN0／baremetal／SRAM4／LPDMA1 channel0；仅一组固定 LPTIM1 CCR1／RCR0／ARR tuple，内部输出未路由。**',
     '**Identity: reference. Scope: STM32U575ZIT6Q / TZEN0 / baremetal / SRAM4 / LPDMA1 channel0; exactly one fixed LPTIM1 CCR1 / RCR0 / ARR tuple, with no routed output.**'),
    ('本图所需的 DIER／write-OK 顺序修正仍待 addendum 的最终源码与 GREEN 证据绑定；冻结参考包不据此获得成功资格。此处显示规范意图，渲染与翻译检查不建立源码符合性。',
     'The DIER / write-OK ordering correction required by this figure still awaits the addendum\'s final source and GREEN evidence binding. The frozen reference package gains no success qualification from this diagram. This is the normative intent; rendering and translation checks do not establish source conformance.'),
    ('![FIG-28：启动账本与活动借用分开；成功 write-OK、撤源、DMA 最终访问、外设复位和全部恢复后才最终 SETTLED](u575-lptim1-lpbam.svg)',
     '![FIG-28: separate start ledger and active loan; success write-OK, producer withdrawal, DMA final access, peripheral reset and all restoration precede final SETTLED](u575-lptim1-lpbam.svg)'),
    ('实线标明必要顺序或分支，虚线标明保留责任与恢复。纯初始化之后显式公共 start 取得冷态独占 LPTIM1 的 gate、LSE mux 与按需 LSESYS；部分失败的启动账本保留至公共 stop 证明恢复。新 ARM owner 为 104 B，其中新增 16 B 账本；原 SRAM4 copy owner 仍为 88 B。',
     'Solid arrows mark required order or branches; dashed arrows mark retained responsibility and recovery. After pure initialization, explicit public start acquires the cold, exclusive LPTIM1 gate, LSE mux and only the needed LSESYS access. A partial start failure retains its ledger until public stop proves restoration. The new ARM owner is 104 B, including a 16 B added ledger; the original SRAM4 copy owner remains 88 B.'),
    ('ACCEPTED 借用 request、12 B tuple 与完整 48 B LLI 工作区。ENABLE 后至少再过两个保留 RTC tick；初始新鲜写 OK 先证明再清旗。硬件请求 13／BREQ1／保留位 DREQ0 写 CCR1，两个 SWREQ continuation LLI 依次写 RCR0、最后写 ARR；成功还须三个新鲜 write-OK。没有重复 tuple 模式；RUN LPTIM2 须预先关闭并 join。',
     'ACCEPTED borrows the request, the 12 B tuple and the complete 48 B LLI workspace. At least two additional retained RTC ticks follow ENABLE; fresh bootstrap write-OK flags are proved and then cleared. Hardware request 13 / BREQ1 / reserved DREQ0 writes CCR1; two SWREQ continuation LLIs write RCR0 and then ARR last. Success also requires all three fresh write-OK flags. There is no repeated-tuple mode; RUN LPTIM2 must already be disabled and joined.'),
    ('cancel／deadline 不撤销存储。UEDE0／DIEROK 证明先于 DMA suspend／reset／idle 及引用撤除；随后通过自有 RCC reset 关闭 LPTIM1，绝不清 ENABLE。全部 RTC／IRQ／loan gate／电源／时钟与引用恢复后才最终 SETTLED；acquire 观察与外部 observer join 后，joined 公共 stop 另行归还启动 access claims。未知 profile 禁止 RTC／DMA／LPTIM MMIO；recover 不再 WFI。自有 reset 仅在 DMA 最终访问证明后可重试；活动借用期间观察到的外部 reset 永久隔离，安静默认值不能证明 join。',
     'Cancel and deadline do not revoke storage. UEDE0 / DIEROK proof precedes DMA suspend / reset / idle and reference withdrawal. Owned RCC reset then shuts down LPTIM1 without clearing ENABLE. Only complete restoration of RTC, IRQ, loan gates, power, clocks and references permits final SETTLED. After acquire observation and external observer joins, joined public stop separately returns the start access claims. An unknown profile forbids RTC / DMA / LPTIM MMIO; recover never executes another WFI. Owned reset can be retried only after DMA final-access proof. External reset observed during an active loan permanently quarantines it; quiet defaults cannot prove a join.'),
    ('依据：[单 tuple 参考合同](../../design/u575-lptim1-lpbam.md)、[公共 receiver](../../../components/stm32u575_lpdma_lptim1/include/nexus/components/stm32u575_lpdma_lptim1.h)、[公共 Stop2 face](../../../components/stm32u575_stop2/include/nexus/components/stm32u575_stop2_lptim1.h)、[私有 LPTIM1 profile](../../../soc/stm32u575/private/stm32u575_lptim1_profile.h)。[可编辑 DOT](u575-lptim1-lpbam.dot)；实施关联：IO-32／SOC-35。图不表示引脚路由、完整 PWM 周期播放或物理／HIL 执行；原完整退出条件仍开放。',
     'Basis: [single-tuple reference contract](../../design/u575-lptim1-lpbam.md), [public receiver](../../../components/stm32u575_lpdma_lptim1/include/nexus/components/stm32u575_lpdma_lptim1.h), [public Stop2 face](../../../components/stm32u575_stop2/include/nexus/components/stm32u575_stop2_lptim1.h), and [private LPTIM1 profile](../../../soc/stm32u575/private/stm32u575_lptim1_profile.h). [Editable DOT](u575-lptim1-lpbam.dot); implementation links: IO-32 / SOC-35. The diagram establishes no pin route, complete PWM-period playback or physical / HIL execution; the original complete exit conditions remain open.'),
]

before = {}
for name in ('labels.json', 'diagram-index.csv', 'README.md'):
    path = PRIMARY / name
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('primary metadata path contains symlink')
    before[name] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                    'bytes': path.stat().st_size}

mapping = json.loads((PRIMARY / 'labels.json').read_text())
for language in ('en', 'zh_CN'):
    for key, value in new[language].items():
        if key in mapping[language] and mapping[language][key] != value:
            raise ValueError('existing translation key conflict')
        mapping[language][key] = value
(FINAL / 'labels.json').write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + '\n')

readme = (PRIMARY / 'README.md').read_text()
anchor = '原15类主图及两张补充图的代码依据保持'
if readme.count(anchor) != 1 or '## FIG-28' in readme:
    raise ValueError('README before context mismatch')
readme = readme.replace(anchor, pairs[0][0] + '\n\n' + anchor)
readme = (readme.rstrip() + '\n\n(fig-28-u575-lptim1-lpbam)=\n' +
          '\n\n'.join(zh for zh, en in pairs[1:]) + '\n')
(FINAL / 'README.md').write_text(readme)

old_csv = (PRIMARY / 'diagram-index.csv').read_text()
rows = list(csv.DictReader(io.StringIO(old_csv)))
if any(row['diagram_id'] == 'FIG-28' for row in rows):
    raise ValueError('FIG-28 already reserved')
fields = tuple(rows[0])
stream = io.StringIO(newline='')
writer = csv.DictWriter(stream, fieldnames=fields, lineterminator='\n')
writer.writerow({
    'diagram_id': 'FIG-28',
    'title': 'U575 LPTIM1 单 tuple 与 Stop2 有序退出',
    'kind': 'reference',
    'source_dot': 'u575-lptim1-lpbam.dot',
    'rendered_svg': 'u575-lptim1-lpbam.svg',
    'render_status': 'rendered',
    'review_status': 'not_reviewed',
    'code_basis': 'Public LPTIM1 receiver/Stop2 contracts and private LPTIM1 profile; docs/design/u575-lptim1-lpbam.md; pending final fresh-write-OK-before-DIER addendum source review',
    'task_id': 'IO-32;SOC-35',
    'scope': '仅 STM32U575ZIT6Q/TZEN0/baremetal/SRAM4/LPDMA1ch0 单组固定 CCR1/RCR0/ARR tuple；唯一 concrete Stop2 owner；独立 start effects 与活动 loan；write-OK/撤源/DMA/自有 RCC reset/全部恢复后最终 SETTLED；无输出 pinroute/PWM 播放/HIL 或完整原退出资格',
})
(FINAL / 'diagram-index.csv').write_text(old_csv.rstrip() + '\n' + stream.getvalue())

(EVIDENCE / 'metadata-before.json').write_text(json.dumps(before, indent=2) + '\n')
(EVIDENCE / 'readme-prose-pairs.json').write_text(json.dumps({
    'source': 'docs/assets/diagrams/README.md',
    'note': 'Exact new Chinese source prose and English equivalents; parent owns README PO generation.',
    'pairs': [{'zh_CN': zh, 'en': en} for zh, en in pairs],
}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'metadata_files': len(before), 'prose_pairs': len(pairs),
                  'added_label_keys': len(new['en'])}))
