from pathlib import Path
import contextlib,hashlib,io,json,shutil,sys
sys.dont_write_bytecode=True
r=Path('/tmp/nexus-u575-lptim1-docs-20261020');final=r/'final';ex=r/'extraction-final';repo=ex/'repository';tools=ex/'normalization-tools'
sys.path.insert(0,str(tools))
from tools.documentation import sphinx_ext
approval=r/'evidence/diagram/final-bilingual-approval.json'
assert json.loads(approval.read_text())['status'].startswith('approved')
merge=json.loads((ex/'po-merge-report.json').read_text());promoted=[]
for item in merge['files']:
 source=Path(item['draft_path']);dest=final/item['path'];raw=source.read_text()
 assert hashlib.sha256(source.read_bytes()).hexdigest()==item['final_sha256']
 assert 'X-Nexus-Reviewed: false' in raw
 raw=raw.replace('X-Nexus-Reviewed: false','X-Nexus-Reviewed: true').replace('# Exact POT merge draft; independent semantic review pending.','# Exact messages independently reviewed; approval bound by companion receipt.')
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(raw)
 meta,messages,fuzzy=sphinx_ext.read_catalog(dest)
 assert meta['X-Nexus-Reviewed']=='true' and not fuzzy and all(messages.values())
 assert meta['X-Nexus-Source-SHA256']==item['source_sha256']
 promoted.append({**item,'path':item['path'],'final_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'change_after_review':'Reviewed header and provenance comment only; messages unchanged'})
(r/'reviewed-catalog-manifest.json').write_text(json.dumps({'approval':{'path':str(approval),'sha256':hashlib.sha256(approval.read_bytes()).hexdigest()},'files':promoted},indent=2)+'\n')
# This preview renders the full new page and two exact related projections.
api=repo/'docs/reference/api/extension-components.md'
atlas=repo/'docs/assets/diagrams/README.md';full=(final/'docs/assets/diagrams/README.md').read_text();atlas.write_text(full[full.index('(fig-28-u575-lptim1-lpbam)='):])
for module in ('diagrams.py','diagram_localization.py'):
 shutil.copyfile(Path('/tmp/nexus-quality-20261019/tools/documentation')/module,tools/'tools/documentation'/module)
for rel in ('labels.json','localized/en/u575-lptim1-lpbam.svg','localized/zh_CN/u575-lptim1-lpbam.svg'):
 dest=repo/'docs/assets/diagrams'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(final/'docs/assets/diagrams'/rel,dest)
(repo/'docs/preview.rst').write_text('Focused LPTIM1 development preview\n================================\n\nFull new page; exact new API and FIG-28 sections only. This is not a full-site or SDK qualification build.\n\n.. toctree::\n   :maxdepth: 2\n\n   design/u575-lptim1-lpbam\n   reference/api/extension-components\n   assets/diagrams/README\n')
selected={'preview.rst','design/u575-lptim1-lpbam.md','reference/api/extension-components.md','assets/diagrams/README.md'}
exclude=[p.relative_to(repo/'docs').as_posix() for p in (repo/'docs').rglob('*') if p.suffix in ('.md','.rst') and p.relative_to(repo/'docs').as_posix() not in selected]
config=r/'preview-configuration';config.mkdir()
text=(ex/'configuration/conf.py').read_text().replace("root_doc = 'design/u575-lptim1-lpbam'","root_doc = 'preview'")
start=text.index('exclude_patterns = ');end=text.index('\n',start);text=text[:start]+'exclude_patterns = '+repr(exclude)+text[end:]
text+='\nlocale_dirs = ['+repr(str(final/'docs/locale'))+']\nhtml_theme = "alabaster"\nhtml_copy_source = False\nhtml_show_sourcelink = False\nproject = "Focused LPTIM1 development preview"\n'
text=text.replace("    app.connect('source-read', rewrite)","    app.connect('source-read', rewrite)\n    from tools.documentation.sphinx_ext import localize_diagram_images, link_local_svg_images, wrap_html_tables\n    app.connect('doctree-read', localize_diagram_images, priority=400)\n    app.connect('doctree-resolved', link_local_svg_images)\n    app.connect('doctree-resolved', wrap_html_tables)")
(config/'conf.py').write_text(text)
from sphinx.application import Sphinx
receipts=[]
for language in ('en','zh_CN'):
 output=r/'preview'/language;doctree=r/'preview-doctrees'/language;logs,warnings=io.StringIO(),io.StringIO()
 with contextlib.redirect_stdout(logs),contextlib.redirect_stderr(warnings):
  app=Sphinx(str(repo/'docs'),str(config),str(output),str(doctree),'html',confoverrides={'language':language},status=logs,warning=warnings,freshenv=True)
  app.build(force_all=True)
 (r/'evidence'/('html-'+language+'.stdout.log')).write_text(logs.getvalue());(r/'evidence'/('html-'+language+'.warnings.log')).write_text(warnings.getvalue())
 page=output/'design/u575-lptim1-lpbam.html';body=page.read_text()
 assert ('U575 跨 Stop2' in body) if language=='zh_CN' else ('U575 single-tuple' in body)
 assert ('NX_ERROR_IO' in body and 'REQ13' not in body) or 'NX_ERROR_IO' in body
 assert app.statuscode==0
 receipts.append({'language':language,'exit_code':app.statuscode,'pages':len(list(output.rglob('*.html'))),'full_new_page':str(page),'sha256':hashlib.sha256(page.read_bytes()).hexdigest(),'warnings':warnings.getvalue(),'catalogs':str(final/'docs/locale')})
report={'scope':'Focused actual bilingual HTML: full canonical new page, exact added API section projection and exact FIG-28 atlas section projection. Other pages excluded; preserved missing-cross-page warnings are preview-context limitations, not a strict whole-site result.','sphinx_version':__import__('sphinx').__version__,'launch_command':[str(Path(sys.executable)),str(Path(__file__))],'harness_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'input_catalog_manifest_sha256':hashlib.sha256((r/'reviewed-catalog-manifest.json').read_bytes()).hexdigest(),'builds':receipts}
(r/'evidence/focused-html-receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'promoted':len(promoted),'html':[{'language':i['language'],'exit':i['exit_code'],'pages':i['pages']} for i in receipts]}))
