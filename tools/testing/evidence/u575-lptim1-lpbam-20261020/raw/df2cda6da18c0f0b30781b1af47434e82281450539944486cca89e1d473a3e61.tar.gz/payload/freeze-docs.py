from pathlib import Path
import difflib,hashlib,json,shutil,subprocess,sys
sys.dont_write_bytecode=True
r=Path('/tmp/nexus-u575-lptim1-docs-20261020');final=r/'final';primary=Path('/tmp/nexus-quality-20261019');future=Path('/tmp/nexus-h743-full-window-diagrams-20261020/delivery/final')
sys.path.insert(0,str(r/'extraction-final/normalization-tools'))
from tools.documentation.sphinx_ext import read_catalog,translation_status
shared={'docs/assets/diagrams/README.md','docs/assets/diagrams/labels.json','docs/assets/diagrams/diagram-index.csv','docs/locale/en/LC_MESSAGES/assets/diagrams/README.po','docs/locale/zh_CN/LC_MESSAGES/assets/diagrams/README.po'}
def ident(path):return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size}
def regular(path):
 assert path.is_file() and not any(p.is_symlink() for p in (path,*path.parents)),str(path)
reviewed=json.loads((r/'reviewed-catalog-manifest.json').read_text());catalog_checks=[]
for item in reviewed['files']:
 path=final/item['path'];regular(path);assert ident(path)['sha256']==item['final_sha256']
 meta,msgs,fuzzy=read_catalog(path);assert meta['X-Nexus-Reviewed']=='true' and not fuzzy and all(msgs.values())
 rel=item['path'].split('/LC_MESSAGES/')[1].removesuffix('.po');source=final/'docs'/(rel+'.md');assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['X-Nexus-Source-SHA256']
 # API required-set union includes the unchanged baseline mapping plus the exact new-section POT.
 if rel=='reference/api/extension-components':
  required=set(read_catalog(primary/'docs/locale/en/LC_MESSAGES/reference/api/extension-components.po')[1]);required.update(read_catalog(r/'extraction-final/gettext/reference/api/extension-components.pot')[1])
 else:required=set(read_catalog(r/'extraction-final/gettext'/(rel+'.pot'))[1])
 state=translation_status(source.read_text(),rel,meta['Language'],final/'docs/locale',tuple(required));assert state['status']=='reviewed',(path,state)
 baseline=(future if item['path'] in shared else primary)/item['path'];old=read_catalog(baseline)[1] if baseline.is_file() else {}
 assert not(set(old)-set(msgs));assert all(msgs[k]==v for k,v in old.items()),str(path)
 catalog_checks.append({'path':item['path'],'messages':len(msgs),'status':state,'baseline_entries_retained':len(old),'old_values_changed':0})
for language in ('en','zh_CN'):
 actual=r/'preview'/language/'_images/u575-lptim1-lpbam.svg';expected=final/'docs/assets/diagrams/localized'/language/'u575-lptim1-lpbam.svg';assert actual.read_bytes()==expected.read_bytes()
rows=[];patch=[];applycheck=r/'patch-check';applycheck.mkdir()
for path in sorted(final.rglob('*')):
 if not path.is_file():continue
 regular(path);rel=path.relative_to(final).as_posix();assert not rel.endswith('.mo')
 base=(future if rel in shared else primary)/rel
 before=ident(base) if base.is_file() else None
 if before:
  regular(base);dest=applycheck/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base,dest)
 patch.extend(difflib.unified_diff(base.read_text().splitlines(True) if before else [],path.read_text().splitlines(True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
 rows.append({'path':rel,'before':before,'final':ident(path),'baseline':'H743 reviewed future-base' if rel in shared else ('primary' if before else 'new')})
(r/'integration.patch').write_text(''.join(patch))
result=subprocess.run(['git','apply','--check',str(r/'integration.patch')],cwd=applycheck,text=True,capture_output=True);assert result.returncode==0,result.stdout+result.stderr
checks={'catalogs':catalog_checks,'localization_asset_hashes_match':True,'actual_regular_file_count':len(rows),'patch_check':{'command':['git','apply','--check',str(r/'integration.patch')],'cwd':str(applycheck),'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr},'scope':'Exact selected-page/catalog and future-base patch checks only; no full-site, integrated SDK or HIL qualification'}
(r/'final-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
manifest={'files':rows,'count':len(rows),'future_base_shared_paths':sorted(shared),'source_reference':{'frozen30':ident(Path('/tmp/nexus-u575-lptim1-lpbam-20261020/integration-manifest.json')),'errata_addendum':ident(Path('/tmp/nexus-u575-lptim1-errata-20261020/integration-manifest.json'))},'scope':'Documentation-only increment; apply after H743 diagrams future-base shared5 and U575 source30+errata5. Source API bytes are authoritative; default selection and original IO32/SOC35 exit criteria unchanged.'}
(r/'integration-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
report={'status':'ready_for_parent_review','changed_files':len(rows),'patch':ident(r/'integration.patch'),'manifest':ident(r/'integration-manifest.json'),'bilingual_review':ident(r/'evidence/diagram/final-bilingual-approval.json'),'catalog_review_promotion':ident(r/'reviewed-catalog-manifest.json'),'checks':ident(r/'final-checks.json'),'focused_html':ident(r/'evidence/focused-html-receipt.json'),'diagram_render':ident(r/'evidence/diagram/render-report.json'),'scope':'One exact single-tuple LPTIM1 reference, public API/Doxygen links, narrow architecture/delivery summaries, FIG28 and 16 reviewed catalogs. Actual bilingual focused HTML/new API+figure projections and three pinned SVG renders; preserved context/deprecation warnings mean this is not a strict full-site result. Initial locale-harness failure is preserved and separately classified. No compiler/configure/HIL/SDK qualification performed by this docs package.','physical_status':'not_executed'}
(r/'final-delivery.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(rows),'patch':report['patch'],'manifest':report['manifest'],'catalogs':len(catalog_checks)}))
