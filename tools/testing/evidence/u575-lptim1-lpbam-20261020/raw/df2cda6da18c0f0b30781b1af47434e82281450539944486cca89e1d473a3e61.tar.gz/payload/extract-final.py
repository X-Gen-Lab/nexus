#!/usr/bin/env python3
"""Extract only changed prose and the two added API sections; no full-site claim."""
from pathlib import Path
import contextlib
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
PRIMARY = Path('/tmp/nexus-quality-20261019')
FROZEN = Path('/tmp/nexus-u575-lptim1-lpbam-20261020')
ERRATA = Path('/tmp/nexus-u575-lptim1-errata-20261020')
WORK = Path('/tmp/nexus-u575-lptim1-docs-20261020')
FINAL = WORK / 'final'
GENERATED = WORK / 'extraction-final'
REPOSITORY = GENERATED / 'repository'
TOOLS = GENERATED / 'normalization-tools'
PREFIX = Path('/tmp/nexus-quality-doc-tools')
PAGES = (
    'docs/design/u575-lptim1-lpbam.md',
    'docs/design/README.md',
    'docs/design/u575-retained-time.md',
    'docs/design/io-evolution.md',
    'docs/design/soc-refinement.md',
    'docs/delivery/README.md',
    'docs/assets/diagrams/README.md',
    'docs/reference/api/extension-components.md',
)
HEADERS = (
    'components/stm32u575_lpdma_lptim1/include/nexus/components/stm32u575_lpdma_lptim1.h',
    'components/stm32u575_stop2/include/nexus/components/stm32u575_stop2_lptim1.h',
)
inputs = {}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def safe(path):
    for item in (path, *path.parents):
        if item.is_symlink():
            raise ValueError('symlink input/output: ' + str(item))

def source(relative):
    for root in (FINAL, ERRATA, FROZEN, PRIMARY):
        path = root / relative
        safe(path)
        if path.exists():
            return path
    return None

def copy(relative, selected_source=None):
    origin = selected_source or source(relative)
    if origin is None:
        return
    destination = REPOSITORY / relative
    safe(destination)
    if origin.is_dir():
        destination.mkdir(parents=True, exist_ok=True)
        return
    if not origin.is_file():
        raise ValueError('nonregular source: ' + str(origin))
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(origin, destination)
    inputs[str(origin)] = digest(origin)

for directory in (GENERATED, REPOSITORY, TOOLS):
    safe(directory)
    directory.mkdir(parents=True, exist_ok=True)
for page in PAGES:
    copy(page, FINAL / page)
# Direct Markdown link targets only: no recursive copy of their dependencies.
for page in PAGES:
    raw = (FINAL / page).read_text()
    for target in re.findall(r'\]\(([^\s)]+)\)', raw):
        path = target.split('#', 1)[0]
        if not path or '://' in path:
            continue
        relative = Path(os.path.normpath(str(Path(page).parent / path)))
        if relative.is_absolute() or '..' in relative.parts:
            continue
        copy(relative)
for relative in HEADERS:
    copy(relative)
# The API projection retains the exact two added source blocks, not old API XML.
api = REPOSITORY / 'docs/reference/api/extension-components.md'
api_source = (FINAL / 'docs/reference/api/extension-components.md').read_text()
sections = []
for stem in ('stm32u575__lpdma__lptim1', 'stm32u575__stop2__lptim1'):
    pattern = r'\(' + re.escape(stem) + r'_8h\)=\n.*?\n```\n'
    match = re.search(pattern, api_source, re.DOTALL)
    if match is None:
        raise ValueError('missing API source block: ' + stem)
    sections.append(match.group(0))
api.write_text(api_source.split('(frame__stream_8h)=', 1)[0] + '\n'.join(sections))
for module in ('sphinx_ext.py', 'breathe_i18n.py'):
    origin = PRIMARY / 'tools/documentation' / module
    target = TOOLS / 'tools/documentation' / module
    safe(origin); safe(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(origin, target)
    inputs[str(origin)] = digest(origin)
for package in (TOOLS / 'tools/__init__.py', TOOLS / 'tools/documentation/__init__.py'):
    package.write_text('')
sys.path.insert(0, str(TOOLS))
from tools.documentation import sphinx_ext

configuration = GENERATED / 'configuration'
configuration.mkdir(exist_ok=True)
exclude = sorted(p.relative_to(REPOSITORY / 'docs').as_posix()
                 for p in (REPOSITORY / 'docs').rglob('*')
                 if p.suffix in ('.md', '.rst')
                 and ('docs/' + p.relative_to(REPOSITORY / 'docs').as_posix()) not in PAGES)
(configuration / 'conf.py').write_text('''from pathlib import Path
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, TOOLS_PATH)
from tools.documentation.sphinx_ext import rewrite_local_links
from tools.documentation.breathe_i18n import SourcedDoxygenFileDirective
extensions = ['myst_parser', 'breathe']
source_suffix = {'.md': 'markdown', '.rst': 'restructuredtext'}
root_doc = 'design/u575-lptim1-lpbam'
language = 'en'
myst_heading_anchors = 5
myst_enable_extensions = ['colon_fence']
gettext_compact = False
gettext_uuid = False
gettext_location = False
exclude_patterns = EXCLUDED
breathe_projects = {'nexus': XML_PATH}
breathe_default_project = 'nexus'
breathe_domain_by_extension = {'h': 'c'}
def rewrite(app, docname, source):
    repository = Path(app.srcdir).parent.resolve()
    source[0] = rewrite_local_links(source[0], repository / 'docs' / (docname + '.md'),
        repository / 'docs', repository, 'NEXUS-DOCUMENTATION-SOURCE')
def setup(app):
    app.add_directive('doxygenfile', SourcedDoxygenFileDirective, override=True)
    app.connect('source-read', rewrite)
'''.replace('TOOLS_PATH', repr(str(TOOLS)))
    .replace('EXCLUDED', repr(exclude))
    .replace('XML_PATH', repr(str(GENERATED / 'api/xml'))))
doxy = GENERATED / 'Doxyfile.focused'
doxy.write_text('@INCLUDE = ' + str(FINAL / 'Doxyfile') + '\n'
    + 'OUTPUT_DIRECTORY = ' + str(GENERATED / 'api') + '\n'
    + 'GENERATE_HTML = NO\nINPUT = '
    + ' '.join(str(REPOSITORY / header) for header in HEADERS) + '\n')
environment = dict(os.environ)
environment.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')
command = [str(PREFIX / 'bin/doxygen'), str(doxy)]
completed = subprocess.run(command, cwd=REPOSITORY, env=environment,
                           text=True, capture_output=True, timeout=120)
(GENERATED / 'doxygen.stdout.log').write_text(completed.stdout)
(GENERATED / 'doxygen.stderr.log').write_text(completed.stderr)
receipt = {'scope': 'selected-page development extraction; API is exact new-section projection only; no full API/site freshness or qualification',
           'doxygen': {'command': command, 'cwd': str(REPOSITORY), 'exit_code': completed.returncode},
           'tools': {'prefix': str(PREFIX),
                     'installation_sha256': digest(PREFIX / 'installation.json'),
                     'python_sha256': digest(PREFIX / 'venv/bin/python')},
           'input_hashes': inputs,
           'launch_command': [str(PREFIX / 'venv/bin/python'), str(Path(__file__))],
           'harness_sha256': digest(Path(__file__))}
if completed.returncode:
    (GENERATED / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    raise SystemExit(completed.returncode)
from sphinx.application import Sphinx
logs, warnings = io.StringIO(), io.StringIO()
with contextlib.redirect_stdout(logs), contextlib.redirect_stderr(warnings):
    app = Sphinx(str(REPOSITORY / 'docs'), str(configuration),
                 str(GENERATED / 'gettext'), str(GENERATED / 'gettext-doctrees'),
                 'gettext', status=logs, warning=warnings, freshenv=True)
    app.build(force_all=True)
(GENERATED / 'gettext.stdout.log').write_text(logs.getvalue())
(GENERATED / 'gettext.stderr.log').write_text(warnings.getvalue())
receipt['sphinx'] = {'call': 'sphinx.application.Sphinx',
                     'positional_arguments': [str(REPOSITORY / 'docs'), str(configuration), str(GENERATED / 'gettext'), str(GENERATED / 'gettext-doctrees'), 'gettext'],
                     'keyword_arguments': {'freshenv': True, 'status': str(GENERATED / 'gettext.stdout.log'), 'warning': str(GENERATED / 'gettext.stderr.log')},
                     'build_call': {'method': 'build', 'force_all': True},
                     'source': str(REPOSITORY / 'docs'), 'configuration': str(configuration),
                     'exit_code': app.statuscode, 'warnings': warnings.getvalue(),
                     'version': __import__('sphinx').__version__}
receipt['messages'] = {}
for page in PAGES:
    docname = page.removeprefix('docs/').removesuffix('.md')
    pot = GENERATED / 'gettext' / (docname + '.pot')
    _, messages, fuzzy = sphinx_ext.read_catalog(pot)
    # Sphinx's untranslated POT header is fuzzy by design; PO output never is.
    receipt['messages'][docname] = {'count': len(messages), 'pot_sha256': digest(pot)}
for origin, expected in inputs.items():
    if digest(Path(origin)) != expected:
        raise ValueError('source changed during extraction: ' + origin)
(GENERATED / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'exit_code': app.statuscode, 'messages': receipt['messages'],
                  'warnings_log': str(GENERATED / 'gettext.stderr.log')}, indent=2))
raise SystemExit(app.statuscode)
