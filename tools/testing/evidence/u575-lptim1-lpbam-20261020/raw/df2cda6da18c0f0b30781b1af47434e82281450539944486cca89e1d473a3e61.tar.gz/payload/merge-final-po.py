#!/usr/bin/env python3
"""Merge exact selected POT messages into draft, explicitly unreviewed PO files."""
from pathlib import Path
import hashlib
import json
import re
import sys

sys.dont_write_bytecode = True
WORK = Path('/tmp/nexus-u575-lptim1-docs-20261020')
PRIMARY = Path('/tmp/nexus-quality-20261019')
H743_BASE = Path('/tmp/nexus-h743-full-window-diagrams-20261020/delivery/final')
REPOSITORY = WORK / 'extraction-final/repository'
FINAL = WORK / 'final'
sys.path.insert(0, str(WORK / 'extraction-final/normalization-tools'))
from tools.documentation import sphinx_ext

extraction_receipt = json.loads((WORK / 'extraction-final/receipt.json').read_text())
pages = tuple(extraction_receipt['messages'])
normalized = {}
source_pairs = [
    WORK / 'summary-translation-pairs.json',
    WORK / 'main-page-translation-pairs.json',
    WORK / 'evidence/diagram/readme-prose-pairs.json',
    WORK / 'api-translation-pairs.json',
    WORK / 'additional-translation-pairs.json',
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def clean(value, page):
    value = re.sub(r'^#+\s+', '', value)
    value = sphinx_ext.rewrite_local_links(value, REPOSITORY / page,
        REPOSITORY / 'docs', REPOSITORY, 'NEXUS-DOCUMENTATION-SOURCE')
    return ' '.join(value.splitlines())

for path in source_pairs:
    if not path.is_file():
        continue
    data = json.loads(path.read_text())
    default_page = data.get('path') or data.get('source')
    for item in data.get('messages', data.get('pairs', [])):
        page = item.get('path') or default_page
        source = item.get('source') or item['zh_CN']
        key = (page.removeprefix('docs/').removesuffix('.md'), clean(source, page))
        translation = {language: clean(item[language], page) for language in ('en', 'zh_CN')}
        normalized[key] = translation
        match = re.fullmatch(r'!\[([^\]]+)\]\(([^)]+)\)', source)
        if match:
            translated = {}
            for language in ('en', 'zh_CN'):
                image = re.fullmatch(r'!\[([^\]]+)\]\(([^)]+)\)', item[language])
                if image:
                    translated[language] = image.group(1)
            if len(translated) == 2:
                normalized[(key[0], match.group(1))] = translated

manifest = []
missing = []
for docname in pages:
    page = 'docs/' + docname + '.md'
    canonical_path = FINAL / page
    canonical = canonical_path.read_text()
    if digest(canonical_path) != extraction_receipt['input_hashes'].get(str(canonical_path)):
        raise ValueError('source changed after gettext; re-extract: ' + page)
    authored = sphinx_ext.source_language(canonical)
    pot = WORK / 'extraction-final/gettext' / (docname + '.pot')
    fresh = sphinx_ext.read_catalog(pot)[1]
    for language in ('en', 'zh_CN'):
        relative = 'docs/locale/' + language + '/LC_MESSAGES/' + docname + '.po'
        baseline_root = H743_BASE if docname == 'assets/diagrams/README' else PRIMARY
        baseline = baseline_root / relative
        old = sphinx_ext.read_catalog(baseline)[1] if baseline.is_file() else {}
        # The API POT is only the exact new-section projection; retain every
        # unchanged existing message. Other POT files cover the full page.
        selected = dict(old) if docname == 'reference/api/extension-components' else {}
        for msgid in fresh:
            pair = normalized.get((docname, msgid))
            if pair is not None:
                selected[msgid] = pair[language]
            elif msgid in old and old[msgid]:
                selected[msgid] = old[msgid]
            elif authored == language:
                selected[msgid] = msgid
            else:
                selected[msgid] = ''
                missing.append({'page': page, 'language': language, 'msgid': msgid})
        header = ('Project-Id-Version: Nexus source documentation\n'
            + 'Language: ' + language + '\nMIME-Version: 1.0\n'
            + 'Content-Type: text/plain; charset=UTF-8\n'
            + 'Content-Transfer-Encoding: 8bit\nX-Nexus-Reviewed: false\n'
            + 'X-Nexus-Source-SHA256: ' + hashlib.sha256(canonical.encode()).hexdigest() + '\n')
        output = WORK / 'extraction-final/draft-catalogs' / relative
        for ancestor in (output, *output.parents):
            if ancestor.is_symlink():
                raise ValueError('symlink output: ' + str(ancestor))
        output.parent.mkdir(parents=True, exist_ok=True)
        rendered = ['# Exact POT merge draft; independent semantic review pending.\n',
                    'msgid ""\nmsgstr ' + json.dumps(header, ensure_ascii=False) + '\n\n']
        for msgid, msgstr in selected.items():
            rendered.append('msgid ' + json.dumps(msgid, ensure_ascii=False) + '\n'
                          + 'msgstr ' + json.dumps(msgstr, ensure_ascii=False) + '\n\n')
        output.write_text(''.join(rendered))
        metadata, emitted, fuzzy = sphinx_ext.read_catalog(output)
        assert metadata['X-Nexus-Reviewed'] == 'false' and not fuzzy
        assert emitted == selected
        manifest.append({'path': relative, 'before_path': str(baseline) if baseline.is_file() else None,
            'before_sha256': digest(baseline) if baseline.is_file() else None,
            'draft_path': str(output), 'final_sha256': digest(output),
            'source_sha256': hashlib.sha256(canonical.encode()).hexdigest(),
            'messages': len(selected), 'empty': sum(not value for value in selected.values()),
            'removed_baseline_messages': sorted(set(old) - set(selected)),
            'scope': 'new-sections-only POT plus complete old mapping' if docname.startswith('reference/api/') else 'complete selected-page POT'})
report = {'reviewed': False, 'files': manifest, 'missing': missing,
          'note': 'Drafts only; no reviewed status, full-site render or software qualification. Atlas baseline is the future H743 delivery, all other old files use primary.'}
(WORK / 'extraction-final/po-merge-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'drafts':len(manifest), 'missing':len(missing), 'report':str(WORK / 'extraction-final/po-merge-report.json')}, indent=2))
