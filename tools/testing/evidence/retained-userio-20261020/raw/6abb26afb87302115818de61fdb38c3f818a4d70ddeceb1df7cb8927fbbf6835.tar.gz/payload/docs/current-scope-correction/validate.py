from pathlib import Path
import contextlib
import hashlib
import io
import json
import sys

PRIMARY = Path('/tmp/nexus-quality-20261019')
WORK = Path('/tmp/nexus-current-scope-docs-20261020')
ARTIFACTS = Path('/dev/shm/nexus-current-scope-docs-20261020')
sys.path.insert(0, str(PRIMARY))
from tools.documentation import check, sphinx_ext
from sphinx.application import Sphinx

config = ARTIFACTS / 'config'
config.mkdir(parents=True, exist_ok=True)
(config / 'conf.py').write_text('''
from pathlib import Path
import sys
sys.path.insert(0, '/tmp/nexus-quality-20261019')
from tools.documentation.sphinx_ext import rewrite_local_links
extensions = ['myst_parser']
source_suffix = {'.md': 'markdown'}
root_doc = 'delivery/README'
language = 'zh_CN'
exclude_patterns = ['locale/**']
myst_heading_anchors = 5
myst_enable_extensions = ['colon_fence']
gettext_compact = False
gettext_uuid = False
gettext_location = False
def rewrite(app, docname, source):
    root = Path('/tmp/nexus-quality-20261019')
    page = root / 'docs' / (docname + '.md')
    source[0] = rewrite_local_links(source[0], page, root / 'docs', root,
                                    'NEXUS-DOCUMENTATION-SOURCE')
def setup(app):
    app.connect('source-read', rewrite)
''')

reports = {}
for side in ('base', 'final'):
    output = ARTIFACTS / side / 'gettext'
    logs = io.StringIO()
    warnings = io.StringIO()
    with contextlib.redirect_stdout(logs), contextlib.redirect_stderr(warnings):
        app = Sphinx(str(WORK / side / 'docs'), str(config), str(output),
                     str(ARTIFACTS / side / 'doctrees'), 'gettext',
                     status=logs, warning=warnings, freshenv=True)
        app.build(force_all=True)
    (ARTIFACTS / f'{side}-gettext.log').write_text(logs.getvalue())
    (ARTIFACTS / f'{side}-gettext-warnings.log').write_text(warnings.getvalue())
    pages = ('delivery/README', 'design/README', 'assets/diagrams/README')
    report = check.validate_translations(WORK / side, pot_root=output,
                                        critical_pages=pages)
    reports[side] = report
    assert not report['errors'], report['errors']

    for name in pages:
        _, extracted, _ = sphinx_ext.read_catalog(output / f'{name}.pot')
        for language in ('en', 'zh_CN'):
            path = WORK / side / 'docs/locale' / language / 'LC_MESSAGES' / f'{name}.po'
            _, entries, _ = sphinx_ext.read_catalog(path)
            assert set(extracted) == set(entries), (
                side, name, language,
                {'missing': sorted(set(extracted) - set(entries)),
                 'extra': sorted(set(entries) - set(extracted))})

pairs = json.loads((WORK / 'translation-pairs.json').read_text())
for name in ('delivery/README', 'design/README', 'assets/diagrams/README'):
    _, before, _ = sphinx_ext.read_catalog(ARTIFACTS / 'base/gettext' / f'{name}.pot')
    _, after, _ = sphinx_ext.read_catalog(ARTIFACTS / 'final/gettext' / f'{name}.pot')
    assert len(set(before) - set(after)) == len(set(after) - set(before)) == 1
    pair = next(item for item in pairs if item['path'].endswith(f'/{name}.po'))
    assert set(before) - set(after) == {pair['old_msgid']}
    assert set(after) - set(before) == {pair['new_msgid']}

for row in json.loads((WORK / 'path-sha256.json').read_text()):
    primary = PRIMARY / row['path']
    assert hashlib.sha256(primary.read_bytes()).hexdigest() == row['base_sha256'], (
        'primary changed during focused correction', row['path'])

(WORK / 'validation.json').write_text(json.dumps({
    'status': 'passed',
    'method': 'Pinned Sphinx gettext for three isolated source copies; maintained '
              'rewrite_local_links and validate_translations; exact extracted '
              'message-set equality for base and final EN/ZH catalogs',
    'reports': reports,
    'one_message_replaced_per_page': True,
    'unchanged_translation_messages_exact': True,
    'primary_input_shas_still_match': True,
    'generated_artifacts': str(ARTIFACTS),
    'limitations': 'Focused extraction omits full-site navigation/resources and '
                   'uses the maintained rewrite hook without the Git-dependent '
                   'site extension; full strict site and ordinary gates remain '
                   'integration work.'}, ensure_ascii=False, indent=2) + '\n')
print('PASS: base/final exact gettext message sets and all six catalogs')
