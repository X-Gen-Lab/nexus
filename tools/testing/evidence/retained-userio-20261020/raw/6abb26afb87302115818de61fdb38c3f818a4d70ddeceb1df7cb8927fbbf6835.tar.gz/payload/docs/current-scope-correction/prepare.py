from pathlib import Path
import ast
import hashlib
import json
import re
import shutil
import sys

PRIMARY = Path('/tmp/nexus-quality-20261019')
WORK = Path('/tmp/nexus-current-scope-docs-20261020')
sys.path.insert(0, str(PRIMARY))
from tools.documentation import sphinx_ext

PAGES = ('delivery/README', 'design/README', 'assets/diagrams/README')
PATHS = [f'docs/{name}.md' for name in PAGES]
PATHS += [f'docs/locale/{lang}/LC_MESSAGES/{name}.po'
          for name in PAGES for lang in ('en', 'zh_CN')]
for rel in PATHS:
    for side in ('base', 'final'):
        dest = WORK / side / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(PRIMARY / rel, dest)

old_delivery_tail = 'Flash 尾跳不代表通用运行态接管；DVFS 和深 STOP 连续计时仍未实现，55 项\n原始退出条件保持不变。'
new_delivery_tail = '''Flash 尾跳不代表通用运行态接管；SOC-34 的 DVFS 仍未实现。SOC-35 已增加
[U575 保留时钟与 Stop2](../design/u575-retained-time.md)的有界软件子集，使用独立
RTC 时间域与显式 WUT/Stop2 owner；LPDMA/LPBAM 尚未实现，物理保留、精度、功耗及
唤醒验收仍未执行。SOC-35 完整退出仍开放；全部 55 项原始退出条件保持不变。'''
old_design = '20 对本地 DOT/SVG：18 张编号主图与 2 张补充图；新增 target 图的渲染与审查另行记录'
new_design = '本地 DOT/SVG 主图与两张补充图；主图以图清单为准，current/reference/target 身份、渲染与审查分别记录'
old_atlas_tail = '以及 IO-31 的 FIG-22 G474 命名 GPIO 状态／所有权图。主图登记见'
new_atlas_tail = '''以及 IO-31 的 FIG-22 G474 命名 GPIO 状态／所有权图。FIG-23–26 依次描述
五项有界软件机制的所有权、U575 保留时钟与 Stop2 所有权及状态、
UART TX 复制代理的 kernel 所有权与退出、I3C 核心借用与整总线证明。主图登记见'''
for name, before, after in (
        ('delivery/README', old_delivery_tail, new_delivery_tail),
        ('design/README', old_design, new_design),
        ('assets/diagrams/README', old_atlas_tail, new_atlas_tail)):
    path = WORK / 'final/docs' / f'{name}.md'
    source = path.read_text()
    assert source.count(before) == 1
    path.write_text(source.replace(before, after))

def msgid(block):
    result, field = '', False
    for line in block.splitlines():
        if line.startswith('msgid '):
            result = ast.literal_eval(line[6:])
            field = True
        elif line.startswith('msgstr '):
            field = False
        elif field and line.startswith('"'):
            result += ast.literal_eval(line)
    return result

def quote(value):
    return json.dumps(value, ensure_ascii=False)

changes = []
for name in PAGES:
    base = (WORK / 'base/docs' / f'{name}.md').read_text()
    final = (WORK / 'final/docs' / f'{name}.md').read_text()
    digest = hashlib.sha256(final.encode()).hexdigest()
    for lang in ('en', 'zh_CN'):
        path = WORK / 'final/docs/locale' / lang / 'LC_MESSAGES' / f'{name}.po'
        text = path.read_text()
        ended_with_newline = text.endswith('\n')
        metadata, messages, fuzzy = sphinx_ext.read_catalog(path)
        assert not fuzzy
        if name == 'delivery/README':
            old = next(key for key in messages if key.startswith('历史 SoC 扩展基线固定源码'))
            new = old.replace(old_delivery_tail.replace('\n', ' '),
                              new_delivery_tail.replace('\n', ' '))
            assert new != old
            if lang == 'en':
                old_tail = ('DVFS and continuous deep-STOP timing remain unimplemented; '
                            'the 55 original exit conditions are unchanged.')
                new_tail = ('SOC-34 DVFS remains unimplemented. SOC-35 now has a bounded '
                            'software subset for [U575 retained time and Stop2]'
                            '(../design/u575-retained-time.md), using an independent RTC '
                            'time domain and an explicit WUT/Stop2 owner. LPDMA/LPBAM '
                            'remain unimplemented; physical retention, accuracy, power '
                            'and wake acceptance remain unexecuted. The complete SOC-35 '
                            'exit remains open; all 55 original exit conditions remain unchanged.')
                assert old_tail in messages[old]
                translated = messages[old].replace(old_tail, new_tail)
            else:
                translated = new
        elif name == 'design/README':
            old, new = old_design, new_design
            translated = (new if lang == 'zh_CN' else
                'Local DOT/SVG main figures and two supplements; the figure index '
                'defines the main set, with current/reference/target identity, '
                'rendering and review recorded separately')
        else:
            old = next(key for key in messages if key.startswith('本图册保留15类必需视图'))
            new = old.replace(old_atlas_tail, new_atlas_tail.replace('\n', ' '))
            assert new != old
            if lang == 'en':
                old_tail = ('diagram, and the IO-31 FIG-22 G474 named GPIO '
                            'state/ownership diagram. See ')
                new_tail = ('diagram, and the IO-31 FIG-22 G474 named GPIO '
                            'state/ownership diagram. FIG-23–26 respectively describe '
                            'ownership of five bounded software mechanisms, U575 '
                            'retained-clock and Stop2 ownership and state, kernel '
                            'ownership and exit for the copied UART TX broker, and '
                            'I3C core borrowing and whole-bus proofs. See ')
                assert old_tail in messages[old]
                translated = messages[old].replace(old_tail, new_tail)
            else:
                translated = ('本图册保留15类必需视图、两张补充图与本轮 I/O 架构视图 FIG-16，'
                              '另加入 IO-24 的 FIG-17/18 目标图源、IO-36 的 FIG-21 Native '
                              '装配／生命周期图，以及 IO-31 的 FIG-22 G474 命名 GPIO 状态／所有权图。'
                              'FIG-23–26 依次描述五项有界软件机制的所有权、U575 保留时钟与 Stop2 '
                              '所有权及状态、UART TX 复制代理的 kernel 所有权与退出、I3C 核心借用与'
                              '整总线证明。主图登记见 {download}`图清单 <diagram-index.csv>`，'
                              '维护规则见[图示标准](../../design/documentation-standards.md)。'
                              '图有精确 current/reference/target 身份，不可从图源存在、渲染成功或软件流程'
                              '推断硬件和外部发布已执行。')
        blocks = text.split('\n\n')
        match = [i for i, block in enumerate(blocks) if msgid(block) == old]
        assert len(match) == 1, (path, len(match))
        index = match[0]
        comments = '\n'.join(line for line in blocks[index].splitlines()
                             if line.startswith('#'))
        blocks[index] = ((comments + '\n') if comments else '') + (
            f'msgid {quote(new)}\nmsgstr {quote(translated)}')
        text = '\n\n'.join(blocks)
        if ended_with_newline and not text.endswith('\n'):
            text += '\n'
        text, count = re.subn(r'(?<=X-Nexus-Source-SHA256: )[0-9a-f]{64}', digest, text)
        assert count == 1
        path.write_text(text)
        final_metadata, final_messages, final_fuzzy = sphinx_ext.read_catalog(path)
        assert not final_fuzzy and final_metadata['X-Nexus-Reviewed'] == 'true'
        assert final_messages[new] == translated
        assert set(final_messages) == (set(messages) - {old}) | {new}
        assert all(final_messages[key] == value for key, value in messages.items() if key != old)
        changes.append({'path': path.relative_to(WORK / 'final').as_posix(),
                        'old_msgid': old, 'old_msgstr': messages[old],
                        'new_msgid': new, 'new_msgstr': translated})

(WORK / 'translation-pairs.json').write_text(json.dumps(changes, ensure_ascii=False, indent=2) + '\n')
manifest = []
for rel in PATHS:
    manifest.append({'path': rel,
        'base_sha256': hashlib.sha256((WORK / 'base' / rel).read_bytes()).hexdigest(),
        'final_sha256': hashlib.sha256((WORK / 'final' / rel).read_bytes()).hexdigest()})
(WORK / 'path-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(PATHS), 'translation_pairs': len(changes)}, indent=2))
