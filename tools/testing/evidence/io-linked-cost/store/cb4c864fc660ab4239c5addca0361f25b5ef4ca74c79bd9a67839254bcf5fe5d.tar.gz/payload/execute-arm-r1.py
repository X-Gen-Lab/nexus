#!/usr/bin/env python3
"""Run only the four authorized exact ARM link profiles under one shared lock."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time

ROOT = Path('/tmp/nexus-quality-20261019')
OUT = Path('/tmp/nexus-io05-probe-cost-20261020')
PYTHON = ROOT / '.venv/bin/python'
EXPECTED = 'bacdc5b8a5d64baebb92517e770d0abac28421b8'
LOCK = '/tmp/nexus-platform-compiler.lock'
BASELINE = {'oom': 61, 'oom_kill': 10, 'oom_group_kill': 0}
MINIMUM = 256 * 1024 * 1024
sys.path.insert(0, str(ROOT))
from tools.dev.process import run


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.new')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def identity(path):
    path = Path(path)
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            checksum.update(block)
    return {'path': str(path), 'sha256': checksum.hexdigest(),
            'bytes': path.stat().st_size}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source():
    current = {'commit': git('rev-parse', 'HEAD'),
               'tree': git('rev-parse', 'HEAD^{tree}'),
               'dirty': bool(git('status', '--porcelain')),
               'submodules': git('submodule', 'status', '--recursive')}
    if current['commit'] != EXPECTED or current['dirty']:
        raise RuntimeError('Frozen clean source identity changed')
    return current


def memory():
    base = Path('/sys/fs/cgroup')
    events = {key: int(value) for key, value in
              (line.split() for line in (base / 'memory.events').read_text().splitlines())}
    current = int((base / 'memory.current').read_text())
    maximum_text = (base / 'memory.max').read_text().strip()
    maximum = None if maximum_text == 'max' else int(maximum_text)
    meminfo = {line.split(':')[0]: int(line.split()[1]) * 1024
               for line in Path('/proc/meminfo').read_text().splitlines()
               if line.startswith(('MemAvailable:', 'MemFree:'))}
    headroom = meminfo['MemAvailable'] if maximum is None else maximum - current
    record = {'observed_ns': time.time_ns(), 'current_bytes': current,
              'maximum_bytes': maximum, 'headroom_bytes': headroom,
              'host_meminfo': meminfo, 'events': events}
    reasons = []
    if headroom < MINIMUM:
        reasons.append('cgroup headroom below 256 MiB')
    for key, initial in BASELINE.items():
        if events.get(key, 0) > initial:
            reasons.append(key + ' increased above root baseline')
    record['stop_reasons'] = reasons
    return record


def environment():
    env = os.environ.copy()
    env['PATH'] = str(ROOT / '.venv/bin') + ':/tmp/nexus-quality-arm/bin:' + env.get('PATH', '')
    env.update(NEXUS_BUILD_JOBS='1', CMAKE_BUILD_PARALLEL_LEVEL='1',
               CTEST_PARALLEL_LEVEL='1', PYTHONDONTWRITEBYTECODE='1', CCACHE_DISABLE='1')
    for name in ('CC', 'CXX', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS',
                 'CMAKE_C_COMPILER_LAUNCHER', 'CMAKE_CXX_COMPILER_LAUNCHER'):
        env.pop(name, None)
    return env


ENV = environment()
RUNS = OUT / 'arm-execution-r1'


class Stopped(RuntimeError):
    pass


def controlled_command(argv, label, timeout):
    before = memory()
    if before['stop_reasons']:
        write_json(RUNS / (label + '.not-launched.json'), before)
        raise Stopped('; '.join(before['stop_reasons']))
    if source() != SOURCE:
        raise Stopped('Source/dependency identity changed before ' + label)
    cancel = threading.Event()
    done = threading.Event()
    observed = []
    samples = RUNS / (label + '.memory.jsonl')

    def observe():
        with samples.open('x') as stream:
            while True:
                sample = memory()
                observed.append(sample)
                stream.write(json.dumps(sample) + '\n')
                stream.flush()
                if sample['stop_reasons']:
                    cancel.set()
                if done.wait(0.25):
                    break

    watcher = threading.Thread(target=observe, daemon=True)
    watcher.start()
    try:
        result = run(argv, cwd=ROOT, env=ENV, log=RUNS / (label + '.raw'),
                     timeout=timeout, stage='io05-' + label, cancel_event=cancel)
    finally:
        done.set()
        watcher.join()
    after = memory()
    record = {'label': label, 'argv': list(map(str, argv)),
              'cwd': str(ROOT), 'exit_code': result.returncode,
              'receipt': identity(RUNS / (label + '.command.json')),
              'memory_before': before, 'memory_after': after,
              'minimum_headroom_bytes': min([before['headroom_bytes'], after['headroom_bytes']] +
                                            [row['headroom_bytes'] for row in observed]),
              'resource_stop': cancel.is_set() or bool(after['stop_reasons'])}
    COMMANDS.append(record)
    write_json(RUNS / 'commands.json', COMMANDS)
    print(json.dumps({'stage': label, 'exit': result.returncode,
                      'minimum_headroom_bytes': record['minimum_headroom_bytes'],
                      'resource_stop': record['resource_stop']}), flush=True)
    if result.returncode or record['resource_stop']:
        raise Stopped('Actual command failed or resource stop: ' + label)
    return result


def prepare_execution_plan():
    reviewed = json.loads((OUT / 'plan.json').read_text())
    profiles = []
    for old in reviewed['profiles']:
        on = old['probe']
        family = 'st407' if old['id'].startswith('f407') else 'gd470'
        equal_name = family + '-probe-' + str(int(on))
        destination = OUT / 'equal-inputs' / (equal_name + '.toml')
        destination.parent.mkdir(exist_ok=True)
        if destination.exists():
            raise Stopped('Derived execution input already exists; preserve and use a new attempt')
        destination.write_bytes(Path(old['assembly']).read_bytes())
        build = OUT / 'equal-builds' / equal_name
        if build.exists():
            raise Stopped('Build root exists; fresh roots are required')
        argv = list(old['configure_argv'])
        argv[argv.index('-B') + 1] = str(build)
        argv = ['-DNEXUS_ASSEMBLY_FILE=' + str(destination)
                if value.startswith('-DNEXUS_ASSEMBLY_FILE=') else value for value in argv]
        profile = dict(old)
        profile.update(assembly=str(destination), assembly_identity=identity(destination),
                       build_root=str(build), configure_argv=argv,
                       build_argv=['cmake', '--build', str(build), '--target',
                                   'io_evolution_fixture', '--parallel', '1', '--verbose'])
        profiles.append(profile)
    assert len({len(row['build_root']) for row in profiles}) == 1
    assert len({len(row['assembly']) for row in profiles}) == 1
    plan = {'reviewed_plan': identity(OUT / 'plan.json'), 'source': SOURCE,
            'actual_source_root': str(ROOT), 'profiles': profiles,
            'path_controls': {'all_build_root_lengths_equal': True,
                              'all_derived_assembly_path_lengths_equal': True,
                              'source_root_identical': True,
                              'prefix_maps_added': False},
            'environment_selection': {key: ENV[key] for key in
                ('PATH', 'NEXUS_BUILD_JOBS', 'CMAKE_BUILD_PARALLEL_LEVEL',
                 'CTEST_PARALLEL_LEVEL', 'PYTHONDONTWRITEBYTECODE', 'CCACHE_DISABLE')},
            'cleared_ambient_codegen_variables': ['CC', 'CXX', 'CFLAGS', 'CXXFLAGS',
                'CPPFLAGS', 'LDFLAGS', 'CMAKE_C_COMPILER_LAUNCHER',
                'CMAKE_CXX_COMPILER_LAUNCHER'],
            'shared_lock': LOCK, 'jobs': 1,
            'qualification': 'ARM linkage/static observations only; no physical I/O or timing'}
    write_json(RUNS / 'actual-plan.json', plan)
    return profiles


def execute_locked():
    global SOURCE, COMMANDS
    if RUNS.exists():
        raise Stopped('Attempt output already exists; do not overwrite retained evidence')
    RUNS.mkdir()
    SOURCE = source()
    COMMANDS = []
    state = {'status': 'running', 'source_before': SOURCE,
             'baseline': memory(), 'root_oom_baseline': BASELINE,
             'physical_status': 'not_executed', 'cycles_status': 'not_measured',
             'latency_status': 'not_measured', 'wcet_status': 'not_measured',
             'software_qualified': False}
    write_json(RUNS / 'execution.json', state)
    try:
        if state['baseline']['stop_reasons']:
            raise Stopped('; '.join(state['baseline']['stop_reasons']))
        profiles = prepare_execution_plan()
        tools = {}
        for name in ('cmake', 'ninja', 'arm-none-eabi-gcc', 'arm-none-eabi-ld',
                     'arm-none-eabi-ar', 'arm-none-eabi-objcopy',
                     'arm-none-eabi-objdump', 'arm-none-eabi-readelf',
                     'arm-none-eabi-nm', 'arm-none-eabi-size'):
            located = shutil.which(name, path=ENV['PATH'])
            if not located:
                raise Stopped('Required actual tool unavailable: ' + name)
            tools[name] = identity(Path(located).resolve())
            controlled_command([located, '--version'], 'tool-' + name, 30)
        write_json(RUNS / 'tool-identities.json', tools)
        for row in profiles:
            name = row['id']
            controlled_command(row['configure_argv'], name + '-configure', 900)
            controlled_command(row['build_argv'], name + '-build', 1800)
            build = Path(row['build_root'])
            elf = build / 'bin/io_evolution_fixture.elf'
            controlled_command(['arm-none-eabi-nm', '-a', '-S', '--size-sort', str(elf)],
                               name + '-nm', 30)
            controlled_command(['arm-none-eabi-readelf', '-h', '-SW', '-Ws', str(elf)],
                               name + '-readelf', 30)
            controlled_command(['ninja', '-C', str(build), '-t', 'commands', 'io_evolution_fixture'],
                               name + '-actual-commands', 30)
            symbols = [row['physical_vector'], row['provider_irq']]
            if row['probe']:
                symbols += ['nx_io_cycle_probe_begin', 'nx_io_cycle_probe_end',
                            'nx_uart_word_port_service_observed', 'nx_uart_word_port_service']
            for symbol in symbols:
                controlled_command(['arm-none-eabi-objdump', '-d', '-z',
                                    '--disassemble=' + symbol, str(elf)],
                                   name + '-disasm-' + symbol, 30)
            generated = build / 'generated'
            controlled_command([str(PYTHON), '-B', str(ROOT / 'tools/measurement/soc_costs.py'),
                                'observe', '--elf', str(elf),
                                '--resolved', str(generated / 'resolved.json'),
                                '--budget', str(generated / 'resource-budget.json'),
                                '--compile-commands', str(build / 'compile_commands.json'),
                                '--output', str(OUT / 'observations-r1' / name),
                                '--symbols', row['physical_vector'], row['provider_irq']],
                               name + '-cost-observe', 180)
            files = [elf, build / 'bin/io_evolution_fixture.bin',
                     build / 'bin/io_evolution_fixture.map',
                     build / 'bin/io_evolution_fixture.resources.json',
                     build / 'bin/provider-retention.json',
                     build / 'compile_commands.json', build / 'CMakeCache.txt',
                     build / 'build.ninja', *sorted(generated.rglob('*'))]
            inventory = [identity(path) for path in files if path.is_file()]
            write_json(RUNS / (name + '-artifacts.json'), inventory)
            state.setdefault('completed_profiles', []).append(name)
            write_json(RUNS / 'execution.json', state)
        for name, tool in tools.items():
            if identity(tool['path']) != tool:
                raise Stopped('Actual tool bytes changed: ' + name)
        if source() != SOURCE:
            raise Stopped('Frozen source/dependency identity changed')
        state['status'] = 'built_and_observed_pending_static_review'
    except BaseException as error:
        state['status'] = 'stopped_retained'
        state['failure'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        state['memory_after'] = memory()
        try:
            state['source_after'] = source()
        except BaseException as error:
            state['source_after_error'] = str(error)
        state['commands'] = len(COMMANDS)
        write_json(RUNS / 'execution.json', state)


if __name__ == '__main__':
    if '--locked' in sys.argv:
        execute_locked()
    else:
        outer = OUT / 'scheduler-r1.raw'
        if outer.with_suffix('.command.json').exists():
            raise SystemExit('Outer attempt already exists; preserve it')
        result = run(['flock', '--exclusive', LOCK, str(PYTHON), '-B',
                      str(Path(__file__).resolve()), '--locked'],
                     cwd=ROOT, env=ENV, log=outer, timeout=10800,
                     stage='io05-four-ARM-images-shared-flock')
        print(result.stdout, end='')
        print(result.stderr, end='', file=sys.stderr)
        raise SystemExit(result.returncode)
