/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#ifndef NX_PLATFORM_REGISTER_WRITE
#define NX_PLATFORM_REGISTER_WRITE(reg, value) ((reg) = (uint32_t)(value))
#endif
#ifndef NX_PLATFORM_PRIORITY_WRITE
#define NX_PLATFORM_PRIORITY_WRITE(reg, value) ((reg) = (uint8_t)(value))
#endif
#include "nexus/io/cycle_probe.h"
NX_IO_IRQ_PROBE_DECLARE(USART0)
#include "gd32f470_provider.h"
#include "gd32f4xx.h"
#include "system.h"
#include "gd32f470_uart_word.h"
#include "gd32f4xx_gpio.h"
#include "gd32f4xx_rcu.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static nx_gd32_uart_word_state_t s_nx_port_uart0;
static const nx_uart_word_port_t s_nx_face_uart0 = {
    &nx_gd32_uart_word_ops, &s_nx_port_uart0
};
const nx_uart_word_port_t* const nx_binding_uart0 = &s_nx_face_uart0;
static uint16_t s_nx_rx_uart0[32];
static nx_result_t prepare_uart0(void) {
    nx_result_t status = NX_SUCCESS;
    uint32_t retained_gpio_clocks = 0u;
    uint32_t saved_clocks = RCU_AHB1EN & 1u;
    uint16_t saved_PA9 = 0u;
    bool captured_PA9 = false;
    uint16_t saved_PA10 = 0u;
    bool captured_PA10 = false;
    status = nx_gd32_gpio_clock_enable(0u);
    if (status != NX_SUCCESS) { goto rollback; }
    saved_PA9 = nx_gd32_pin_capture(GPIOA, 9u);
    captured_PA9 = true;
    status = nx_gd32_pin_configure(GPIOA, 9u, 2u, 7u, 1u, false);
    if (status != NX_SUCCESS) { goto rollback; }
    status = nx_gd32_gpio_clock_enable(0u);
    if (status != NX_SUCCESS) { goto rollback; }
    saved_PA10 = nx_gd32_pin_capture(GPIOA, 10u);
    captured_PA10 = true;
    status = nx_gd32_pin_configure(GPIOA, 10u, 2u, 7u, 1u, false);
    if (status != NX_SUCCESS) { goto rollback; }
    status = nx_gd32_uart_word_initialize(&s_nx_port_uart0, &nx_gd32_usart0_controller, 115200u, s_nx_rx_uart0, 32u, 5u);
    if (status != NX_SUCCESS) {
        if (s_nx_port_uart0.initialized) { return status; }
        goto rollback;
    }
    return NX_SUCCESS;
rollback:
    if (captured_PA10) {
        {
            bool pin_restored = true;
            {
                uint32_t pin_mode = GPIO_CTL(GPIOA) & 3145728u;
                if (pin_mode != 0u && pin_mode != 3145728u) {
                    NX_PLATFORM_REGISTER_WRITE(GPIO_CTL(GPIOA), GPIO_CTL(GPIOA) | 3145728u);
                    nx_arch_dsb();
                    if ((GPIO_CTL(GPIOA) & 3145728u) != 3145728u) { pin_restored = false; }
                }
            }
            if (pin_restored) {
                nx_gd32_pin_restore(GPIOA, 10u, saved_PA10);
                nx_arch_dsb();
                pin_restored = nx_gd32_pin_capture(GPIOA, 10u) == saved_PA10;
            }
            if (!pin_restored) { retained_gpio_clocks |= 1u; }
        }
    }
    if (captured_PA9) {
        {
            bool pin_restored = true;
            {
                uint32_t pin_mode = GPIO_CTL(GPIOA) & 786432u;
                if (pin_mode != 0u && pin_mode != 786432u) {
                    NX_PLATFORM_REGISTER_WRITE(GPIO_CTL(GPIOA), GPIO_CTL(GPIOA) | 786432u);
                    nx_arch_dsb();
                    if ((GPIO_CTL(GPIOA) & 786432u) != 786432u) { pin_restored = false; }
                }
            }
            if (pin_restored) {
                nx_gd32_pin_restore(GPIOA, 9u, saved_PA9);
                nx_arch_dsb();
                pin_restored = nx_gd32_pin_capture(GPIOA, 9u) == saved_PA9;
            }
            if (!pin_restored) { retained_gpio_clocks |= 1u; }
        }
    }
    RCU_AHB1EN = (RCU_AHB1EN & ~1u) | saved_clocks | retained_gpio_clocks;
    nx_arch_dsb();
    return status;
}
static nx_result_t stop_uart0(void) {
    nx_result_t status = nx_uart_word_port_stop(&s_nx_face_uart0);
    if (status != NX_SUCCESS) { return status; }
    {
        uint32_t pin_mode = GPIO_CTL(GPIOA) & 786432u;
        if (pin_mode != 0u && pin_mode != 786432u) {
            NX_PLATFORM_REGISTER_WRITE(GPIO_CTL(GPIOA), GPIO_CTL(GPIOA) | 786432u);
            nx_arch_dsb();
            if ((GPIO_CTL(GPIOA) & 786432u) != 786432u) { return NX_ERROR_IO; }
        }
    }
    (void)nx_gd32_pin_configure(GPIOA, 9u, 0u, 0u, 0u, false);
    {
        uint32_t pin_mode = GPIO_CTL(GPIOA) & 3145728u;
        if (pin_mode != 0u && pin_mode != 3145728u) {
            NX_PLATFORM_REGISTER_WRITE(GPIO_CTL(GPIOA), GPIO_CTL(GPIOA) | 3145728u);
            nx_arch_dsb();
            if ((GPIO_CTL(GPIOA) & 3145728u) != 3145728u) { return NX_ERROR_IO; }
        }
    }
    (void)nx_gd32_pin_configure(GPIOA, 10u, 0u, 0u, 0u, false);
    return NX_SUCCESS;
}
void USART0_IRQHandler(void);
/** \brief Fixed generated UART controller dispatch. */
void USART0_IRQHandler(void) { NX_IO_IRQ_PROBE_BEGIN(USART0); nx_gd32_uart_word_irq(&s_nx_port_uart0); NX_IO_IRQ_PROBE_END(USART0); }
static uint16_t s_nx_platform_pin_state[2u];
static bool s_nx_platform_pins_captured;
static uint32_t s_nx_platform_gpio_clocks_added;
static nx_result_t nx_platform_pins_admit(bool powered_only) {
    if (!powered_only || (RCU_AHB1EN & RCU_AHB1EN_PAEN) != 0u) {
        uint32_t mode = GPIO_CTL(GPIOA);
        if (((mode >> 18u) & 3u) != 0u && ((mode >> 18u) & 3u) != 3u) { return NX_ERROR_BUSY; }
        if (((mode >> 20u) & 3u) != 0u && ((mode >> 20u) & 3u) != 3u) { return NX_ERROR_BUSY; }
        if ((GPIO_LOCK(GPIOA) & 1536u) != 0u) { return NX_ERROR_BUSY; }
    }
    return NX_SUCCESS;
}
static nx_result_t nx_platform_gpio_clocks_release(void) {
    if (s_nx_platform_gpio_clocks_added != 0u) {
        NX_PLATFORM_REGISTER_WRITE(RCU_AHB1EN, RCU_AHB1EN & ~s_nx_platform_gpio_clocks_added);
        nx_arch_dsb();
        if ((RCU_AHB1EN & s_nx_platform_gpio_clocks_added) != 0u) { return NX_ERROR_IO; }
        s_nx_platform_gpio_clocks_added = 0u;
    }
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pins_acquire(void) {
    if (s_nx_platform_pins_captured || s_nx_platform_gpio_clocks_added != 0u) { return NX_ERROR_STATE; }
    s_nx_platform_gpio_clocks_added = ~RCU_AHB1EN & (RCU_AHB1EN_PAEN);
    if (s_nx_platform_gpio_clocks_added != 0u) {
        NX_PLATFORM_REGISTER_WRITE(RCU_AHB1EN, RCU_AHB1EN | (RCU_AHB1EN_PAEN));
        nx_arch_dsb();
    }
    if ((RCU_AHB1EN & (RCU_AHB1EN_PAEN)) != (RCU_AHB1EN_PAEN)) { return NX_ERROR_IO; }
    nx_result_t status = nx_platform_pins_admit(false);
    if (status != NX_SUCCESS) { return status; }
    s_nx_platform_pin_state[0u] = nx_gd32_pin_capture(GPIOA, 9u);
    s_nx_platform_pin_state[1u] = nx_gd32_pin_capture(GPIOA, 10u);
    s_nx_platform_pins_captured = true;
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pins_release(void) {
    if (s_nx_platform_pins_captured) {
        {
            uint32_t mode = GPIO_CTL(GPIOA);
            uint32_t driven = 0u;
            if (((mode >> 18u) & 3u) == 1u || ((mode >> 18u) & 3u) == 2u) { driven |= 786432u; }
            if (((mode >> 20u) & 3u) == 1u || ((mode >> 20u) & 3u) == 2u) { driven |= 3145728u; }
            if (driven != 0u) {
                NX_PLATFORM_REGISTER_WRITE(GPIO_CTL(GPIOA), mode | driven);
                nx_arch_dsb();
                if ((GPIO_CTL(GPIOA) & driven) != driven) { return NX_ERROR_IO; }
            }
        }
        if (nx_gd32_pin_capture(GPIOA, 10u) != s_nx_platform_pin_state[1u]) {
            nx_gd32_pin_restore(GPIOA, 10u, s_nx_platform_pin_state[1u]);
            nx_arch_dsb();
            if (nx_gd32_pin_capture(GPIOA, 10u) != s_nx_platform_pin_state[1u]) { return NX_ERROR_IO; }
        }
        if (nx_gd32_pin_capture(GPIOA, 9u) != s_nx_platform_pin_state[0u]) {
            nx_gd32_pin_restore(GPIOA, 9u, s_nx_platform_pin_state[0u]);
            nx_arch_dsb();
            if (nx_gd32_pin_capture(GPIOA, 9u) != s_nx_platform_pin_state[0u]) { return NX_ERROR_IO; }
        }
        s_nx_platform_pins_captured = false;
    }
    return nx_platform_gpio_clocks_release();
}
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = stop_uart0();
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_result_t pins = nx_platform_pins_release();
    if (pins != NX_SUCCESS) { return pins; }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started && nx_gd32_soc_stop() != 0) { return NX_ERROR_IO; }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_gd32_soc_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    if ((RCU_APB2EN & (RCU_APB2EN_USART0EN)) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if (((NVIC->ISER[(uint32_t)USART0_IRQn / 32u] | NVIC->ISPR[(uint32_t)USART0_IRQn / 32u] | NVIC->IABR[(uint32_t)USART0_IRQn / 32u]) & (1u << ((uint32_t)USART0_IRQn % 32u))) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    result.primary = nx_platform_pins_admit(true);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_platform_pins_acquire();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_gpio_clocks_release();
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    if (nx_gd32_soc_start() != 0) {
        result.primary = NX_ERROR_IO;
        result.cleanup = nx_gd32_soc_stop() == 0 ? NX_SUCCESS : NX_ERROR_IO;
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        s_nx_platform_pins_captured = false;
        nx_result_t pins = nx_platform_gpio_clocks_release();
        if (pins != NX_SUCCESS) { result.cleanup = pins; result.remaining_effects = 1u; }
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = prepare_uart0();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_word_port_t* nx_factory_uart_word(nx_uart_word_id_t id) {
    switch (id) {
        case NX_UART_WORD_ID_UART0:
            return nx_binding_uart0;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_uart_word_uart0 = {
    NX_FACTORY_CAP_IRQ, 0U, 2U, 2U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_word_capability(
    nx_uart_word_id_t id) {
    switch (id) {
        case NX_UART_WORD_ID_UART0:
            return &s_nx_capability_uart_word_uart0;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_uart_word_traits_t s_nx_traits_uart_uart0 = {
    9U,
    0U,
    2U,
    115200U,
    NX_IO_ABORT_REQUEST,
    NX_IO_CONTINUITY_IRQ_BUFFERED,
    NX_IO_TIMESTAMP_UNKNOWN,
    NX_IO_DMA_POLICY_NONE,
    0U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_uart_word_traits_t* nx_factory_uart_word_traits(
    nx_uart_word_id_t id) {
    switch (id) {
        case NX_UART_WORD_ID_UART0:
            return &s_nx_traits_uart_uart0;
        default:
            return NULL;
    }
}
const nx_io_cycle_probe_t* nx_factory_uart_word_irq_probe(
    nx_uart_word_id_t id) {
    switch (id) {
        case NX_UART_WORD_ID_UART0:
            return &nx_io_irq_probe_USART0;
        default:
            return NULL;
    }
}
