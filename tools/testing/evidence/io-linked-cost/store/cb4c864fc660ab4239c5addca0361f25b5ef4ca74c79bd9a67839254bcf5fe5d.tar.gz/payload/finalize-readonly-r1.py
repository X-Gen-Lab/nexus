import fnmatch
import hashlib
import json
from pathlib import Path
import re
import time

BASE = Path('/tmp/nexus-io05-probe-cost-20261020')
RUN = BASE / 'arm-execution-r1'
load = lambda path: json.loads(Path(path).read_text())


def identity(path):
    path = Path(path)
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            checksum.update(block)
    return {'path': str(path), 'sha256': checksum.hexdigest(),
            'bytes': path.stat().st_size}


def verified(record):
    actual = identity(record['path'])
    return (actual['sha256'] == record['sha256'] and
            actual['bytes'] == record.get('bytes', record.get('size')))


execution = load(RUN / 'execution.json')
plan = load(RUN / 'actual-plan.json')
commands = load(RUN / 'commands.json')
outer = load(BASE / 'scheduler-r1.command.json')
assert execution['source_before'] == execution['source_after']
assert execution['source_after']['commit'] == 'bacdc5b8a5d64baebb92517e770d0abac28421b8'
assert not execution['source_after']['dirty']
assert outer['outcome'] == 'completed' and outer['exit_code'] == outer['child_returncode'] == 0
assert outer['command'][:3] == ['flock', '--exclusive', '/tmp/nexus-platform-compiler.lock']
for command in commands:
    receipt = load(command['receipt']['path'])
    assert verified(command['receipt'])
    assert receipt['outcome'] == 'completed' and receipt['exit_code'] == receipt['child_returncode'] == 0
    assert verified(receipt['stdout']) and verified(receipt['stderr'])
    assert not command['resource_stop']
    assert command['minimum_headroom_bytes'] >= 256 * 1024 * 1024
    assert outer['started_ns'] <= receipt['started_ns'] <= receipt['finished_ns'] <= outer['finished_ns']

profiles = []
observations = {}
for profile in plan['profiles']:
    name = profile['id']
    build = Path(profile['build_root'])
    observed_path = BASE / 'observations-r1' / name / 'report.json'
    observed = load(observed_path)
    observations[name] = observed
    for artifact in load(RUN / (name + '-artifacts.json')):
        assert verified(artifact)
    symbols = {}
    for line in (RUN / (name + '-nm.raw')).read_text().splitlines():
        match = re.fullmatch(r'([0-9a-fA-F]+)\s+([0-9a-fA-F]+)\s+(\S)\s+(.+)', line)
        if match:
            symbols[match[4]] = {'address': int(match[1], 16),
                                  'bytes': int(match[2], 16), 'nm_type': match[3]}
    for name_required in profile['symbols_present']:
        assert name_required in symbols, (name, name_required)
    absent = profile['symbols_absent_globs']
    assert not [symbol for symbol in symbols for pattern in absent
                if fnmatch.fnmatch(symbol, pattern)]
    sidecars = {symbol: facts for symbol, facts in symbols.items()
                if symbol.startswith('nx_io_irq_probe_')}
    assert len(sidecars) == int(profile['probe'])
    if profile['probe']:
        assert next(iter(sidecars.values()))['bytes'] == 36
        assert next(iter(sidecars.values()))['nm_type'] == 'B'
    link_lines = [line for line in (RUN / (name + '-actual-commands.raw')).read_text().splitlines()
                  if '-Wl,-Map,' in line and 'io_evolution_fixture.elf' in line]
    assert len(link_lines) == 1
    assert link_lines[0] in (RUN / (name + '-build.raw')).read_text()
    assert ('--undefined=nx_uart_word_port_service_observed' in link_lines[0]) == profile['probe']
    retention = load(build / 'bin/provider-retention.json')
    resources = load(build / 'bin/io_evolution_fixture.resources.json')
    assert retention['status'] == resources['status'] == 'passed'
    state = profile['provider_state']
    face = 's_nx_face_' + state.removeprefix('s_nx_port_')
    ops = 'nx_stm32_uart_word_ops' if name.startswith('f407') else 'nx_gd32_uart_word_ops'
    readonly = {symbol: symbols[symbol] for symbol in
                (face, ops, 'nx_factory_uart_word_irq_probe') if symbol in symbols}
    assert all(facts['nm_type'].lower() == 't' for facts in readonly.values())
    assert re.search(r'\.text\s+PROGBITS[^\n]*\bAX\b',
                     (RUN / (name + '-readelf.raw')).read_text())
    metrics = observed['metrics']
    profiles.append({'id': name, 'build_root': str(build),
        'Flash_LOAD_bytes': metrics['flash']['loaded_bytes'],
        'Flash_footprint_bytes': metrics['flash']['footprint_bytes'],
        'BIN_bytes': (build / 'bin/io_evolution_fixture.bin').stat().st_size,
        'SRAM_reserved_bytes': metrics['ram']['sram']['reserved_bytes'],
        'MSP_reserved_bytes': metrics['reservations']['msp']['bytes'],
        'provider_state': symbols[state], 'readonly_symbols': readonly,
        'sidecars': sidecars, 'resource_status': resources['status'],
        'provider_retention_status': retention['status'],
        'ELF': identity(build / 'bin/io_evolution_fixture.elf'),
        'BIN': identity(build / 'bin/io_evolution_fixture.bin'),
        'map': identity(build / 'bin/io_evolution_fixture.map'),
        'cost_observation': identity(observed_path),
        'actual_link_argv_raw': link_lines[0],
        'artifact_inventory': identity(RUN / (name + '-artifacts.json'))})

pairs = []
for family in ('f407', 'gd470'):
    off = next(row for row in profiles if row['id'] == family + '-probe-off')
    on = next(row for row in profiles if row['id'] == family + '-probe-on')
    assert off['provider_state']['bytes'] == on['provider_state']['bytes']
    assert observations[off['id']]['comparison_profile'] != observations[on['id']]['comparison_profile']
    pairs.append({'family': family, 'off': off['id'], 'on': on['id'],
        'Flash_LOAD_delta_bytes': on['Flash_LOAD_bytes'] - off['Flash_LOAD_bytes'],
        'Flash_footprint_delta_bytes': on['Flash_footprint_bytes'] - off['Flash_footprint_bytes'],
        'SRAM_reserved_delta_bytes': on['SRAM_reserved_bytes'] - off['SRAM_reserved_bytes'],
        'named_sidecar_bytes': 36, 'provider_state_growth_bytes': 0,
        'extra_alignment_reserved_bytes': 4,
        'strict_comparison': 'Actual comparison_profile differs; existing strict admission must reject. No strict comparison command or passing strict comparison is claimed.',
        'scope': 'Controlled optional-observation selection overhead including ON sidecar/getter/snapshot fixture and explicit retained service-wrapper link root. Not all-options-identical, implementation saving or isolated pure-IRQ cost.'})

independent = BASE / 'independent-static-review.json'
assert independent.exists()
report = {'schema_version': 1,
    'kind': 'IO05_four_exact_ARM_probe_link_static_closure',
    'status': 'passed_selected_link_static_checks', 'written_ns': time.time_ns(),
    'executed_source': execution['source_after'], 'source_before_after_equal': True,
    'freeze_release': 'All 50 commands finished with captured clean bacdc5b8 and unchanged source/tree/recursive Gitlinks. Root was explicitly told it may release the freeze and repair unrelated CI. This report binds those artifacts, not any subsequent live workspace state.',
    'scheduler': {'outer_receipt': identity(BASE / 'scheduler-r1.command.json'),
        'shared_flock': '/tmp/nexus-platform-compiler.lock', 'jobs': 1,
        'actual_commands': len(commands), 'all_actual_commands_completed_zero': True,
        'all_raw_receipt_hashes_rechecked': True,
        'all_commands_inside_outer_attempt': True,
        'actual_plan': identity(RUN / 'actual-plan.json'),
        'path_controls': plan['path_controls']},
    'resource_observation': {'minimum_cgroup_headroom_bytes': min(
        row['minimum_headroom_bytes'] for row in commands),
        'threshold_bytes': 256 * 1024 * 1024,
        'events_before': execution['baseline']['events'],
        'events_after': execution['memory_after']['events'],
        'OOM_growth': False, 'resource_stop': False},
    'profiles': profiles, 'controlled_selection_deltas': pairs,
    'independent_static_review': identity(independent),
    'static_conclusions': [
        'ON linked physical vector performs begin, exactly one original provider dispatch, then end. OFF tailbranches directly to the provider.',
        'OFF full nm/map/readelf closure has no observer sidecar/probe/counter/getter/observed-service symbol. ON has one writable 36-byte .bss sidecar.',
        'ROM face is 8 bytes and ops table 24 bytes in nonwritable AX .text. F407 provider state remains 56 bytes; GD470 remains 48 bytes.',
        'ON valid-face observed-service CFG converges to one original service helper call, whose helper performs one ops->service tail dispatch. NULL/unusable/reentrant/unavailable observation does not repeat or drop the original service.',
        'controller_main is a retention fixture and does not run I/O methods. A linked wrapper is not a runtime service/traffic observation.'],
    'input_tool_closure': {'tool_binary_identities': identity(RUN / 'tool-identities.json'),
        'tools_rehashed_by_locked_executor': True,
        'generated_compile_link_artifact_inventory_rehashed': True,
        'link_argv_in_executed_verbose_build_matches_ninja_listing': True},
    'navigation_correction': 'actual-plan inherited reviewed-plan expected_artifacts/post_link_readonly_argvs/soc_costs_observe_argv navigation with earlier roots; those fields were not executed. Actual command receipts, configure/build argv and per-profile *-artifacts.json bind the real equal-length roots.',
    'planning_attempts': 'An earlier Python-only preparation raised ConfigurationIR.part AttributeError before any CMake/build; accessor corrected, then four recorded Python preflights passed. A first final-summary read used an obsolete metadata key and produced no report; corrected here. No failed build/output or source was deleted.',
    'host_semantics_evidence': {
        'executed_behavior_source': '48242993f768cdb89d1cd745dad721a61669d472',
        'bacdc_delta': 'four documentation files only',
        'execution_sha256': '27335a0044030a6b3011203d84304c03a1618deacc49096fdf4cb956c1662c5c',
        'sealed_archive_sha256': 'db601e5812ae8eded1c90c593532ea8e450e0951c1ce33546bb01558c7be4c44',
        'flat_xmls': {'google-38.xml': 'CycleProbeDisabled 2 cases',
            'google-39.xml': 'CycleProbeNative 1 case',
            'google-40.xml': 'CycleProbe 16 cases; WordServiceStillDispatchesOnceWhenTheCounterIsUnavailable',
            'google-199.xml': 'IOTimestampBudget/IOTimestamp/IOCheckedService 17 cases'},
        'scope': 'Separate prior host software semantics with previously verified actual argv/flat XML hashes/attempt times. No old tdd/google/<binary>.xml and no ARM/runtime/physical promotion.'},
    'implementation_scope_assessment': 'Alongside existing exact host regressions and caller-policy timestamp_budget WITHIN/EXCEEDED/UNKNOWN, this closes finite optional-probe compile-out and existing IRQ/service dispatch implementation evidence for the reviewed F407/F470 word scopes. No all-provider producer/schema or elapsed-time promotion was added.',
    'physical_status': 'not_executed', 'cycles_status': 'not_measured',
    'IRQ_latency_status': 'not_measured', 'WCET_status': 'not_measured',
    'software_candidate': False, 'primary_writes_by_this_agent': False}
destination = BASE / 'final-summary.json'
assert not destination.exists()
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': identity(destination), 'status': report['status'],
                  'profiles': [{key: row[key] for key in
                      ('id', 'Flash_LOAD_bytes', 'SRAM_reserved_bytes')} for row in profiles],
                  'minimum_headroom_MiB': round(report['resource_observation']['minimum_cgroup_headroom_bytes'] / 1048576, 2)}, indent=2))
