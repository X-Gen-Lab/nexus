"""Read-only artifact checks and existing comparison CLIs; never rebuild images."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

REPO = Path('/tmp/nexus-quality-20261019')
BASE = Path('/tmp/nexus-io08-cost-20261020')
sys.path.insert(0, str(REPO))
from tools.dev.process import run
from tools.evidence.common import atomic_json


def identity(path):
    path = Path(path)
    return {'path': str(path), 'size': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def ar_members(path):
    data = Path(path).read_bytes()
    if not data.startswith(b'!<arch>\n'):
        raise ValueError('Expected original normal ar archive')
    offset, result = 8, []
    while offset < len(data):
        header = data[offset:offset + 60]
        if len(header) != 60 or header[58:] != b'`\n':
            raise ValueError('Malformed ar header')
        size = int(header[48:58].strip())
        payload = data[offset + 60:offset + 60 + size]
        if len(payload) != size:
            raise ValueError('Truncated original archive member')
        result.append({'name_field': header[:16].decode('ascii'),
            'mtime': header[16:28].decode('ascii').strip(), 'size': size,
            'header_except_mtime_hex': (header[:16] + header[28:]).hex(),
            'payload_sha256': hashlib.sha256(payload).hexdigest()})
        offset += 60 + size + size % 2
    if offset != len(data):
        raise ValueError('Archive trailing bytes changed')
    return result


record = {'kind': 'io08_final_readonly_verification', 'status': 'running',
          'physical_status': 'not_executed', 'cycles_status': 'not_measured',
          'wcet_status': 'not_measured', 'energy_status': 'not_measured',
          'commands': [], 'archive_checks': {}, 'qualification': False}


def save():
    atomic_json(BASE / 'verification.json', record)


def clean_source():
    head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=REPO,
                                   text=True).strip()
    dirty = subprocess.check_output(['git','status','--porcelain'], cwd=REPO,
                                    text=True)
    if head != 'bacdc5b8a5d64baebb92517e770d0abac28421b8' or dirty:
        raise RuntimeError('Frozen clean source changed')
    return {'commit': head, 'dirty': False}


def memory():
    events = {key: int(value) for key,value in (line.split() for line in
        Path('/sys/fs/cgroup/memory.events').read_text().splitlines())}
    if events['oom'] != 61 or events['oom_kill'] != 10:
        raise RuntimeError('OOM baseline changed')
    return {'events': events, 'current': int(Path('/sys/fs/cgroup/memory.current').read_text()),
            'maximum': int(Path('/sys/fs/cgroup/memory.max').read_text())}


def compare(baseline, candidate, label, expected):
    env = os.environ.copy()
    env.update({'PYTHONDONTWRITEBYTECODE':'1','NEXUS_BUILD_JOBS':'1',
                'CMAKE_BUILD_PARALLEL_LEVEL':'1','CTEST_PARALLEL_LEVEL':'1'})
    command = [REPO / '.venv/bin/python', '-B', REPO / 'tools/measurement/soc_costs.py',
        'compare', '--baseline', BASE / 'observations' / baseline / 'report.json',
        '--candidate', BASE / 'observations' / candidate / 'report.json',
        '--growth', BASE / 'growth.json', '--report', BASE / (label + '.json')]
    result = run([str(value) for value in command], cwd=REPO, env=env,
        timeout=180, log=BASE / 'commands' / (label + '.raw'), stage=label)
    record['commands'].append({'label': label, 'argv': [str(x) for x in command],
        'expected_exit': expected, 'actual_exit': result.returncode,
        'receipt': identity(BASE / 'commands' / (label + '.command.json'))})
    record['memory_after_' + label] = memory()
    save()
    print(label + ': exit=' + str(result.returncode), flush=True)
    if result.returncode != expected:
        raise RuntimeError(label + ' unexpected comparison status')
    return result


try:
    record['source_before'] = clean_source()
    record['memory_before'] = memory()
    prior = json.loads((BASE / 'continuation.json').read_text())
    record['original_failed_execution'] = identity(BASE / 'execution.json')
    record['retained_continuation'] = identity(BASE / 'continuation.json')
    record['growth'] = identity(BASE / 'growth.json')
    if record['growth'] != prior['growth_predeclared']:
        raise RuntimeError('Predeclared growth limits changed')
    for name, tool in prior['tools'].items():
        if identity(tool['path']) != tool:
            raise RuntimeError('Tool bytes changed: ' + name)
    images = prior['images']
    b,c = images['image-b'], images['image-c']
    if prior['B_C_object_mismatches']:
        raise RuntimeError('Unresolved compilation object mismatch')
    if b['actual_link_inputs']['normalized_without_declared_treatment'] != \
            c['actual_link_inputs']['normalized_without_declared_treatment'] or \
            b['actual_link_inputs']['treatment_count'] != 0 or \
            c['actual_link_inputs']['treatment_count'] != 1:
        raise RuntimeError('Unresolved full link command treatment')
    archive_b = b['actual_link_inputs']['archive_inputs']
    archive_c = c['actual_link_inputs']['archive_inputs']
    if archive_b.keys() != archive_c.keys():
        raise RuntimeError('Archive input set changed')
    for name in archive_b:
        left,right = ar_members(archive_b[name]['path']),ar_members(archive_c[name]['path'])
        if len(left) != len(right):
            raise RuntimeError('Archive member count changed')
        for old,new in zip(left,right):
            if {key:value for key,value in old.items() if key != 'mtime'} != \
                    {key:value for key,value in new.items() if key != 'mtime'}:
                raise RuntimeError('Archive differs beyond member timestamp: ' + name)
        record['archive_checks'][name] = {'original_B':archive_b[name],
            'original_C':archive_c[name], 'members_B':left, 'members_C':right,
            'member_payloads_and_non_mtime_headers_identical':True,
            'container_difference':'Original member timestamps only; original archives retained unchanged'}
    record['B_C_object_count'] = len(b['compilation_units'])
    record['B_C_object_hashes_and_compile_argv_identical'] = True
    record['B_C_link_argv_only_declared_retention_treatment'] = True
    record['built_vs_linked_scope'] = 'Actual built object set is independently selected by Ninja firmware dependency graph and matched to compile database. Final link raw supplies direct objects and archives. Archive members are identical, but final ELF/map alone establish extracted/retained sections.'
    record['unbuilt_optional_units'] = {
        name: images[name]['excluded_optional_units'] for name in images}
    record['costs'] = {name:image['costs'] for name,image in images.items()}
    record['linked_symbols'] = {name:image['symbols'] for name,image in images.items()}
    state_names = ['s_nx_port_uart1','s_nx_rx_uart1','s_nx_face_uart1','nx_stm32_uart_ops']
    for name in state_names:
        if len({images[image]['symbols'][name]['size'] for image in images}) != 1:
            raise RuntimeError('Default byte state/buffer/face/table size changed')
    producers = {}
    for unit,row in b['compilation_units'].items():
        if row['source_role'] == 'source/soc/stm32f407/drivers/uart.c':
            checks = {image:images[image]['compilation_units'][unit]['object'] for image in images}
            if len({item['sha256'] for item in checks.values()}) != 1:
                raise RuntimeError('Ordinary producer object differs')
            producers[unit] = checks
    if not producers:
        raise RuntimeError('No actual ordinary UART producer object found')
    record['ordinary_uart_producer_objects_identical_all_images'] = producers
    save()
    compare('image-b','image-c','traits-retention-comparison',0)
    result = compare('image-a','image-b','A-B-profile-rejection',1)
    if 'cost observations are not strictly comparable' not in result.stdout + result.stderr:
        raise RuntimeError('A/B did not reject for expected strict profile reason')
    if (BASE / 'A-B-profile-rejection.json').exists():
        raise RuntimeError('Rejected comparison unexpectedly published success report')
    record['source_after'] = clean_source()
    record['memory_final'] = memory()
    record['status'] = 'passed_controlled_link_cost_observation'
    record['finished_ns'] = time.time_ns()
    save()
    print('Verified three fresh exact images. B/C +40 Flash bytes, zero RAM growth; '
          'A/B selection comparison correctly rejected. Original failures retained.', flush=True)
except BaseException as error:
    record['status'] = 'failed_retained'
    record['failure'] = type(error).__name__ + ': ' + str(error)
    save()
    print(record['failure'], flush=True)
    raise SystemExit(1)
