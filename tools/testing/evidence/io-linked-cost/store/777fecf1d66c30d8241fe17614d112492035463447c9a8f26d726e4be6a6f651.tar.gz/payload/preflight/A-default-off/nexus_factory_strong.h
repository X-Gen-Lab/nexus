/**
 * \file            nexus_factory_strong.h
 * \brief           Optional nominal factory identities.
 * \author          Nexus Team
 */
#ifndef NEXUS_FACTORY_STRONG_H
#define NEXUS_FACTORY_STRONG_H
#include "nexus_factory.h"
#ifdef __cplusplus
#define NX_FACTORY_REF_VALUE(type, value)                                      \
    type {                                                                     \
        value                                                                  \
    }
extern "C" {
#else
#define NX_FACTORY_REF_VALUE(type, value) ((type){value})
#endif
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_gpio_ref_t;
#define NX_GPIO_REF_COUNT NX_FACTORY_REF_VALUE(nx_gpio_ref_t, NX_GPIO_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_gpio_port_t* nx_factory_gpio_ref(nx_gpio_ref_t id) {
    return nx_factory_gpio(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_uart_ref_t;
#define NX_UART_REF_UART1 NX_FACTORY_REF_VALUE(nx_uart_ref_t, NX_UART_ID_UART1)
#define NX_UART_REF_COUNT NX_FACTORY_REF_VALUE(nx_uart_ref_t, NX_UART_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_uart_port_t* nx_factory_uart_ref(nx_uart_ref_t id) {
    return nx_factory_uart(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_spi_ref_t;
#define NX_SPI_REF_COUNT NX_FACTORY_REF_VALUE(nx_spi_ref_t, NX_SPI_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_spi_port_t* nx_factory_spi_ref(nx_spi_ref_t id) {
    return nx_factory_spi(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_i2c_ref_t;
#define NX_I2C_REF_COUNT NX_FACTORY_REF_VALUE(nx_i2c_ref_t, NX_I2C_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_i2c_port_t* nx_factory_i2c_ref(nx_i2c_ref_t id) {
    return nx_factory_i2c(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_flash_ref_t;
#define NX_FLASH_REF_COUNT                                                     \
    NX_FACTORY_REF_VALUE(nx_flash_ref_t, NX_FLASH_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_flash_port_t* nx_factory_flash_ref(nx_flash_ref_t id) {
    return nx_factory_flash(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_watchdog_ref_t;
#define NX_WATCHDOG_REF_COUNT                                                  \
    NX_FACTORY_REF_VALUE(nx_watchdog_ref_t, NX_WATCHDOG_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_watchdog_port_t*
nx_factory_watchdog_ref(nx_watchdog_ref_t id) {
    return nx_factory_watchdog(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_exti_ref_t;
#define NX_EXTI_REF_COUNT NX_FACTORY_REF_VALUE(nx_exti_ref_t, NX_EXTI_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_exti_port_t* nx_factory_exti_ref(nx_exti_ref_t id) {
    return nx_factory_exti(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_pwm_ref_t;
#define NX_PWM_REF_COUNT NX_FACTORY_REF_VALUE(nx_pwm_ref_t, NX_PWM_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_pwm_port_t* nx_factory_pwm_ref(nx_pwm_ref_t id) {
    return nx_factory_pwm(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_adc_ref_t;
#define NX_ADC_REF_COUNT NX_FACTORY_REF_VALUE(nx_adc_ref_t, NX_ADC_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_adc_port_t* nx_factory_adc_ref(nx_adc_ref_t id) {
    return nx_factory_adc(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_can_ref_t;
#define NX_CAN_REF_COUNT NX_FACTORY_REF_VALUE(nx_can_ref_t, NX_CAN_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_can_port_t* nx_factory_can_ref(nx_can_ref_t id) {
    return nx_factory_can(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_usb_device_ref_t;
#define NX_USB_DEVICE_REF_COUNT                                                \
    NX_FACTORY_REF_VALUE(nx_usb_device_ref_t, NX_USB_DEVICE_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_usb_device_port_t*
nx_factory_usb_device_ref(nx_usb_device_ref_t id) {
    return nx_factory_usb_device(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_eth_ref_t;
#define NX_ETH_REF_COUNT NX_FACTORY_REF_VALUE(nx_eth_ref_t, NX_ETH_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_eth_port_t* nx_factory_eth_ref(nx_eth_ref_t id) {
    return nx_factory_eth(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_timer_capture_ref_t;
#define NX_TIMER_CAPTURE_REF_COUNT                                             \
    NX_FACTORY_REF_VALUE(nx_timer_capture_ref_t, NX_TIMER_CAPTURE_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_timer_capture_t*
nx_factory_timer_capture_ref(nx_timer_capture_ref_t id) {
    return nx_factory_timer_capture(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_advanced_pwm_ref_t;
#define NX_ADVANCED_PWM_REF_COUNT                                              \
    NX_FACTORY_REF_VALUE(nx_advanced_pwm_ref_t, NX_ADVANCED_PWM_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_advanced_pwm_t*
nx_factory_advanced_pwm_ref(nx_advanced_pwm_ref_t id) {
    return nx_factory_advanced_pwm(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_pwm_group_ref_t;
#define NX_PWM_GROUP_REF_COUNT                                                 \
    NX_FACTORY_REF_VALUE(nx_pwm_group_ref_t, NX_PWM_GROUP_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_pwm_group_t*
nx_factory_pwm_group_ref(nx_pwm_group_ref_t id) {
    return nx_factory_pwm_group(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_encoder_ref_t;
#define NX_ENCODER_REF_COUNT                                                   \
    NX_FACTORY_REF_VALUE(nx_encoder_ref_t, NX_ENCODER_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_encoder_t* nx_factory_encoder_ref(nx_encoder_ref_t id) {
    return nx_factory_encoder(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_pwm_adc_ref_t;
#define NX_PWM_ADC_REF_COUNT                                                   \
    NX_FACTORY_REF_VALUE(nx_pwm_adc_ref_t, NX_PWM_ADC_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_pwm_adc_t* nx_factory_pwm_adc_ref(nx_pwm_adc_ref_t id) {
    return nx_factory_pwm_adc(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_can_fd_ref_t;
#define NX_CAN_FD_REF_COUNT                                                    \
    NX_FACTORY_REF_VALUE(nx_can_fd_ref_t, NX_CAN_FD_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_can_fd_port_t*
nx_factory_can_fd_ref(nx_can_fd_ref_t id) {
    return nx_factory_can_fd(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_adc_group_ref_t;
#define NX_ADC_GROUP_REF_COUNT                                                 \
    NX_FACTORY_REF_VALUE(nx_adc_group_ref_t, NX_ADC_GROUP_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_adc_group_port_t*
nx_factory_adc_group_ref(nx_adc_group_ref_t id) {
    return nx_factory_adc_group(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_eth_frames_ref_t;
#define NX_ETH_FRAMES_REF_COUNT                                                \
    NX_FACTORY_REF_VALUE(nx_eth_frames_ref_t, NX_ETH_FRAMES_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_eth_frames_port_t*
nx_factory_eth_frames_ref(nx_eth_frames_ref_t id) {
    return nx_factory_eth_frames(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_rtc_ref_t;
#define NX_RTC_REF_COUNT NX_FACTORY_REF_VALUE(nx_rtc_ref_t, NX_RTC_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_rtc_port_t* nx_factory_rtc_ref(nx_rtc_ref_t id) {
    return nx_factory_rtc(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_lptim_ref_t;
#define NX_LPTIM_REF_COUNT                                                     \
    NX_FACTORY_REF_VALUE(nx_lptim_ref_t, NX_LPTIM_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_lptim_port_t* nx_factory_lptim_ref(nx_lptim_ref_t id) {
    return nx_factory_lptim(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_spi_device_ref_t;
#define NX_SPI_DEVICE_REF_COUNT                                                \
    NX_FACTORY_REF_VALUE(nx_spi_device_ref_t, NX_SPI_DEVICE_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_spi_endpoint_t*
nx_factory_spi_device_ref(nx_spi_device_ref_t id) {
    return nx_factory_spi_device(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_i2c_device_ref_t;
#define NX_I2C_DEVICE_REF_COUNT                                                \
    NX_FACTORY_REF_VALUE(nx_i2c_device_ref_t, NX_I2C_DEVICE_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_i2c_endpoint_t*
nx_factory_i2c_device_ref(nx_i2c_device_ref_t id) {
    return nx_factory_i2c_device(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_usb_endpoint_ref_t;
#define NX_USB_ENDPOINT_REF_COUNT                                              \
    NX_FACTORY_REF_VALUE(nx_usb_endpoint_ref_t, NX_USB_ENDPOINT_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_usb_endpoint_port_t*
nx_factory_usb_endpoint_ref(nx_usb_endpoint_ref_t id) {
    return nx_factory_usb_endpoint(id.value);
}
/** \brief Explicit assembly-local ID; not a wire ABI. */
typedef struct {
    uint16_t value;
} nx_mdio_ref_t;
#define NX_MDIO_REF_COUNT NX_FACTORY_REF_VALUE(nx_mdio_ref_t, NX_MDIO_ID_COUNT)
/** \brief Pure getter; lifecycle remains explicit. */
static inline const nx_mdio_port_t* nx_factory_mdio_ref(nx_mdio_ref_t id) {
    return nx_factory_mdio(id.value);
}
#ifdef __cplusplus
}
#endif
#endif
