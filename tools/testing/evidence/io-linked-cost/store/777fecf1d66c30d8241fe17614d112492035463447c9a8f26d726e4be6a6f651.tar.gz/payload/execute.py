"""One root-authorized, serial IO08 measurement sequence; not a build framework."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import threading
import time

REPO = Path('/tmp/nexus-quality-20261019')
BASE = Path('/tmp/nexus-io08-cost-20261020')
EXPECTED = 'bacdc5b8a5d64baebb92517e770d0abac28421b8'
sys.path.insert(0, str(REPO))
from tools.dev.process import run
from tools.evidence.common import atomic_json
from tools.measurement.elf import Elf32
from tools.measurement.soc_costs import cost_values

PYTHON = REPO / '.venv/bin/python'
CMAKE = REPO / '.venv/bin/cmake'
NINJA = REPO / '.venv/bin/ninja'
ARM = Path('/tmp/nexus-quality-arm/bin')
GCC = ARM / 'arm-none-eabi-gcc'
OBJDUMP = ARM / 'arm-none-eabi-objdump'
report = {'kind': 'io08_controlled_link_cost_execution', 'status': 'running',
          'expected_commit': EXPECTED, 'images': {}, 'commands': [],
          'memory_samples': [], 'physical_status': 'not_executed',
          'cycles_status': 'not_measured', 'wcet_status': 'not_measured',
          'energy_status': 'not_measured', 'qualification': False}
environment = os.environ.copy()
environment.update({'PATH': str(REPO / '.venv/bin') + ':' + str(ARM) + ':' +
                    environment.get('PATH', ''), 'PYTHONDONTWRITEBYTECODE': '1',
                    'NEXUS_BUILD_JOBS': '1', 'CMAKE_BUILD_PARALLEL_LEVEL': '1',
                    'CTEST_PARALLEL_LEVEL': '1', 'CCACHE_DISABLE': '1'})


def identity(path):
    path = Path(path)
    return {'path': str(path), 'size': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def save():
    atomic_json(BASE / 'execution.json', report)


def source():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO,
                                   text=True).strip()
    dirty = subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO,
                                    text=True)
    if head != EXPECTED or dirty:
        raise RuntimeError('Exact clean source changed; retain evidence and stop')
    return {'commit': head, 'dirty': False}


def memory(label):
    events = dict(line.split() for line in
                  Path('/sys/fs/cgroup/memory.events').read_text().splitlines())
    item = {'label': label, 'time_ns': time.time_ns(),
            'current': int(Path('/sys/fs/cgroup/memory.current').read_text()),
            'maximum': int(Path('/sys/fs/cgroup/memory.max').read_text()),
            'events': {key: int(value) for key, value in events.items()}}
    report['memory_samples'].append(item)
    return item


def healthy(item):
    initial = report['memory_baseline']['events']
    if any(item['events'][name] != initial[name] for name in ('oom', 'oom_kill')):
        return False, 'OOM counters changed'
    if item['maximum'] - item['current'] < 256 * 1024 * 1024:
        return False, 'cgroup headroom below 256 MiB'
    return True, None


def execute(argv, label, timeout=600, expected=0):
    source()
    valid, reason = healthy(memory(label + '-before'))
    if not valid:
        raise RuntimeError(reason)
    cancel = threading.Event()
    done = threading.Event()
    monitor_failure = []
    def monitor():
        while not done.wait(1):
            item = memory(label + '-sample')
            valid, reason = healthy(item)
            if not valid:
                monitor_failure.append(reason)
                cancel.set()
                return
    thread = threading.Thread(target=monitor, daemon=True)
    thread.start()
    print(label + ': started', flush=True)
    try:
        result = run([str(arg) for arg in argv], cwd=REPO, env=environment,
                     timeout=timeout, cancel_event=cancel,
                     log=BASE / 'commands' / (label + '.raw'), stage=label)
    finally:
        done.set()
        thread.join()
    item = memory(label + '-after')
    valid, reason = healthy(item)
    report['commands'].append({'label': label, 'argv': [str(arg) for arg in argv],
        'exit_code': result.returncode, 'expected_exit_code': expected,
        'receipt': identity(BASE / 'commands' / (label + '.command.json'))})
    save()
    print(label + ': exit=' + str(result.returncode) + ', memory=' +
          str(item['current']) + ', oom=' + str(item['events']['oom']) + '/' +
          str(item['events']['oom_kill']), flush=True)
    if monitor_failure or not valid:
        raise RuntimeError('; '.join(monitor_failure) or reason)
    if result.returncode != expected:
        print((result.stdout + result.stderr)[-3000:], flush=True)
        raise RuntimeError(label + ' returned unexpected status')
    return result


def compilation_units(build):
    rows = json.loads((build / 'compile_commands.json').read_text())
    result = {}
    for row in rows:
        argv = row.get('arguments') or shlex.split(row['command'])
        output = argv[argv.index('-o') + 1]
        obj = Path(output)
        if not obj.is_absolute():
            obj = Path(row['directory']) / obj
        source_path = Path(row['file'])
        if source_path.is_relative_to(build):
            role = 'build/' + source_path.relative_to(build).as_posix()
        else:
            role = 'source/' + source_path.relative_to(REPO).as_posix()
        target = output.split('.dir/', 1)[0]
        key = target + '|' + role
        def normalize(token):
            return (token.replace(str(build), '{build}')
                    .replace(str(build).lstrip('/'), '{build}')
                    .replace(str(REPO), '{source}'))
        if key in result:
            raise RuntimeError('Ambiguous compilation unit')
        result[key] = {'source_role': role, 'object': identity(obj),
                       'normalized_argv': [normalize(token) for token in argv]}
    return result


def symbols(elf_path):
    elf = Elf32(elf_path.read_bytes(), float_abi='hard')
    desired = {'nx_factory_uart', 'nx_factory_uart_traits',
               's_nx_traits_uart_uart1', 'nx_factory_uart_capability',
               's_nx_capability_uart_uart1', 's_nx_port_uart1',
               's_nx_rx_uart1', 's_nx_face_uart1', 'nx_stm32_uart_ops',
               'nx_stm32_uart_irq', 'nx_stm32_uart_submit',
               'nx_stm32_uart_read_bytes'}
    found = {}
    for item in elf.defined_symbols:
        if item['name'] in desired:
            section = elf.sections[item['section']]
            found[item['name']] = {'size': item['size'],
                'address': item['value'], 'section': section['name'],
                'section_flags': section['flags']}
    return found


try:
    if (BASE / 'build').exists():
        raise RuntimeError('Fresh independent build root already exists')
    report['source_before'] = source()
    report['memory_baseline'] = memory('baseline')
    if report['memory_baseline']['events']['oom'] != 61 or \
            report['memory_baseline']['events']['oom_kill'] != 10:
        raise RuntimeError('Root-authorized OOM baseline 61/10 changed')
    report['tools'] = {name: identity(path) for name, path in
        [('python', PYTHON), ('cmake', CMAKE), ('ninja', NINJA), ('gcc', GCC),
         ('objdump', OBJDUMP), ('ar', ARM / 'arm-none-eabi-ar'),
         ('objcopy', ARM / 'arm-none-eabi-objcopy'),
         ('as', ARM / 'arm-none-eabi-as'), ('ld', ARM / 'arm-none-eabi-ld')]}
    report['growth_predeclared'] = identity(BASE / 'growth.json')
    report['plan'] = identity(BASE / 'plan.json')
    save()
    for name in ('image-a', 'image-b', 'image-c'):
        build = BASE / 'build' / name
        assembly = BASE / 'inputs' / ('input-a.toml' if name == 'image-a' else
                                      'input-b.toml')
        mapped = []
        for option in ('-ffile-prefix-map=', '-fdebug-prefix-map=',
                       '-fmacro-prefix-map='):
            mapped.extend([option + str(REPO) + '=src',
                           option + str(build) + '=build'])
        treatment = '-Wl,--undefined=nx_factory_uart_traits' if \
            name == 'image-c' else ''
        configure = [CMAKE, '-S', REPO, '-B', build, '-G', 'Ninja',
            '-DCMAKE_MAKE_PROGRAM=' + str(NINJA),
            '-DCMAKE_TOOLCHAIN_FILE=' + str(REPO / 'cmake/toolchains/arm-gcc.cmake'),
            '-DCMAKE_C_COMPILER=' + str(GCC),
            '-DCMAKE_ASM_COMPILER=' + str(GCC),
            '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
            '-DNEXUS_ASSEMBLY_FILE=' + str(assembly), '-DNEXUS_BUILD_TESTS=OFF',
            '-DNEXUS_IO_EVOLUTION_FIXTURE=OFF', '-DNEXUS_BUILD_WORKLOAD=ON',
            '-DNEXUS_WORKLOAD=uart', '-DNEXUS_WORKLOAD_UART_ID=NX_UART_ID_UART1',
            '-DNEXUS_COMPILER_CACHE=OFF', '-DCMAKE_C_COMPILER_LAUNCHER=',
            '-DCMAKE_INTERPROCEDURAL_OPTIMIZATION=OFF',
            '-DCMAKE_C_FLAGS=' + ' '.join(mapped),
            '-DCMAKE_EXE_LINKER_FLAGS=' + treatment]
        execute(configure, name + '-configure', timeout=180)
        execute([CMAKE, '--build', build, '--parallel', '1', '--verbose'],
                name + '-build', timeout=600)
        execute([PYTHON, '-B', REPO / 'tools/measurement/soc_costs.py', 'observe',
            '--elf', build / 'bin/nexus_firmware.elf', '--resolved',
            build / 'generated/resolved.json', '--budget',
            build / 'generated/resource-budget.json', '--compile-commands',
            build / 'compile_commands.json', '--output', BASE / 'observations' / name,
            '--objdump', OBJDUMP, '--symbols', 'nx_factory_uart',
            'nx_stm32_uart_irq', 'nx_stm32_uart_submit', 'nx_stm32_uart_read_bytes'],
            name + '-observe', timeout=180)
        execute([PYTHON, '-B', REPO / 'tools/measurement/interfaces.py', '--elf',
            build / 'bin/nexus_firmware.elf', '--resolved',
            build / 'generated/resolved.json', '--require-interfaces', '--output',
            BASE / 'observations' / (name + '-interfaces.json')],
            name + '-interfaces', timeout=120)
        units = compilation_units(build)
        found = symbols(build / 'bin/nexus_firmware.elf')
        metadata = {'nx_factory_uart_traits', 's_nx_traits_uart_uart1'}
        if metadata.issubset(found) != (name == 'image-c') or \
                ('nx_factory_uart_capability' in found) or \
                ('s_nx_capability_uart_uart1' in found):
            raise RuntimeError('Optional metadata retention differs from treatment')
        for symbol in metadata.intersection(found):
            if found[symbol]['section_flags'] & 1:
                raise RuntimeError('Optional metadata is writable')
        observed = json.loads((BASE / 'observations' / name / 'report.json').read_text())
        report['images'][name] = {'build': str(build), 'symbols': found,
            'compilation_units': units, 'costs': cost_values(observed['metrics']),
            'elf': observed['inputs']['elf'], 'source_after': source()}
        save()
    b, c = report['images']['image-b'], report['images']['image-c']
    if b['compilation_units'].keys() != c['compilation_units'].keys():
        raise RuntimeError('B/C compilation unit set changed')
    mismatches = []
    for name, row in b['compilation_units'].items():
        other = c['compilation_units'][name]
        if row['object']['sha256'] != other['object']['sha256'] or \
                row['normalized_argv'] != other['normalized_argv']:
            mismatches.append(name)
    report['B_C_object_mismatches'] = mismatches
    save()
    if mismatches:
        raise RuntimeError('B/C object or compile argv differs; stop attribution')
    comparison = [PYTHON, '-B', REPO / 'tools/measurement/soc_costs.py', 'compare',
        '--baseline', BASE / 'observations/image-b/report.json', '--candidate',
        BASE / 'observations/image-c/report.json', '--growth', BASE / 'growth.json',
        '--report', BASE / 'traits-retention-comparison.json']
    execute(comparison, 'B-C-strict-compare', timeout=180)
    rejected = [PYTHON, '-B', REPO / 'tools/measurement/soc_costs.py', 'compare',
        '--baseline', BASE / 'observations/image-a/report.json', '--candidate',
        BASE / 'observations/image-b/report.json', '--growth', BASE / 'growth.json',
        '--report', BASE / 'A-B-should-not-exist.json']
    result = execute(rejected, 'A-B-profile-rejection', timeout=180, expected=1)
    if 'cost observations are not strictly comparable' not in result.stderr + result.stdout:
        raise RuntimeError('A/B did not reject specifically for profile mismatch')
    report['source_after'] = source()
    report['status'] = 'built_and_observed_pending_full_link_argv_review'
    report['memory_final'] = memory('final')
    save()
    print('Three images observed; B/C objects identical; strict compare passed; '
          'A/B rejected. Full link argv review remains.', flush=True)
except BaseException as error:
    report['status'] = 'failed_retained'
    report['failure'] = type(error).__name__ + ': ' + str(error)
    try:
        report['memory_final'] = memory('failed')
        save()
    finally:
        print(report['failure'], flush=True)
    raise SystemExit(1)
