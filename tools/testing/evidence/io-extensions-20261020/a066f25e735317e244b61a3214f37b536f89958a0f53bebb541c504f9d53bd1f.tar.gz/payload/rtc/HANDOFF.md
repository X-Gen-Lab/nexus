# U575 retained-calendar RTC RUN software increment

Apply `integration.patch` to the primary checkout and copy only the new production,
test, Board, assembly and public consumer files listed below. Shared mirrored files
are review material; applying their patch avoids overwriting parallel changes.
Do not copy `integration-source/` or `verification/` into the repository. No primary
repository edits, staging, commits or pushes were performed by this subtask.

New repository files:

- `soc/stm32u575/drivers/rtc.c`
- `soc/stm32u575/private/stm32u575_rtc.h`
- `tests/google/u575_rtc.cmake`
- `tests/google/u575_rtc_model.h`
- `tests/google/u575_rtc_model.cpp`
- `tests/google/u575_rtc_test.cpp`
- `tools/configure/providers/stm32u575/test_rtc.py`
- `tools/configure/assemblies/u575-rtc-run.toml`
- `boards/stm32u575zi_rtc_reference/board.json`
- `cmake/package/verification/io_evolution/consumers/u575-rtc.c`

The existing public `rtc.h` remains unchanged. The exact selection is RTC0,
`retained-calendar-alarm`, baremetal, fixed MSIS4 system/Core clock. Static typed
factory lookup returns `NX_RTC_ID_CALENDAR` without hardware work. Calendar read,
one finite Alarm A, cancel, explicit bounded service and stop are implemented;
public set returns `UNSUPPORTED`. Natural YY99 to YY00 does not change the setting
domain. Reopen after stop/joins increments the checked nonwrapping generation.

The external boot owner prepares and preserves valid retained calendar provenance,
TZEN0, LSE32768/LSERDY/RTCEN/RTCSEL, RTCAPBEN, PWREN/DBP, BCD24h BYPSHAD,
PRER127/255, no shift/calibration/foreign RTC owners and locked WPR. The unreadable
WPR state cannot be discovered or saved: locked handoff, locked between calls and
no competing writer are explicit premises. Accepted hardware write phases briefly
write CA/53, write and read back the target, then unconditionally write FF before
return. Preflight, reads and admission perform no writes. Provider never writes
calendar, RCC, PWR, TAMP, oscillator selection, calibration or backup reset.

The software-only Board has no crystal route or measured clock claim. External
boot ownership includes LSE pins PC14/PC15; selected conflicting GPIO owners are
rejected. INITS alone cannot prove valid provenance, especially intentional YY00.
Read retries at most eight complete SSR/TR/DR pairs using BYPSHAD per ES0499
Rev12 2.19.3. No fabricated calendar epoch comes from Core time or timeouts.

Every accepted request stays borrowed through acquire-observed SETTLED and
separate joins. Core deadlines are independent absolute monotonic microseconds.
Cancel/stop latch cancellation without revoking the loan; first service observation
checks expiry before event. Service advances one phase per call. Initial source
isolation and final withdrawal clear ALRAE, observe readback and wait100us in the
Core domain before flag handling or alarm programming. This interval assumes the
externally supplied declared32768Hz source and the maintained1MHz RUN timebase;
it is not a measured timing claim. A phase deadline overflow fails closed.

Final drain proves disabled source after synchronization, W1C CALRAF observed clear,
restored saved alarm/subsecond registers, quiet IRQ and detached provider reference
before release settlement. Failed disable/unlock/clear/restore retains QUARANTINED
request storage. Foreign source/configuration drift taints the owner and retains
external recovery responsibility without resetting the backup domain. No task,
queue, heap, IRQ handler or hidden polling wait is added.

Executed development evidence is in `evidence/`:

- `red-test-r4.log` and `red-result.xml`: actual compiled C11 stub RED,15 failures.
- `cold-sync-red-test.log`:17pass/1fail for initial disable clock crossing;
  corresponding production fix verified GREEN.
- `wpr-red-test.log`:12pass/7fail with real modeled WPR protection;
  scoped unlock/relock fix verified GREEN.
- `arm-overflow-red-test.log`:19pass/1fail for saturated ARM synchronization;
  fail-closed fix verified GREEN.
- `final-test.log`, `final-result.xml`:20 GoogleTest/GoogleMock cases, no skips,
  filters or disabled cases; actual C11 production provider, hardware/clock leaves.
- `configuration-red.log`: new fixture rejected by original missing route;
  `configuration-final.log`:2 configuration cases passed.
- `sdk-call-final-test.log`:41 SDK orchestration cases passed.
- `sdk-payload-final-test.log`:19 payload cases passed.
- `arm-baseline-final-build.log`, `arm-resources-final.json`,
  `arm-retention-final.json`: actual public-only consumer/official SDK ARM C11
  ELF/BIN/map, resource budget and retained provider/method proof.

All compiler and CMake consumer commands ran under
`flock /tmp/nexus-platform-compiler.lock` with one compiler job. GoogleTest1.16.0
commit6910c9d9165801d8827d628cb72eb7ea9dd538c5 and actual GoogleMock libraries
were reused from the existing pinned build. Firmware does not link C++ or Google.
Initial setup failures and transient snapshot integration failures remain in raw
logs; they are not counted as expected TDD RED or successful qualification.

This is development software evidence. Full integrated complete-index gates,
clean-source candidate identity, offline reproducible dual builds and physical
station work remain the root integration/delivery responsibility. Original IO36
exit criteria are not reduced. Hardware is not connected: physical results,
Stop2/autonomous power behavior, VBAT continuity and all applicable HIL remain
`not_executed`. LPDMA is not implemented by this increment.

中文范围：本次仅新增外部已准备并保留的RTC日历读取及RUN轮询Alarm A。公开接口不变，
set明确不支持；初始与排空阶段均等待真实Core时间覆盖ALRAE跨时钟同步，只有实际源、
标志和寄存器恢复排空后才归还请求。WPR采用短暂CA/53解锁及无条件FF锁回，外部必须
以锁定状态交接且无其他写者；不写日历、时钟、电源、TAMP或备份域复位。软件Board
不声明已审晶振路线。YY99→00不重置domain，取消、超时及排空失败不撤销loan。
没有Stop2、LPDMA、VBAT连续性或实板资格；原始退出条件继续保留。
