"""Compile actual C11 production and run the whole pinned GoogleMock suite."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/tmp/nexus-quality-20261019')
phase = sys.argv[1]
out = ROOT / 'evidence' / phase
out.mkdir(parents=True, exist_ok=True)
include = ['-I' + str(ROOT / 'components/amp_ipc' / part)
           for part in ('include',)]
include += ['-I' + str(SOURCE / 'core/include')]
google = SOURCE / 'ext/googletest'
framework = Path('/tmp/nexus-googletest-tdd-20261019/smoke-build/lib')
commands = [
    ['flock', '/tmp/nexus-platform-compiler.lock', 'gcc', '-std=c11', '-O0',
     '-g0', '-Wall', '-Wextra', '-Werror', '-Wconversion', '-Wshadow',
     *include, '-c', str(ROOT / 'components/amp_ipc/src/amp_ipc.c'),
     '-o', str(out / 'amp_ipc.o')],
    ['flock', '/tmp/nexus-platform-compiler.lock', 'g++', '-std=c++17',
     '-O0', '-g0', '-Wall', '-Wextra', '-Werror', *include,
     '-isystem', str(google / 'googlemock/include'),
     '-isystem', str(google / 'googletest/include'),
     '-c', str(ROOT / 'tests/google/amp_ipc_test.cpp'),
     '-o', str(out / 'amp_ipc_test.o')],
    ['flock', '/tmp/nexus-platform-compiler.lock', 'g++',
     str(out / 'amp_ipc_test.o'), str(out / 'amp_ipc.o'),
     str(framework / 'libgmock_main.a'), str(framework / 'libgmock.a'),
     str(framework / 'libgtest.a'), '-pthread',
     '-o', str(out / 'amp_ipc_test')],
    [str(out / 'amp_ipc_test'), '--gtest_output=xml:' + str(out / 'results.xml')],
]
report = {'phase': phase, 'executions': []}
for index, command in enumerate(commands):
    start = time.monotonic()
    result = subprocess.run(command, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, check=False)
    (out / f'{index}.log').write_bytes(result.stdout)
    entry = {'command': command, 'returncode': result.returncode,
             'elapsed_seconds': time.monotonic() - start}
    report['executions'].append(entry)
    print(json.dumps(entry), flush=True)
    if result.returncode and index != 3:
        break
files = list((ROOT / 'components/amp_ipc').rglob('*'))
files += [ROOT / 'tests/google/amp_ipc_test.cpp',
          SOURCE / 'dependencies/googletest.lock.json']
files += list(framework.glob('libgm*.a')) + [framework / 'libgtest.a']
report['sha256'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in files if p.is_file()}
(out / 'execution.json').write_text(json.dumps(report, indent=2) + '\n')
sys.exit(report['executions'][-1]['returncode'])
