/**
 * \file            handoff.c
 * \brief           F407 owner admission and exact Flash-image tail handoff
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-20
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "clock_domain_impl.h"
#include "nexus/components/stm32f407_handoff.h"
#include "stm32f407_handoff_hw.h"
#include "stm32f407_system.h"

static nx_clock_domain_t s_handoff_domain;

nx_result_t nx_stm32f407_handoff_initialize(size_t consumer_capacity) {
  return nx_clock_domain_construct(&s_handoff_domain, consumer_capacity);
}

nx_clock_domain_t *nx_stm32f407_handoff_domain(void) {
  return &s_handoff_domain;
}

nx_result_t nx_stm32f407_handoff(nx_clock_barrier_t owners,
                                 uint32_t vector_address) {
  (void)owners;
  (void)vector_address;
  return NX_ERROR_UNSUPPORTED;
}
