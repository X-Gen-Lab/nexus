#!/usr/bin/env bash
set -euxo pipefail
src=/tmp/nexus-quality-20261019
draft=/tmp/nexus-handoff-clock-20261020
cmake_tool=/tmp/nexus-quality-20261019/.venv/bin/cmake
if [ ! -x "$cmake_tool" ]; then cmake_tool=cmake; fi
export PATH=/tmp/nexus-quality-arm/bin:/tmp/nexus-quality-20261019/.venv/bin:$PATH
"$cmake_tool" -G Ninja -S "$draft/evidence/arm-source" -B "$draft/evidence/arm-$1" -DCMAKE_TOOLCHAIN_FILE="$src/cmake/toolchains/arm-gcc.cmake" -DNEXUS_ASSEMBLY_FILE="$src/tools/configure/assemblies/$1-baremetal-empty.toml" -DNEXUS_BUILD_TESTS=OFF -DNEXUS_BUILD_WORKLOAD=OFF
"$cmake_tool" --build "$draft/evidence/arm-$1" --target handoff_public --parallel 1
arm-none-eabi-objdump -d "$draft/evidence/arm-$1/bin/handoff_public.elf" > "$draft/evidence/arm-$1/disassembly.txt"
arm-none-eabi-size "$draft/evidence/arm-$1/bin/handoff_public.elf"
