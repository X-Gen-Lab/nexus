#!/usr/bin/env bash
set -euxo pipefail
src=/tmp/nexus-quality-20261019
draft=/tmp/nexus-handoff-clock-20261020
out=$draft/evidence/host-$1
mkdir -p "$out"
common=(-I"$draft/components/stm32f407_handoff/include" -I"$draft/soc/stm32f407/private" -I"$draft/tests/google" -I"$src/soc/stm32f407/private" -I"$src/arch/include" -I"$src/core/include" -I"$src/components/clock_domain/include" -I"$src/components/clock_domain/private" -isystem "$src/vendors/st/cmsis_device_f4/Include" -isystem "$src/vendors/arm/CMSIS_5/CMSIS/Core/Include" -DNX_F407_HANDOFF_MODEL -DNX_F407_HANDOFF_FLASH_BYTES=$1 -DSTM32F407xx -Wall -Wextra -Werror)
gcc -std=c11 -O0 -g -fexceptions "${common[@]}" -c "$draft/soc/stm32f407/handoff.c" -o "$out/handoff.o"
gcc -std=c11 -O0 -g -fexceptions "${common[@]}" -c "$src/components/clock_domain/src/clock_domain.c" -o "$out/clock-domain.o"
g++ -std=c++17 -O0 -g "${common[@]}" -isystem "$src/ext/googletest/googletest/include" -isystem "$src/ext/googletest/googlemock/include" "$draft/tests/google/stm32f407_handoff_test.cpp" "$out/handoff.o" "$out/clock-domain.o" "$src/build/native-debug/lib/libgmock_main.a" "$src/build/native-debug/lib/libgmock.a" "$src/build/native-debug/lib/libgtest.a" -pthread -o "$out/test"
"$out/test" --gtest_output=xml:"$out/results.xml"
