#!/usr/bin/env bash
set -euo pipefail
armcc=/tmp/nexus-quality-arm/bin/arm-none-eabi-gcc
primary=/tmp/nexus-quality-20261019
draft=/tmp/nexus-stream-frames-20261020
out=/tmp/nexus-stream-frames-harness-20261020/arm
includes=(-I"$draft/io/include" -I"$draft/components/frame_dma2d/include"
    -I"$primary/io/include" -I"$primary/core/include" -I"$primary/arch/include")
"$armcc" -std=c11 -mcpu=cortex-m7 -mthumb -mfloat-abi=soft -Os \
    -ffunction-sections -fdata-sections -Wall -Wextra -Werror -Wpedantic -Wconversion -Wshadow -Wstrict-prototypes -Wmissing-prototypes -fshort-enums \
    -DSTM32H743xx -DNEXUS_ARCH_HAS_DWT_CYCCNT=1 "${includes[@]}" \
    -isystem "$primary/vendors/st/cmsis_device_h7/Include" \
    -isystem "$primary/vendors/arm/CMSIS_5/CMSIS/Core/Include" \
    "$draft/tests/contracts/h743_frame_dma2d/consumer.c" \
    "$draft/components/frame_dma2d/src/h743_frame_dma2d.c" \
    "$draft/io/src/frame_stream.c" "$primary/io/src/stream.c" \
    "$primary/io/src/dma.c" "$primary/core/src/request.c" \
    "$primary/arch/cortex_m/nx_arch_cortex_m.c" \
    -nostartfiles -specs=nosys.specs -Wl,-e,main -Wl,-Ttext=0x08000000 \
    -Wl,-Tdata=0x24010000 -Wl,--gc-sections -Wl,-Map,"$out/consumer.map" \
    -o "$out/consumer.elf"
"$armcc" -std=c11 -mcpu=cortex-m4 -mthumb -mfloat-abi=soft -Os \
    -Wall -Wextra -Werror -Wpedantic -Wconversion -Wshadow -Wstrict-prototypes -Wmissing-prototypes -fshort-enums "${includes[@]}" -c "$draft/io/src/frame_stream.c" \
    -o "$out/frame-stream-m4.o"
/tmp/nexus-quality-arm/bin/arm-none-eabi-size "$out/consumer.elf" \
    "$out/frame-stream-m4.o"
