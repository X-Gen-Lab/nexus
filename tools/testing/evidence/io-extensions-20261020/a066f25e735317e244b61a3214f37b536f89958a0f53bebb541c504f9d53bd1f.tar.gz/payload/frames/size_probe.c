#include "/tmp/nexus-stream-frames-20261020/components/frame_dma2d/src/h743_frame_dma2d.c"
unsigned char nexus_frame_owner_bytes[sizeof(owner_t)];
unsigned char nexus_frame_owner_alignment[_Alignof(owner_t)];
unsigned char nexus_frame_storage_bytes[sizeof(nx_h743_frame_dma2d_storage_t)];
unsigned char nexus_frame_storage_alignment[_Alignof(nx_h743_frame_dma2d_storage_t)];
