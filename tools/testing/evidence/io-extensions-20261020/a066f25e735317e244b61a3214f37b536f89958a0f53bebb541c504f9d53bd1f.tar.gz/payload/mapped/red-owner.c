/**
 * \file            mapped_storage_owner.c
 * \brief           Explicit mapped-storage owner contract before implementation
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-20
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus/components/mapped_storage_owner.h"
#include <string.h>
static const nx_mapped_storage_geometry_t* geometry(const void* context) {
    return &((const nx_mapped_storage_owner_t*)context)->backend.geometry;
}
static nx_result_t acquire(void* context, nx_mapped_storage_reader_t reader,
                           size_t offset, size_t length,
                           nx_mapped_storage_loan_t* loan) {
    (void)context; (void)reader; (void)offset; (void)length; (void)loan;
    return NX_ERROR_UNSUPPORTED;
}
static nx_result_t release(void* context, const nx_mapped_storage_loan_t* loan) {
    (void)context; (void)loan; return NX_ERROR_UNSUPPORTED;
}
static nx_result_t submit(void* context, nx_mapped_storage_request_t* request,
                          nx_mapped_storage_ticket_t* ticket) {
    (void)context; (void)request; (void)ticket; return NX_ERROR_UNSUPPORTED;
}
static nx_result_t cancel(void* context, nx_mapped_storage_ticket_t ticket) {
    (void)context; (void)ticket; return NX_ERROR_UNSUPPORTED;
}
static void service(void* context) { (void)context; }
static nx_result_t stop(void* context) {
    (void)context; return NX_ERROR_UNSUPPORTED;
}
const nx_mapped_storage_ops_t nx_mapped_storage_owner_ops = {
    geometry, acquire, release, submit, cancel, service, stop};
nx_result_t nx_mapped_storage_owner_init(nx_mapped_storage_owner_t* owner,
                                         nx_mapped_storage_slot_t* slots,
                                         size_t capacity,
                                         nx_mapped_storage_backend_t backend,
                                         nx_clock_t clock) {
    if (owner == NULL || slots == NULL || capacity == 0) {
        return NX_ERROR_INVALID;
    }
    memset(owner, 0, sizeof(*owner));
    memset(slots, 0, capacity * sizeof(*slots));
    owner->backend = backend; owner->clock = clock; owner->slots = slots;
    owner->capacity = capacity; owner->accepting = true;
    return NX_SUCCESS;
}
