#!/usr/bin/env bash
set -u
phase="${1:?red or green}"
source_root=/tmp/nexus-quality-20261019
draft_root=/tmp/nexus-mapped-storage-20261020
build_root="$draft_root/evidence/$phase-build"
mkdir -p "$build_root"
exec 9>/tmp/nexus-platform-compiler.lock
flock 9
set -e
includes=(-I"$source_root/core/include" -I"$draft_root/components/mapped_storage/include")
mode_flags=(-O0)
case "$phase" in
    *release) mode_flags=(-O2) ;;
    *asan) mode_flags=(-O0 -fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie -no-pie) ;;
    *tsan) mode_flags=(-O0 -fsanitize=thread -fno-omit-frame-pointer -fno-pie -no-pie) ;;
esac
flags=(-std=c11 -Wall -Wextra -Werror -Wpedantic -Wconversion -Wshadow -Wstrict-prototypes -Wmissing-prototypes -g "${mode_flags[@]}")
for unit in mapped_storage mapped_storage_owner native_mapped_storage; do
    cc "${flags[@]}" "${includes[@]}" -c "$draft_root/components/mapped_storage/src/$unit.c" -o "$build_root/$unit.o"
done
for unit in request time; do
    cc "${flags[@]}" "${includes[@]}" -c "$source_root/core/src/$unit.c" -o "$build_root/$unit.o"
done
c++ -std=c++17 -Wall -Wextra -Werror -Wpedantic -Wconversion -Wshadow -g "${mode_flags[@]}" \
    "${includes[@]}" \
    -isystem "$source_root/ext/googletest/googletest/include" \
    -isystem "$source_root/ext/googletest/googlemock/include" \
    "$draft_root/tests/google/mapped_storage_test.cpp" "$build_root/"*.o \
    /tmp/nexus-googletest-tdd-20261019/smoke-build/lib/libgmock_main.a \
    /tmp/nexus-googletest-tdd-20261019/smoke-build/lib/libgmock.a \
    /tmp/nexus-googletest-tdd-20261019/smoke-build/lib/libgtest.a \
    -pthread -o "$build_root/mapped_storage_test"
"$build_root/mapped_storage_test" --gtest_output="xml:$draft_root/evidence/$phase.xml"
