/**
 * \file            native_mapped_storage.c
 * \brief           Native mapped-storage contract before mutation implementation
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-20
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus/components/native_mapped_storage.h"
#include <string.h>
static nx_result_t noop(void* context) { (void)context; return NX_SUCCESS; }
static nx_result_t start(void* context, nx_mapped_storage_operation_t operation,
                         size_t offset, const void* data, size_t length) {
    (void)context; (void)operation; (void)offset; (void)data; (void)length;
    return NX_ERROR_UNSUPPORTED;
}
static nx_result_t poll(void* context, size_t* completed) {
    (void)context; *completed = 0; return NX_ERROR_UNSUPPORTED;
}
nx_result_t nx_native_mapped_storage_init(
    nx_native_mapped_storage_t* model, uint8_t* bytes, size_t size,
    size_t program_unit, size_t erase_unit, size_t quantum,
    nx_mapped_storage_backend_t* backend) {
    if (model == NULL || bytes == NULL || backend == NULL) {
        return NX_ERROR_INVALID;
    }
    memset(model, 0, sizeof(*model)); model->bytes = bytes; model->size = size;
    model->quantum = quantum; model->fault_after = SIZE_MAX;
    *backend = (nx_mapped_storage_backend_t){
        model, {bytes, size, program_unit, erase_unit, NX_MAPPED_STORAGE_CPU_READ},
        noop, noop, start, poll, noop, noop};
    return NX_SUCCESS;
}
