"""Every required SDK source must survive the real snapshot selection."""
import sys
import unittest
sys.path.insert(0, '/tmp/nexus-quality-20261019/cmake/package')
import package_source_sdk as source_sdk

class RequiredSelectionTests(unittest.TestCase):
    def test_required_sources_survive_snapshot_selection(self):
        omitted = sorted(name for name in source_sdk.REQUIRED_FILES
                         if name.startswith("cmake/package/verification/io_evolution/")
                         and not source_sdk.selected(name))
        self.assertEqual(omitted, [],
                         'Required SDK sources cannot be excluded by selection')

if __name__ == '__main__':
    unittest.main()
