import hashlib,json,os,re,shutil,stat,subprocess,time,uuid
from pathlib import Path
ROOT=Path('/tmp/nexus-quality-20261019')
OUT=Path('/tmp/nexus-dependency-stat-refresh-20261020')
READ_ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}

def file_state(path):
    s=path.stat()
    return {'inode':s.st_ino,'device':s.st_dev,'mode':stat.S_IMODE(s.st_mode),'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

def git(path,*args,refresh=False,trace=False):
    env=os.environ.copy() if refresh else READ_ENV.copy()
    if refresh:env.pop('GIT_OPTIONAL_LOCKS',None)
    if trace:env['GIT_TRACE2_PERF']='1'
    before=time.perf_counter()
    result=subprocess.run(['git','-C',str(path),*args],env=env,capture_output=True)
    elapsed=time.perf_counter()-before
    return result,elapsed

def checked(path,*args):
    result,_=git(path,*args)
    if result.returncode:raise RuntimeError(result.stderr.decode())
    return result.stdout

def index_tree(raw):
    top={}
    for row in raw.split(b'\0'):
        if not row:continue
        meta,name=row.split(b'\t',1);mode,oid,stage=meta.split()
        if stage!=b'0':raise RuntimeError('Unmerged index')
        node=top;parts=name.split(b'/')
        for part in parts[:-1]:node=node.setdefault(part,{})
        node[parts[-1]]=(mode,bytes.fromhex(oid.decode()))
    def encode(node):
        entries=[]
        for name,value in node.items():
            isdir=isinstance(value,dict)
            mode,oid=(b'40000',encode(value)) if isdir else value
            entries.append((name+(b'/' if isdir else b''),mode+b' '+name+b'\0'+oid))
        raw=b''.join(value for _,value in sorted(entries))
        return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).digest()
    return encode(top).hex()

def repository(path):
    stage=checked(path,'ls-files','--stage','-z')
    gd=Path(os.fsdecode(checked(path,'rev-parse','--absolute-git-dir')).strip())
    if not gd.is_relative_to(ROOT/'.git/modules') and path!=ROOT:raise RuntimeError('External dependency Git directory')
    return {'head':checked(path,'rev-parse','HEAD').decode().strip(),'head_tree':checked(path,'rev-parse','HEAD^{tree}').decode().strip(),'index_tree':index_tree(stage),'stage_sha256':hashlib.sha256(stage).hexdigest(),'index':file_state(gd/'index'),'gitdir':str(gd)}

def stat_facts(path):
    raw=checked(path,'ls-files','--debug').decode();name=None;rows=[]
    for line in raw.splitlines():
        if not line.startswith('  '):name=line
        elif line.startswith('  ctime:'):
            m=re.search(r'(\d+):(\d+)',line);cache=int(m[1])*10**9+int(m[2]);p=path/name
            if p.is_file():
                s=p.stat();rows.append((cache,s.st_ctime_ns,s.st_size,s.st_nlink))
    return {'regular_files':len(rows),'bytes':sum(v[2] for v in rows),'ctime_mismatches':sum(v[0]!=v[1] for v in rows),'mismatch_bytes':sum(v[2] for v in rows if v[0]!=v[1]),'hardlinked':sum(v[3]>1 for v in rows)}

def status(path,label,trace=False):
    r,elapsed=git(path,'status','--porcelain','--untracked-files=all',trace=trace)
    (OUT/(label+'.stdout')).write_bytes(r.stdout);(OUT/(label+'.stderr')).write_bytes(r.stderr)
    scans=[int(m.group(1)) for m in re.finditer(rb'refresh/sum_scan:(\d+)',r.stderr)]
    return {'returncode':r.returncode,'seconds':elapsed,'clean':r.returncode==0 and not r.stdout,'refresh_sum_scan':scans,'stdout':r.stdout.decode(errors='replace')}

def lock_observers(lock):
    sig=lock.stat();holders=[];writers=[];unreadable=[];zombies=0
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            info=(proc/'status').read_text();state=next(x for x in info.splitlines() if x.startswith('State:')).split()[1]
            if state in ('Z','X'):zombies+=1;continue
            args=[os.fsdecode(x) for x in (proc/'cmdline').read_bytes().split(b'\0') if x]
            if args and (os.path.basename(args[0])=='git' or os.path.basename(args[0]).startswith('git-')):writers.append({'pid':int(proc.name),'argv':args})
            try:fds=list((proc/'fd').iterdir())
            except PermissionError:
                unreadable.append({'pid':int(proc.name),'command':args[0] if args else ''});continue
            for fd in fds:
                try:
                    s=fd.stat()
                    if (s.st_dev,s.st_ino)==(sig.st_dev,sig.st_ino):holders.append({'pid':int(proc.name),'fd':fd.name})
                except OSError:pass
        except (OSError,StopIteration):pass
    return {'holders':holders,'git_processes':writers,'unreadable_live_fd_directories':unreadable,'zombies_no_live_fds':zombies}

root_before=repository(ROOT)
report={'root_before':root_before,'dependencies':[],'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
queue=[]
def discover(parent):
    for row in checked(parent,'ls-files','--stage','-z').split(b'\0'):
        if not row.startswith(b'160000 '):continue
        meta,name=row.split(b'\t',1);mode,pin,stage=meta.split();dep=parent/os.fsdecode(name)
        if not (dep/'.git').exists():continue
        if dep.is_symlink() or not dep.resolve().is_relative_to(ROOT):raise RuntimeError('Invalid initialized dependency path')
        queue.append((dep,pin.decode()));discover(dep)
discover(ROOT)
for dep,pin in queue:
    name=str(dep.relative_to(ROOT));label=name.replace('/','_');row={'path':name,'parent_gitlink':pin}
    report['dependencies'].append(row)
    row['before']=repository(dep);row['stat_before']=stat_facts(dep)
    row['status_before']=status(dep,label+'-before',trace=name=='vendors/arm/CMSIS_5')
    if row['before']['head']!=pin or row['before']['index_tree']!=row['before']['head_tree'] or not row['status_before']['clean']:
        row['outcome']='skipped_dirty_or_unpinned';continue
    lock=Path(row['before']['gitdir'])/'index.lock'
    if lock.exists():
        before=file_state(lock);observers=lock_observers(lock);row['lock_before']=before;row['lock_observers']=observers
        unknown=[x for x in observers['unreadable_live_fd_directories'] if os.path.basename(x['command']) not in ('dockerd','containerd')]
        if before['bytes']!=0 or time.time_ns()-before['mtime_ns']<1800*10**9 or observers['holders'] or observers['git_processes'] or unknown:
            row['outcome']='skipped_live_or_unconfirmed_lock';continue
        if file_state(lock)!=before:row['outcome']='skipped_changed_lock';continue
        backups=OUT/'lock-backups';backups.mkdir(exist_ok=True)
        backup=backups/(label+'-'+str(before['inode'])+'-'+uuid.uuid4().hex+'.index.lock')
        if backup.exists():raise RuntimeError('Backup collision')
        os.rename(lock,backup);row['lock_backup']=str(backup);row['lock_backup_after_rename']=file_state(backup)
    result,elapsed=git(dep,'update-index','--refresh',refresh=True)
    (OUT/(label+'-refresh.stdout')).write_bytes(result.stdout);(OUT/(label+'-refresh.stderr')).write_bytes(result.stderr)
    row['refresh']={'argv':['git','-C',str(dep),'update-index','--refresh'],'returncode':result.returncode,'seconds':elapsed}
    row['after']=repository(dep);row['stat_after']=stat_facts(dep);row['status_after']=status(dep,label+'-after',trace=name=='vendors/arm/CMSIS_5')
    unchanged=all(row['before'][key]==row['after'][key] for key in ('head','head_tree','index_tree','stage_sha256'))
    row['outcome']='refreshed' if result.returncode==0 and unchanged and row['status_after']['clean'] else 'verification_failed'
    if name=='vendors/arm/CMSIS_5':row['status_after_second']=status(dep,label+'-after-second',trace=True)
    (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
report['root_after']=repository(ROOT)
report['root_index_bytes_unchanged']=report['root_before']['index']==report['root_after']['index']
report['root_tree_and_entries_unchanged']=all(report['root_before'][key]==report['root_after'][key] for key in ('head','head_tree','index_tree','stage_sha256'))
report['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
report['success']=report['root_index_bytes_unchanged'] and report['root_tree_and_entries_unchanged'] and all(x['outcome']=='refreshed' for x in report['dependencies'])
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'success':report['success'],'dependencies':len(queue),'root_index_bytes_unchanged':report['root_index_bytes_unchanged'],'root_index_tree':root_before['index_tree'],'modules':[{'path':x['path'],'outcome':x['outcome'],'ctime_mismatches_before':x['stat_before']['ctime_mismatches'],'ctime_mismatches_after':x.get('stat_after',{}).get('ctime_mismatches'),'status_before_seconds':x['status_before']['seconds'],'status_after_seconds':x.get('status_after',{}).get('seconds')} for x in report['dependencies']]},indent=2))
if not report['success']:raise SystemExit(1)
