/**
 * \file            main.c
 * \brief           Public-only installed H743 Flash RAM link consumer
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-20
 * \copyright       Copyright (c) 2026 Nexus Team
 * \details         This image is linked, never executed by SDK verification.
 *                  Volatile references retain all public Flash methods and the
 *                  concrete ops table without issuing program or erase calls.
 */
#include "nexus/io/flash.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"

_Static_assert(__STDC_VERSION__ == 201112L, "Strict public C11 consumer");
_Static_assert(NX_FLASH_ID_COUNT == 1, "Exactly one selected Flash controller");

static const nx_flash_geometry_t* (*volatile s_geometry)(
    const nx_flash_port_t*) = nx_flash_port_geometry;
static nx_result_t (*volatile s_read)(const nx_flash_port_t*, uint32_t, void*,
                                      size_t) = nx_flash_port_read;
static nx_result_t (*volatile s_program)(const nx_flash_port_t*, uint32_t,
                                         const void*, size_t,
                                         nx_time_us_t) = nx_flash_port_program;
static nx_result_t (*volatile s_erase)(const nx_flash_port_t*, uint32_t, size_t,
                                       nx_time_us_t) = nx_flash_port_erase;

/** \brief Retain real public lifecycle, geometry and all four Flash methods. */
int main(void) {
    const nx_flash_port_t* port = nx_factory_flash(NX_FLASH_ID_STORAGE);
    if (port == NULL || nx_factory_flash(NX_FLASH_ID_COUNT) != NULL)
        return 1;
    const volatile nx_flash_port_t* face = port;
    const volatile nx_flash_ops_t* methods = face->ops;
    if (methods == NULL)
        return 2;
    (void)face->context;
    (void)methods->geometry;
    (void)methods->read;
    (void)methods->program;
    (void)methods->erase;
    (void)s_geometry;
    (void)s_read;
    (void)s_program;
    (void)s_erase;
    const nx_platform_start_result_t started = nx_platform_start();
    if (started.primary != NX_SUCCESS || started.cleanup != NX_SUCCESS ||
        started.remaining_effects != 0U)
        return 3;
    const nx_flash_geometry_t* geometry = nx_flash_port_geometry(port);
    if (geometry == NULL || geometry->base_address != UINT32_C(0x08000000) ||
        geometry->size != UINT32_C(0x200000) || geometry->program_unit != 32U ||
        geometry->sector_count != 16U)
        return 4;
    const nx_result_t read_result = nx_flash_port_read(port, 0U, NULL, 0U);
    const nx_result_t stopped = nx_platform_stop();
    return read_result == NX_SUCCESS && stopped == NX_SUCCESS ? 0 : 5;
}
