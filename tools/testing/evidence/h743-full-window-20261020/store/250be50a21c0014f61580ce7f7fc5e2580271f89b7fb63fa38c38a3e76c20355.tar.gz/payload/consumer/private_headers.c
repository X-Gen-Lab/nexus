/**
 * \file            private_headers.c
 * \brief           Reject vendor and private provider include leakage
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-20
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#if __has_include("stm32h7xx.h") ||                                            \
                  __has_include("stm32h743xx.h") ||                            \
                                __has_include("core_cm7.h") ||                 \
                                              __has_include("stm32h7xx_hal.h")
#error Vendor headers leaked into the public consumer
#endif
#if __has_include("stm32h743_provider.h") ||                                   \
                  __has_include(                                               \
                      "stm32h743_clock.h") ||                                  \
                      __has_include(                                           \
                          "stm32h743_flash_ram.h") ||                          \
                          __has_include(                                       \
                              "stm32h743_flash_ram_layout.h") ||               \
                              __has_include(                                   \
                                  "stm32h743_flash_mpu.h") ||                  \
                                  __has_include("stm32h743_flash_execution.h")
#error Private provider headers leaked into the public consumer
#endif
_Static_assert(__STDC_VERSION__ == 201112L, "Strict public C11 include scope");
