# Prepared H743 relocated installed-SDK check

Status: **not executed**. This directory contains only a small public consumer,
future execution scripts and expected-source bindings. No SDK preparation,
configure, compiler, firmware execution or compiler-lock acquisition occurred
during preparation. No primary/index/vendor/ext files are changed.

The exact existing profile is `hsi64-fixed-cache-off`, with `optimization="Os"`,
baremetal and only `flash.storage -> flash0/poll-word`. The existing software
Board is `stm32h743zi_hsi_reference` (STM32H743ZIT6, 2MiB). HSI16 is not an
authored supported profile. No PCB, regulator, physical revision or HIL facts are
inferred. The image will only be linked; it is not an approved Flash/HIL image.

`consumer/CMakeLists.txt` uses real `find_package(Nexus 0.2.0 EXACT)` and
`nexus_add_firmware`, with strict public C11 diagnostics. The TOML references the
relocated SDK Board through a relative path containing a space. Only four small
consumer files are copied to a new execution directory; the repository is never
cloned or mirrored. The maintained packager alone creates the SDK payload.

The main includes public generated bindings/factory and `nexus/io/flash.h`.
Volatile face/ops reads preserve the concrete operations table and all four
methods through section GC. Four volatile public-function references also keep
geometry/read/program/erase wrappers. The source uses real Platform start/stop,
geometry and a zero-length read; it never calls program/erase. The final inspector
must find the fixed workspace, full RAM entry/transaction/gate/exception/program
leaf graph, all public wrappers, and four real provider functions in the linked
ops table. These retention references add fixture data and are not a platform
RAM-cost claim. `private_headers.c` fails if vendor/private headers leak into
the consumer. No private runtime entry, manual source list or alternate build
graph is used.

Before execution, integrate the approved **20 + 17 + 1** files. The one-file
compatibility fix is `tools/testing/test_h743_flash_ram_static.py` at
`a26fed8bbda65f98d92a439b313a3c9c3d949a752bffc222456843b475882129`.
`expected-source.json` pins those bytes plus the existing build, public-API,
Board/SoC, resolver, package and checker inputs. It is deliberately bound to the
future primary integration. A mismatch rejects before creating an execution.
Any later approved source change requires an explicitly reviewed binding update.

After root's ordinary gates release the compiler lock, run with the exact
then-current primary commit (the caller supplies the full 40-digit revision):

```sh
python3 -B /tmp/nexus-h743-installed-sdk-20261020/run.py \
  --expected-revision FULL_40_DIGIT_PRIMARY_COMMIT \
  --run-name h743-final
```

This future command holds `flock(2)` on
`/tmp/nexus-platform-compiler.lock` across SDK preparation, configure, every
compiler descendant and final verification. Builds use one job. It clears
injected include/library search variables, disables Python bytecode and Git's
optional index writes, and records command arrays/raw stdout/stderr/return codes.
Timeout/interruption cancels and joins the owned subprocess group. It never
overwrites a prior run and never deletes a prefix or prior evidence.

The exact sequence is:

1. Recheck the future primary revision, approved file hashes and read-only index
   record digest, then require at least 384MiB measured cgroup headroom and 220MiB
   free filesystem space. The recorded preparation snapshot had about 316MiB
   headroom; this is a later execution prerequisite, not an executed result.
2. Use maintained `cmake/package/package_source_sdk.py --development-fixture`
   directly on primary, creating `runs/h743-final/sdk original`. This always
   records `publishable:false`, including from a clean source checkout.
3. Rename the complete prefix to `sdk relocated`, preserving manifest bytes.
   Run its installed maintained `package_source_sdk.py --verify` against
   `share/nexus/src`. The repository has no separate `verify_prefix` function;
   this verifier checks the complete source payload and exported prefix files.
4. Configure the separate `consumer source` using the relocated toolchain and
   `Nexus_DIR`, the explicit fixture opt-in and exact expected source revision.
   Build only target `h743_ram_sdk` through the normal maintained target graph.
5. Require the automatic normal postlink RAM audit, actual four `.su` inputs,
   zero unresolved reads/writes, `all_data_operands:proved`, return-gate device
   protocol `proved`, and at most one programming-leaf invocation/eight stores.
   The inspector reads this produced report; it never manufactures it or calls
   a RAM checker as an external substitute for the normal link.
6. Parse the actual ELF and public compile rows, verify required installed
   source hashes and public include isolation, then rerun installed-prefix
   verification. Recheck primary/index identities before recording success.

Expected output is roughly 120–135MiB for the maintained full SDK payload (the
previous retained SDK measured 117,191,254 bytes), under 15MiB for the small
firmware build/logs, and roughly 30–40MiB for one existing-CAS archive. These are
planning estimates. The actual package file map and resource/ELF reports remain
authoritative. A 384MiB headroom guard leaves room for package transient data,
Python/CMake and one compiler; it is not a measured peak guarantee.

After successful execution, preserve the **whole installed prefix once** with
the existing evidence store, outside that prefix:

```sh
python3 -B /tmp/nexus-quality-20261019/tools/evidence/store.py export \
  --source '/tmp/nexus-h743-installed-sdk-20261020/runs/h743-final/sdk relocated' \
  --store /tmp/nexus-h743-installed-sdk-20261020/sdk-store \
  --report /tmp/nexus-h743-installed-sdk-20261020/runs/h743-final/evidence/sdk-package.json
python3 -B /tmp/nexus-quality-20261019/tools/evidence/store.py verify \
  --package /tmp/nexus-h743-installed-sdk-20261020/runs/h743-final/evidence/sdk-package.json \
  --report /tmp/nexus-h743-installed-sdk-20261020/runs/h743-final/evidence/sdk-archive-verified.json
```

Keep the compact prefix manifest/command receipts and exact ELF/BIN/map/audit
bytes. Reference the CAS member manifest instead of repeatedly copying source
trees. Prefix reclamation remains a separate root decision after archive
verification; neither prepared script performs deletion. This check establishes
one installed-source software consumer, not a publishable SDK, the full consumer
matrix, same-root reproducibility, complete IO-24 candidate qualification or HIL.
