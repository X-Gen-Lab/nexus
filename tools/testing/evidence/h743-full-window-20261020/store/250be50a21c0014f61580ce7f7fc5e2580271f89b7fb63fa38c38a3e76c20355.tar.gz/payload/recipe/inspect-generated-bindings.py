#!/usr/bin/env python3
"""Inspect an existing normal installed-SDK link; never run a RAM checker here."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shlex
import struct
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def identity(path):
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data)}


def inspect(run, revision, expected):
    prefix = run / "sdk relocated"
    sdk = prefix / "share/nexus/src"
    build, consumer = run / "build", run / "consumer source"
    sys.path.insert(0, str(sdk))
    from tools.measurement.elf import Elf32
    package = json.loads((sdk / ".nexus-source-sdk.json").read_text())
    require(package["publishable"] is False, "Expected a development fixture")
    require(package["source_revision"] == revision, "SDK revision changed")
    bindings = []
    for path in expected["required_sdk_paths"]:
        wanted = expected["files"][path]
        item = identity(sdk / path)
        require(item["sha256"] == wanted == package["files_sha256"][path],
                "Installed required source differs: " + path)
        bindings.append({"path": path, "sha256": wanted})
    require((build / "installed-source.txt").read_text() == str(sdk),
            "find_package did not select the relocated source")
    config = Path((build / "installed-config.txt").read_text())
    require(config.is_relative_to(build), "Generated inputs escaped the build")
    resolved = json.loads((config / "resolved.json").read_text())
    require(resolved["soc_family"] == "stm32h743" and
            resolved["clock_profile"] == "hsi64-fixed-cache-off" and
            resolved["backend"] == "baremetal", "Wrong resolved profile")
    rows = json.loads((build / "compile_commands.json").read_text())
    public_rows = []
    for row in rows:
        source = Path(row["file"]).resolve()
        # The normal maintained graph compiles its one generated bindings unit.
        # This exact resolved bundle path is allowed; arbitrary build files are not.
        require(source.is_relative_to(sdk) or source.is_relative_to(consumer) or
                source == config / "bindings.c",
                "A primary or foreign source entered the installed graph")
        if source.parent != consumer:
            continue
        argv = row.get("arguments") or shlex.split(row["command"])
        require("-std=c11" in argv and "-std=gnu11" not in argv,
                "Public source was not compiled as strict C11")
        require(all(flag in argv for flag in ("-Werror", "-Wpedantic",
                                               "-Wconversion")),
                "Public strict warnings missing")
        for arg in argv:
            require(not any(part in {"vendors", "ext", "soc", "private"}
                            for part in Path(arg.removeprefix("-I")).parts),
                    "Vendor/private include scope leaked to public source")
        public_rows.append(row)
    require({Path(row["file"]).name for row in public_rows} ==
            {"main.c", "private_headers.c"}, "Missing public C compile rows")
    binary = build / "bin"
    elf_path = binary / "h743_ram_sdk.elf"
    image = Elf32(elf_path.read_bytes())
    required = ("Reset_Handler", "SystemInit", "main", "nx_platform_start",
                "nx_platform_stop", "nx_factory_flash", "nx_flash_port_geometry",
                "nx_flash_port_read", "nx_flash_port_program", "nx_flash_port_erase",
                "nx_stm32h743_flash_ram_initialize", "nx_stm32h743_flash_ram_stop",
                "nx_stm32h743_flash_ram_enter", "nx_stm32h743_flash_ram_transaction",
                "nx_stm32h743_flash_ram_return", "nx_stm32h743_flash_ram_program_words",
                "nx_stm32h743_flash_ram_nmi", "nx_stm32h743_flash_ram_hardfault")
    for name in required:
        image.symbol(name)
    workspace, = [row for row in image.defined_symbols if row["name"] ==
                  "g_nx_stm32h743_flash_ram_workspace"]
    require(workspace["type"] == 1 and workspace["size"] == 1800 and
            workspace["value"] % 1024 == 0, "Fixed workspace ABI missing")
    ops, = [row for row in image.defined_symbols if row["name"] ==
            "nx_stm32h743_flash_ops"]
    require(ops["type"] == 1 and ops["size"] == 16, "Real Flash ops table missing")
    load, = [row for row in image.loads if row["virtual"] <= ops["value"] <
             ops["value"] + 16 <= row["virtual"] + row["files"]]
    require(load["flags"] & 2 == 0, "Flash operations table is writable")
    offset = load["offset"] + ops["value"] - load["virtual"]
    methods = []
    for name, address in zip(("geometry", "read", "program", "erase"),
                             struct.unpack_from("<4I", image.data, offset)):
        matches = [row for row in image.defined_symbols if row["type"] == 2 and
                   row["value"] & ~1 == address & ~1 and row["size"] > 0 and
                   row["file"] == "flash.c" and
                   (row["name"] == name or row["name"].startswith(name + "."))]
        require(address & 1 and matches, "Real provider method lost: " + name)
        methods.append({"method": name, "address": address,
                        "symbols": [row["name"] for row in matches]})
    report_path = binary / "h743_ram_sdk.h743-flash-ram.json"
    report = json.loads(report_path.read_text())
    resources = json.loads((binary / "h743_ram_sdk.resources.json").read_text())
    require(report["status"] == resources["status"] == "passed",
            "Normal automatic link/resource gate failed")
    require(report["elf"]["sha256"] == identity(elf_path)["sha256"],
            "Postlink report is for another ELF")
    for checker in report["checker_sources"]:
        require(Path(checker["path"]).is_relative_to(sdk),
                "Postlink used a checker outside the relocated SDK")
    for entry in report["stack_usage"]:
        require(Path(entry["source"]["path"]).is_relative_to(sdk),
                "Postlink used RAM source outside the relocated SDK")
    closure = report["static_closure"]
    memory = closure["constant_memory"]
    require(closure["status"] == "passed" and memory["all_data_operands"] == "proved"
            and not memory["unresolved_read_sites"]
            and not memory["unresolved_write_sites"], "Explicit operands unproved")
    require(closure["return_gate"]["device_protocol"] == "proved" and
            closure["program_invocations"]["maximum_invocations"] == 1 and
            closure["program_invocations"]["maximum_dynamic_word_stores"] == 8,
            "Return protocol or pulse bound unproved")
    require(report["physical_execution"] == "not_executed" and
            report["qualification"] is False, "Unexpected qualification promotion")
    require(len(report["stack_usage"]) == 4, "Missing real RAM-source SU inputs")
    for command in (report["compiler_execution"], report["objdump_execution"]):
        require(command["exit_code"] == 0 and command["outcome"] == "completed",
                "Automatic audit tool execution failed")
    return {"status": "passed", "scope": "One relocated installed public C11 H743 link",
            "source_revision": revision, "sdk_publishable": False,
            "sdk_snapshot_sha256": package["snapshot_sha256"],
            "automatic_checker_sources": report["checker_sources"],
            "sdk_manifest": identity(sdk / ".nexus-source-sdk.json"),
            "generated_binding": identity(config / "bindings.c"),
            "generated_identity": identity(config / "generator-identity.json"),
            "required_source_bindings": bindings, "public_compile_rows": public_rows,
            "provider_methods": methods, "workspace": workspace,
            "artifacts": [identity(binary / name) for name in (
                "h743_ram_sdk.elf", "h743_ram_sdk.bin", "h743_ram_sdk.map",
                "h743_ram_sdk.resources.json", "h743_ram_sdk.h743-flash-ram.json")],
            "private_stack_bound_bytes": closure["stack_required_bytes"],
            "qualification": False, "physical_execution": "not_executed"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, type=Path)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--expected", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    result = inspect(args.run.resolve(), args.revision,
                     json.loads(args.expected.read_text()))
    args.report.write_text(json.dumps(result, indent=2) + "\n")
