"""Continue the recorded failed configure with the approved tool PATH.

The original run/SDK/failed receipt stays unchanged. This is one development
link continuation, not a fresh or reproducible build and not a source repair.
"""
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import sys

root = Path('/tmp/nexus-quality-20261019')
prepared = Path('/tmp/nexus-h743-installed-sdk-20261020')
run = prepared / 'runs/h743-final'
evidence = run / 'evidence'
sys.path.insert(0, str(root))
from tools.dev import process
spec = importlib.util.spec_from_file_location('prepared_h743', prepared / 'run.py')
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)
expected = json.loads((prepared / 'expected-source.json').read_text())
revision = 'be919138b2270ee754eb06c1a379b1bff9b4cacb'
env = recipe.clean_environment(Path('/tmp/nexus-quality-arm/bin'))
env['PATH'] = str(root / '.venv/bin') + os.pathsep + env['PATH']
env['NEXUS_BUILD_JOBS'] = '1'
original = json.loads((evidence / 'commands.json').read_text())
configure = next(x['argv'] for x in original if x['label'] == 'configure')
assert original[-1]['exit_code'] == 1
before = json.loads((evidence / 'source-before.json').read_text())
sdk = run / 'sdk relocated/share/nexus/src'
cmake = root / '.venv/bin/cmake'
commands = [
    ('verify-before-retry', [sys.executable, '-B', sdk / 'cmake/package/package_source_sdk.py', '--verify', sdk]),
    ('configure-retry', configure),
    ('build', [cmake, '--build', run / 'build', '--target', 'h743_ram_sdk', '--parallel', '1']),
    ('inspect', [sys.executable, '-B', prepared / 'inspect_result.py', '--run', run, '--revision', revision, '--expected', prepared / 'expected-source.json', '--report', evidence / 'installed-proof.json']),
    ('verify-after-build', [sys.executable, '-B', sdk / 'cmake/package/package_source_sdk.py', '--verify', sdk]),
]
summary = {'status': 'failed', 'scope': 'Continuation of original one-prefix public C11 H743 development link', 'reason_for_retry': 'Original caller PATH omitted prepared .venv/bin/ninja; no production source or SDK change', 'original_failed_execution_preserved': True, 'qualification': False, 'physical_execution': 'not_executed'}
try:
    with Path('/tmp/nexus-platform-compiler.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        assert recipe.source_snapshot(expected, revision, env) == before
        summary['headroom'] = recipe.check_headroom(384)
        summary['ninja_sha256'] = recipe.digest(root / '.venv/bin/ninja')
        for name, argv in commands:
            log = evidence / ('continuation-' + name + '.txt')
            assert not log.exists()
            result = process.run(argv, cwd=run, env=env, log=log, timeout=600, stage=name)
            if result.returncode:
                raise RuntimeError(name + ' returned ' + str(result.returncode))
        assert recipe.source_snapshot(expected, revision, env) == before
        summary['status'] = 'passed'
finally:
    (evidence / 'continuation.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
