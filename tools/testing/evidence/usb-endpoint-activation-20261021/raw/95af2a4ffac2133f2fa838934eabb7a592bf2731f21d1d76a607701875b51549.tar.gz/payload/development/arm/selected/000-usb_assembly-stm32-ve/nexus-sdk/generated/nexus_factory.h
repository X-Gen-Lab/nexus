/**
 * \file            nexus_factory.h
 * \brief           Typed lookup of statically selected instances.
 * \author          Nexus Team
 */
#ifndef NEXUS_FACTORY_H
#define NEXUS_FACTORY_H
#include "nexus/io/gpio.h"
#include "nexus/io/uart.h"
#include "nexus/io/spi.h"
#include "nexus/io/i2c.h"
#include "nexus/io/flash.h"
#include "nexus/io/watchdog.h"
#include "nexus/io/exti.h"
#include "nexus/io/timer.h"
#include "nexus/io/adc.h"
#include "nexus/io/can.h"
#include "nexus/io/usb_device.h"
#include "nexus/io/ethernet.h"
#include "nexus/io/timer_capture.h"
#include "nexus/io/advanced_pwm.h"
#include "nexus/io/pwm_group.h"
#include "nexus/io/encoder.h"
#include "nexus/io/pwm_adc.h"
#include "nexus/io/can_fd.h"
#include "nexus/io/adc_group.h"
#include "nexus/io/ethernet_frames.h"
#include "nexus/io/rtc.h"
#include "nexus/io/lptim.h"
#include "nexus/io/mdio.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef uint16_t nx_gpio_id_t;
enum {
    NX_GPIO_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id);
typedef uint16_t nx_uart_id_t;
enum {
    NX_UART_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id);
typedef uint16_t nx_spi_id_t;
enum {
    NX_SPI_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id);
typedef uint16_t nx_i2c_id_t;
enum {
    NX_I2C_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id);
typedef uint16_t nx_flash_id_t;
enum {
    NX_FLASH_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id);
typedef uint16_t nx_watchdog_id_t;
enum {
    NX_WATCHDOG_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id);
typedef uint16_t nx_exti_id_t;
enum {
    NX_EXTI_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id);
typedef uint16_t nx_pwm_id_t;
enum {
    NX_PWM_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id);
typedef uint16_t nx_adc_id_t;
enum {
    NX_ADC_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id);
typedef uint16_t nx_can_id_t;
enum {
    NX_CAN_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_can_port_t* nx_factory_can(nx_can_id_t id);
typedef uint16_t nx_usb_device_id_t;
enum {
    NX_USB_DEVICE_ID_FS = 0,
    NX_USB_DEVICE_ID_COUNT = 1
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id);
typedef uint16_t nx_eth_id_t;
enum {
    NX_ETH_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id);
typedef uint16_t nx_timer_capture_id_t;
enum {
    NX_TIMER_CAPTURE_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id);
typedef uint16_t nx_advanced_pwm_id_t;
enum {
    NX_ADVANCED_PWM_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id);
typedef uint16_t nx_pwm_group_id_t;
enum {
    NX_PWM_GROUP_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id);
typedef uint16_t nx_encoder_id_t;
enum {
    NX_ENCODER_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id);
typedef uint16_t nx_pwm_adc_id_t;
enum {
    NX_PWM_ADC_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id);
typedef uint16_t nx_can_fd_id_t;
enum {
    NX_CAN_FD_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id);
typedef uint16_t nx_adc_group_id_t;
enum {
    NX_ADC_GROUP_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id);
typedef uint16_t nx_eth_frames_id_t;
enum {
    NX_ETH_FRAMES_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id);
typedef uint16_t nx_rtc_id_t;
enum {
    NX_RTC_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id);
typedef uint16_t nx_lptim_id_t;
enum {
    NX_LPTIM_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id);
typedef uint16_t nx_spi_device_id_t;
enum {
    NX_SPI_DEVICE_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id);
typedef uint16_t nx_i2c_device_id_t;
enum {
    NX_I2C_DEVICE_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id);
typedef uint16_t nx_usb_endpoint_id_t;
enum {
    NX_USB_ENDPOINT_ID_CONTROL_IN = 0,
    NX_USB_ENDPOINT_ID_CONTROL_OUT = 1,
    NX_USB_ENDPOINT_ID_BULK_IN = 2,
    NX_USB_ENDPOINT_ID_BULK_OUT = 3,
    NX_USB_ENDPOINT_ID_COUNT = 4
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id);
typedef uint16_t nx_mdio_id_t;
enum {
    NX_MDIO_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id);
/** \brief Maintained execution traits; no physical qualification. */
enum {
    NX_FACTORY_CAP_MODEL = 1U << 0,
    NX_FACTORY_CAP_POLLING = 1U << 1,
    NX_FACTORY_CAP_IRQ = 1U << 2,
    NX_FACTORY_CAP_TX_DMA = 1U << 3,
    NX_FACTORY_CAP_RX_DMA = 1U << 4,
    NX_FACTORY_CAP_BLOCK_STREAM = 1U << 5,
    NX_FACTORY_CAP_STREAM_GAPS = 1U << 6,
    NX_FACTORY_CAP_BUS_MASTER_DMA = 1U << 7
};
/**
 * \brief Readonly bounds of the selected provider/mode.
 * \note Zero units/messages means no bound described, not unlimited.
 * Zero unit_bytes means no fixed byte width; the typed face defines units.
 * For I2C, units bounds each message; unit_bytes is the payload unit.
 * For enhanced SPI, max_messages bounds segments, never I2C messages.
 * For Flash, unit_bytes constrains destination offset and length;
 * buffer_alignment describes caller input, independently of that unit.
 * Board wiring, memory domains and deadlines remain separate contracts.
 */
typedef struct {
    uint32_t features;
    uint32_t max_transfer_units;
    uint16_t unit_bytes;
    uint16_t buffer_alignment;
    uint16_t max_messages;
} nx_factory_io_capability_t;
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id);
/** \brief Pure lookup; NULL for an invalid assembly ID. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id);
#include "nexus/io/usb_profile.h"
/** \brief Pure selected USB facts, never hardware qualification. */
const nx_usb_device_profile_t* nx_factory_usb_profile(
    nx_usb_device_id_t id);
#include "nexus/io/usb_activation.h"
/** \brief Fixed controller activation identity, or NULL.
 * \note Task/ISR safe; no start, locks or hardware access.
 */
const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id);
#ifdef __cplusplus
}
#endif
#endif
