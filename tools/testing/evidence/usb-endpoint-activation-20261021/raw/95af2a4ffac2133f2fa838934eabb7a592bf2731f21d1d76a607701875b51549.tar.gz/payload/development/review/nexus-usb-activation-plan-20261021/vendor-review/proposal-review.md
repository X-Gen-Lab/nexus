# Independent review of the endpoint-activation proposal

Read-only review on 2026-10-21 of `plan.md`, `contract-tests.cpp`,
`configure-tests.py` and the then-current `contract-tests.patch`. No compiler,
configure, tests, patch application or primary/index writes were performed.
The files are an unapplied proposal, not runtime RED/GREEN evidence. A future
declared public face and inert UNSUPPORTED provider scaffold remain necessary
before actual runtime RED can be recorded. The parent will regenerate the patch
from the latest fragments; the current patch predates cosmetic fragment edits.

## Material boundaries to clarify before implementation

1. **Post-reset activation is not yet a universal family contract.** The plan
   accurately avoids claiming that GD silicon clears EPACT, but says both
   families require explicit activation. Its cold-inactive change proves this
   after cold start. Its reset design and reset test prove it only for the
   modeled ST reset behavior. If GD retains EPACT, existing reset completion can
   clear reset_pending while a selected nonzero direction is still active, and
   packet submission can pass the active check. Keep GD post-reset readiness
   explicitly external/unproved, or deliberately add/test a generic software
   active-clear operation after reset drain. Do not convert uncertainty into a
   claim that every reset on both families forces a new setter call.

2. **Epoch zero must be explicitly valid for cold activation.** The controller
   currently preserves its initial epoch 0 at cold start. The proposed tests
   activate directly at that epoch. Copying `reject_setup`'s `epoch == 0`
   rejection would break the intended cold EP0/endpoint sequence. An equality
   check against the authoritative current epoch is sufficient here. Existing
   restart epoch reuse/ABA is clearly deferred; this API is not a host-policy
   authorization token.

3. **Static EPMASK routing is a deliberate source-sequence deviation.** It is
   consistent with distinguishing active from packet enable and interrupt
   routing, and the tests intentionally preserve the existing mask. RM0090's
   full SetConfiguration recipe nevertheless explicitly masks inactive endpoint
   interrupts. State that Nexus borrows the register/ownership mechanisms while
   deliberately keeping selected routes static; do not say every step of the
   complete ST/Zephyr configuration recipe is reproduced. Static masking must
   retain the existing idle-event cleanup and full-stop source/join proof.

4. **Already-active geometry failure needs one explicit outcome.** The plan
   correctly permits a no-write successful repeat only when immutable geometry
   is valid, and must preserve DATA1/HALT. Define corrupted MPS/type/IN FIFO
   selector on that branch as an error with admission closed; do not repair it
   by replaying fresh activation/DATA0. Add a small regression for this branch
   when implementing. The planned post-write readback failures cover a distinct
   failure path.

None requires a new state pool, worker, batch transaction or public-layout
change. Items 1–3 are contract/scope precision; item 4 closes an otherwise
underspecified error branch.

## Checked designs and proposed tests

- Reference timing is now correct: endpoints can be staged before status IN;
  configured readiness and subsequent packet permission remain external. A
  status ACK by itself does not activate anything. EP0 uses its separate control
  path and is rejected by ordinary activation.
- The selected-direction table exercises bulk IN/OUT and interrupt IN for
  EP1–3. OUT remains bulk even when the paired IN selection is interrupt. Its
  OUT bits25:22 check prevents copying the GD helper's reserved-field mistake.
- USBAEP/EPACT and EPENA/EPEN are kept separate. Activation leaves EPENA clear,
  submits a real later packet and settles only after the modeled actual ACK.
- Idempotent enable preserves DATA1 and HALT; fresh disable/enable resets DATA0
  and clears HALT only after proof. This avoids turning a repeated enable into
  hidden halt recovery.
- The proposed DATA0 failure test is meaningful with the existing model: a real
  completed IN packet first establishes DATA1, disable preserves it, then
  `hold_bulk_pid` prevents DATA0 command completion. The independently accepted
  OUT request remains ACTIVE across activation IO, and full stop remains BUSY
  with storage/clock retained while disable proof is withheld.
- IN SNAK can raise target INEPNE/IEPNE bit6; acknowledging only this expected
  target event is compatible with the manuals and existing model. W1C failure,
  unexpected flags, rollback failure and raw-reset admission still need the
  additional cases already listed in plan §7. Do not report the initial patch
  as having covered them.
- Pure malformed-address/stale-epoch checks before MMIO are coherent with the
  proposed negative tests. A visible raw reset check is a separate hardware
  preflight after those pure checks; it cannot make activation atomic with a
  physical SETUP/reset arriving after the observation.
- The Python fragments establish expected emitted syntax and absence of a
  second controller allocation. They do not establish linked ABI, real getter
  identity/no-effects or capabilities-false compilation; the plan correctly
  schedules those independent runtime/ARM checks later.

The proposed API is suitable for contract-first implementation once these
boundaries are explicit. No production implementation or physical qualification
was reviewed in this proposal review.

## Resolution addendum

Read the revised `plan.md`, `sdk-contract-tests.cpp` and the separate
`declaration-inert-scaffold.patch`. All four findings above are resolved in the
proposal:

- Cold epoch 0 is explicitly valid.
- Cold start unmasks EP0 only; activation changes only its target EP_MASK bit,
  with ordered readback and target-only rollback. Physical vector/priority
  routing remains fixed. This now follows the inactive-endpoint mask sequence.
- Reset completion deliberately masks/deactivates selected nonzero endpoints
  in platform software only after accepted loans and FIFO work have drained.
  The raw USBRST SDK test intentionally leaves active set, withholds disable
  proof, checks loan/clock retention, then checks platform withdrawal and
  explicit reactivation followed by actual modeled ACK. This is a meaningful
  uniform software postcondition, without inventing GD silicon reset behavior.
- Already-active corrupt geometry returns IO/closing without replaying DATA0;
  the new SDK regression also requires no MMIO writes and retention of DATA1.

No new material hazard was found in these revisions. The separate scaffold
declares the face, adds the ordinary wrapper and exports a NULL `set` method:
it supplies UNSUPPORTED rather than fake activation behavior. It does not
implement cold/reset/mask/endpoint behavior or generator output. All tests and
scaffolding remain unapplied and unexecuted in this review; these findings do
not establish runtime RED/GREEN, linked ABI, rollback qualification or HIL.
