# Optional USB activation factory proposal

This owned patch follows the actual live-generator RED recorded in
`/tmp/nexus-usb-activation-config-red-20261021/verified-red.json`: three methods,
six intended failing part/capabilities subtests, no errors or skips. The two
inherited original methods provide unchanged-profile controls.

Only `factory.py` and `usb_profiles.py` have production after-images. No primary
checkout/index change, configure, compiler or test execution was performed by
this author. There is no runtime GREEN or platform qualification claim.

The generated header always declares `nx_factory_usb_activation()` using the
existing controller ID namespace. A selected validated USB controller receives
one static const two-pointer face using the existing controller context and
shared activation operations. The switch returns NULL for invalid IDs; with no
selected USB it has no cases, faces, state or provider references. It remains
available when optional factory capability metadata is disabled. This adds no
TOML/IR fields, mutable storage, context, pools, workers, clock/start effects or
ABI epoch change. The existing profile emitter is preserved byte for byte.

`configure.py` appends factory source after the existing bindings definitions,
so the preexisting `s_nx_port_<id>` declarations are visible. The public
`nexus/io/usb_activation.h` and private activation-ops declaration are supplied
by the separately reviewed API scaffold, and must be integrated before any
generated C compilation. No selected-provider fallback or discovery is added.

Independent static review accepted this proposal in `independent-review.json`.
After integration, root must run the new authored getter regression plus the
complete existing USB profile module, actual getter/context/MMIO-purity Google
cases for both SDK bindings and capabilities false, no-USB generated consumers,
and the unchanged complete-index ordinary gate. Do not inherit these results
from the RED attempt or this static review.
