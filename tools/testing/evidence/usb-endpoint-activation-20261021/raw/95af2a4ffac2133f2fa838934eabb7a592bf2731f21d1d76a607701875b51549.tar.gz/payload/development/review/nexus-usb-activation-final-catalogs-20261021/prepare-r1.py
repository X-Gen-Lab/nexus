"""Owned minimal final prose catalogs from actual frozen 127-page extraction."""
from pathlib import Path
import ast
import difflib
import hashlib
import importlib.util
import json
import re
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path('/tmp/nexus-quality-20261019');OWN=Path(__file__).resolve().parent
WORK=Path('/dev/shm/nexus-usb-activation-final-gettext-20261021')
EXTRACTION=WORK/'extraction.json'
sha=lambda data:hashlib.sha256(data).hexdigest()
def rec(path):
 raw=path.read_bytes();return {'path':str(path),'sha256':sha(raw),'bytes':len(raw)}
def key(block):
 value=None;active=False
 for line in block.splitlines():
  text=line.strip()
  if text.startswith('msgid '):value=ast.literal_eval(text[6:]);active=True
  elif text.startswith('msgstr '):active=False
  elif text.startswith('"') and active:value+=ast.literal_eval(text)
 return value
def blocks(text):
 parts=re.split(r'(\n[ \t]*\n)',text)
 return [(parts[i],parts[i+1]if i+1<len(parts)else '')for i in range(0,len(parts),2)]
spec=importlib.util.spec_from_file_location('actual_live_sphinx_ext',ROOT/'tools/documentation/sphinx_ext.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
read_catalog=module.read_catalog
extraction_bytes=EXTRACTION.read_bytes();extraction=json.loads(extraction_bytes)
assert extraction['all_passed'] and extraction['unchanged'] and extraction['before']==extraction['after']
assert len(extraction['commands'])==2
for command in extraction['commands']:
 assert command['exit_code']==0 and command['child_returncode']==0 and command['outcome']=='completed' and command['withdrawal_complete']
 receipt=json.loads(Path(command['attempt_receipt']).read_text());assert receipt['command']==command['command']and receipt['exit_code']==0
 for field in ['stdout','stderr']:
  raw=Path(command[field]['path']).read_bytes();assert len(raw)==command[field]['bytes']and sha(raw)==command[field]['sha256']
for relative,digest in extraction['before'].items():assert sha((ROOT/relative).read_bytes())==digest

# Every new paragraph is translated explicitly; unchanged catalog messages are never regenerated.
english_design=[
 'The public interface is `nexus/io/usb_device.h`. The current slice provides internal-PHY full-speed device PIO mechanisms for Native, STM32F407 and GD32F470, with actual SDK bindings. Its maintained scope covers EP0 control, explicitly selected EP1–EP3 bulk IN/OUT and interrupt IN, SETUP/reset/suspend/resume facts, STALL, SET_ADDRESS, cancellation and exit. One DCD request remains one packet no larger than MPS. A separate optional activation face explicitly controls nonzero endpoint active state and interrupt masks. The external Chapter 9 owner supplies SET_CONFIGURATION, configured readiness and rollback; packet mechanisms alone do not prove complete enumeration or physical reset recovery. Optional `Nexus::USBControl` composes EP0 multipacket DATA, necessary ZLP and STATUS; the separate `Nexus::USBDescriptors` validates external descriptor structure. Neither creates tasks or allocates memory. External projects supply class dispatch, descriptor bytes and lookup, VID/PID, strings, configuration and recovery policy. Optional `Nexus::USBACM` composes only the CDC ACM control subset below; it provides no data pump or complete CDC/HID class stack, nor Host, HS, DMA, ISO or remote wake support.',
 'SETUP strictly decodes eight little-endian bytes and generates monotonically increasing epochs. New SETUP/reset makes old control loans drain; changing an epoch cannot revoke a borrow. Reset and queued SETUP in one snapshot have no proven order, so previously queued SETUP is discarded. After old loans drain and FIFOs are flushed, reset must also explicitly mask and clear active state on the selected nonzero directions of both families. Only successful readback clears `reset_pending`. Failure retains the reset barrier and clock; service or full stop continues recovery. New admission still requires the endpoint to be active in hardware. SET_ADDRESS validates every field of the current standard SETUP, stages the address and writes DCFG only after actual XFRC of the corresponding status-IN. Address readback failure closes the controller.',
 'STM32F407 bus reset clears USBAEP on nonzero endpoints; the model preserves this hardware fact. Automatic EPACT clearing on GD has not been verified. After loans drain, the common production path clears nonzero active state and masks those directions on both families. This is a uniform platform postcondition, not an assertion of automatic GD hardware behavior. The GD regression must leave hardware active and prove that common code actually clears it. Completed reset still requires explicit enable with the new current epoch; reset, clear-halt and submit never activate endpoints automatically. Submitting to an inactive nonzero endpoint returns STATE, leaves the prepared request READY and creates no new request/buffer borrow or FIFO write. EP0 control retains its existing contract; DATA0 recovery, a reset event or a controller that is not closing does not prove an external configuration has been committed.',
 'Explicit nonzero endpoint activation',
 'The separate `nexus/io/usb_activation.h` provides `nx_usb_activation_port_t`: a two-pointer face containing shared read-only ops and the existing controller context, with one synchronous `nx_usb_activation_set(port, epoch, endpoint_address, active)` operation. Generated `nx_factory_usb_activation(nx_usb_device_id_t)` returns a static borrowed face for the selected controller, or NULL for an invalid or unsupported identity. Lookup neither initializes hardware nor retains the clock. Generation is independent of `factory.capabilities`, needs no ROM profile and changes no existing USB ops, profile or face layout, or factory ABI epoch 1. The mechanism adds no mutable controller/endpoint state, queue, worker, instance pool, dynamic allocation, TOML field or IR type. The two-pointer layout describes the face shape; retained read-only cost, unreferenced GC and complete-image cost require separate evidence from the corresponding ARM ELF.',
 'The operation addresses one already selected EP1–EP3 direction. Both EP0 addresses and reserved or unselected addresses are rejected; OUT still supports only existing bulk mode. The caller must be the same serialized privileged Task with incoming IRQ masks clear. The controller must be started, retain its clock and have no closing/reset barrier. The `epoch` argument must equal the latest authoritative software control/reset epoch; cold epoch 0 is valid. Invalid identities and already-known stale software epochs reject before MMIO. After software checks pass, an observed raw USBRST also returns STATE before writes. A physical SETUP/reset not yet acquired may still arrive later; the IRQ guard is not a wire-atomic transaction. External callers must discard cached epochs after stop/restart.',
 'The target direction must have no request loan, disable work, EPENA, unacknowledged defined event or unfinished SETUP cleanup. IN also requires its dedicated FIFO fully free and no flush; OUT requires the shared RX status FIFO empty. Otherwise the operation returns BUSY without implicitly cancelling requests, consuming another direction\'s RX or releasing its storage. INVALID/CONTEXT/STATE/BUSY preflight rejection performs no hardware writes and creates no new loan. Activation itself never borrows a request or payload and cannot replace an existing packet\'s cancel/drain/acquire SETTLED.',
 'Cold start activates and unmasks only the two EP0 directions. Other selected directions retain immutable geometry but remain inactive/SNAK. Enabling an inactive direction first applies its selected MPS and wire type, and the FIFO selector for IN only, establishes DATA0, clears STALL and sets active/SNAK. It leaves EPENA clear and writes neither TSIZ nor the payload FIFO. It proves stable control fields, DATA0 and NAK, then handles only new target IN NAK-effective/token-empty hints (0x50) arising after the command and proves their W1C clear. Any other new event fails the operation with partial IO/closing. Defined events already present on entry still return BUSY and are not cleared during preflight rejection. It then unmasks the target EP_MASK bit and reads back the complete expected mask. OUT never writes reserved TxFIFO fields. Active state, transfer enable and IRQ masking are independent conditions; a mask or active bit alone does not mean a packet was admitted.',
 'Before deactivation, the external owner must actually cancel/drain and acquire SETTLED for the target packet. The operation first masks the target direction and proves other mask bits unchanged, then sets SNAK, clears active and reads back the result. Each call changes only its direction, preserving other endpoints and both EP0 bits; physical vector/priority routing stays fixed. It neither flushes shared RX, resets the controller, stops the clock nor starts a transfer. Explicit Task operations wait for control/W1C readback within the existing finite poll budget, issuing each command once. The added reset-progress deactivation step makes one observation and relies on later service to continue; it does not introduce this Task wait loop into IRQ execution.',
 'Idempotent calls require the same no-loan/no-pending preflight. Enable on an already active direction first validates immutable geometry, does not replay control-register configuration and only repairs the target mask if needed. Repeated enable must not reset DATA1 to DATA0, clear a real HALT or send a packet. Disable on an already inactive direction does not reprogram geometry; it only proves the target mask is off and events are clear. Only explicit disable followed by enable establishes fresh DATA0 and clears halt after successful readback; disable preserves PID. Corrupt immutable geometry on an active direction returns IO/closing without concealing the fault by rewriting control registers.',
 'Failed readback after a control or mask write returns IO and retains the existing `closing` barrier. IO may already have partial hardware effects; it is not a no-operation rejection. Best-effort mask/inactive rollback affects only the target. If EPENA is unexpectedly observed set, writing zero cannot pretend disable has completed. Retrying activation cannot clear closing. The external owner must continue progressing other loans and perform explicit full stop. Stop may still return BUSY, retaining the clock and caller storage until existing disable/flush/IRQ-join proofs complete.',
 'The external Chapter 9/configuration owner chooses directions for the configuration or alternate setting, cancels/drains/disables old directions, stages new directions and then submits STATUS IN for that request. This matches the before-status sequence in the ST manual and reference Zephyr; it does not impose activation only after ACK. The external owner publishes configured readiness only after actual corresponding STATUS completion and while the current transaction conditions still hold, and must gate ordinary nonzero packet admission beforehand. Several setter calls are not a configuration transaction. On a later failure, superseding SETUP or failed status, the owner must undo successful staging or explicitly stop. Platform rollback cannot revoke an ACK already observed by the host. Deconfiguration also requires actual drain/deactivation before the external deadline/rejection policy decides whether to accept; the DCD does not decode configuration values.',
 'Activation adds an explicit control call to existing FIG-16 without a new lifecycle owner or execution thread. It supplies no Chapter 9/class stack, CDC notification, multiple-configuration/alternate policy, continuous transfer, DMA, ISO, interrupt OUT, HS/Host/OTG or electrical integration. Software mechanisms do not prove physical enumeration/reset timing, full IO-35 exit, a clean candidate or HIL.',
 'The full IO-35 exit remains open. Finite interrupt IN and explicit activation supply no notification policy, complete Chapter 9/class stack, external configuration transaction or physical reset-recovery qualification. They establish neither a clean software candidate, product release nor physical qualification. USB role, VBUS sensing/power/backfeed, pull-up/ESD, electrical jumpers, pin leases and shared-pin conflicts for the three PCBs still require independently reviewed Board assemblies; this batch configures none of those pins. Enumeration, host retries, reset/unplug, transfer errors, PHY three-cycle flush timing and actual ISR/WCET/HIL have not been executed; old example tests confer no qualification.'
]
zh_source_map=[
 '可选的 USB `nx_usb_activation_port_t` 是 controller face，只提供一个同步 setter 并使用既有 provider context。生成的 `nx_factory_usb_activation` 查找独立于可选 ROM profile 和 `factory.capabilities`，不访问硬件，不新增可变状态、队列、worker 或分配。既有 USB face、ops/profile 布局和 factory ABI epoch 1 保持不变。实际只读 ARM 保留成本及未引用 GC 须以链接证据分别确认，不能从两指针 face 布局直接推断。',
 'activation 控制一个已经选定的非零 endpoint 方向；EP0 单独处理。冷启动仅激活并解除 EP0 的 mask。setter 使用当前软件 epoch，冷态 epoch 0 合法，目标必须静止且无借用。enable 先证明 endpoint 几何、DATA0、NAK 与 active，再解除该方向 mask；disable 先屏蔽再清 active。两者均不启动传输。重复 enable 保留 DATA1/HALT；显式 disable/enable 仅在证明成立后建立新 DATA0。其他方向及其借用继续受原所有权约束。reset 实际排空后，公共软件在两系列上显式屏蔽并反激活非零方向；这不宣称 GD 有未经证明的 reset 副作用。reset、clear-halt 和 submit 从不激活非零 endpoint。',
 '写入后的证明失败可能已有部分效果：IO 关闭准入并保留 clock/storage，要求继续排空及显式完整 stop。外部 Chapter 9 策略在 status IN 之前 stage 选定 endpoint，在 configured readiness 提交之前阻止普通 packet 准入，并在被新 SETUP 取代或 status 失败时负责回滚或 stop。setter 不是配置事务。[USB packet 合同](/design/usb-device.md) 保留 FIG-16，以及完整 IO-35、class/configuration 和物理 HIL 的边界。'
]
english_support='Internal-PHY PIO, EP0 control IN/OUT64, EP1–3 bulk IN/OUT MPS8/16/32/64 B and interrupt IN MPS1–64 B, packet loans, SETUP epochs, reset/stop drain and an independent 48 MHz owner; a separate optional activation face explicitly manages nonzero direction active state and masks, with only EP0 active at cold start; after actual reset drain, software masks and withdraws nonzero active state, requiring explicit enable with the current epoch; the external owner supplies Chapter 9 configuration transactions and rollback; no Host/HS/DMA/ISO/class stack'

# Pure inventory inspection: fresh extraction is authoritative for messages, not a site result.
pots=sorted((WORK/'gettext').rglob('*.pot'));assert len(pots)==127
inventory=[];gap_pairs=[]
for pot in pots:
 doc=pot.relative_to(WORK/'gettext').with_suffix('').as_posix();source=ROOT/'docs'/(doc+'.md');assert source.is_file()
 _,expected,_=read_catalog(pot);original=module.source_language(source.read_text());source_digest=sha(source.read_bytes())
 for language in ('en','zh_CN'):
  catalog=ROOT/'docs/locale'/language/'LC_MESSAGES'/(doc+'.po')
  row={'doc':doc,'language':language,'source_sha256':source_digest,'POT_sha256':sha(pot.read_bytes()),'expected_messages':len(expected)}
  if catalog.exists():
   metadata,old,fuzzy=read_catalog(catalog);new=[msg for msg in expected if msg not in old];obsolete=[msg for msg in old if msg not in expected]
   row.update(catalog=rec(catalog),new_ids=new,obsolete_ids=obsolete,sourcehash_matches=metadata.get('X-Nexus-Source-SHA256')==source_digest,fuzzy=fuzzy,empty_messages=sum(not value for value in old.values()))
   if new or obsolete or not row['sourcehash_matches']or fuzzy or row['empty_messages']:gap_pairs.append((doc,language))
  else:
   row.update(catalog=None,source_original=original==language);assert original==language
  inventory.append(row)
assert set(gap_pairs)=={('design/usb-device','en'),('delivery/support','en'),('delivery/support','zh_CN'),('explanation/source-map','en'),('explanation/source-map','zh_CN')}
inventory_path=OWN/'actual-127-POT-inventory.json';inventory_path.write_text(json.dumps({'classification':'Pure current message/source inspection, not strict site execution','extraction':rec(EXTRACTION),'pages':127,'language_records':254,'POTs':[rec(p)for p in pots],'records':inventory,'gap_pairs':gap_pairs},ensure_ascii=False,indent=2)+'\n')

files=[];pairs=[];preserved=[];diffs=[]
for doc,language in gap_pairs:
 source=ROOT/'docs'/(doc+'.md');pot=WORK/'gettext'/(doc+'.pot');relative=Path('docs/locale')/language/'LC_MESSAGES'/(doc+'.po');catalog=ROOT/relative
 _,expected,_=read_catalog(pot);metadata,old,fuzzy=read_catalog(catalog);assert not fuzzy and metadata['X-Nexus-Reviewed']=='true'
 additions=[msg for msg in expected if msg not in old];obsolete=[msg for msg in old if msg not in expected]
 if doc=='design/usb-device':
  assert language=='en'and len(additions)==14 and len(obsolete)==4
  values=english_design
 elif doc=='delivery/support':
  assert len(additions)==1 and len(obsolete)==1
  values=[english_support if language=='en'else additions[0]]
 else:
  assert doc=='explanation/source-map'and len(additions)==3 and not obsolete
  values=additions if language=='en'else zh_source_map
 assert len(additions)==len(values)
 old_bytes=catalog.read_bytes();old_text=old_bytes.decode();source_digest=sha(source.read_bytes());old_source=metadata['X-Nexus-Source-SHA256']
 result=[];retained=[]
 for block,separator in blocks(old_text):
  msg=key(block)
  if msg=='':
   assert block.count('X-Nexus-Reviewed: true')==1
   header=block.replace('X-Nexus-Source-SHA256: '+old_source,'X-Nexus-Source-SHA256: '+source_digest,1).replace('X-Nexus-Reviewed: true','X-Nexus-Reviewed: false',1)
   result.append(header+separator)
  elif msg is None:result.append(block+separator)
  elif msg in expected:result.append(block+separator);retained.append((msg,block))
  else:assert msg in obsolete
 candidate=''.join(result)
 if not candidate.endswith('\n'):candidate+='\n'
 if not candidate.endswith('\n\n'):candidate+='\n'
 pot_blocks={key(b):b for b,s in blocks(pot.read_text())if key(b)}
 for msg,value in zip(additions,values):
  comments='\n'.join(line for line in pot_blocks[msg].splitlines()if line.startswith('#:'))
  if comments:candidate+=comments+'\n'
  candidate+='msgid '+json.dumps(msg,ensure_ascii=False)+'\nmsgstr '+json.dumps(value,ensure_ascii=False)+'\n\n'
  pairs.append({'doc':doc,'language':language,'msgid':msg,'msgstr':value,'basis':'canonical source identity'if value==msg else 'explicit reviewed-meaning translation preserving symbols, ownership and failure scope'})
 candidate=candidate[:-1]
 destination=OWN/'candidate'/relative;destination.parent.mkdir(parents=True,exist_ok=True);assert not destination.exists();destination.write_text(candidate)
 meta,new,ff=read_catalog(destination);assert set(new)==set(expected)and all(new.values())and not ff
 assert meta['X-Nexus-Reviewed']=='false'and meta['X-Nexus-Source-SHA256']==source_digest
 assert all(new[msg]==value for msg,value in old.items()if msg in expected)
 assert [key(b)for b,s in blocks(candidate)if key(b)in old]==[msg for msg,b in retained]
 position=0
 for index,(msg,block)in enumerate(retained):
  found=candidate.find(block,position);assert found>=0;position=found+len(block)
  preserved.append({'doc':doc,'language':language,'old_order':index,'msgid_sha256':sha(msg.encode()),'raw_block_sha256':sha(block.encode()),'raw_block_bytes':len(block.encode()),'candidate_identical':True})
 old_header=next(b for b,s in blocks(old_text)if key(b)=='');preview=candidate.replace('X-Nexus-Reviewed: false','X-Nexus-Reviewed: true',1);new_header=next(b for b,s in blocks(preview)if key(b)=='')
 assert old_header.replace(old_source,source_digest,1)==new_header
 files.append({'relative_path':str(relative),'doc':doc,'language':language,'before':rec(catalog),'candidate':rec(destination),'source':rec(source),'POT':rec(pot),'messages':len(new),'new_ids':additions,'obsolete_ids':obsolete,'retained_raw_blocks':len(retained),'header_sourcehash':{'before':old_source,'after':source_digest,'changed':old_source!=source_digest,'reason':'Canonical prose source changed'if old_source!=source_digest else 'Page source unchanged; included README adds extracted messages only. Final original header stays byte-identical.'},'all_other_header_bytes_unchanged':True,'old_raw_blocks_order_bytes_and_translations_unchanged':True})
 diffs.append(''.join(difflib.unified_diff(old_text.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/'+str(relative),tofile='b/'+str(relative))))
 assert catalog.read_bytes()==old_bytes
patch=OWN/'candidate.patch';patch.write_text(''.join(diffs))
preservation=OWN/'unchanged-raw-blocks.json';preservation.write_text(json.dumps({'scope':'All retained nonheader old raw message blocks in original order; obsolete messages alone removed. Header sourcehash/Reviewed changes recorded separately.','blocks':preserved},ensure_ascii=False,indent=2)+'\n')
packet={'kind':'USB_activation_final_prose_catalog_candidates','status':'awaiting independent review','created_ns':time.time_ns(),'extraction':rec(EXTRACTION),'actual_commands':[{'stage':c['stage'],'receipt':rec(Path(c['attempt_receipt'])),'exit_code':0}for c in extraction['commands']],'actual_127_POT_inventory':rec(inventory_path),'source_inputs_before_after':extraction['before'],'files':files,'pairs':pairs,'totals':{'catalogs':len(files),'new_pair_occurrences':len(pairs),'obsolete_pair_occurrences':sum(len(row['obsolete_ids'])for row in files),'retained_raw_blocks':len(preserved)},'patch':rec(patch),'unchanged_raw_blocks':rec(preservation),'API_recheck':{'doc':'reference/api/io','new':0,'obsolete':0,'sourcehash':'5d2e781ea5e0e1bfb26f6e08f96913088436932c25ef064adf27cce2f7ad4778','catalog_changes':0,'reason':'Header formatting changed byte identity after earlier extraction; actual finalPOT message sets and canonical API page digest match applied catalogs exactly.'},'prose_semantic_review':rec(Path('/tmp/nexus-usb-activation-prose-review-20261021/review.json')),'no_new_catalog_or_primary_index_write':True,'no_tests_compiler_configure_docs_gettext_execution':True,'qualification':'Owned source/message/translation preparation from actual two-command final extraction. Whole strict bilingual site remains a later root execution; no runtime/ARM/HIL qualification claimed.'}
packet_path=OWN/'review-input.json';packet_path.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
assert EXTRACTION.read_bytes()==extraction_bytes
for relative,digest in extraction['after'].items():assert sha((ROOT/relative).read_bytes())==digest
print(json.dumps({'review_input':rec(packet_path),'patch':rec(patch),'totals':packet['totals'],'pages':127,'language_records':254,'only_five_actual_gap_catalogs':True},ensure_ascii=False))
