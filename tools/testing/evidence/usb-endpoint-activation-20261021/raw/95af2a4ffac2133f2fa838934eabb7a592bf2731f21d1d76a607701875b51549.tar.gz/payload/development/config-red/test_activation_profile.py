import json
from pathlib import Path
import sys
import unittest
ROOT = Path('/tmp/nexus-quality-20261019')
sys.path.insert(0, str(ROOT))
from tools.configure import test_usb_profile as profiles

class ActivationProfileTests(profiles.UsbProfileGenerationTests):
    def test_activation_getter_is_independent_of_optional_rom_profiles(self):
        for family in ('stm32-zg', 'stm32-ve', 'gd32'):
            for capabilities in (False, True):
                with self.subTest(family=family, capabilities=capabilities):
                    header, source = self.generate(family, capabilities)
                    self.assertTrue('nx_factory_usb_activation(' in header,
                                    'Selected controller has no activation getter declaration')
                    self.assertTrue('nx_factory_usb_activation(' in source,
                                    'Selected controller has no activation getter implementation')
                    if not capabilities:
                        self.assertNotIn('nx_usb_device_profile_t', source)
                        self.assertNotIn('nx_usb_endpoint_profile_t', source)

if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ActivationProfileTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    Path(__file__).with_name('actual-result.json').write_text(json.dumps({
        'phase': 'expected RED against unchanged live generator',
        'executed': result.testsRun, 'failures': len(result.failures),
        'errors': len(result.errors), 'skipped': len(result.skipped),
        'primary_writes': False,
    }, indent=2) + '\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
