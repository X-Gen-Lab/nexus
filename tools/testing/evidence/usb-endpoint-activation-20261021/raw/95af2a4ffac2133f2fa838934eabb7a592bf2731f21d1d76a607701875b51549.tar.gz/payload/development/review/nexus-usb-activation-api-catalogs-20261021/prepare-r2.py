"""Minimal owned EN/ZH API catalogs from an actual completed fresh extraction."""
from pathlib import Path
import ast
import difflib
import hashlib
import importlib.util
import json
import re
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path('/tmp/nexus-quality-20261019')
OWN=Path(__file__).resolve().parent
WORK=Path('/dev/shm/nexus-usb-activation-api-gettext-20261021')
SOURCE=ROOT/'docs/reference/api/io.md'
POT=WORK/'gettext/reference/api/io.pot'
HEADER=ROOT/'io/include/nexus/io/usb_activation.h'
EXTRACTION=WORK/'extraction.json'

def digest(data):return hashlib.sha256(data).hexdigest()
def rec(path):
 raw=path.read_bytes();return {'path':str(path),'sha256':digest(raw),'bytes':len(raw)}
def key(block):
 value=None;active=False
 for line in block.splitlines():
  text=line.strip()
  if text.startswith('msgid '):value=ast.literal_eval(text[6:]);active=True
  elif text.startswith('msgstr '):active=False
  elif text.startswith('"') and active:value+=ast.literal_eval(text)
 return value
def blocks(text):
 parts=re.split(r'(\n[ \t]*\n)',text)
 return [(parts[i],parts[i+1] if i+1<len(parts) else '')for i in range(0,len(parts),2)]
spec=importlib.util.spec_from_file_location('actual_live_catalog_reader',ROOT/'tools/documentation/sphinx_ext.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
read_catalog=module.read_catalog

extraction_bytes=EXTRACTION.read_bytes();extraction=json.loads(extraction_bytes)
assert extraction['all_passed'] is True and extraction['unchanged'] is True
assert extraction['before']==extraction['after']
assert len(extraction['commands'])==2
for command in extraction['commands']:
 assert command['exit_code']==0 and command['child_returncode']==0 and command['outcome']=='completed'
 assert command['withdrawal_complete'] is True
 receipt=json.loads(Path(command['attempt_receipt']).read_text())
 assert receipt['exit_code']==0 and receipt['command']==command['command']
 for field in ['stdout','stderr']:
  data=Path(command[field]['path']).read_bytes()
  assert len(data)==command[field]['bytes'] and digest(data)==command[field]['sha256']
for relative,expected in extraction['before'].items():assert digest((ROOT/relative).read_bytes())==expected
source_digest=digest(SOURCE.read_bytes())
assert source_digest=='5d2e781ea5e0e1bfb26f6e08f96913088436932c25ef064adf27cce2f7ad4778'
_,expected,pot_fuzzy=read_catalog(POT)
# Sphinx POT template has the normal fuzzy header; only final PO must be nonfuzzy.
assert POT.read_text().count("#, fuzzy")==1 and "#, fuzzy" in blocks(POT.read_text())[0][0]
translations={
 'usb_activation.h':'usb_activation.h',
 'Optional explicit nonzero USB endpoint activation.':'可选的非零 USB endpoint 显式激活接口。',
 'Explicitly activate or deactivate one selected nonzero direction.':'显式激活或反激活一个已选定的非零 endpoint 方向。',
 'No request or buffer is borrowed. Existing loans must be explicitly cancelled and drained before target changes; failure never revokes other loans. Configuration/class policy remains external.':'不借用任何 request 或 buffer。目标变更之前，必须显式取消并排空既有借用；失败从不撤销其他借用。配置／类策略仍由外部负责。',
 '[in] Started serialized privileged Task owner, IRQ masks clear.':'[in] 已启动；由序列化特权 Task owner 调用，进入时 IRQ masks 须 clear。',
 '[in] Current software USB epoch; cold epoch zero is valid.':'[in] 当前软件 USB epoch；冷态 epoch 0 合法。',
 '[in] USB address byte; EP0 is not admitted.':'[in] USB 地址字节；不准入 EP0。',
 '[in] Requested active state, never packet submission.':'[in] 请求的 active 状态；此操作从不提交 packet。',
 'Success after proof; UNSUPPORTED when the operation is absent. INVALID/CONTEXT/STATE/BUSY reject before writes. IO may have partial effects and closes controller admission until explicit recovery.':'证明成立后成功；操作缺失时返回 UNSUPPORTED。INVALID／CONTEXT／STATE／BUSY 在写入前拒绝。IO 可能已有部分效果，并关闭 controller 准入，直到显式恢复。',
 'Optional controller operation; absence means UNSUPPORTED.':'可选的 controller 操作；操作缺失时返回 UNSUPPORTED。',
 'Immutable borrowed face, using the existing controller context.':'不可变的借用 face，使用既有 controller context。',
}
pot_blocks={key(block):block for block,separator in blocks(POT.read_text())if key(block)}
files=[];pairs=[];preserved=[];patches=[]
for language in ('en','zh_CN'):
 relative=Path('docs/locale')/language/'LC_MESSAGES/reference/api/io.po'
 original=ROOT/relative;old_bytes=original.read_bytes();old_text=old_bytes.decode()
 metadata,old,fuzzy=read_catalog(original)
 assert not fuzzy and metadata['X-Nexus-Reviewed']=='true'
 additions=[msg for msg in expected if msg not in old]
 obsolete=[msg for msg in old if msg not in expected]
 assert not obsolete and set(additions)==set(translations) and len(additions)==11
 old_source=metadata['X-Nexus-Source-SHA256']
 assert old_source=='73a3d84a77d809cc222cc4cf065cb50c88f594ccbcb2e74562cbd652ecf52898'
 header_block=next(block for block,separator in blocks(old_text)if key(block)=='')
 updated_header=header_block.replace('X-Nexus-Source-SHA256: '+old_source,'X-Nexus-Source-SHA256: '+source_digest,1).replace('X-Nexus-Reviewed: true','X-Nexus-Reviewed: false',1)
 assert updated_header!=header_block and old_text.count(header_block)==1
 candidate=old_text.replace(header_block,updated_header,1)
 if not candidate.endswith('\n'):candidate+='\n'
 if not candidate.endswith('\n\n'):candidate+='\n'
 for msg in additions:
  value=msg if language=='en' else translations[msg]
  comments='\n'.join(line for line in pot_blocks[msg].splitlines()if line.startswith('#:'))
  if comments:candidate+=comments+'\n'
  candidate+='msgid '+json.dumps(msg,ensure_ascii=False)+'\nmsgstr '+json.dumps(value,ensure_ascii=False)+'\n\n'
  pairs.append({'language':language,'msgid':msg,'msgstr':value,'semantic_basis':'Canonical English source identity' if language=='en' else 'Independently reviewable direct Chinese translation preserving code symbols and contract strength'})
 candidate=candidate[:-1]
 destination=OWN/'candidate'/relative;destination.parent.mkdir(parents=True,exist_ok=True);assert not destination.exists();destination.write_text(candidate)
 newmeta,new,newfuzzy=read_catalog(destination)
 assert set(new)==set(expected) and all(new.values()) and not newfuzzy
 assert newmeta['X-Nexus-Reviewed']=='false' and newmeta['X-Nexus-Source-SHA256']==source_digest
 assert all(new[msg]==value for msg,value in old.items())
 old_blocks=[(msg,block)for block,separator in blocks(old_text)if (msg:=key(block)) not in (None,'')]
 candidate_blocks=[(msg,block)for block,separator in blocks(candidate)if (msg:=key(block)) in old]
 assert old_blocks==candidate_blocks
 for index,(msg,block)in enumerate(old_blocks):
  preserved.append({'language':language,'old_order':index,'msgid_sha256':digest(msg.encode()),'raw_block_sha256':digest(block.encode()),'raw_block_bytes':len(block.encode()),'candidate_identical':True})
 files.append({'relative_path':str(relative),'before':rec(original),'candidate':rec(destination),'source':rec(SOURCE),'pot':rec(POT),'messages':len(new),'retained_raw_blocks':len(old_blocks),'retained_raw_blocks_order_byte_identical':True,'new_ids':additions,'removed_ids':obsolete,'header_changes':{'X-Nexus-Source-SHA256':{'before':old_source,'after':source_digest,'reason':'Existing API page adds eight lines for usb_activation.h; source identity must change honestly.'},'X-Nexus-Reviewed':{'before':'true','candidate':'false','final':'true only after independent semantic review'}},'other_header_bytes_unchanged':True})
 patches.append(''.join(difflib.unified_diff(old_text.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/'+str(relative),tofile='b/'+str(relative))))
 assert original.read_bytes()==old_bytes
patch=OWN/'candidate.patch';patch.write_text(''.join(patches))
preservation=OWN/'unchanged-raw-blocks.json';preservation.write_text(json.dumps({'scope':'Every old nonheader message block in the two API catalogs; exact bytes and order retained. Existing source reference comments intentionally preserved. Header changes recorded separately.','blocks':preserved},ensure_ascii=False,indent=2)+'\n')
packet={'kind':'USB_activation_actual_API_extraction_catalog_candidate','status':'awaiting independent semantic review','created_ns':time.time_ns(),'classification':'Owned catalog preparation only; no Sphinx/gettext/tests/primary/index writes and no HTML/site qualification','extraction':rec(EXTRACTION),'actual_commands':[{'stage':c['stage'],'receipt':rec(Path(c['attempt_receipt'])),'exit_code':c['exit_code']}for c in extraction['commands']],'public_header':rec(HEADER),'public_header_XML':rec(WORK/'api/xml/usb__activation_8h.xml'),'POT':rec(POT),'source':rec(SOURCE),'files':files,'pairs':pairs,'catalogs':len(files),'new_pair_occurrences':len(pairs),'obsolete_pair_occurrences':0,'retained_raw_blocks':len(preserved),'unchanged_raw_blocks':rec(preservation),'patch':rec(patch),'page_count_construction':'Existing API page only; no new page. Strict full site still requires later root execution.','scope_limit':'Later design/support finalPOT is separate. This API extraction has stable four source inputs, not every future platform source or implementation qualification.'}
packet_path=OWN/'review-input.json';packet_path.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
assert EXTRACTION.read_bytes()==extraction_bytes
print(json.dumps({'review_input':rec(packet_path),'patch':rec(patch),'catalogs':2,'new_occurrences':22,'obsolete_occurrences':0,'retained_raw_blocks':len(preserved)},ensure_ascii=False))
