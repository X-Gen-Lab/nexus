"""Prepared supervisor: six selected plus two empty ARM links; no physical run."""
from pathlib import Path
import hashlib
import json
import os
import re
import struct
import subprocess
import sys
sys.dont_write_bytecode = True
ROOT = Path('/tmp/nexus-quality-20261019')
OUT = Path('/dev/shm/nexus-usb-activation-arm-20261021')
BASE = '8b27691c9a8ba4980ed2475eed6f43e46b9cc341'
BASE_REPORT = Path('/dev/shm/nexus-usb-interrupt-arm-r2-20261021/selected/report.json')
LOCK = '/tmp/nexus-platform-compiler.lock'
sys.path.insert(0, str(ROOT))
from tools.dev import process, provenance
from tools.evidence.identity import observe_git_source
from tools.evidence.common import file_identity
from tools.measurement.elf import Elf32
from tools.measurement.resources import resolved_float_abi


def digest(path):
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def normalized_body(source, name):
    source = re.sub(r'/\*.*?\*/|//[^\n]*', ' ', source, flags=re.S)
    pattern = (r'struct\s+nx_usb_controller\s*\{([^{}]*)\}\s*;'
               if name == 'nx_usb_controller' else
               r'typedef\s+struct\s*\{([^{}]*)\}\s*' + re.escape(name) + r'\s*;')
    bodies = re.findall(pattern, source)
    assert len(bodies) == 1, name
    return re.sub(r'\s+', '', bodies[0])


def unchanged_layouts():
    result = []
    groups = {'io/private/usb_device_controller.h':
              ('nx_usb_endpoint_t', 'nx_usb_controller'),
              'io/include/nexus/io/usb_device.h':
              ('nx_usb_request_t', 'nx_usb_setup_t', 'nx_usb_event_t',
               'nx_usb_device_state_t', 'nx_usb_endpoint_port_t',
               'nx_usb_device_port_t', 'nx_usb_endpoint_ops_t',
               'nx_usb_device_ops_t')}
    for relative, names in groups.items():
        old = subprocess.check_output(['git', '-C', str(ROOT), 'show',
                                       BASE + ':' + relative]).decode()
        current = (ROOT / relative).read_text()
        for name in names:
            a, b = normalized_body(old, name), normalized_body(current, name)
            assert a == b, ('USB existing RAM/ABI layout changed', name)
            result.append({'type': name, 'path': relative,
                           'normalized_layout_sha256': hashlib.sha256(b.encode()).hexdigest()})
    return result


def symbols(elf):
    result = {}
    for row in elf.defined_symbols:
        if row['name'] in result:
            continue
        result[row['name']] = row
    return result


def actual_elf(row):
    path = Path(row['artifacts']['elf']['path'])
    assert digest(path) == row['artifacts']['elf']
    resolved = Path(row['artifacts']['resolved']['path'])
    assert digest(resolved) == row['artifacts']['resolved']
    abi = resolved_float_abi(json.loads(resolved.read_text()), require_cpu=True)
    return path, Elf32(path.read_bytes(), float_abi=abi)


def object_bytes(elf, symbol):
    section = elf.sections[symbol['section']]
    assert section['flags'] & 2 and not section['flags'] & 1
    assert section['kind'] != 8
    offset = section['offset'] + symbol['value'] - section['address']
    assert section['offset'] <= offset and offset + symbol['size'] <= section['offset'] + section['size']
    return elf.data[offset:offset + symbol['size']], section


def inspect_activation(row, baseline):
    path, elf = actual_elf(row)
    old_path, old = actual_elf(baseline)
    table, previous = symbols(elf), symbols(old)
    needed = ('s_nx_usb_activation_fs', 'nx_usb_fs_activation_ops',
              'nx_factory_usb_activation', 'nx_usb_activation_set', 's_nx_port_fs')
    assert all(n in table for n in needed), ('activation GC retention', str(path))
    face, _ = object_bytes(elf, table['s_nx_usb_activation_fs'])
    ops, _ = object_bytes(elf, table['nx_usb_fs_activation_ops'])
    assert len(face) == 8 and len(ops) == 4
    ops_pointer, context_pointer = struct.unpack('<II', face)
    assert ops_pointer == table['nx_usb_fs_activation_ops']['value']
    assert context_pointer == table['s_nx_port_fs']['value']
    method_pointer = struct.unpack('<I', ops)[0]
    methods = [x for x in elf.defined_symbols if x['type'] == 2
               and (x['value'] & ~1) == (method_pointer & ~1)]
    assert method_pointer & 1 and methods
    for name in ('nx_factory_usb_activation', 'nx_usb_activation_set'):
        sym = table[name]; sec = elf.sections[sym['section']]
        assert sym['type'] == 2 and sec['flags'] & 4 and not sec['flags'] & 1
    mutable = lambda e: {x['name']: x['size'] for x in e.defined_symbols
                         if x['type'] == 1 and x['size'] > 0 and
                         x['section'] < len(e.sections) and
                         e.sections[x['section']]['flags'] & 1 and
                         (x['name'] == 's_nx_port_fs' or x['name'].startswith('s_nx_usb_'))}
    old_mutable, new_mutable = mutable(old), mutable(elf)
    assert old_mutable and old_mutable == new_mutable, ('USB static RAM objects changed', old_mutable, new_mutable)
    assert not any('activation' in x['name'] and x['type'] == 1 and
                   x['section'] < len(elf.sections) and
                   elf.sections[x['section']]['flags'] & 1 for x in elf.defined_symbols)
    assert row['ram_reserved_bytes'] == baseline['ram_reserved_bytes']
    return {'status': 'passed', 'elf': file_identity(path),
            'baseline_elf': file_identity(old_path),
            'activation_face_bytes': len(face), 'activation_ops_bytes': len(ops),
            'activation_face_and_ops_readonly': True,
            'face_uses_existing_controller_context': True,
            'ops_method_symbols': [x['name'] for x in methods],
            'retained_symbols': {n: table[n] for n in needed},
            'USB_mutable_symbol_sizes_before_after': new_mutable,
            'ram_reserved_bytes_before_after': row['ram_reserved_bytes'],
            'no_new_USB_RAM_objects_or_fields': True,
            'stack_peak_status': 'not_measured'}


def main():
    assert not OUT.exists(), 'fresh output required; never delete an earlier run'
    baseline = json.loads(BASE_REPORT.read_text())
    assert baseline['status'] == 'passed' and baseline['fixture_count'] == 6
    old = {Path(x['assembly']['path']).name: x for x in baseline['fixtures']}
    for row in old.values(): actual_elf(row)
    layout = unchanged_layouts()
    OUT.mkdir()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', NEXUS_BUILD_JOBS='1', CMAKE_BUILD_PARALLEL_LEVEL='1')
    env['PATH'] = ':'.join((str(ROOT / '.venv/bin'), '/tmp/nexus-quality-arm/bin',
                            '/tmp/nexus-quality-doc-tools/bin', '/usr/local/bin', '/usr/bin', '/bin'))
    removed = [n for n in env if n.startswith(('GIT_', 'GTEST_', 'CTEST_'))]
    for name in removed: del env[name]
    record = {'status': 'running', 'source_before': observe_git_source(ROOT),
              'removed_environment_names': removed, 'commands': [],
              'existing_RAM_layouts_unchanged_from_git': {'commit': BASE, 'types': layout},
              'baseline_report': file_identity(BASE_REPORT),
              'baseline_source_identity_preserved': baseline['source_before'],
              'qualification': False, 'physical_status': 'not_executed'}
    def save(): (OUT / 'execution.json').write_text(json.dumps(record, indent=2) + '\n')
    def execute(name, command, timeout=600):
        wrapped = ['flock', LOCK, *[str(x) for x in command]]
        done = process.run(wrapped, cwd=ROOT, env=env, log=OUT / (name + '.raw'),
                           timeout=timeout, stage='usb-activation-' + name)
        record['commands'].append(str(done.receipt_path)); save()
        print(name, done.returncode, flush=True)
        if done.returncode:
            record['status'] = 'failed'; save(); raise SystemExit(done.returncode)
        return done, wrapped
    save()
    try:
        fixtures = [f'tests/contracts/usb_assembly/{n}.toml' for n in
                    ('stm32-ve', 'stm32-zg', 'gd32', 'stm32-ve-interrupt', 'stm32-zg-interrupt', 'gd32-interrupt')]
        args = [ROOT / '.venv/bin/python', '-B', ROOT / 'scripts/ci/provider_assemblies.py',
                '--root', ROOT, '--output', OUT / 'selected', '--parallel', '1']
        for f in fixtures: args += ['--fixture', f]
        execute('selected-matrix', args, 1200)
        matrix = json.loads((OUT / 'selected/report.json').read_text())
        assert matrix['status'] == 'passed' and matrix['fixture_count'] == 6
        record['selected_report'] = file_identity(OUT / 'selected/report.json')
        record['selected_activation'] = []
        for row in matrix['fixtures']:
            key = Path(row['assembly']['path']).name; prior = old[key]
            assert row['assembly'] == prior['assembly']
            assert row['configuration_sha256'] == prior['configuration_sha256']
            record['selected_activation'].append(inspect_activation(row, prior)); save()
        record['unselected'] = []
        for name in ('qiming-baremetal', 'liangshan-baremetal'):
            build = OUT / name
            configure = ['cmake', '-S', ROOT, '-B', build, '-G', 'Ninja',
                '-DCMAKE_TOOLCHAIN_FILE=' + str(ROOT / 'cmake/toolchains/arm-gcc.cmake'),
                '-DCMAKE_BUILD_TYPE=Release', '-DPython3_EXECUTABLE=' + str(ROOT / '.venv/bin/python'),
                '-DNEXUS_ASSEMBLY_FILE=' + str(ROOT / 'tools/configure/assemblies' / (name + '.toml')),
                '-DNEXUS_BUILD_TESTS=OFF', '-DNEXUS_BUILD_WORKLOAD=ON', '-DNEXUS_COMPILER_CACHE=OFF',
                '-DNEXUS_WORKLOAD=empty', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
            done, wrapped = execute(name + '-configure', configure)
            provenance.capture(ROOT, build, done.receipt_path, action='configure', expected_command=wrapped, expected_cwd=ROOT)
            done, wrapped = execute(name + '-build', ['cmake', '--build', build, '--target', 'nexus_firmware', '--parallel', '1'])
            provenance.capture(ROOT, build, done.receipt_path, action='build', expected_command=wrapped, expected_cwd=ROOT)
            elf = build / 'bin/nexus_firmware.elf'
            execute(name + '-symbols', ['arm-none-eabi-nm', '--defined-only', elf])
            text = (OUT / (name + '-symbols.raw')).read_text()
            assert not any(t in text for t in ('nx_usb_', 'nx_stm32_usb_', 'nx_gd32_usb_', 'nx_factory_usb_activation', 's_nx_usb_activation_'))
            resources = json.loads((build / 'bin/nexus_firmware.resources.json').read_text())
            assert resources['status'] == 'passed' and not resources['violations']
            record['unselected'].append({'name': name, 'elf': file_identity(elf), 'resources': resources, 'USB_activation_symbols_absent': True}); save()
        record['source_after'] = observe_git_source(ROOT)
        assert record['source_before'] == record['source_after']
        assert layout == unchanged_layouts()
        record['status'] = 'passed'; save()
    except BaseException as error:
        record['status'] = 'failed'; record['error'] = repr(error); save(); raise

if __name__ == '__main__':
    main()
