# Independent activation/mask/reset fault review

Read-only review of the latest R2 Native 13 cases and SDK 2 cases, the current
Native register model, and the revised activation plan. Factory/fixture/RAII
review was reassigned and is outside this report. No patch application,
compiler, configure, tests or primary/index writes were performed.

## Conclusion

The 13+2 cases preserve the important active-versus-enabled, DATA0/HALT,
epoch/reset, selected direction and loan-retention boundaries. The raw USBRST
SDK leaf is valuable: it deliberately does not clear active in hardware, so the
shared production reset path must withdraw selected nonzero active/mask state
after actual drain. It does not assert unverified GD silicon behavior.

The newly dynamic EP_MASK transaction has **no independent failure injection**
in those cases. The existing DATA0 failure test proves closing and preservation
of another loan, but cannot prove endpoint interrupt-mask readback or rollback.
The success case checks SNAK/INEPNE cleanup; it likewise does not prove handling
of a refused W1C. Add the small independent failures below before declaring this
new transaction's error paths covered.

## Minimal hardware leaf

Existing `hold_clear` already refuses W1C in the Native hardware model, including
IN endpoint bit6. No new W1C field is necessary.

There is no existing fault for EP_MASK at offset 0x81c. The smallest useful
addition is one **Native hardware-only** field, initially declaration-only:

```c
/** \brief EP_MASK bits whose stored value is held by the hardware leaf. */
uint32_t hold_ep_mask_bits;
```

Its eventual hardware-leaf behavior is restricted to writes of register 0x81c:
each selected bit retains its previous stored value, while other bits follow the
write. Thus the same field can model a target bit stuck at zero while enabling,
or stuck at one while disabling. It must not modify any controller snapshot,
request, endpoint active bit, return code, clock or completion logic. No new
callback, arbitrary register fault framework, provider state or MCU field is
needed.

For the first test patch, declare the field and reset it to zero in the existing
Native `UsbDevice::TearDown` **before** ordinary stop. Do not add its working
register behavior until the future actual RED has been recorded. The contract
tests access the public activation wrapper and real DCD; they must not implement
failure behavior in a test substitute for that DCD. A declaration-only leaf is
not a claim that the fault already works.

## Three small independent contract cases

### 1. Refused interrupt enable after endpoint proof

Proposed name:
`RefusedTargetInterruptEnableClosesAndRetainsOtherLoan`.

Setup before fault:

1. Explicitly activate OUT1 and submit an ordinary real OUT request. Leave IN1
   inactive and empty, with all other failure controls false.
2. Record EP_MASK, OUT1 control and EP0 controls. Set
   `hold_ep_mask_bits = 1U << 1U`, holding IN1's mask bit at zero.

Call `Activate(0x81U, true)` and require:

- IO and closing, because DATA0/control/W1C may succeed but the subsequent
  endpoint interrupt unmask cannot be proved.
- IN1 has no request, EPENA clear and no FIFO payload write; successful target
  rollback leaves its active bit and mask bit clear.
- Every unrelated EP_MASK bit, EP0 controls and OUT1 control are unchanged.
- OUT1 still owns the same request in ACTIVE and the clock consumer remains 1.
- With `hold_disable=true`, explicit full stop remains BUSY and does not release
  that loan or clock. Release both faults, service the existing drain and
  observe final settlement through the ordinary path.

This isolates the **second-register** failure. Do not combine it with
hold_bulk_pid, hold_clear, bad geometry or a pre-existing request on IN1, any of
which could prevent the mask write from being reached.

### 2. Refused interrupt withdrawal and failed mask rollback

Proposed name:
`RefusedTargetInterruptWithdrawalRetainsClosingUntilRecovery`.

1. Activate a quiescent IN1 successfully so its mask bit is one.
2. Set `hold_ep_mask_bits = 1U << 1U`, now holding that bit at one.
3. Call `Activate(0x81U, false)`: require IO/closing, retained clock, no request
   loan, unchanged unrelated mask bits and no packet enable.
4. The held mask bit must remain one. Neither the original clear nor the
   best-effort rollback can be reported as successful interrupt withdrawal.
5. Another activation call must reject STATE without repairing closing.
6. Full stop with this fault still active must return BUSY/retain clock because
   its own source-mask readback cannot be proved. After releasing the fault,
   explicit full stop succeeds and releases the clock.

Do not require false atomicity: IO permits partial active-bit withdrawal, and
the retained closing barrier is authoritative. A mask bit still set does not
mean the endpoint must remain active, and clearing active does not prove the
interrupt route was withdrawn.

This case is distinct from case 1: it proves failure to **clear**, and retained
full-stop ownership while rollback itself cannot complete. Both use one field;
no combinatorial family/MPS matrix is justified for the common register path.

### 3. Refused IN NAK-effective W1C before unmask

Proposed name:
`FailedInNakEffectiveClearClosesBeforeEndpointUnmask`.

After successful cold initialization, record EP_MASK, then set only existing
`hold_clear=true` and call `Activate(0x81U, true)`:

- Require IO/closing, retained clock, target request NULL, no EPENA or payload
  FIFO writes, and no new IN1 unmask. Unrelated mask bits remain unchanged.
- IN1 interrupt bit6 remains latched, proving the fault was actually exercised.
- Release hold_clear, then recover through ordinary full stop. Existing
  TearDown already clears hold_clear before stop if a fatal assertion returns
  early.

Cold init must finish before setting hold_clear; otherwise the test merely
faults old cold initialization. Start with no pending target flags so preflight
does not return BUSY before activation emits SNAK/INEPNE. Leave DATA0 and STALL
fault controls false. This catches an implementation that omits the W1C proof
or incorrectly returns success despite the new target event still being set.

## Remaining contract precision

- Keep the successful repeated-enable case: when active, quiescent and correctly
  configured, it must not replay DATA0, clear HALT or issue a control write.
  A target mask repair may be a mask-only write; no endpoint configuration
  replay follows from mask repair.
- Keep strict target-only EP_MASK RMW and preserve both EP0 bits. Masking is not
  token disable, packet completion, request settlement or physical IRQ join.
- Reset masks/deactivates only after all accepted loans and required FIFO work
  have drained. If a new mask proof fails, reset_pending stays set and admission
  stays closed; it must not be cleared merely because requests are SETTLED.
  Case 2 supplies the mask fault leaf needed for a later focused reset retry
  regression if the implementation changes that branch.
- The current 13+2 do not independently exercise a raw reset flag **before**
  calling activation without service, ISR/unprivileged entry, every BUSY
  FIFO/flag precondition or geometry/STALL/active readback fault. The plan lists
  these future cases; do not report initial test-code volume as full coverage.
- In particular, a visible uncollected USBRST must reject without hardware
  writes. A short direct raw-flag preflight regression needs no new model field.

The above additions are three source cases for three distinct hardware proofs,
not a new framework or a request to expand unrelated testing. Actual RED/GREEN,
ordinary complete-index gates and physical station qualification remain the
root owner's responsibility.
