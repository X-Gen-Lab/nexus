import hashlib,json,os,pathlib,subprocess,sys,xml.etree.ElementTree as ET
ROOT=pathlib.Path('/tmp/nexus-quality-20261019');OUT=pathlib.Path(__file__).parent
sys.path.insert(0,str(ROOT))
from tools.dev.process import run
names=['nexus_usb_device_test','nexus_stm32f407_usb_device_test','nexus_gd32f470_usb_device_test','nexus_stm32_usb_factory_test','nexus_gd32_usb_factory_test','nexus_stm32_usb_activation_factory_no_capabilities_test','nexus_gd32_usb_activation_factory_no_capabilities_test']
env=dict(os.environ,NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1',PATH=str(ROOT/'.venv/bin')+':/tmp/nexus-quality-arm/bin:/tmp/nexus-quality-doc-tools/bin:/usr/local/bin:/usr/bin:/bin')
rows=[]
def execute(name,args):
 result=run(['flock','/tmp/nexus-platform-compiler.lock',*args],cwd=ROOT,env=env,log=OUT/(name+'.raw'),timeout=600,stage='activation-'+name)
 rows.append({'name':name,'exit_code':result.returncode,'receipt':str(result.receipt_path)})
 (OUT/'red-execution.json').write_text(json.dumps({'phase':'declaration/inert scaffolds against old hardware behavior','commands':rows},indent=2)+'\n')
 return result.returncode
for name,args in [('red-configure',[str(ROOT/'.venv/bin/python'),'tools/dev/dev.py','configure','--preset','native-debug']),('red-build',['cmake','--build','build/native-debug','--target',*names,'--parallel','1'])]:
 code=execute(name,args)
 if code:raise SystemExit(code)
results=[]
for name in names:
 report=OUT/(name+'-red.xml');assert not report.exists()
 code=execute(name+'-red',[str(ROOT/'build/native-debug/bin'/name),'--gtest_output=xml:'+str(report)])
 xml=ET.parse(report).getroot();assert code==1 and int(xml.get('tests','0'))>0 and int(xml.get('failures','0'))>0 and int(xml.get('errors','0'))==0 and int(xml.get('disabled','0'))==0 and not list(xml.iter('skipped'))
 results.append({'program':name,'tests':int(xml.get('tests')),'failures':int(xml.get('failures'))})
(OUT/'runtime-red-result.json').write_text(json.dumps({'status':'expected runtime RED','build_exit_code':0,'programs':results,'cases':sum(x['tests'] for x in results),'failed_cases':sum(x['failures'] for x in results),'new_provider_implementation':False,'new_model_fault_handler':False},indent=2)+'\n')
print(json.dumps(results),flush=True)
