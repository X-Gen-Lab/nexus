# Independent R5 raw-reset regression review

Read-only review of the6636-byte test patch and current request/control/stop
contracts. No primary/index writes, production after-image, compiler, configure
or tests. No factory/CMake review was repeated.

**PASS for immediate runtime RED.** Native's four directions plus the two SDK
directions isolate the visible raw-reset gap without adding build targets:

- Fresh stop/init and explicit owner activation establish active nonzero
  directions. Requests have valid DATA stage, direction, length and deadline.
- For EP0, ReceiveSetup publishes length1 DATA and the correct direction, clears
  setup_pending and establishes the current control epoch before reset is
  injected. These bytes are accepted by the raw DCD's intentionally policy-free
  SETUP decoder; no invalid epoch or stage hides the admission defect.
- Only raw bit12 is injected. Active remains set, software reset_pending is
  false, no request is attached and all other fault controls are off.
- Assertions require STATE/READY/no new request pointer, no MMIO writes or
  TSIZ/control/mask/FIFO effects, unchanged software epoch and retained clock.
  The raw reset latch remains for normal collection.
- On actual RED the old submit may accept. Both request and payload are existing
  fixture members and remain alive until the real full stop joins their hardware
  references. EP0 OUT is safely handled by the existing disconnect/FIFO/source
  final-access proof; the test does not attempt its unsupported individual
  disable. The next table row starts only after successful stop.
- `if (result == NX_SUCCESS)` only verifies cleanup for an accepted RED request.
  All rejection assertions ran unconditionally first; it is not a test skip,
  SFINAE path or fake success fallback.
- READY and SETTLED are both legal preparation states, so reusing the fixture
  request after each stopped row is valid on both RED and future GREEN.

Minor optional protocol polish: the current raw EP0 fixture uses request6 and
wValue0 for both directions. Although valid at this generic DCD boundary,
IN GET_DESCRIPTOR with wValue0x0100 and OUT vendor-data with request_type0x40
would be coherent USB requests too. This does not block the intended regression
or justify adding a standard-request decoder to the platform.

The patch proves only a reset latch already visible before Task admission. It
does not claim atomicity against physical reset arriving after the raw read;
accepted requests in that later race retain the ordinary reset drain contract.
