# TEST-only mask proof hardening after frozen runtime RED

Apply this small delta after the already applied original r3 tests. Original r3
patch and declaration bytes remain unchanged and have initial-* copies. This is
an additive assertion hardening only, not new provider/model behavior.

The three fault cases now compare all unrelated EP_MASK bits, including EP0,
rather than only the target or OUT1 bit; IN activation error paths also prove no
payload FIFO write. Existing Native/SDK reset-drain cases additionally check that
the full endpoint interrupt mask remains intact while the old loan is unproved.
Software withdrawal follows genuine drain; the GD leaf still makes no silicon
auto-clear claim.

No test case or original assertion is removed. No primary/index write, compiler,
configure, tests or physical HIL was performed here. Root owns applying and GREEN.
The fixture-owner migration is a separate TEST-only patch; context hunks do not
conflict with this delta and may be applied in either order.
