"""Prepare reviewed final catalogs and inspect full message closure without a site run."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path('/tmp/nexus-quality-20261019');OWN=Path(__file__).resolve().parent
REVIEW=Path('/tmp/nexus-usb-activation-final-catalog-review-20261021/review.json')
sha=lambda data:hashlib.sha256(data).hexdigest()
def rec(path):
 raw=path.read_bytes();return {'path':str(path),'sha256':sha(raw),'bytes':len(raw)}
spec=importlib.util.spec_from_file_location('actual_live_sphinx_ext',ROOT/'tools/documentation/sphinx_ext.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
read_catalog=module.read_catalog
packet_path=OWN/'review-input.json';packet=json.loads(packet_path.read_text());review=json.loads(REVIEW.read_text())
assert review['status']=='ACCEPT'and review['review_input_sha256']==sha(packet_path.read_bytes())
assert review['candidate_patch_sha256']==packet['patch']['sha256']==sha(Path(packet['patch']['path']).read_bytes())
extraction=json.loads(Path(packet['extraction']['path']).read_text())
for relative,digest in extraction['after'].items():assert sha((ROOT/relative).read_bytes())==digest
files=[];diffs=[]
for row in packet['files']:
 original=Path(row['before']['path']);candidate=Path(row['candidate']['path']);old=original.read_bytes();raw=candidate.read_bytes()
 assert sha(old)==row['before']['sha256']and sha(raw)==row['candidate']['sha256']
 text=raw.decode();assert text.count('X-Nexus-Reviewed: false')==1
 final=text.replace('X-Nexus-Reviewed: false','X-Nexus-Reviewed: true',1)
 destination=OWN/'final'/row['relative_path'];destination.parent.mkdir(parents=True,exist_ok=True);assert not destination.exists();destination.write_text(final)
 metadata,new,fuzzy=read_catalog(destination);_,expected,_=read_catalog(Path(row['POT']['path']))
 assert metadata['X-Nexus-Reviewed']=='true'and metadata['X-Nexus-Source-SHA256']==row['source']['sha256']
 assert set(new)==set(expected)and all(new.values())and not fuzzy
 old_header=old.decode().split('\n\n',1)[0];new_header=final.split('\n\n',1)[0]
 assert old_header.replace(row['header_sourcehash']['before'],row['header_sourcehash']['after'],1)==new_header
 files.append({**row,'final':rec(destination),'candidate_to_final':'Only Reviewed:false to true after independent semantic/source/message/raw-block ACCEPT. Sourcehash changes remain accurately recorded; every other original header byte retained.'})
 diffs.append(''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),final.splitlines(keepends=True),fromfile='a/'+row['relative_path'],tofile='b/'+row['relative_path'])))
 assert original.read_bytes()==old
patch=OWN/'final-catalogs.patch';patch.write_text(''.join(diffs))
# Inspect final overlay against all127 actualPOTs, including existing RST source.
inventory=json.loads(Path(packet['actual_127_POT_inventory']['path']).read_text())
statuses=[]
for row in inventory['records']:
 doc=row['doc'];language=row['language'];source=ROOT/'docs'/(doc+'.md')
 if not source.is_file():source=ROOT/'docs'/(doc+'.rst')
 assert sha(source.read_bytes())==row['source_sha256']
 pot=Path(packet['extraction']['path']).parent/'gettext'/(doc+'.pot');assert sha(pot.read_bytes())==row['POT_sha256']
 _,expected,_=read_catalog(pot)
 relative=Path(language)/'LC_MESSAGES'/(doc+'.po')
 locale_root=OWN/'final/docs/locale'if (OWN/'final/docs/locale'/relative).exists()else ROOT/'docs/locale'
 status=module.translation_status(source.read_text(),doc,language,locale_root,tuple(expected))
 assert status['status']in ('reviewed','original')and status['actual_language']==language
 statuses.append({'doc':doc,'language':language,**status})
assert len(statuses)==254
closure={'classification':'Pure final-overlay source/message/metadata inspection; not Sphinx/gettext/HTML execution','pages':127,'language_records':254,'reviewed_catalog_records':sum(row['status']=='reviewed'for row in statuses),'source_original_records':sum(row['status']=='original'for row in statuses),'errors':[],'statuses':statuses}
closure_path=OWN/'final-overlay-127-page-closure.json';closure_path.write_text(json.dumps(closure,ensure_ascii=False,indent=2)+'\n')
record={'kind':'USB_activation_reviewed_final_prose_catalog_delivery','status':'ready_for_root_apply','created_ns':time.time_ns(),'review_input':rec(packet_path),'independent_review':rec(REVIEW),'extraction':packet['extraction'],'actual_127_POT_inventory':packet['actual_127_POT_inventory'],'files':files,'patch':rec(patch),'totals':packet['totals'],'unchanged_raw_blocks':packet['unchanged_raw_blocks'],'final_overlay_closure':rec(closure_path),'API_recheck':packet['API_recheck'],'prose_semantic_review':packet['prose_semantic_review'],'no_new_catalog_or_primary_index_writes':True,'no_tests_compiler_configure_docs_gettext_execution':True,'qualification':'Review and pure final-overlay closure from actual final extraction. Strict complete bilingual site still requires later root execution; no actual HTML/site or runtime/ARM/HIL qualification asserted.'}
p=OWN/'final-catalogs.json';p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'delivery':rec(p),'patch':rec(patch),'totals':record['totals'],'pure_overlay':{'pages':127,'records':254,'reviewed':closure['reviewed_catalog_records'],'source_original':closure['source_original_records'],'errors':0}},ensure_ascii=False))
