from pathlib import Path
import json
import os
import sys

root = Path('/tmp/nexus-quality-20261019')
out = Path(__file__).parent
sys.path.insert(0, str(root))
from tools.dev.process import run

done = run([sys.executable, '-B', 'tools/documentation/cli.py', 'build',
            '--tool-prefix', '/tmp/nexus-quality-doc-tools',
            '--output', '/dev/shm/nexus-usb-activation-final-docs-20261021',
            '--language', 'all'], cwd=root,
           env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'),
           log=out / 'strict-docs.raw', timeout=900,
           stage='usb-activation-strict-bilingual-docs')
(out / 'strict-docs-result.json').write_text(json.dumps({
    'returncode': done.returncode, 'receipt': str(done.receipt_path)},
    indent=2) + '\n')
print(done.returncode, flush=True)
raise SystemExit(done.returncode)
