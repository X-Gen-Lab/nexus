"""Prepare two owned documentation after-images for a not-yet-implemented contract."""
import difflib
import hashlib
import json
from pathlib import Path
import time

ROOT = Path('/tmp/nexus-quality-20261019')
OUT = Path(__file__).resolve().parent
PLAN = Path('/tmp/nexus-usb-activation-plan-20261021/plan.md')
REVIEW = PLAN.parent / 'vendor-review/proposal-review.md'

section = '''## 非零 endpoint 显式 activation：待实现合同草案

本节仅记录下一项待实现合同，尚未形成生产实现、测试通过、ARM 成本或实板验收。
上文的当前支持范围与 activation 缺口继续有效。以下 API 名称与行为须在实际
实现及回归后核对，不能仅凭本文更新支持矩阵或关闭 IO-35。

计划新增独立的 `nexus/io/usb_activation.h` 与 `nx_usb_activation_port_t`：face
仍是共享只读 ops 与既有 controller context 两指针，只提供一个同步
`nx_usb_activation_set(port, epoch, endpoint_address, active)` 操作。生成的
`nx_factory_usb_activation(nx_usb_device_id_t)` 只返回选定 controller 的静态
借用 face，非法或不支持的 identity 返回 NULL；查找不初始化硬件、不 retain clock。
生成应独立于 `factory.capabilities`，不要求启用 ROM profile，不改变既有 USB
ops、profile、face 布局或 factory ABI epoch 1。设计不新增可变 controller／endpoint
状态、队列、worker、实例池、动态分配、TOML 字段或 IR 类型；实际只读保留成本与
未引用 GC 仍须以新 ARM ELF 测量，不能将两指针布局直接当成整项零成本证明。

操作只面向已经选定的 EP1–EP3 某一个方向，拒绝两个 EP0 地址及保留／未选地址；
OUT 仍只允许既有 bulk。调用者须是同一个序列化特权 Task，进入时 incoming IRQ
masks clear。controller 须 started、持有 clock、没有 closing／reset 屏障，参数
`epoch` 等于最新权威软件 control/reset epoch；冷态 epoch 0 合法。无效 identity
或已知旧软件 epoch 在 MMIO 前拒绝。尚未采集的物理 SETUP/reset 仍可能随后发生，
IRQ 临界区不提供总线原子性；stop/restart 后外部须丢弃旧缓存的 epoch。

目标方向必须没有 request loan、disable 工作、EPENA、待确认的定义事件或尚未完成的
SETUP 清理。IN 还要求专用 FIFO 全空且没有 flush；OUT 要求共享 RX status FIFO 空。
否则返回 BUSY，不暗中取消请求、消费其他方向的 RX 或释放其存储。前置检查返回
INVALID／CONTEXT／STATE／BUSY 时没有硬件写入，不建立新 loan；激活本身从不借用
request 或 payload，不能代替已有 packet 的 cancel／drain／acquire SETTLED。

冷启动拟仅使两个 EP0 方向 active 并解除其 endpoint mask；其余选定方向保留
immutable 几何但 inactive／SNAK。使能一个 inactive 方向时，先按选定 MPS、wire
类型和仅 IN 的 FIFO selector 配置目标，建立 DATA0、清 STALL、置 active 与 SNAK，
保持 EPENA clear，不写 TSIZ 或 payload FIFO。核对稳定控制字段、DATA0 与 NAK，
仅确认这次 SNAK 允许产生的目标 NAK-effective W1C 事件，再解除目标 EP_MASK 位并
读回完整预期 mask。OUT 不写 reserved TxFIFO 字段。active、传输使能与 IRQ mask
是三个独立条件；mask 或 active 单独成立均不代表已经接受一个包。

反激活之前，外部必须实际 cancel／drain 并 acquire 目标 packet 的 SETTLED。
操作先屏蔽目标方向且核对其他 mask 位未变，再设置 SNAK、清 active 并核对。
每次仅修改对应方向，保留其他 endpoint 和两个 EP0 位，物理 vector／priority
route 不变；不 flush 共享 RX、不重置 controller、不停止 clock，也不开始传输。

幂等调用必须先满足同样的无 loan／无 pending 前置条件。已经处于所需状态且几何
正确时，不重放控制寄存器配置；目标 mask 如需修正只更新该位。重复 enable 不得
把 DATA1 重置为 DATA0、清除真实 HALT 或发送包。只有显式 disable 后重新 enable
才建立新 DATA0 并在读回成功后清 halt；disable 保留 PID。已 active 但 immutable
几何损坏时返回 IO／closing，不通过重写控制寄存器掩盖错误。

控制或 mask 写入后的读回失败返回 IO，并保留既有 `closing` 屏障；IO 可以已有
部分硬件效果，不能作为无操作拒绝。只对目标 best-effort mask／inactive 回滚，
若观察到 EPENA 意外为一，不能假装写零已完成 disable。失败不能通过重试 activation
清 closing；外部须继续推进其他 loan 并执行显式完整 stop。stop 仍可能 BUSY，
在既有 disable／flush／IRQ join 证明完成前保留 clock 与 caller storage。

reset 拟在旧 loan 真正排空、FIFO flush 成立之后，由公共生产路径软件屏蔽并
清除两系列选定非零方向的 active，读回成功才清 `reset_pending`。这是待实现的
统一平台后置条件；ST 已确认的硬件 USBAEP 清除事实不等于 GD 自动清 EPACT。
GD 回归须故意保留硬件 active，再证明公共代码实际清除。失败保留 reset 屏障和
clock，由 service 或完整 stop 继续恢复。reset／clear-halt／submit 均不自动激活，
新当前 epoch 下仍需显式 enable；EP0 SETUP／SET_ADDRESS 保留各自特殊合同。

外部 Chapter 9/configuration owner 根据配置或 alternate 选择方向，先 cancel／
drain／disable 旧方向，再 stage 新方向，随后提交该请求的 STATUS IN。这与 ST
手册及参考 Zephyr 的 before-status 顺序一致，不强制解释为 ACK 后才可激活。
外部仅在对应实际 STATUS 完成且仍满足当前事务条件后发布 configured readiness，
此前自行阻止普通非零 packet admission。多次 setter 不是配置事务：后续失败、
新 SETUP supersede 或 status 失败时，外部须撤销已经成功的 staging 或显式 stop；
不能用平台 rollback 撤销主机已观察到的 ACK。去配置也须先实际排空／反激活，
再按外部 deadline 与拒绝策略决定是否接受；DCD 不解码 configuration value。

本草案只补充既有 FIG-16 的显式控制调用，不新增生命周期 owner 或执行线程。
完整 Chapter 9／class stack、CDC notification、多配置／alternate 策略、连续传输、
DMA、ISO、interrupt OUT、HS／Host／OTG、电气和物理枚举／reset 时序仍在范围外。
即使未来实现及软件回归通过，也不自动构成完整 IO-35 退出、clean candidate 或 HIL。

'''

io_addition = '''
USB endpoint activation is a **pending contract draft**, not a delivered provider
capability. The planned optional `nx_usb_activation_port_t` is a controller face
with one synchronous setter and the existing provider context. Its generated
`nx_factory_usb_activation` lookup would remain independent of optional ROM
profiles and `factory.capabilities`, with no hardware access or new mutable
state, queue, worker or allocation. Existing USB faces, ops/profile layouts and
factory ABI epoch 1 would stay unchanged; retained read-only ARM cost and GC still
need actual linked evidence.

The draft permits explicit control of one selected nonzero endpoint direction;
EP0 remains separate. Cold start would activate/unmask only EP0. A setter uses
the current software epoch, including valid cold epoch 0, and requires a quiet
target with no loan. Enable proves endpoint geometry, DATA0, NAK and active state
before unmasking that direction; disable masks it before withdrawing active.
Neither starts a transfer. Repeated enable preserves DATA1/HALT; fresh
disable/enable establishes DATA0 only after proof. Other directions and their
loans remain owned. After actual reset drain, common software would explicitly
mask/deactivate nonzero directions on both families; this does not assert an
unproved GD reset side effect.

A failed post-write proof may have partial effects: IO closes admission, retains
clock/storage and requires continued drain plus explicit full stop. External
Chapter 9 policy stages selected endpoints before status IN, gates ordinary
packet admission until it commits configured readiness, and owns rollback or
stop on superseding SETUP/status failure. The setter is not a configuration
transaction. The [USB packet contract](../docs/design/usb-device.md) retains
FIG-16 and the full IO-35, class/configuration and physical HIL limits. These
sentences must be checked against real implementation and fresh evidence before
removing the draft label.
'''

sha=lambda b: hashlib.sha256(b).hexdigest()
files=[]
patches=[]
for relative in ('docs/design/usb-device.md','io/README.md'):
    before=(ROOT/relative).read_bytes()
    text=before.decode('utf-8')
    if relative.startswith('docs/'):
        anchor='## 可选 EP0 packetizer 与外层借用\n'
        assert text.count(anchor)==1
        after=text.replace(anchor,section+anchor)
    else:
        after=text+io_addition
    destination=OUT/'after'/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    assert not destination.exists()
    destination.write_text(after,encoding='utf-8')
    patch=''.join(difflib.unified_diff(text.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative))
    patches.append(patch)
    assert (ROOT/relative).read_bytes()==before
    files.append({'path':relative,'baseline_sha256':sha(before),'draft_sha256':sha(after.encode()),'draft_bytes':len(after.encode()),'primary_unchanged':True})
patch=''.join(patches)
(OUT/'draft.patch').write_text(patch,encoding='utf-8')
manifest={'status':'pending implementation contract draft; not applied or accepted as delivered support','created_ns':time.time_ns(),'files':files,'inputs':[{'path':str(p),'sha256':sha(p.read_bytes())}for p in (PLAN,REVIEW)],'patch_sha256':sha(patch.encode()),'no_primary_or_index_writes':True,'no_compiler_configure_gettext_tests':True,'no_PO_changes':True,'no_new_figure_ledger_or_status_authority':True,'integration_note':'Both owned after-images intentionally retain existing delivered gap statements and add explicitly pending prose. After real implementation, reconcile/remove the draft label and superseded gap text against actual code/tests before final integration or translation.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':files,'patch_sha256':manifest['patch_sha256']}))
