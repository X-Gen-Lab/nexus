USB activation owned documentation proposal R2

Status: PENDING IMPLEMENTATION, UNAPPLIED. These two normative after-images describe the intended contract for later application only after actual runtime GREEN and root semantic review. They are not evidence of current provider behavior, tests, software qualification or HIL. The previous draft-label-in-prose proposal is preserved as draft-r1.patch/manifest-r1.json.

Only docs/design/usb-device.md and io/README.md are proposed. No primary/index writes, compiler/configure/test/gettext/Sphinx execution, PO changes, new figure, ledger or status authority. Existing FIG-16 remains. Final code/docs agreement precedes freshPOT and minimal reviewed translations.
