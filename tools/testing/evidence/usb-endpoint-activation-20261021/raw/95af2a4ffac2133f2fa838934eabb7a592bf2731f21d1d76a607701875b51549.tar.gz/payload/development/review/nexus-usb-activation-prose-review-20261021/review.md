Independent prose/code review: ACCEPT

No material mismatch found in the exact three-file proposal. Reviewed against provider v2, public wrapper/header and generated factory: cold EP0-only activation, direction masks, preexisting BUSY versus post-command0x50 hints, epoch0, target-loan ownership, partial IO/closing/recovery, DATA0/HALT idempotence, bounded Task waits versus single-observation reset withdrawal, and deliberate GD software reset cleanup all agree. External before-status staging/rollback and full IO35/HIL limits remain explicit.

Patch/original manifest/current-source addendum and all six provider inputs plus three root-applied afterimages are bound in review.json. No tests/builds/extraction, primary/index or afterimage writes were performed. This is semantic inspection, not executed runtime/site/ARM/candidate/HIL qualification.
