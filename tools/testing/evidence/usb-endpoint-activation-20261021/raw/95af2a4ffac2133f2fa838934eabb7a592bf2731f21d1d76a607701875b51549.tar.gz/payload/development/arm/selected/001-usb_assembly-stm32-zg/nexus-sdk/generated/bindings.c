/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#ifndef NX_PLATFORM_REGISTER_WRITE
#define NX_PLATFORM_REGISTER_WRITE(reg, value) ((reg) = (uint32_t)(value))
#endif
#ifndef NX_PLATFORM_PRIORITY_WRITE
#define NX_PLATFORM_PRIORITY_WRITE(reg, value) ((reg) = (uint8_t)(value))
#endif
#include "stm32f407_provider.h"
#include "stm32f407_usb_device.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static nx_usb_controller_t s_nx_port_fs;
static const nx_usb_device_port_t s_nx_face_fs = {
    &nx_usb_fs_device_ops, &s_nx_port_fs
};
const nx_usb_device_port_t* const nx_binding_fs = &s_nx_face_fs;
static nx_stm32_usb_clock_state_t s_nx_usb_clock_fs;
static nx_usb_endpoint_t s_nx_usb_endpoints_fs[4];
static nx_usb_event_t s_nx_usb_events_fs[8];
static uint16_t s_nx_usb_pin_snapshots_fs[2];
static uint8_t s_nx_usb_pin_leases_fs;
static const nx_usb_endpoint_port_t s_nx_device_face_control_in = {
    &nx_usb_fs_endpoint_ops, &s_nx_usb_endpoints_fs[0]
};
const nx_usb_endpoint_port_t* const nx_device_control_in = &s_nx_device_face_control_in;
static const nx_usb_endpoint_port_t s_nx_device_face_control_out = {
    &nx_usb_fs_endpoint_ops, &s_nx_usb_endpoints_fs[1]
};
const nx_usb_endpoint_port_t* const nx_device_control_out = &s_nx_device_face_control_out;
static const nx_usb_endpoint_port_t s_nx_device_face_bulk_in = {
    &nx_usb_fs_endpoint_ops, &s_nx_usb_endpoints_fs[2]
};
const nx_usb_endpoint_port_t* const nx_device_bulk_in = &s_nx_device_face_bulk_in;
static const nx_usb_endpoint_port_t s_nx_device_face_bulk_out = {
    &nx_usb_fs_endpoint_ops, &s_nx_usb_endpoints_fs[3]
};
const nx_usb_endpoint_port_t* const nx_device_bulk_out = &s_nx_device_face_bulk_out;
static nx_result_t stop_fs(void) {
    nx_result_t status = nx_usb_device_stop(&s_nx_face_fs);
    if (status != NX_SUCCESS) { return status; }
    status = nx_stm32_usb_clock_stop(&s_nx_usb_clock_fs,
        nx_deadline_after(nx_time_now_us(), 5000u));
    if (status != NX_SUCCESS) { return status; }
    if ((s_nx_usb_pin_leases_fs & 2u) != 0u) {
        {
            uint32_t pin_mode = GPIOA->MODER & 50331648u;
            if (pin_mode != 0u && pin_mode != 50331648u) {
                NX_PLATFORM_REGISTER_WRITE(GPIOA->MODER, GPIOA->MODER | 50331648u);
                nx_arch_dsb();
                if ((GPIOA->MODER & 50331648u) != 50331648u) { return NX_ERROR_IO; }
            }
        }
        nx_stm32_pin_restore(GPIOA, 12u, s_nx_usb_pin_snapshots_fs[1]);
        if (nx_stm32_pin_capture(GPIOA, 12u) != s_nx_usb_pin_snapshots_fs[1]) {
            return NX_ERROR_IO;
        }
        s_nx_usb_pin_leases_fs &= (uint8_t)~2u;
    }
    if ((s_nx_usb_pin_leases_fs & 1u) != 0u) {
        {
            uint32_t pin_mode = GPIOA->MODER & 12582912u;
            if (pin_mode != 0u && pin_mode != 12582912u) {
                NX_PLATFORM_REGISTER_WRITE(GPIOA->MODER, GPIOA->MODER | 12582912u);
                nx_arch_dsb();
                if ((GPIOA->MODER & 12582912u) != 12582912u) { return NX_ERROR_IO; }
            }
        }
        nx_stm32_pin_restore(GPIOA, 11u, s_nx_usb_pin_snapshots_fs[0]);
        if (nx_stm32_pin_capture(GPIOA, 11u) != s_nx_usb_pin_snapshots_fs[0]) {
            return NX_ERROR_IO;
        }
        s_nx_usb_pin_leases_fs &= (uint8_t)~1u;
    }
    return NX_SUCCESS;
}
static nx_result_t prepare_fs(void) {
    nx_result_t status;
    s_nx_usb_endpoints_fs[0] = (nx_usb_endpoint_t){
        .number = 0u, .in = true,
        .transfer = NX_USB_PROFILE_CONTROL, .max_packet = 64u,
        .fifo_start = 96u, .fifo_words = 32u
    };
    s_nx_usb_endpoints_fs[1] = (nx_usb_endpoint_t){
        .number = 0u, .in = false,
        .transfer = NX_USB_PROFILE_CONTROL, .max_packet = 64u,
        .fifo_start = 0u, .fifo_words = 0u
    };
    s_nx_usb_endpoints_fs[2] = (nx_usb_endpoint_t){
        .number = 1u, .in = true,
        .transfer = NX_USB_PROFILE_BULK, .max_packet = 64u,
        .fifo_start = 128u, .fifo_words = 32u
    };
    s_nx_usb_endpoints_fs[3] = (nx_usb_endpoint_t){
        .number = 1u, .in = false,
        .transfer = NX_USB_PROFILE_BULK, .max_packet = 64u,
        .fifo_start = 0u, .fifo_words = 0u
    };
    s_nx_port_fs = (nx_usb_controller_t){
        .endpoints = s_nx_usb_endpoints_fs, .endpoint_count = 4u,
        .events = s_nx_usb_events_fs, .capacity = 8u,
        .snapshot = { .epoch = s_nx_port_fs.snapshot.epoch },
        .irq_policy = { NX_IRQ_KERNEL_NONE, 82u, 4u, 0u },
        .irq = { .priority = 5u },
        .poll_limit = 128u, .drain_timeout_us = 1000u,
        .rx_fifo_words = 96u, .vbus_sensing = false
    };
    status = nx_stm32_gpio_clock_enable(0u);
    if (status != NX_SUCCESS) { return status; }
    s_nx_usb_pin_snapshots_fs[0] = nx_stm32_pin_capture(GPIOA, 11u);
    s_nx_usb_pin_leases_fs |= 1u;
    status = nx_stm32_pin_configure(GPIOA, 11u, 2u, 10u, 0u, false);
    if (status != NX_SUCCESS) { return status; }
    status = nx_stm32_gpio_clock_enable(0u);
    if (status != NX_SUCCESS) { return status; }
    s_nx_usb_pin_snapshots_fs[1] = nx_stm32_pin_capture(GPIOA, 12u);
    s_nx_usb_pin_leases_fs |= 2u;
    status = nx_stm32_pin_configure(GPIOA, 12u, 2u, 10u, 0u, false);
    if (status != NX_SUCCESS) { return status; }
    status = nx_stm32_usb_clock_start(&s_nx_usb_clock_fs, true,
        nx_deadline_after(nx_time_now_us(), 5000u));
    if (status != NX_SUCCESS) { return status; }
    return nx_stm32_usb_device_initialize(&s_nx_port_fs, &s_nx_usb_clock_fs);
}
void OTG_FS_IRQHandler(void);
/** \brief Dispatch the selected internal-PHY FS PIO controller. */
void OTG_FS_IRQHandler(void) { nx_usb_controller_irq(&s_nx_port_fs); }
static bool s_nx_platform_pins_captured;
static uint32_t s_nx_platform_gpio_clocks_added;
static nx_result_t nx_platform_pins_admit(bool powered_only) {
    if (!powered_only || (RCC->AHB1ENR & RCC_AHB1ENR_GPIOAEN) != 0u) {
        uint32_t mode = GPIOA->MODER;
        if (((mode >> 22u) & 3u) != 0u && ((mode >> 22u) & 3u) != 3u) { return NX_ERROR_BUSY; }
        if (((mode >> 24u) & 3u) != 0u && ((mode >> 24u) & 3u) != 3u) { return NX_ERROR_BUSY; }
        if ((GPIOA->LCKR & 6144u) != 0u) { return NX_ERROR_BUSY; }
    }
    return NX_SUCCESS;
}
static nx_result_t nx_platform_gpio_clocks_release(void) {
    if (s_nx_platform_gpio_clocks_added != 0u) {
        NX_PLATFORM_REGISTER_WRITE(RCC->AHB1ENR, RCC->AHB1ENR & ~s_nx_platform_gpio_clocks_added);
        nx_arch_dsb();
        if ((RCC->AHB1ENR & s_nx_platform_gpio_clocks_added) != 0u) { return NX_ERROR_IO; }
        s_nx_platform_gpio_clocks_added = 0u;
    }
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pins_acquire(void) {
    if (s_nx_platform_pins_captured || s_nx_platform_gpio_clocks_added != 0u) { return NX_ERROR_STATE; }
    s_nx_platform_gpio_clocks_added = ~RCC->AHB1ENR & (RCC_AHB1ENR_GPIOAEN);
    if (s_nx_platform_gpio_clocks_added != 0u) {
        NX_PLATFORM_REGISTER_WRITE(RCC->AHB1ENR, RCC->AHB1ENR | (RCC_AHB1ENR_GPIOAEN));
        nx_arch_dsb();
    }
    if ((RCC->AHB1ENR & (RCC_AHB1ENR_GPIOAEN)) != (RCC_AHB1ENR_GPIOAEN)) { return NX_ERROR_IO; }
    nx_result_t status = nx_platform_pins_admit(false);
    if (status != NX_SUCCESS) { return status; }
    s_nx_usb_pin_snapshots_fs[0] = nx_stm32_pin_capture(GPIOA, 11u);
    s_nx_usb_pin_snapshots_fs[1] = nx_stm32_pin_capture(GPIOA, 12u);
    s_nx_platform_pins_captured = true;
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pins_release(void) {
    if (s_nx_platform_pins_captured) {
        {
            uint32_t mode = GPIOA->MODER;
            uint32_t driven = 0u;
            if (((mode >> 22u) & 3u) == 1u || ((mode >> 22u) & 3u) == 2u) { driven |= 12582912u; }
            if (((mode >> 24u) & 3u) == 1u || ((mode >> 24u) & 3u) == 2u) { driven |= 50331648u; }
            if (driven != 0u) {
                NX_PLATFORM_REGISTER_WRITE(GPIOA->MODER, mode | driven);
                nx_arch_dsb();
                if ((GPIOA->MODER & driven) != driven) { return NX_ERROR_IO; }
            }
        }
        if (nx_stm32_pin_capture(GPIOA, 12u) != s_nx_usb_pin_snapshots_fs[1]) {
            nx_stm32_pin_restore(GPIOA, 12u, s_nx_usb_pin_snapshots_fs[1]);
            nx_arch_dsb();
            if (nx_stm32_pin_capture(GPIOA, 12u) != s_nx_usb_pin_snapshots_fs[1]) { return NX_ERROR_IO; }
        }
        if (nx_stm32_pin_capture(GPIOA, 11u) != s_nx_usb_pin_snapshots_fs[0]) {
            nx_stm32_pin_restore(GPIOA, 11u, s_nx_usb_pin_snapshots_fs[0]);
            nx_arch_dsb();
            if (nx_stm32_pin_capture(GPIOA, 11u) != s_nx_usb_pin_snapshots_fs[0]) { return NX_ERROR_IO; }
        }
        s_nx_platform_pins_captured = false;
    }
    return nx_platform_gpio_clocks_release();
}
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = stop_fs();
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_result_t pins = nx_platform_pins_release();
    if (pins != NX_SUCCESS) { return pins; }
    nx_arch_dsb();
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started && nx_stm32_system_stop(&g_nx_stm32_system, 1000000u) != 0) {
        return NX_ERROR_IO;
    }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_stm32_system_preflight(&g_nx_stm32_system);
    if (result.primary != NX_SUCCESS) { return result; }
    if ((RCC->AHB2ENR & (RCC_AHB2ENR_OTGFSEN)) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if (((NVIC->ISER[(uint32_t)OTG_FS_IRQn / 32u] | NVIC->ISPR[(uint32_t)OTG_FS_IRQn / 32u] | NVIC->IABR[(uint32_t)OTG_FS_IRQn / 32u]) & (1u << ((uint32_t)OTG_FS_IRQn % 32u))) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    result.primary = nx_platform_pins_admit(true);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32_validate_identity(1048576u);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_platform_pins_acquire();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_gpio_clocks_release();
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    nx_stm32_start_result_t system = nx_stm32_system_start(&g_nx_stm32_system, 1000000u);
    if (system.primary != 0) {
        result.primary = NX_ERROR_IO;
        result.cleanup = system.cleanup == 0 ? NX_SUCCESS : NX_ERROR_IO;
        result.remaining_effects = system.remaining_effects;
        s_nx_platform_pins_captured = false;
        nx_result_t pins = nx_platform_gpio_clocks_release();
        if (pins != NX_SUCCESS) { result.cleanup = pins; result.remaining_effects = 1u; }
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = prepare_fs();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        case NX_USB_DEVICE_ID_FS:
            return nx_binding_fs;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        case NX_USB_ENDPOINT_ID_CONTROL_IN:
            return nx_device_control_in;
        case NX_USB_ENDPOINT_ID_CONTROL_OUT:
            return nx_device_control_out;
        case NX_USB_ENDPOINT_ID_BULK_IN:
            return nx_device_bulk_in;
        case NX_USB_ENDPOINT_ID_BULK_OUT:
            return nx_device_bulk_out;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_usb_device_fs = {
    NX_FACTORY_CAP_IRQ, 64U, 1U, 1U, 1U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id) {
    switch (id) {
        case NX_USB_DEVICE_ID_FS:
            return &s_nx_capability_usb_device_fs;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_usb_endpoint_control_in = {
    NX_FACTORY_CAP_IRQ, 64U, 1U, 1U, 1U
};
static const nx_factory_io_capability_t s_nx_capability_usb_endpoint_control_out = {
    NX_FACTORY_CAP_IRQ, 64U, 1U, 1U, 1U
};
static const nx_factory_io_capability_t s_nx_capability_usb_endpoint_bulk_in = {
    NX_FACTORY_CAP_IRQ, 64U, 1U, 1U, 1U
};
static const nx_factory_io_capability_t s_nx_capability_usb_endpoint_bulk_out = {
    NX_FACTORY_CAP_IRQ, 64U, 1U, 1U, 1U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id) {
    switch (id) {
        case NX_USB_ENDPOINT_ID_CONTROL_IN:
            return &s_nx_capability_usb_endpoint_control_in;
        case NX_USB_ENDPOINT_ID_CONTROL_OUT:
            return &s_nx_capability_usb_endpoint_control_out;
        case NX_USB_ENDPOINT_ID_BULK_IN:
            return &s_nx_capability_usb_endpoint_bulk_in;
        case NX_USB_ENDPOINT_ID_BULK_OUT:
            return &s_nx_capability_usb_endpoint_bulk_out;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_usb_endpoint_profile_t s_nx_usb_profiles_fs[4] = {
    { &s_nx_device_face_control_in, 64U, 0U, true, NX_USB_PROFILE_CONTROL },
    { &s_nx_device_face_control_out, 64U, 0U, false, NX_USB_PROFILE_CONTROL },
    { &s_nx_device_face_bulk_in, 64U, 1U, true, NX_USB_PROFILE_BULK },
    { &s_nx_device_face_bulk_out, 64U, 1U, false, NX_USB_PROFILE_BULK },
};
static const nx_usb_device_profile_t s_nx_usb_profile_fs = {
    &s_nx_face_fs, s_nx_usb_profiles_fs, 4U,
    NX_USB_FS_PHY_CLOCK_HZ, NX_USB_FS_FIFO_WORDS,
    96U, NX_USB_FS_ENDPOINT_NUMBERS,
    NX_USB_PROFILE_DEVICE, NX_USB_PROFILE_FULL_SPEED,
    NX_USB_PROFILE_INTERNAL_FS, NX_USB_PROFILE_PIO,
    { &nx_usb_fs_setup_decision_ops, &s_nx_port_fs }
};
/** \brief Pure typed lookup; no start, allocation or MMIO. */
const nx_usb_device_profile_t* nx_factory_usb_profile(
    nx_usb_device_id_t id) {
    switch (id) {
        case NX_USB_DEVICE_ID_FS:
            return &s_nx_usb_profile_fs;
        default:
            return NULL;
    }
}
static const nx_usb_activation_port_t s_nx_usb_activation_fs = {
    &nx_usb_fs_activation_ops, &s_nx_port_fs
};
/** \brief Pure lookup; no start or hardware access. */
const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id) {
    switch (id) {
        case NX_USB_DEVICE_ID_FS:
            return &s_nx_usb_activation_fs;
        default:
            return NULL;
    }
}
