# Raw reset admission regression

TEST-only successor to the applied activation increment. This packet contains no
production after-image and adds no model behavior, fields, targets or skip/filter.

Current submit checks reset_pending and the nonzero active bit, but not the raw
USB reset latch. The shared DCD can therefore accept a new packet before ordinary
IRQ/service collects reset: GD-style hardware may retain nonzero active, and EP0
remains active on ST too. Activation_set already rejects the raw latch.

The patch adds two source cases, executed by Native plus the two existing SDK
bindings. Native covers nonzero IN/OUT and EP0 IN/OUT; its EP0 rows first receive
and process a real SETUP, producing an otherwise-valid published control epoch.
The same SDK case covers nonzero IN/OUT in both existing family executables.
Each row publishes only the external raw reset bit while leaving active intact;
this deliberately does not infer either silicon family's active-clear behavior.

Expected admission is STATE with READY and no retained reference, MMIO write,
FIFO payload, register/epoch/mask/clock change or implicit reset acknowledgement.
The original raw latch remains for normal IRQ/service. All request and payload
objects are fixture members, and actual full stop runs after the rejection
assertions so a request accepted in RED stays alive through real withdrawal.

The narrow proposed fix is one raw-reset check under the existing guard, before
request_admit and any hardware effect, applying to every endpoint direction.
It must not call service, acknowledge reset, change epochs, revoke old loans or
add a new lifecycle path. A physical reset can still arrive after the observation;
such an accepted request remains borrowed until ordinary real drain completes.

This agent has not compiled, configured or executed the tests. Root applies the
TEST-only patch after the current whole-program GREEN, records actual RED, then
owns the smallest implementation and subsequent whole-program GREEN.
