"""Prepare owned final prose deltas against currently applied provider contracts."""
from pathlib import Path
import difflib
import hashlib
import json
import time

ROOT=Path('/tmp/nexus-quality-20261019');OUT=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
previous=json.loads((OUT/'manifest.json').read_text())
assert previous['revision'].startswith('R3')
(OUT/'draft-r3.patch').write_bytes((OUT/'draft.patch').read_bytes())
(OUT/'manifest-r3.json').write_bytes((OUT/'manifest.json').read_bytes())
provider_paths=['io/src/usb_device_controller.c','io/src/usb_device.c','io/private/usb_device_controller.h','io/include/nexus/io/usb_activation.h','tools/configure/usb_profiles.py','tools/configure/factory.py']
provider_before={p:sha((ROOT/p).read_bytes())for p in provider_paths}
relative='docs/design/usb-device.md';target=OUT/'after'/relative;text=target.read_text()
changes=[
 ('或已知旧软件 epoch 在 MMIO 前拒绝。尚未采集的物理 SETUP/reset 仍可能随后发生，\nIRQ 临界区不提供总线原子性；stop/restart 后外部须丢弃旧缓存的 epoch。',
  '或已知旧软件 epoch 在 MMIO 前拒绝。软件检查通过后，已观察到的 raw USBRST\n也使本次调用在写入前返回 STATE。尚未采集的物理 SETUP/reset 仍可能随后发生，\nIRQ 临界区不提供总线原子性；stop/restart 后外部须丢弃旧缓存的 epoch。'),
 ('保持 EPENA clear，不写 TSIZ 或 payload FIFO。核对稳定控制字段、DATA0 与 NAK，\n仅确认这次 SNAK 允许产生的目标 NAK-effective W1C 事件，再解除目标 EP_MASK 位并\n读回完整预期 mask。OUT 不写 reserved TxFIFO 字段。active、传输使能与 IRQ mask',
  '保持 EPENA clear，不写 TSIZ 或 payload FIFO。核对稳定控制字段、DATA0 与 NAK，\n仅处理命令后新出现的目标 IN NAK-effective／token-empty 提示（0x50），并证明其\nW1C 清除；其他新事件使本次操作失败，进入 partial IO／closing。调用前已有的\n定义事件仍返回 BUSY，不在前置拒绝中清除。随后解除目标 EP_MASK 位并读回完整\n预期 mask。OUT 不写 reserved TxFIFO 字段。active、传输使能与 IRQ mask'),
 ('幂等调用必须先满足同样的无 loan／无 pending 前置条件。已经处于所需状态且几何\n正确时，不重放控制寄存器配置；目标 mask 如需修正只更新该位。重复 enable 不得\n把 DATA1 重置为 DATA0、清除真实 HALT 或发送包。只有显式 disable 后重新 enable\n才建立新 DATA0 并在读回成功后清 halt；disable 保留 PID。已 active 但 immutable\n几何损坏时返回 IO／closing，不通过重写控制寄存器掩盖错误。',
  '幂等调用必须先满足同样的无 loan／无 pending 前置条件。已经 active 的 enable\n先核对 immutable 几何，不重放控制寄存器配置，只按需修正目标 mask；重复 enable\n不得把 DATA1 重置为 DATA0、清除真实 HALT 或发送包。已经 inactive 的 disable\n不重新编程几何，只证明目标 mask 关闭及事件清除。只有显式 disable 后重新 enable\n才建立新 DATA0 并在读回成功后清 halt；disable 保留 PID。已 active 但 immutable\n几何损坏时返回 IO／closing，不通过重写控制寄存器掩盖错误。'),
 ('route 不变；不 flush 共享 RX、不重置 controller、不停止 clock，也不开始传输。\n\n幂等调用',
  'route 不变；不 flush 共享 RX、不重置 controller、不停止 clock，也不开始传输。\nTask 显式操作在既有有限 poll budget 内等待控制／W1C 读回，每项命令只发一次；\nreset progress 新增的反激活步骤只单次观察，由后续 service 继续，不在 IRQ 引入\n此 Task 等待循环。\n\n幂等调用')]
for old,new in changes:
 assert text.count(old)==1,old
 text=text.replace(old,new)
target.write_text(text)
# The README contract remains the accepted R2/R3 bytes; all detail is in the design page.
support='docs/delivery/support.md';raw=(ROOT/support).read_bytes();original=raw.decode()
old='非零 endpoint 配置／reset 后重新启用待接入'
new='独立可选 activation face 显式管理非零方向 active／mask，冷态仅 EP0；reset 实际排空后软件屏蔽并撤销非零 active，再以当前 epoch 显式启用；Chapter 9 配置事务／回滚由外部负责'
assert original.count(old)==1
support_after=original.replace(old,new,1);destination=OUT/'after'/support;destination.parent.mkdir(parents=True,exist_ok=True);assert not destination.exists();destination.write_text(support_after)
files=[];patches=[]
for relative in ['docs/design/usb-device.md','io/README.md',support]:
 baseline=(ROOT/relative).read_bytes();after=(OUT/'after'/relative).read_bytes()
 if relative!=support:
  expected=next(row['baseline_sha256']for row in previous['files']if row['path']==relative)
  assert sha(baseline)==expected
 files.append({'path':relative,'baseline_sha256':sha(baseline),'proposal_sha256':sha(after),'proposal_bytes':len(after),'application_state':'pending root apply after actual GREEN and semantic review'})
 patches.append(''.join(difflib.unified_diff(baseline.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative)))
patch=''.join(patches);patch_path=OUT/'final-prose.patch';assert not patch_path.exists();patch_path.write_text(patch)
api=next(row for row in previous['files']if row['path']=='docs/reference/api/io.md')
assert sha((ROOT/api['path']).read_bytes())==api['proposal_sha256']
assert provider_before=={p:sha((ROOT/p).read_bytes())for p in provider_paths},'Provider changed during prose snapshot'
record={'status':'Owned unapplied normative final-prose proposal; not site/test execution evidence','revision':'R4 actual provider v2 semantic reconciliation plus minimal support row','created_ns':time.time_ns(),'files':files,'patch':{'path':str(patch_path),'sha256':sha(patch.encode()),'bytes':len(patch.encode())},'provider_inputs':[{'path':p,'sha256':h}for p,h in provider_before.items()],'provider_source_stable_during_preparation':True,'semantic_reconciliation':['Independent getter is outside capabilities gate; all existing public faces/ops/layouts remain unchanged.','Only already-selected nonzero directions are controlled; EP0 separate; cold startup mask/active onlyEP0.','Software/current epoch0 and already-observed raw USBRST gate admission before writes; no wire atomicity.','Preexisting defined endpoint flags are strict BUSY; post-command only newly raised knownIN0x50 hints may be acknowledged.','Fresh enable proves geometry/DATA0/NAK, then target mask. Disable masks before active withdrawal, preserving unrelated directions.','Already-active enable checks geometry, does not replay DATA0/HALT; already-inactive disable does not reprogram geometry.','Explicit Task waits use existing finite poll budget; added reset withdrawal uses single observations with service retry.','Common reset active/mask withdrawal follows actual loan/FIFO drain on both families, without inventing GD reset silicon behavior.','IO partial-effect failure uses existing closing/clock/loan retention and explicit complete stop.','External Chapter9 stages before statusIN and independently owns configured readiness and partial rollback.'],'already_applied_API_entry':{'path':api['path'],'sha256':api['proposal_sha256'],'do_not_reapply':'Original R3 draft.patch includes this old-to-new entry and is historical; final-prose.patch deliberately excludes it.'},'already_applied_API_catalogs':['docs/locale/en/LC_MESSAGES/reference/api/io.po','docs/locale/zh_CN/LC_MESSAGES/reference/api/io.po'],'deferred_translation':'Root fresh finalPOT after final prose application must determine exact design/support/source-map catalog deltas. No PO generated or changed by this phase. API page source bytes remain unchanged.','capabilities':'Purely generated matrix; no new activation mode/route/TOML authority. Regenerate/check normally after final fixtures, admit only actual derived diff.','no_primary_or_index_write':True,'no_compiler_configure_docs_gettext_tests':True,'no_new_page_figure_ledger_status_authority':True,'remaining_qualification':'Root reports actual210 focusedGREEN separately. This record is prose/code inspection only; rawreset regression, full ordinary gates, strict bilingual site, SDK and HIL remain separately proven.'}
(OUT/'final-prose-manifest.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
(OUT/'README.txt').write_text('USB activation owned documentation proposal R4\n\nUse final-prose.patch for the three still-pending prose files: docs/design/usb-device.md, io/README.md, docs/delivery/support.md. Original draft.patch/R1/R2/R3 records remain historical and include the API entry now already applied by root; do not apply them again.\n\nThe normative after-images are unapplied and require root semantic review after actual runtime GREEN. This phase only read current provider v2, wrapper/header and generator. It adds no execution, strict site or HIL claim. No primary/index writes, compiler/configure/docs/gettext/test execution or PO edits were made.\n\nHeader/API catalogs were prepared from their separate actual fresh extraction and reviewed independently; final design/support/source-map translations must use a new finalPOT after prose application. FIG-16 and full IO-35/HIL boundaries remain.\n')
print(json.dumps({'patch_sha256':sha(patch.encode()),'patch_bytes':len(patch.encode()),'manifest_sha256':sha((OUT/'final-prose-manifest.json').read_bytes()),'files':files},ensure_ascii=False))
