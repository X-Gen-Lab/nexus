USB activation owned documentation proposal R4

Use final-prose.patch for the three still-pending prose files: docs/design/usb-device.md, io/README.md, docs/delivery/support.md. Original draft.patch/R1/R2/R3 records remain historical and include the API entry now already applied by root; do not apply them again.

The normative after-images are unapplied and require root semantic review after actual runtime GREEN. This phase only read current provider v2, wrapper/header and generator. It adds no execution, strict site or HIL claim. No primary/index writes, compiler/configure/docs/gettext/test execution or PO edits were made.

Header/API catalogs were prepared from their separate actual fresh extraction and reviewed independently; final design/support/source-map translations must use a new finalPOT after prose application. FIG-16 and full IO-35/HIL boundaries remain.
