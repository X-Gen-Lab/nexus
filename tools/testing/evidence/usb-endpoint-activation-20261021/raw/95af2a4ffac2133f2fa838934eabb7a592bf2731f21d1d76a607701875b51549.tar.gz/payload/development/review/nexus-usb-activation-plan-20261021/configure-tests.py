    def test_activation_getter_is_independent_of_optional_rom_profiles(self):
        for family in ("stm32-zg", "stm32-ve", "gd32"):
            for capabilities in (False, True):
                with self.subTest(family=family, capabilities=capabilities):
                    header, source = self.generate(family, capabilities)
                    self.assertIn('#include "nexus/io/usb_activation.h"',
                                  header)
                    self.assertIn("const nx_usb_activation_port_t* "
                                  "nx_factory_usb_activation(", header)
                    self.assertIn("nx_factory_usb_activation(", source)
                    self.assertIn("&nx_usb_fs_activation_ops, &s_nx_port_fs",
                                  source)
                    self.assertIn("case NX_USB_DEVICE_ID_FS:", source)
                    if not capabilities:
                        self.assertNotIn("nx_usb_device_profile_t", source)
                        self.assertNotIn("nx_usb_endpoint_profile_t", source)

    def test_activation_face_reuses_selected_controller_storage(self):
        header, source = self.generate("stm32-zg", capabilities=False)
        self.assertIn("static const nx_usb_activation_port_t ", source)
        self.assertIn("static nx_usb_endpoint_t s_nx_usb_endpoints_fs[4]",
                      source)
        self.assertIn("static nx_usb_event_t s_nx_usb_events_fs[8]", source)
        self.assertEqual(
            source.count("static nx_usb_controller_t s_nx_port_fs;"), 1)

