# Explicit USB endpoint activation: contract-first proposal

Status: **planning, unapplied tests and separately requested inert declaration
scaffold only**. No activation behavior after-image, primary checkout/index
change, compiler/configure/test execution or physical HIL was performed by this
planning agent. This is the next bounded USB mechanism, not an IO-35 or complete
USB stack delivery claim. The separate inert scaffold is documented in
`scaffold.md`; it adds no functional provider capability.

Reviewed checkout: `/tmp/nexus-quality-20261019`; source identities are recorded
in `plan-manifest.json`. The current interrupt-IN increment remains frozen and
must be committed independently. Review inputs include `AGENTS.md`, the current
`docs/design/usb-device.md`, both reports under
`/tmp/nexus-usb-interrupt-final-review-20261021`, and `vendor-review/facts.md`.

## 1. Problem and smallest useful result

The current packet interface correctly refuses a selected nonzero endpoint whose
hardware active bit is clear, before borrowing a request or writing a FIFO. The
ST reset fact is now modeled faithfully: reset clears nonzero USBAEP. However,
external configuration policy has no supported way to make a drained selected
endpoint active again. Full stop/cold restart currently works around the gap;
it is not an endpoint configuration mechanism.

Add one explicit, synchronous controller-owned operation which enables or
disables one **already selected nonzero endpoint direction**. Configuration
selection, standard requests, class policy, notifications, descriptors,
configuration value, alternate settings and rollback orchestration remain with
the external owner. No new worker, queue, allocation, instance registry,
configuration-state pool, interval field or product policy is needed.

The result permits the real sequence: cold EP0 enumeration, an external owner
activating its selected directions, ordinary packet I/O, reset invalidation and
drain, then explicit reactivation using the new current epoch. It does not
establish complete enumeration or physical qualification.

## 2. Reference findings that constrain the design

The exact sources, lines and hashes are in `vendor-review/facts.md`.

| Fact | Consequence for Nexus |
| --- | --- |
| ST USBAEP / GD EPACT is bit 15; transfer EPENA / EPEN is bit 31. | Activation does not start a transfer and does not borrow a buffer. |
| ST LL and GD SPL activate MPS/type/DATA0/FIFO identity and active state; packet start is separate. | Reuse those register contracts, with direction-specific fields and readback. |
| ST deactivate can issue NAK/disable without waiting for complete proof; GD clears active/mask without a Nexus loan proof. | Never use a vendor success return as request settlement or permission to release storage. |
| RM0090 section 34.17.5, pp.1342–1343 programs endpoints before configuration/interface status IN. Zephyr's pinned Chapter 9/configuration layer does the same. | Do not attribute a mandatory after-ACK activation rule to either source. External policy can stage hardware before status, and must gate actual packet submission and commit its configured state after status success. |
| Zephyr separates EP enable/disable, packet enqueue/dequeue, and Chapter 9 policy; its API excludes EP0 from ordinary activation. | Borrow that separation without importing its queues, net_buf pools or class/configuration framework. |
| Zephyr DWC2 inactive check precedes FIFO writes. Some stop waits only log timeout before returning success. | Keep Nexus's inactive rejection and stronger readback/drain/quarantine semantics. |
| ST nonzero-USBAEP reset clear is documented; equivalent GD reset effect remains unproved. | Deliberately clear selected nonzero active state in software after reset loans drain, for a uniform platform postcondition. Test GD with a reset leaf that leaves active set; do not invent a GD silicon claim. |
| GD's broad common activation expression includes TxFIFO bits for OUT, although those bits are reserved for OUT. | Do not copy that expression verbatim. Only IN receives a TxFIFO selector. |

## 3. Public shape and ABI boundary

Recommended additive API names, subject to root's ordinary interface review:

```c
typedef struct {
    nx_result_t (*set)(void* context, uint64_t epoch,
                       uint8_t endpoint_address, bool active);
} nx_usb_activation_ops_t;

typedef struct {
    const nx_usb_activation_ops_t* ops;
    void* context;
} nx_usb_activation_port_t;

nx_result_t nx_usb_activation_set(const nx_usb_activation_port_t* port,
                                  uint64_t epoch,
                                  uint8_t endpoint_address, bool active);

const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id);
```

This is a controller-level face even though the operation selects one endpoint.
The context is the existing static `nx_usb_controller_t`; it is not an endpoint
allocation or an adapter object. One shared readonly ops object serves every
selected controller. The getter returns a static borrowed face or NULL for an
invalid/unsupported controller identity. Factory lookup has no hardware access,
initialization, lock, registration, clock retention or lifecycle transition.

`endpoint_address` uses the USB address byte: bit7 is direction, bits3:0 are the
number, bits6:4 must be zero. The present FS implementation admits only selected
numbers 1..3. Both EP0 addresses and unselected/reserved addresses return INVALID.
The getter can be declared like the other generic factory getters for all
assemblies; assemblies with no selected/supported USB controller return NULL and
emit no activation face. It must work with `factory.capabilities=false`.

Do not append a member to `nx_usb_endpoint_ops_t`, `nx_usb_device_ops_t`,
`nx_usb_device_profile_t` or any existing face. Do not bump factory ABI epoch1.
No new public/private runtime state is required. On a 32-bit ARM target, the new
face is expected to occupy two readonly pointers and the shared one-method ops
object one readonly pointer; actual retained linked bytes must be measured.
Unreferenced faces/ops/code should disappear under the existing section GC.

### Why per endpoint rather than batch

| Choice | Advantages | Costs / limits |
| --- | --- | --- |
| One endpoint direction per call — recommended | Exact external selection; no array validation or borrowed metadata; bounded scan of at most eight selected directions; simple fault attribution; no new RAM. | Enabling several endpoints is sequential. A later failure does not roll back earlier calls; the owner must track and undo successful changes or stop the controller. |
| Batch containing selected addresses | Can preflight every target before any write; somewhat easier external configuration loop. | Hardware writes still are not physically atomic, reset can intervene, and partial-write failure still needs cleanup. Requires more public argument/alias/duplicate semantics without removing the fundamental rollback responsibility. |
| Boolean enable-all-selected | Very small caller surface. | Incorrectly chooses configuration/alternate membership inside the platform when the immutable resource plan can be a superset. |

There is no promise of a configuration transaction or wire-atomic activation.
A later batch convenience, if justified by real callers, belongs above this
primitive and must not be smuggled into this delivery.

## 4. Runtime contract

### Entry and preflight

The serialized privileged Task owner calls with incoming IRQ masks clear.
Validate the public face/ops/context before dispatch; absent operation is
UNSUPPORTED, malformed face is INVALID. The provider rejects ISR, unprivileged
or already-masked entry with CONTEXT and restores exactly the incoming IRQ state.
Use the existing local saved-IRQ transaction; no OS mutex or wait loop is added.

Within the guard, validate before any write:

Pure address/selected-identity validation and software state/epoch checks precede
all MMIO. Thus invalid identity and an already-known stale software epoch reject
without even a peripheral read. Hardware-only preconditions follow those checks.

1. Controller is started, retains its clock and is not closing or reset-pending.
   Stopped/closing/reset/stale epoch returns STATE. A visible raw reset-pending
   hardware flag should also prevent a new activation write; service remains
   responsible for collecting reset and publishing the new software epoch.
2. `epoch` equals the authoritative current software USB control/reset epoch.
   Zero is a valid cold epoch; do not copy `reject_setup`'s epoch-zero rejection.
   It is a stale-software-observation check, not a token proving host policy or
   atomicity with a not-yet-collected physical SETUP/reset. Cached authority must
   be discarded after stop/restart. Do not silently change the existing cold
   epoch behavior in this small increment; assess restart ABA separately if a
   caller needs cached authority across a restart.
3. Selected nonzero endpoint exists. No request pointer, disable-in-progress,
   EPENA/EPEN or defined unacknowledged endpoint flag remains. Otherwise BUSY.
   For IN, the selected FIFO must report fully free space and no global FIFO
   flush may be in progress. For OUT, RX status FIFO must be empty; return BUSY
   rather than flushing shared RX state or consuming another endpoint's data.
4. Software setup-drain work must have completed before the operation can be
   applied to a published SETUP epoch. Use BUSY for pending setup cleanup; do not
   require a particular standard request or `control_pending=true`.

No preflight rejection takes a new reference, starts a transfer, acknowledges
unrelated events, changes another endpoint or repairs hardware. A target with an
ACTIVE/DRAINING/QUARANTINED request returns BUSY even if the desired value equals
its current hardware state. Existing loans elsewhere can remain live: the
operation is local, not a hidden controller-wide cancellation.

### Enable an inactive direction

Reapply the selected immutable MPS and wire transfer type (BULK2 / INTERRUPT3),
and only for IN its selected dedicated TxFIFO identity. Clear STALL and old
packet-start/disable/command bits as specified by the manuals. Issue DATA0 only
for the selected nonzero bulk/interrupt endpoint, set active and SNAK, leave
EPENA clear, and leave TSIZ, payload FIFO and all caller storage untouched.
Use a careful read/modify/write which preserves read-only observed status bits;
do not write IN-only fields to OUT or any reserved EP0 PID command.

Read back only meaningful stable fields: active, MPS, type, IN FIFO selector,
STALL clear, DATA0 and no transfer enable. Confirm NAK status according to the
locked manual. IN SNAK can create INEPNE: acknowledge only that expected defined
target NAK-effective event and prove its W1C clear. Any other unexpected flag or
failed proof is a partial-operation error, not successful activation. Publish
`ep->halted=false` only after all relevant hardware proof succeeds. No request is
ever borrowed by activation itself.

Only after target endpoint control/W1C proof, unmask its selected endpoint bit by
read/modify/write of EP_MASK and prove the full expected mask readback. Preserve
every unrelated bit, including both EP0 directions. A mask proof failure enters
the same partial-IO/closing path as a control proof failure.

### Disable a quiescent direction

The caller must first cancel and drain any request using existing operations and
observe acquire SETTLED. Under the same preflight, mask only the target EP_MASK
bit and prove unrelated bits preserved before withdrawing its active state.
Then write SNAK and clear active;
do not issue EPENA or initiate hidden packet cancellation. Preserve DATA PID,
geometry and other endpoints. Verify inactive, no transfer enable and expected
NAK/W1C proof. Do not flush shared RX FIFO, reset the core or release the clock.
The controller remains started and EP0 continues receiving SETUP.

### Idempotence and halt

A fully quiescent endpoint already in the requested state succeeds without a
control-register write when its required immutable geometry is valid. The target
interrupt-mask bit must also match the requested state; an explicit set may
update that bit without replaying endpoint DATA0/HALT configuration. Repeating
enable on an already active endpoint must not reset DATA1, clear a real HALT, or
start a packet. A new configuration that requires DATA0/HALT reset performs an
explicit disable then enable. Disabling preserves PID; enabling an inactive
direction establishes fresh DATA0 and clears halt only after readback proof.

If already-active geometry is corrupt, do not silently replay DATA0 or repair a
live configuration. Return IO with the existing closing barrier and no endpoint
control write; the external owner performs full recovery. This is an observed
hardware integrity failure, distinguished from an invalid caller preflight.

### Endpoint masks and fixed physical routing

Keep the selected physical IRQ/vector/priority routing and controller ownership
unchanged, but follow the official inactive-endpoint mask sequence: cold start
unmasks EP0 only; enable unmasks its target after control proof; disable masks its
target before active withdrawal. EP_MASK read/modify/write preserves every other
direction. No new software mask state is needed. The two registers are not a
wire-atomic transaction, so readback failure has an explicit partial-operation
contract. Masking alone neither disables tokens nor releases storage. Full stop
retains controller-wide source/NVIC/publisher-join proof.

### Partial failure and rollback

INVALID/CONTEXT/STATE/BUSY preflight rejections perform no hardware write and do
not change request state. Once a register write has happened, a failed readback
returns IO and sets the existing controller `closing` barrier. This method is a
synchronous hardware mutator, not request admission: IO may have partial hardware
effects, which must be stated explicitly in its return contract.

Under the same bounded guard, first best-effort clear only the target mask bit
with readback, and make a best-effort target-only rollback to
inactive/SNAK if EPENA is still clear, without resetting the shared core or
touching any borrowed storage. If EPENA is unexpectedly observed set, do not
pretend that writing zero to it disables the endpoint: retain the closing barrier
and let explicit stop use the existing disable proof. Record no false success if
rollback readback also fails; the
existing closing state and retained clock require the external owner to service
existing loans and perform explicit full stop/recovery. No new recovery flag or
state pool is needed. Do not clear `closing` by retrying activation.

Existing loans on other directions remain retained and are not implicitly
settled or revoked by activation failure. A subsequent explicit stop may return
BUSY and retain clock/storage until the existing disable/flush/IRQ-join proofs
complete. Tests must exercise that retention, rather than only inspect a result
code.

### Cold start, bus reset and clear halt

Cold initialize configures immutable FIFO geometry and selected endpoint
register attributes, but sets active/unmasks only EP0. Nonzero directions remain
inactive/SNAK and cannot take a loan. A successful getter/start/reset/DATA0 or
clear-halt operation does not activate them. EP0 setup and SET_ADDRESS keep their
existing special handling. Activation rejects EP0 even if an external caller
supplies a standard request referring to address zero.

Reset never revokes an accepted request. Extend the existing `reset_pending`
progress path, after all old requests have genuinely drained and both FIFOs have
proved flushed, to mask and explicitly deactivate every selected nonzero
direction. Reuse the bounded selected endpoint loop and guard; no new state
field, worker or public operation from IRQ is required. Preserve EP0 behavior,
address-zero and selected PID/halt proof, and clear `reset_pending` only after
nonzero active/mask readback also succeeds. Any failed reset proof retains the
reset barrier and clock and can be retried through ordinary service or full stop.

This creates a uniform **platform** postcondition: completed reset leaves selected
nonzero directions inactive and masked in both families, so a new current-epoch
activation is required for packet admission. ST may clear USBAEP earlier in
hardware; GD software explicitly performs the documented active-bit clear after
loan quiescence. Do not claim GD automatically clears EPACT on reset. The GD SDK
test must inject only the reset interrupt, retain active in the hardware leaf,
and require actual common production reset code to withdraw it. No reset, halt
or submit path automatically activates an endpoint.

## 5. External control-policy integration

```text
external Chapter 9/config owner        generic Nexus mechanism
---------------------------------     ------------------------------------
read authoritative SETUP + epoch       state / read_events
choose configuration endpoints        no request/class/config decoder
cancel former packet owners           endpoint cancel
wait for acquire SETTLED               monotonic service / drain / quarantine
disable old selected directions       activation.set(epoch, address, false)
stage new selected directions         activation.set(epoch, address, true)
send status IN for accepted request    ordinary EP0 STATUS request
observe actual status completion       acquire SETTLED + current epoch/state
publish configured readiness          external state only
permit actual endpoint packet I/O      ordinary endpoint submit
```

This matches the documented ST/Zephyr before-status configuration sequence while
keeping configured readiness external. An alternate after-ACK strategy must be
justified by the external policy and host-retry timing; it is not the default
reference contract. If status fails, a new SETUP supersedes it, or a later
endpoint activation fails, the owner undoes successfully staged changes or stops
the controller. No platform method can undo a USB status ACK already observed by
the host. For deconfiguration, finish required cancel/drain/disable before
acknowledging acceptance; otherwise withhold/stall according to external policy
and its deadline. The DCD does not wait for class teardown or infer configuration
value from raw SETUP bytes.

## 6. Concrete file touchpoints

| File | Necessary change |
| --- | --- |
| `io/include/nexus/io/usb_activation.h` (new) | Add optional two-pointer face, one-method readonly ops and full mutator/partial-failure/Task/EP0/epoch contract. No existing public layout changes. |
| `io/src/usb_device.c` | Thin additive public wrapper; reuse existing null/missing-method conventions. No new source target required. |
| `io/private/usb_device_controller.h` | Include the new public type and declare one shared readonly activation ops symbol. No new private struct fields. |
| `io/src/usb_device_controller.c` | Add bounded selected-direction setter and target-mask proof; cold start activates/unmasks EP0 only. After reset loans drain, explicitly deactivate/mask selected nonzero directions before clearing reset_pending. Reuse existing loops/guard/state; no implicit activation. |
| `tools/configure/usb_profiles.py` | Add a separate activation-face/getter emission function using existing controller IDs and contexts. Keep existing optional profile emission unchanged. |
| `tools/configure/factory.py` | Invoke activation emission outside `factory.capabilities`; preserve ABI epoch1 and existing getter/ops/profile layouts. No new TOML field or IR type. |
| `soc/stm32f407/drivers/usb_device.c`, `soc/gd32f470/drivers/usb_device.c` | Review existing locked SDK assertions for every reused control/status field; add only genuinely missing mask/readback facts. Do not copy the GD OUT TxFIFO expression. |
| `tests/google/usb_device_test.cpp` | Add runtime contract cases first; existing fixture owners then explicitly activate directions used by existing packet tests. Replace obsolete cold-restart-success expectations with inactive + explicit activation. Preserve all meaningful ownership assertions. |
| `tests/google/usb_device_soc_test.cpp` | Exercise both real SDK bindings, including GD reset whose hardware leaf does not clear active. Prove software withdrawal only after loan drain, target mask/readback, explicit reactivation and later actual ACK. |
| `tests/google/factory_*` / existing generated factory fixture | Verify actual typed getter identity/context, invalid ID NULL, no MMIO/clock/start, and capabilities-false compilation. Select exact current factory fixture after root inventory. |
| `tools/configure/test_usb_profile.py`, `test_usb_device.py` | Test getter emission independent of optional profiles; old private state sizes/IR shape remain unchanged and no new ownership authority exists. |
| `io/native/usb_device.h/.c` only if needed after RED | Add a small hardware leaf fault holding target active write readback, if existing DATA0/STALL faults cannot isolate the required proof. No new success logic, class policy or test-only MCU state. First proposal uses existing faults and needs no new model production after-image. |
| `docs/design/usb-device.md`, `io/README.md`, English/Chinese API docs and maintained catalogs | Replace the activation-gap statement with exact new software scope and remaining external config/class/reset/HIL limits; document before-status staging accurately. Follow ordinary docs/translation tooling. |

No assembly fixture needs a new authored field or interval. No unrelated
controller, product repo, old work package or evidence framework belongs in this
increment. The three currently frozen interrupt TOML fixtures and their evidence
stay untouched until the ordinary interrupt commit is complete.

## 7. TDD sequence and meaningful validation

`contract-tests.patch` is **unapplied test code only**. It references the proposed
public names and the shared provider ops symbol. It is not a passing test report
and currently is not intended to compile until root agrees on the contract and
adds minimal declarations plus an inert UNSUPPORTED provider scaffold. A missing
header/symbol is a compile failure, not the required runtime RED. Do not use
SFINAE, skips, feature-detection tests or assertions against a duplicated setter
algorithm to manufacture green.

The generated typed getter may initially return NULL for every ID in that inert
scaffold; do not manufacture an apparent provider capability before its operation
exists. The real-provider runtime tests bind the declared shared table directly
to the existing controller context, so its UNSUPPORTED method produces a real
assertion failure independently of generator/factory completion. This scaffold
strategy is described here, not supplied as a production after-image.

1. Commit the frozen current USB work with its ordinary gate. Refresh this
   proposal's source hashes before applying anything in a new focused increment.
2. Agree the API and make the smallest declaration/dispatch-only scaffold whose
   provider `set` is NULL and therefore returns UNSUPPORTED through the wrapper.
   Apply the contract
   tests; run the appropriate ordinary GoogleTest target to capture **actual
   runtime RED**, including the existing cold-start active-bit mismatch and the
   absent explicit mechanism. Keep the failing exact source/command identity.
3. Only after RED, implement the smallest controller/generator changes. No
   generated production after-image is present in this planning packet.
4. Adapt existing explicit fixture owners and old assertions intentionally.
   Common packet fixtures may explicitly enable their chosen endpoints; keep a
   separate cold-start test so fixture convenience cannot hide default activity.
   Existing reset/clear-halt/cancel/flush/NAK/address proofs must remain intact.
5. Run the affected real GoogleTest targets (Native, both SDK bindings,
   factory/control/ACM integration where touched), configuration tests and focused
   ASan as appropriate. Each test must establish a different public/hardware or
   lifetime boundary; do not add hundreds of mirrored combinations.
6. Build the three selected ARM USB fixtures with capabilities true and false
   where needed. Check static face/context identity, unchanged existing layouts,
   no extra mutable USB state, retained linked flash/RAM and unselected-section
   GC. A source-level two-pointer estimate is not a measurement.
7. Run standard formatting/docs and the mandatory complete-index ordinary gate
   once the staged source is final. Preserve genuine failures; no focused filter
   substitutes for the ordinary commit gate. Parent owns execution/commit/push.
8. Keep physical station cases prepared, not executed: first enumeration,
   configuration/deconfiguration, repeated reset/reconfigure, halt/DATA0,
   cancellation under host traffic, suspend/unplug, no active default endpoint,
   both families' FIFO/NAK/disable timing, and borrowed-storage retention.

### Required cases beyond the initial test-only patch

- Public wrapper rejects malformed faces and missing ops; delegates exact context
  and arguments once, including false/IN/OUT/epoch. GoogleMock may cover this
  boundary only; never mock the production DCD under test.
- Activation readback failure of active, geometry, STALL or DATA0 closes admission
  and retains the clock; failed target rollback is not reported as success.
- Both SDK targets use exact active/NAK/type/MPS/IN-only FIFO facts. OUT reserved
  fields, EP0 PID commands, unrelated mask bits and unrelated registers remain
  unchanged. Target mask tracks explicit active state; reset masks nonzero only
  after existing loans drain, including when the GD leaf leaves active set.
- Target IN FIFO-not-empty, target flags or global flush pending, and shared OUT
  RX status pending yield BUSY without a hardware write. Other endpoint loans
  are retained and can progress; no shared flush or hidden cancel occurs.
- ISR and unprivileged entry reject before MMIO; saved masks restore on success,
  preflight rejection and partial-failure exits. A masked caller stays masked.
- Visible hardware reset before admission rejects; reset arriving after observed
  activation invokes ordinary invalidation/drain. Document unavoidable physical
  race rather than claim atomicity from local IRQ masking.
- Factory getter exists without optional ROM profiles, returns the actual static
  controller context, and invalid/non-USB selection yields NULL without access.
- A host SET_CONFIGURATION status ACK alone never changes nonzero active state.
  External-owner staging + status ACK + later packet I/O works without any new
  standard/class decoder in the DCD.

## 8. Exit and remaining limits

The software increment is complete only when explicit cold/reset reactivation
works end to end through real provider code, no-borrow inactive rejection and all
prior lifetime proofs remain, generated integration works independently of
optional profiles, resource/ABI checks are measured, docs agree, and ordinary
complete-index gates pass on the committed tree.

It still does not deliver a Chapter9/class stack, CDC notification scheduling,
multiple USB configurations/alternate-setting policy, streaming/multipacket/DMA,
ISO/interrupt OUT/HS/host/OTG role support, electrical qualification, physical
enumeration or full IO-35 acceptance. Those require separate bounded work and,
where applicable, an actual HIL station.
