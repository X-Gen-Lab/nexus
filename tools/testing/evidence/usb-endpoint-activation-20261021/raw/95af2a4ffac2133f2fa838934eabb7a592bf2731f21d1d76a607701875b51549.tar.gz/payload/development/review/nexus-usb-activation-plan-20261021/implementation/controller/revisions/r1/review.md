# Independent controller activation review

Read-only review of before.c, after.c, controller-activation.patch and manifest.
Reviewed after-image SHA256:
`3cd3733094fc1e8dd15fef47c0022c064618038dd4103a183f8be901b3e81c4b`.
No compiler, configure, tests, primary/index changes or after-image edits.

## Material findings

1. **Allowed idle IN hints are rejected before their cleanup helper.**
   `activation_set` rejects `ep_flags(ep) != 0U` in hardware preflight. Thus
   INEPNE/token-empty flags0x50 are returned as BUSY, despite
   `activation_hints` explicitly accepting them. Real host polling can produce
   the token-empty hint on an idle selected direction. It should not become an
   unexplained failure to activate/deactivate. Validate that flags contain only
   the permitted hint subset during pure preflight, then acknowledge/prove those
   hints only after all other rejecting checks. Include the idempotent active
   path: it currently skips activate_endpoint and therefore skips its hint
   cleanup. Never admit XFRC, EPDISD or error flags under this exception, and do
   not clear a hint before a later FIFO/geometry/reset precondition rejects.

2. **Failed mask proof prevents the promised best-effort active withdrawal.**
   `deactivate_endpoint` returns immediately if set_endpoint_mask(false) fails.
   On partial-operation failure, activation_set invokes that same helper for
   rollback, which again returns before reading or clearing ACTIVE. For a mask
   bit stuck at one, a safely idle target is never even attempted inactive.
   Keep mask proof and safe target-control withdrawal as independent bounded
   steps; return failure unless both complete, but still attempt target ACTIVE
   withdrawal when EPENA/DISABLE are clear. This must retain IO/closing and the
   existing clock if mask readback cannot be proved. Never force-clear observed
   EPENA or treat partial withdrawal as request settlement. No helper parameter,
   new state or recovery framework is required.

Both findings were sent to the parent immediately. They do not require changing
the public ABI or loan contracts. A stuck-one mask remains a full-stop BUSY
condition until actual source withdrawal succeeds.

## Checked boundaries

- Cold start programs static FIFO geometry but sets ACTIVE/unmasks only EP0;
  reads back selected active/enable/disable/geometry/PID and complete EP_MASK.
  Nonzero admission remains guarded by actual active hardware.
- Target mask RMW computes from the actual register and compares its full
  expected value. Other selected directions and EP0 are preserved.
- Fresh activation applies immutable MPS/type/IN FIFO, clears HALT and commands,
  initializes DATA0/NAK, and leaves EPENA and transfer TSIZ/payload untouched.
  OUT receives no IN FIFO bits; OUT bits25:22 are zeroed and checked as reserved.
- Repeated enable validates active geometry and avoids replaying DATA0/HALT.
  DATA1 and a real HALT remain intact; only target mask repair can be needed.
  Corrupt active geometry closes admission without control writes.
- Disable preserves geometry, STALL and DATA PID. It never clears a request,
  increments an epoch, releases a clock or flushes shared RX state.
- Partial error uses the existing closing barrier. Other endpoint requests and
  clock retention remain unchanged; the existing explicit stop still owns
  disable/FIFO/source/join proof. Unexpected EPENA is rejected, never forced zero.
- Cold epoch0 is accepted. Stopped/closing/reset/stale epoch and malformed or
  unselected address checks precede MMIO. Raw uncollected USBRST rejects before
  writes. Local IRQ masking is not misrepresented as physical reset atomicity.
- Reset withdrawal is reached only after all endpoint request pointers are gone,
  both hot FIFO flushes complete and selected halt/PID proof succeeds. Selected
  nonzero active/mask readback gates clearing reset_pending. A failure retains
  the barrier and clock and can be retried. The GD hardware leaf need not clear
  active automatically for this platform postcondition to hold.
- No new mutable controller/endpoint field, queue, worker, allocation or standard
  request/class policy is introduced.

One comment should say "never transfer size or EPENA" rather than "never packet
size": fresh activation does program the selected maximum packet size as part of
immutable geometry. This is a wording correction only.

The existing Native model is not a physical timing proof. In particular, hints
may relatch from host activity, and no local guard makes several register writes
wire-atomic. Keep actual RED/GREEN and HIL claims distinct from this code review.

## Scope clarification after root review

Root confirmed strict preexisting-flags BUSY admission. Finding1 is therefore
resolved by clarifying that the0x50 helper handles only new known hints after
this operation's write, not preexisting flag admission. No policy expansion is
requested. See `handshake-review.md` for the exact manual timing/acknowledgement
facts and Task-only bounded-observation recommendation. Finding2 remains the
identified rollback change and is being corrected by the controller owner.
