/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#ifndef NX_PLATFORM_REGISTER_WRITE
#define NX_PLATFORM_REGISTER_WRITE(reg, value) ((reg) = (uint32_t)(value))
#endif
#ifndef NX_PLATFORM_PRIORITY_WRITE
#define NX_PLATFORM_PRIORITY_WRITE(reg, value) ((reg) = (uint8_t)(value))
#endif
#include "stm32f407_provider.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static nx_stm32_gpio_state_t s_nx_port_led0;
static const nx_gpio_port_t s_nx_face_led0 = {
    &nx_stm32_gpio_ops, &s_nx_port_led0
};
const nx_gpio_port_t* const nx_binding_led0 = &s_nx_face_led0;
/* Fixed GPIOE authorization. */
static nx_result_t prepare_led0(void) {
    s_nx_port_led0.registers = GPIOE;
    s_nx_port_led0.mask = 8u;
    s_nx_port_led0.output = true;
    uint32_t saved_clock = RCC->AHB1ENR & 16u;
    nx_result_t clock = nx_stm32_gpio_clock_enable(4u);
    if (clock != NX_SUCCESS) { RCC->AHB1ENR = (RCC->AHB1ENR & ~16u) | saved_clock; return clock; }
    uint16_t saved_3 = nx_stm32_pin_capture(GPIOE, 3u);
    nx_result_t status = nx_stm32_gpio_initialize(&s_nx_port_led0, 8u);
    if (status != NX_SUCCESS) {
        uint32_t retained_gpio_clocks = 0u;
        {
            bool pin_restored = true;
            {
                uint32_t pin_mode = GPIOE->MODER & 192u;
                if (pin_mode != 0u && pin_mode != 192u) {
                    NX_PLATFORM_REGISTER_WRITE(GPIOE->MODER, GPIOE->MODER | 192u);
                    nx_arch_dsb();
                    if ((GPIOE->MODER & 192u) != 192u) { pin_restored = false; }
                }
            }
            if (pin_restored) {
                nx_stm32_pin_restore(GPIOE, 3u, saved_3);
                nx_arch_dsb();
                pin_restored = nx_stm32_pin_capture(GPIOE, 3u) == saved_3;
            }
            if (!pin_restored) { retained_gpio_clocks |= 16u; }
        }
        RCC->AHB1ENR = (RCC->AHB1ENR & ~16u) | saved_clock | retained_gpio_clocks;
        nx_arch_dsb();
    }
    return status;
}
static nx_stm32_uart_state_t s_nx_port_uart1;
static const nx_uart_port_t s_nx_face_uart1 = {
    &nx_stm32_uart_ops, &s_nx_port_uart1
};
const nx_uart_port_t* const nx_binding_uart1 = &s_nx_face_uart1;
static nx_uart_rx_event_t s_nx_rx_uart1[32];
static nx_result_t prepare_uart1(void) {
    s_nx_port_uart1.registers = USART1;
    s_nx_port_uart1.rx_storage = s_nx_rx_uart1;
    s_nx_port_uart1.rx_capacity = 32u;
    s_nx_port_uart1.baud = 115200u;
    s_nx_port_uart1.profile = NX_UART_RX_EVENTS;
    s_nx_port_uart1.irq = USART1_IRQn;
    uint32_t saved_clock = RCC->AHB1ENR & RCC_AHB1ENR_GPIOAEN;
    uint32_t saved_uart_clock = RCC->APB2ENR & RCC_APB2ENR_USART1EN;
    nx_result_t clock = nx_stm32_gpio_clock_enable(0u);
    if (clock != NX_SUCCESS) {
        RCC->AHB1ENR = (RCC->AHB1ENR & ~(uint32_t)RCC_AHB1ENR_GPIOAEN) | saved_clock;
        return clock;
    }
    uint16_t saved_tx = nx_stm32_pin_capture(GPIOA, 9u);
    uint16_t saved_rx = nx_stm32_pin_capture(GPIOA, 10u);
    nx_result_t pins = nx_stm32_uart1_pins_prepare();
    nx_result_t uart = pins == NX_SUCCESS ? nx_stm32_uart_initialize(&s_nx_port_uart1, 84000000u) : pins;
    if (uart != NX_SUCCESS) {
        uint32_t retained_gpio_clocks = 0u;
        {
            bool pin_restored = true;
            {
                uint32_t pin_mode = GPIOA->MODER & 786432u;
                if (pin_mode != 0u && pin_mode != 786432u) {
                    NX_PLATFORM_REGISTER_WRITE(GPIOA->MODER, GPIOA->MODER | 786432u);
                    nx_arch_dsb();
                    if ((GPIOA->MODER & 786432u) != 786432u) { pin_restored = false; }
                }
            }
            if (pin_restored) {
                nx_stm32_pin_restore(GPIOA, 9u, saved_tx);
                nx_arch_dsb();
                pin_restored = nx_stm32_pin_capture(GPIOA, 9u) == saved_tx;
            }
            if (!pin_restored) { retained_gpio_clocks |= 1u; }
        }
        {
            bool pin_restored = true;
            {
                uint32_t pin_mode = GPIOA->MODER & 3145728u;
                if (pin_mode != 0u && pin_mode != 3145728u) {
                    NX_PLATFORM_REGISTER_WRITE(GPIOA->MODER, GPIOA->MODER | 3145728u);
                    nx_arch_dsb();
                    if ((GPIOA->MODER & 3145728u) != 3145728u) { pin_restored = false; }
                }
            }
            if (pin_restored) {
                nx_stm32_pin_restore(GPIOA, 10u, saved_rx);
                nx_arch_dsb();
                pin_restored = nx_stm32_pin_capture(GPIOA, 10u) == saved_rx;
            }
            if (!pin_restored) { retained_gpio_clocks |= 1u; }
        }
        RCC->APB2ENR = (RCC->APB2ENR & ~(uint32_t)RCC_APB2ENR_USART1EN) | saved_uart_clock;
        RCC->AHB1ENR = (RCC->AHB1ENR & ~(uint32_t)RCC_AHB1ENR_GPIOAEN) | saved_clock | retained_gpio_clocks;
        nx_arch_dsb();
        return uart;
    }
    NVIC_SetPriority(s_nx_port_uart1.irq, 5u);
    return NX_SUCCESS;
}
static nx_result_t stop_uart1(void) {
    nx_result_t status = nx_uart_port_stop(&s_nx_face_uart1);
    if (status != NX_SUCCESS) { return status; }
    {
        uint32_t pin_mode = GPIOA->MODER & 786432u;
        if (pin_mode != 0u && pin_mode != 786432u) {
            NX_PLATFORM_REGISTER_WRITE(GPIOA->MODER, GPIOA->MODER | 786432u);
            nx_arch_dsb();
            if ((GPIOA->MODER & 786432u) != 786432u) { return NX_ERROR_IO; }
        }
    }
    {
        uint32_t pin_mode = GPIOA->MODER & 3145728u;
        if (pin_mode != 0u && pin_mode != 3145728u) {
            NX_PLATFORM_REGISTER_WRITE(GPIOA->MODER, GPIOA->MODER | 3145728u);
            nx_arch_dsb();
            if ((GPIOA->MODER & 3145728u) != 3145728u) { return NX_ERROR_IO; }
        }
    }
    (void)nx_stm32_pin_configure(GPIOA, 9u, 0u, 0u, 0u, false);
    (void)nx_stm32_pin_configure(GPIOA, 10u, 0u, 0u, 0u, false);
    RCC->APB2ENR &= ~(uint32_t)RCC_APB2ENR_USART1EN;
    nx_arch_dsb();
    return NX_SUCCESS;
}
void USART1_IRQHandler(void);
/** \brief Fixed single-controller IRQ dispatch. */
void USART1_IRQHandler(void) { nx_stm32_uart_irq(&s_nx_port_uart1); }
static uint16_t s_nx_platform_pin_state[3u];
static bool s_nx_platform_pins_captured;
static uint32_t s_nx_platform_gpio_clocks_added;
static nx_result_t nx_platform_pins_admit(bool powered_only) {
    if (!powered_only || (RCC->AHB1ENR & RCC_AHB1ENR_GPIOAEN) != 0u) {
        uint32_t mode = GPIOA->MODER;
        if (((mode >> 18u) & 3u) != 0u && ((mode >> 18u) & 3u) != 3u) { return NX_ERROR_BUSY; }
        if (((mode >> 20u) & 3u) != 0u && ((mode >> 20u) & 3u) != 3u) { return NX_ERROR_BUSY; }
        if ((GPIOA->LCKR & 1536u) != 0u) { return NX_ERROR_BUSY; }
    }
    if (!powered_only || (RCC->AHB1ENR & RCC_AHB1ENR_GPIOEEN) != 0u) {
        uint32_t mode = GPIOE->MODER;
        if (((mode >> 6u) & 3u) != 0u && ((mode >> 6u) & 3u) != 3u) { return NX_ERROR_BUSY; }
        if ((GPIOE->LCKR & 8u) != 0u) { return NX_ERROR_BUSY; }
    }
    return NX_SUCCESS;
}
static nx_result_t nx_platform_gpio_clocks_release(void) {
    if (s_nx_platform_gpio_clocks_added != 0u) {
        NX_PLATFORM_REGISTER_WRITE(RCC->AHB1ENR, RCC->AHB1ENR & ~s_nx_platform_gpio_clocks_added);
        nx_arch_dsb();
        if ((RCC->AHB1ENR & s_nx_platform_gpio_clocks_added) != 0u) { return NX_ERROR_IO; }
        s_nx_platform_gpio_clocks_added = 0u;
    }
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pins_acquire(void) {
    if (s_nx_platform_pins_captured || s_nx_platform_gpio_clocks_added != 0u) { return NX_ERROR_STATE; }
    s_nx_platform_gpio_clocks_added = ~RCC->AHB1ENR & (RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOEEN);
    if (s_nx_platform_gpio_clocks_added != 0u) {
        NX_PLATFORM_REGISTER_WRITE(RCC->AHB1ENR, RCC->AHB1ENR | (RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOEEN));
        nx_arch_dsb();
    }
    if ((RCC->AHB1ENR & (RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOEEN)) != (RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOEEN)) { return NX_ERROR_IO; }
    nx_result_t status = nx_platform_pins_admit(false);
    if (status != NX_SUCCESS) { return status; }
    s_nx_platform_pin_state[0u] = nx_stm32_pin_capture(GPIOA, 9u);
    s_nx_platform_pin_state[1u] = nx_stm32_pin_capture(GPIOA, 10u);
    s_nx_platform_pin_state[2u] = nx_stm32_pin_capture(GPIOE, 3u);
    s_nx_platform_pins_captured = true;
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pins_release(void) {
    if (s_nx_platform_pins_captured) {
        {
            uint32_t mode = GPIOE->MODER;
            uint32_t driven = 0u;
            if (((mode >> 6u) & 3u) == 1u || ((mode >> 6u) & 3u) == 2u) { driven |= 192u; }
            if (driven != 0u) {
                NX_PLATFORM_REGISTER_WRITE(GPIOE->MODER, mode | driven);
                nx_arch_dsb();
                if ((GPIOE->MODER & driven) != driven) { return NX_ERROR_IO; }
            }
        }
        {
            uint32_t mode = GPIOA->MODER;
            uint32_t driven = 0u;
            if (((mode >> 18u) & 3u) == 1u || ((mode >> 18u) & 3u) == 2u) { driven |= 786432u; }
            if (((mode >> 20u) & 3u) == 1u || ((mode >> 20u) & 3u) == 2u) { driven |= 3145728u; }
            if (driven != 0u) {
                NX_PLATFORM_REGISTER_WRITE(GPIOA->MODER, mode | driven);
                nx_arch_dsb();
                if ((GPIOA->MODER & driven) != driven) { return NX_ERROR_IO; }
            }
        }
        if (nx_stm32_pin_capture(GPIOE, 3u) != s_nx_platform_pin_state[2u]) {
            nx_stm32_pin_restore(GPIOE, 3u, s_nx_platform_pin_state[2u]);
            nx_arch_dsb();
            if (nx_stm32_pin_capture(GPIOE, 3u) != s_nx_platform_pin_state[2u]) { return NX_ERROR_IO; }
        }
        if (nx_stm32_pin_capture(GPIOA, 10u) != s_nx_platform_pin_state[1u]) {
            nx_stm32_pin_restore(GPIOA, 10u, s_nx_platform_pin_state[1u]);
            nx_arch_dsb();
            if (nx_stm32_pin_capture(GPIOA, 10u) != s_nx_platform_pin_state[1u]) { return NX_ERROR_IO; }
        }
        if (nx_stm32_pin_capture(GPIOA, 9u) != s_nx_platform_pin_state[0u]) {
            nx_stm32_pin_restore(GPIOA, 9u, s_nx_platform_pin_state[0u]);
            nx_arch_dsb();
            if (nx_stm32_pin_capture(GPIOA, 9u) != s_nx_platform_pin_state[0u]) { return NX_ERROR_IO; }
        }
        s_nx_platform_pins_captured = false;
    }
    return nx_platform_gpio_clocks_release();
}
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 2u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 1u);
        nx_result_t status_0 = stop_uart1();
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 1u;
    }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = nx_stm32_gpio_stop(&s_nx_port_led0, 8u);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_result_t pins = nx_platform_pins_release();
    if (pins != NX_SUCCESS) { return pins; }
    nx_arch_dsb();
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started && nx_stm32_system_stop(&g_nx_stm32_system, 1000000u) != 0) {
        return NX_ERROR_IO;
    }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_stm32_system_preflight(&g_nx_stm32_system);
    if (result.primary != NX_SUCCESS) { return result; }
    if ((RCC->APB2ENR & (RCC_APB2ENR_USART1EN)) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if (((NVIC->ISER[(uint32_t)USART1_IRQn / 32u] | NVIC->ISPR[(uint32_t)USART1_IRQn / 32u] | NVIC->IABR[(uint32_t)USART1_IRQn / 32u]) & (1u << ((uint32_t)USART1_IRQn % 32u))) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    result.primary = nx_platform_pins_admit(true);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32_validate_identity(1048576u);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_platform_pins_acquire();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_gpio_clocks_release();
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    nx_stm32_start_result_t system = nx_stm32_system_start(&g_nx_stm32_system, 1000000u);
    if (system.primary != 0) {
        result.primary = NX_ERROR_IO;
        result.cleanup = system.cleanup == 0 ? NX_SUCCESS : NX_ERROR_IO;
        result.remaining_effects = system.remaining_effects;
        s_nx_platform_pins_captured = false;
        nx_result_t pins = nx_platform_gpio_clocks_release();
        if (pins != NX_SUCCESS) { result.cleanup = pins; result.remaining_effects = 1u; }
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    result.primary = prepare_led0();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 1u);
    result.primary = prepare_uart1();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 2u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        case NX_GPIO_ID_LED0:
            return nx_binding_led0;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_UART1:
            return nx_binding_uart1;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure lookup; no start or hardware access. */
const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
