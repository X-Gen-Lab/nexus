# Independent R3 activation fault review

Read-only review of `activation-fault-tests.cpp`, its extension patch, the
separate Native field declaration, README and manifest. No patch was applied;
no compiler, configure, tests, hardware-model handler or provider implementation
was executed or written. Factory review is outside this report.

The three cases have sound independent causes:

- **Failed unmask:** a real OUT request is accepted before the target IN mask
  bit is held at zero. The target has no request; DATA0/W1C faults remain off.
  IO/closing therefore tests the new post-control mask proof. Requiring target
  inactive/no EPENA, the same OUT request ACTIVE and the same retained clock
  distinguishes rollback from revoking another borrow. Withholding disable
  during explicit stop checks retention through the real drain path.
- **Failed withdrawal:** IN's mask bit is proved one before holding it. Refused
  clear and refused rollback remain distinguishable from endpoint token state.
  Requiring full stop BUSY, started=true and clock consumer1 until the fault is
  released is the correct source-withdrawal proof. The second explicit stop
  proves final recovery and clock release.
- **Failed INEPNE W1C:** cold init has already succeeded and target W1C flags
  are zero before hold_clear is set. SNAK can then latch bit6; requiring that
  bit still latched proves this fault was exercised. IO/closing, no target
  unmask/EPENA/request and retained clock are appropriate. Releasing hold_clear
  before stop avoids confusing the intended activation failure with recovery.

The separate field patch adds only `uint32_t hold_ep_mask_bits` to Native
hardware storage. It implements no success/failure logic. The test patch clears
that field in the existing fixture TearDown before stop. Each test also releases
its live faults before subsequent fatal ASSERTs; earlier ASSERT failures occur
before faults are set. Existing TearDown clears hold_clear/hold_disable, so the
fault paths do not create an artificial uncleanable fixture.

One small coverage improvement is recommended before sealing: compare all
unrelated EP_MASK bits, including both EP0 directions, rather than only OUT1
bit17 in the failed-unmask case. Capture the mask with target bit1 excluded and
compare that complete value after failure. In the failed-W1C case, compare the
whole original mask because no new target unmask is allowed; in the withdrawal
case the held bit remains one, so the whole original mask should remain equal.
This needs no additional case and prevents a faulty rollback from clearing EP0
routes while preserving the one observed OUT route. A `tx_count[1] == 0` check
in the unmask/W1C cases would also directly retain the no-payload-write boundary.

No other material causality, borrowed-storage lifetime or teardown hazard was
found. These remain unapplied contract proposals. An inert declaration/model
field is not executed fault evidence; root still must record actual RED, wire
the hardware-only leaf after RED, and obtain GREEN through the real DCD.
