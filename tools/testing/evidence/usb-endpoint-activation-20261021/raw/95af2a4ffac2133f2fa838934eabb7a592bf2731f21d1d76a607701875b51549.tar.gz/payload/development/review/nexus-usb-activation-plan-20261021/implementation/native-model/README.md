# Native mask fault leaf and SDK activation assertions

Root's actual runtime RED was read from
`/tmp/nexus-usb-activation-root-20261021/runtime-red-result.json`: successful
build, seven programs, 126 cases and 24 expected new failing cases. This agent
performed no compiler/configure/test execution. No primary/index files changed.

## Small hardware leaf

`native-mask-leaf.patch` changes only `io/native/usb_device.c`. The corresponding
after-image is under that relative path here. `manifest.json` binds exact before
and after bytes; apply only against the matching primary before-image.

The new register0x81c write leaf retains each old bit selected by
`hold_ep_mask_bits`; all other bits receive the ordinary write value. The
existing accessor write counter is incremented first. Fault value zero is the
old unmodified register-write behavior. No request, controller, epoch, clock,
active/PID/NAK, success return or completion condition is touched. Endpoint
summary flags are unchanged, as they already were on an ordinary mask write.

This supports both stuck-zero unmask and stuck-one withdrawal/rollback tests.
Root owns the declared field, test cleanup and actual future RED/GREEN runs.

## SDK assertions

`sdk-activation-assertions.patch` adds compile-time facts to the two real SDK
binding sources; it makes no executable driver change. Existing assertions
already bind endpoint layout/stride, active, DATA0, INEPNE/IEPNE, transfer type,
IN FIFO, packet count and IN NAK status. The small additions bind the newly
relied-upon target mask selection and missing control facts:

- ST: selected low-four IN/OUT mask bits, OUT offset16, IN/OUT SNAK/CNAK/STALL,
  and OUT MPS/NAK-status/enable/disable. No full family-wide mask-range claim.
- GD: selected low-four IN/OUT mask bits and shared IN/OUT SNAK/CNAK/STALL.
  Shared MPL/NAKS/EPEN/EPD are already asserted and need no duplicate.

The GD SDK mask contains more OUT bits than the selected FS configuration uses.
Checking coverage of the four selected directions avoids treating that broad
shared definition as proof of extra FS endpoint support.

Exact locked macro anchors:

| Header | Source lines |
| --- | --- |
| `vendors/st/cmsis_device_f4/Include/stm32f407xx.h` | DAINTMSK IEPM/OEPM :14376–14381; IN STALL/CNAK/SNAK :14669–14685; OUT MPS/NAK :14949–14957; OUT STALL/CNAK/SNAK/EPDIS/EPENA :14972–14986 |
| `vendors/gigadevice/gd32f4xx/Firmware/GD32F4xx_usb_library/driver/Include/drv_usb_regs.h` | DAEPINTEN selected IN/OUT masks :490–491; common SNAK/CNAK/STALL :522–525; existing common MPL/NAKS/active :528–532; existing IEPNE :537 |

Exact header SHA256 identities:

- ST: `ae1ab57d8ab750f64f04fd73476bc2760c761e18e45bde648e0bc350c9a1d9ac`.
- GD: `18aebc7f97d182f7366af5433ad3867328c25c08198a2e80fc64caddbf297685`.

Source identity/size is also in `manifest.json`. ST CMSIS belongs to the fixed
`cmsis_device_f4` checkout; GD belongs to locked Firmware Library3.3.3. These
assertions do not replace the already cited official manual sequence or establish
physical HIL behavior.

## Independent review focus for the parent

- The provider must preserve every unrelated target-mask bit on ordinary writes
  and rollback. A refused clear cannot release the clock during full stop.
- IN NAK-effective W1C failure must be caught before successful target unmask;
  activation itself must never start a packet or detach another request.
- The new Native block must remain before generic ordinary register storage and
  must not intercept endpoint W1C or core reset/flush operations.
- Run the same actual fault cases with field zero and with only the selected
  target bit held; avoid coupling this leaf to a specific API result.

No public ABI, MCU mutable state, worker, queue or provider implementation is
added by this artifact. Root alone applies and executes it.
