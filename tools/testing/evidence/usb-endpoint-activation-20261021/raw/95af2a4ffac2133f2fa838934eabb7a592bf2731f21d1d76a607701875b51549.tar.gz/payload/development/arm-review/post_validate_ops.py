"""Read-only, after-run validation of the six actual activation ops targets."""
from pathlib import Path
import hashlib
import json
import struct
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/tmp/nexus-quality-20261019')
OUT = Path('/dev/shm/nexus-usb-activation-arm-20261021')
DEST = Path('/tmp/nexus-usb-activation-arm-prep-20261021/ops-method-post-validation.json')
sys.path.insert(0, str(ROOT))
from tools.measurement.elf import Elf32
from tools.measurement.resources import resolved_float_abi


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def main():
    assert not DEST.exists(), 'append separate validation; never overwrite a prior result'
    report_path = OUT / 'selected/report.json'
    execution_path = OUT / 'execution.json'
    report_id, execution_id = identity(report_path), identity(execution_path)
    report = json.loads(report_path.read_text())
    execution = json.loads(execution_path.read_text())
    assert report['status'] == execution['status'] == 'passed'
    assert report['fixture_count'] == len(report['fixtures']) == 6
    assert execution['source_before'] == execution['source_after']
    rows = []
    for fixture in report['fixtures']:
        elf_path = Path(fixture['artifacts']['elf']['path'])
        resolved_path = Path(fixture['artifacts']['resolved']['path'])
        elf_id, resolved_id = identity(elf_path), identity(resolved_path)
        assert elf_id == fixture['artifacts']['elf']
        assert resolved_id == fixture['artifacts']['resolved']
        elf = Elf32(elf_path.read_bytes(), float_abi=resolved_float_abi(
            json.loads(resolved_path.read_text()), require_cpu=True))
        ops = [s for s in elf.defined_symbols if s['name'] == 'nx_usb_fs_activation_ops']
        assert len(ops) == 1 and ops[0]['type'] == 1 and ops[0]['size'] == 4
        symbol = ops[0]
        section = elf.sections[symbol['section']]
        assert section['flags'] & 2 and not section['flags'] & 1 and section['kind'] != 8
        offset = section['offset'] + symbol['value'] - section['address']
        assert section['offset'] <= offset and offset + 4 <= section['offset'] + section['size']
        pointer = struct.unpack('<I', elf.data[offset:offset + 4])[0]
        assert pointer & 1, 'Thumb method pointer required'
        address = pointer & ~1
        methods = [s for s in elf.defined_symbols if s['type'] == 2
                   and (s['value'] & ~1) == address]
        assert methods, 'ops pointer must resolve to a defined FUNC symbol'
        checked = []
        for method in methods:
            target = elf.sections[method['section']]
            assert method['size'] > 0
            end = address + method['size']
            assert target['flags'] & 2 and target['flags'] & 4 and not target['flags'] & 1
            assert target['kind'] != 8
            assert target['address'] <= address and end <= target['address'] + target['size']
            loads = [load for load in elf.loads if load['flags'] & 1
                     and not load['flags'] & 2 and load['virtual'] <= address
                     and end <= load['virtual'] + load['files']]
            assert loads, 'complete method must lie inside executable nonwritable LOAD file bytes'
            checked.append({'symbol': method, 'section': target,
                            'containing_executable_nonwritable_loads': loads})
        assert identity(elf_path) == elf_id and identity(resolved_path) == resolved_id
        rows.append({'fixture': fixture['assembly'], 'elf': elf_id,
                     'resolved': resolved_id, 'ops_pointer': pointer,
                     'thumb': True, 'methods': checked, 'status': 'passed'})
    assert identity(report_path) == report_id and identity(execution_path) == execution_id
    record = {'schema_version': 1, 'kind': 'read-only-post-validation',
              'status': 'passed', 'completed_ns': time.time_ns(),
              'scope': 'existing actual ARM links; no configure, compile, matrix rerun or physical execution',
              'original_supervisor': identity(Path(__file__).with_name('run_arm.py')),
              'validator': identity(Path(__file__)),
              'actual_execution': execution_id, 'actual_selected_report': report_id,
              'fixture_count': len(rows), 'fixtures': rows,
              'checks': ['ops pointer is Thumb and resolves to defined nonzero FUNC',
                         'full method is in file-backed ALLOC+EXEC, non-WRITE section',
                         'full method is within executable, nonwritable LOAD file bytes',
                         'ELF/resolved/report/execution identities match and remain unchanged'],
              'qualification': False, 'physical_status': 'not_executed'}
    DEST.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'status': record['status'], 'fixture_count': len(rows),
                      'result': identity(DEST)}))


if __name__ == '__main__':
    main()
