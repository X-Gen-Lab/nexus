import json,os,pathlib,sys,xml.etree.ElementTree as ET
ROOT=pathlib.Path('/tmp/nexus-quality-20261019');OUT=pathlib.Path(__file__).parent
sys.path.insert(0,str(ROOT))
from tools.dev.process import run
rows=[];results=[]
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_')}
env.update(NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1',PATH=str(ROOT/'.venv/bin')+':/tmp/nexus-quality-arm/bin:/tmp/nexus-quality-doc-tools/bin:/usr/local/bin:/usr/bin:/bin')
def execute(name,command):
 result=run(['flock','/tmp/nexus-platform-compiler.lock',*command],cwd=ROOT,env=env,log=OUT/(name+'.raw'),timeout=600,stage='activation-'+name)
 rows.append({'name':name,'exit_code':result.returncode,'receipt':str(result.receipt_path)})
 (OUT/'green-execution.json').write_text(json.dumps({'commands':rows,'programs':results},indent=2)+'\n')
 return result.returncode
code=execute('green-configure',[str(ROOT/'.venv/bin/python'),'tools/dev/dev.py','configure','--preset','native-debug'])
if code:raise SystemExit(code)
manifest=json.loads((ROOT/'build/native-debug/google-contracts.json').read_text())
names=sorted(pathlib.Path(p).name for p in manifest['executables'] if 'usb' in pathlib.Path(p).name)
assert len(names)==12
code=execute('green-build',['cmake','--build','build/native-debug','--target',*names,'--parallel','1'])
if code:raise SystemExit(code)
failed=False
for name in names:
 report=OUT/(name+'-green.xml');assert not report.exists()
 code=execute(name+'-green',[str(ROOT/'build/native-debug/bin'/name),'--gtest_filter=*','--gtest_repeat=1','--gtest_also_run_disabled_tests','--gtest_output=xml:'+str(report)])
 xml=ET.parse(report).getroot()
 record={'program':name,'cases':int(xml.get('tests','0')),'failures':int(xml.get('failures','0')),'errors':int(xml.get('errors','0')),'disabled':int(xml.get('disabled','0')),'skipped':len(list(xml.iter('skipped'))),'exit_code':code}
 results.append(record)
 failed=failed or code!=0 or record['cases']==0 or any(record[k] for k in ('failures','errors','disabled','skipped'))
(OUT/'green-execution.json').write_text(json.dumps({'commands':rows,'programs':results,'cases':sum(x['cases'] for x in results),'status':'failed' if failed else 'passed','scope':'12 whole USB Google programs only; no complete-index/physical acceptance'},indent=2)+'\n')
print(json.dumps(results),flush=True)
raise SystemExit(1 if failed else 0)
