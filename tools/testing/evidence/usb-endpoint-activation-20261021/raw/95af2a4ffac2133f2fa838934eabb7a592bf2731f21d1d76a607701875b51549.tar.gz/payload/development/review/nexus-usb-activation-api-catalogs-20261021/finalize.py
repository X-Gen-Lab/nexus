"""Promote owned reviewed catalog candidates without primary/index writes."""
from pathlib import Path
import difflib
import hashlib
import importlib.util
import json
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path('/tmp/nexus-quality-20261019');OWN=Path(__file__).resolve().parent
REVIEW=Path('/tmp/nexus-usb-activation-api-catalog-review-20261021/review.json')
sha=lambda data:hashlib.sha256(data).hexdigest()
def rec(path):
 data=path.read_bytes();return {'path':str(path),'sha256':sha(data),'bytes':len(data)}
spec=importlib.util.spec_from_file_location('actual_live_catalog_reader',ROOT/'tools/documentation/sphinx_ext.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
read_catalog=module.read_catalog
packet_path=OWN/'review-input.json';packet=json.loads(packet_path.read_text());review=json.loads(REVIEW.read_text())
assert review['status']=='ACCEPT'
assert review['review_input_sha256']==sha(packet_path.read_bytes())
assert review['candidate_patch_sha256']==packet['patch']['sha256']==sha(Path(packet['patch']['path']).read_bytes())
extraction=json.loads(Path(packet['extraction']['path']).read_text())
for relative,digest in extraction['after'].items():assert sha((ROOT/relative).read_bytes())==digest
_,expected,_=read_catalog(Path(packet['POT']['path']))
files=[];diffs=[]
for row in packet['files']:
 source=Path(row['before']['path']);candidate=Path(row['candidate']['path']);old=source.read_bytes();raw=candidate.read_bytes()
 assert sha(old)==row['before']['sha256'] and sha(raw)==row['candidate']['sha256']
 text=raw.decode();assert text.count('X-Nexus-Reviewed: false')==1
 final=text.replace('X-Nexus-Reviewed: false','X-Nexus-Reviewed: true',1)
 relative=row['relative_path'];destination=OWN/'final'/relative;destination.parent.mkdir(parents=True,exist_ok=True);assert not destination.exists();destination.write_text(final)
 metadata,messages,fuzzy=read_catalog(destination);assert metadata['X-Nexus-Reviewed']=='true' and not fuzzy and all(messages.values()) and set(messages)==set(expected)
 assert metadata['X-Nexus-Source-SHA256']==row['source']['sha256']
 oldheader=old.decode().split('\n\n',1)[0];newheader=final.split('\n\n',1)[0]
 assert oldheader.replace(row['header_changes']['X-Nexus-Source-SHA256']['before'],row['header_changes']['X-Nexus-Source-SHA256']['after'],1)==newheader
 files.append({**row,'final':rec(destination),'candidate_to_final':'Only Reviewed:false to true after independent semantic/hash/closure ACCEPT. Source SHA remains honestly updated; all other original header bytes identical.'})
 diffs.append(''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),final.splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative)))
 assert source.read_bytes()==old
patch=OWN/'final-catalogs.patch';patch.write_text(''.join(diffs))
result={'kind':'USB_activation_reviewed_API_catalog_delivery','status':'ready_for_root_apply','created_ns':time.time_ns(),'review_input':rec(packet_path),'independent_review':rec(REVIEW),'extraction':packet['extraction'],'POT':packet['POT'],'public_header':packet['public_header'],'source':packet['source'],'files':files,'patch':rec(patch),'totals':{'catalogs':2,'new_pair_occurrences':22,'obsolete_pair_occurrences':0,'retained_raw_blocks':3066},'unchanged_raw_blocks':packet['unchanged_raw_blocks'],'header_sourcehash_change':{'before':'73a3d84a77d809cc222cc4cf065cb50c88f594ccbcb2e74562cbd652ecf52898','after':'5d2e781ea5e0e1bfb26f6e08f96913088436932c25ef064adf27cce2f7ad4778','reason':'Actual existing API page includes eight new public-header declaration lines.'},'no_primary_or_index_writes':True,'no_compiler_configure_gettext_tests_or_site_execution':True,'qualification':'Reviewed message/source/byte closure from the actual two-command API extraction only. Root must apply and execute later complete strict bilingual build; not HTML/site/HIL or current provider execution evidence.'}
p=OWN/'final-catalogs.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'delivery':rec(p),'patch':rec(patch),'independent_review':rec(REVIEW),'totals':result['totals']},ensure_ascii=False))
