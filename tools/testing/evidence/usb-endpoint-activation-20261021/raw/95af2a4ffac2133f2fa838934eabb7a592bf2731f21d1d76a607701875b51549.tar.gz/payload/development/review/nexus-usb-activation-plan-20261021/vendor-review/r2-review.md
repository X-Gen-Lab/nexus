# Factory integration: small real generated-getter tests

Read-only inspection of `tests/google/usb_factory_test.cpp`,
`usb_factory.cmake`, `tools/configure/factory.py` and `usb_profiles.py`.
No primary/index writes, compiler, configure or tests. This is a test integration
recommendation, not executed evidence.

## Recommended integration

Preserve both existing factory programs and every existing lifecycle/profile/
capability case. Append the new pure activation-getter case to those existing
capabilities-true programs. Add only **two getter-only programs**, STM32F407 and
GD32F470, generated with capabilities=false. No additional F407VE host program
is necessary for this generator contract; current assembly/tool and ARM checks
can cover the other board without duplicating the same host fixture.

The existing C++ source contains external clock/pin/system model hooks and the
`UsbFactory` fixture before its first TEST_F. The clean small reuse is:

1. Move that fixture prefix, unchanged, into `usb_factory_fixture.h`.
2. Put just the new TEST_F into `usb_activation_factory_cases.h`.
3. Existing `usb_factory_test.cpp` includes the fixture header and the new case
   header, retaining all its existing tests.
4. New `usb_activation_factory_test.cpp` includes those same two headers and
   nothing that registers unrelated lifecycle/profile tests.

Each executable then has exactly **one C++ translation unit**. This is important:
the fixture currently defines external C hooks plus private `s_ports`/pin/hold
state. Do not compile two sources that both include those hook definitions into
one executable, and do not split the hooks and fixture into headers with separate
TU-local `s_ports` variables. That causes duplicate definitions or hooks reading
the wrong mock state. A larger support .cpp/.h extraction is unnecessary here.

This adds no framework, runtime skip, SFINAE or GTest filter. Original programs
keep their full registration set; new programs register only their new, explicit
contract. Prefer this to surrounding old tests with a getter-only macro, which
is shorter but makes test-retention intent harder to audit.

## One meaningful pure getter case

Run while the existing fixture has never called `nx_platform_start`:

- Record hardware MMIO read/write counters, the modeled clock register bytes,
  controller `snapshot.started` and `clock_retained`, and NVIC state.
- Expect zero calls to external Preflight, Start, Stop, EnableClock, Configure,
  Capture and Restore across the lookup itself. Verify/clear those expectations
  before ordinary fixture teardown, which legitimately calls platform stop.
- Obtain `nx_factory_usb_activation(NX_USB_DEVICE_ID_FS)` and require non-NULL.
  Repeated lookup must return exactly the same face pointer.
- Its ops must be the shared `nx_usb_fs_activation_ops`; its context must equal
  `nx_factory_usb_device(...)->context` / the existing `state`, and differ from
  the bulk endpoint context. Do not require a new controller/private-array name.
- Invalid COUNT and UINT16_MAX IDs return NULL. Repeat the no-effects/state/
  counter checks after all lookups. No activation method should be invoked by
  this pure factory case.

Use the exact same case in capabilities=true and false programs. The true
programs retain the existing real profile/capability tests. The false programs
must compile the actual generated bindings, not hand-authored substitute faces.
The absence of profile APIs under capabilities=false is checked naturally by
not including unrelated profile-dependent test bodies, and can retain the
existing focused Python public-output opt-out check.

MMIO counters observe the model's controller access boundary; snapshots and mock
calls establish no modeled clock/pin/start effects. They do not independently
instrument every possible raw vendor register read, so do not overstate that
runtime evidence as a proof about arbitrary hidden direct reads. The generated
getter body is also inspected as the simple static lookup under test.

## CMake scope and cost

Extend the existing `usb_factory.cmake` family loop with a small, explicit
capabilities-false generation/target variant. Keep the true target names and
sources unchanged except the new test case. False targets use
`usb_activation_factory_test.cpp`, the same SDK binding/clock sources, NativeModel
and existing forced model headers/definitions. They add one small C++ compile and
the needed generated/SDK C sources per family, while reusing the already-built
GoogleTest/NativeModel/Arch libraries. Do not build or execute all old lifecycle
cases again under capabilities=false.

Create the false TOML input in the build tree from the existing fixture, changing
only factory capabilities and resolving `board_package` to the existing absolute
board fixture path. A copied assembly cannot retain the original relative board
path while moving to a different directory. Track the **original** assembly and
board inputs in CMAKE_CONFIGURE_DEPENDS as well as generated input_paths.json;
fail generation normally. Do not edit the frozen authored assembly files.

No custom test discovery/filter or extra success-report cache is needed. Register
the new executables through ordinary `nexus_google_test`, so nonzero discovery,
fresh result admission and ordinary complete-index gates apply unchanged.

## Runtime RED bootstrap

The new generated getter must have an ordinary declaration and an inert
all-ID-NULL body before recording actual runtime RED. Put that minimal scaffold
in the generic generator path, outside optional ROM profile/capability emission;
it emits no activation face, context allocation, hardware access or lifecycle
behavior. The real getter test then compiles, runs and fails its non-NULL
selected-ID assertion. A missing declaration/link symbol is not runtime RED.

Do not define a fallback getter inside the test, use weak-link selection,
conditionally omit the case, or manually fabricate generated bindings. After
recorded RED, replace the generic NULL body with the real selected-controller
face emission and rerun the exact same tests. The existing NULL-set provider
scaffold remains the separate runtime-operation RED boundary.

Remove the proposed Python private-array/context-name assertions. A small public
header/getter-emission check can remain, but actual generated identity, invalid
IDs, context sharing and no startup effects now belong to these real programs.
