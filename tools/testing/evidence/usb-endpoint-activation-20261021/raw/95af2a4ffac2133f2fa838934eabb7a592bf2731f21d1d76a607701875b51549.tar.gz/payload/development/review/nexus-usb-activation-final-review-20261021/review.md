# Independent USB activation review

Read-only source review, 2026-10-21. Reviewer: separate activation_final_code_review
agent. No primary/index writes, build, configure, tests or hardware execution.
`reviewed-source.json` records exact reviewed bytes. Runtime results cited below
were executed by root, not this reviewer.

## Verdict

**No additional blocking activation defect found.** Final acceptance requires the
already identified raw USBRST admission guard and its actual RED/GREEN regression.
The current snapshot still has that known guard gap in `submit`; this review does
not approve shipping the gap. The root has assigned the regression separately.
After that narrow correction, the activation mechanism is acceptable within the
software scope stated here; root retains responsibility for complete-index, ARM,
strict bilingual and remote gates.

## Source and contract checks

- Public extension is an additive immutable two-pointer face. Its one shared
  read-only operation receives existing controller context. Existing USB device
  and endpoint tables, profile layout, ABI epoch and typed IR are not enlarged.
- Factory generation occurs outside `factory.capabilities`. Selected objects are
  static const faces over existing state; switches return identity or NULL. No
  initialization, MMIO, locks, allocation or runtime discovery is generated.
- Private controller/endpoint fields are unchanged. The sole added fault field
  belongs to the Native hardware leaf and cannot expand firmware state.
- Cold start reserves selected FIFO geometry but leaves nonzero ACTIVE clear and
  endpoint masks at EP0 only. All directions are bound to controller before a
  cold MMIO failure could transfer cleanup responsibility. IN/OUT EP0 retain
  their distinct PID/SETUP handling.
- Setter validates selected nonzero address, Task privilege/incoming masks,
  started/retained/closing state, expected epoch and reset before effects. Cold
  epoch zero is valid. Target loans, disables, pending flags, hardware enable,
  FIFO/reset activity require explicit owner progress. Rejection does not
  acknowledge a raw event or borrow storage.
- Fresh enable programs immutable MPS, type, IN-only FIFO number, DATA0, ACTIVE
  and SNAK. It never writes transfer size, payload or EPENA. Complete geometry,
  PID, NAK status and per-direction mask readback precede SUCCESS.
- Already-active enable verifies geometry without DATA0/HALT replay. Disable
  does not revoke loans or infer token withdrawal from an interrupt mask alone.
  Its mask RMW preserves every other direction, including EP0.
- Post-command hint cleanup admits only new known idle IN 0x50 hints. Preexisting
  endpoint flags remain a no-write BUSY condition requiring ordinary service.
  XFRC, EPDISD and errors cannot become false activation success.
- Task acknowledgement uses existing finite poll_limit. Reset IRQ withdrawal
  chooses the single-observation branch, retaining reset_pending for retry;
  no cold wait_bits loop is introduced in IRQ reset progress.
- Partial write failure closes admission. Rollback attempts safe ACTIVE withdrawal
  even when mask proof fails; it never force-clears an unexpected EPENA. Other
  loans, quarantine and clock responsibility remain until actual stop proof.
- Reset waits for all attached request pointers to detach, both FIFO flushes and
  halt/PID proofs before nonzero software withdrawal. Complete withdrawal gates
  clearing reset_pending. Both families deliberately get this platform behavior;
  GD silicon automatic ACTIVE clearing is not inferred from ST documentation.
- Source SDK required files include the additive public header. Firmware remains
  C11 and allocation-free; tests remain host-only GoogleTest/GoogleMock.

## Exact vendor comparison

Compared actual locked ST `stm32f4xx_ll_usb.c` activation (598-630), GD
`drv_usb_dev.c` activation (250-296), CMSIS/SPL register masks, and the existing
manual fact transcripts under `nexus-usb-activation-plan-20261021/vendor-review`.
The implementation preserves the useful split between configuration-active,
packet-enable and borrow release. It avoids GD SDK's OUT expression that writes
reserved IN-FIFO bits and strengthens the SDK helpers' unproved return semantics
with explicit status/source proofs. Reviewed references are RM0090 Rev22
34.16.4/34.17.5/34.17.6 and GD32F4xx Rev3.3 chapter28.7.3, with exact source hashes
already retained in the vendor-review packet. No new manual download occurred.

## Known correction and final cleanup

`submit()` currently checks only software reset_pending and actual ACTIVE. Raw
USBRST can precede IRQ collection while GD still exposes ACTIVE. Before any
request admission or hardware write, reject that observed raw reset with STATE,
keep READY/no borrow/no FIFO effect, and leave the event for ordinary collection.
This is already assigned and is the only known blocking behavior in this snapshot.
It does not imply a wire-atomic transaction: a later physical reset remains
asynchronous and must be handled through normal drain ownership.

Remove two obsolete test comments saying the cases are "Unapplied". They describe
previous patch preparation and are inaccurate in integrated source. No case or
assertion should be removed.

## Evidence limits

Root's `green-r2-execution.json` records 12 complete programs / 210 cases with
zero failures/errors/skips for this pre-raw-guard snapshot. This report does not
replace new actual RED/GREEN, full ordinary gates, ARM resource/link proofs,
clean-main formal qualification or physical HIL. Configuration/class selection,
status readiness and rollback policy remain external; no complete Chapter9,
Host/HS/DMA/ISO or full USB-stack support is inferred.

## Final raw-reset correction review

**ACCEPT** for the source bytes in `final-acceptance.json`. The sole previously
blocking gap is fixed. `submit` checks the raw INTERRUPT USBRST bit12 under the
existing local IRQ guard before `request_valid`, `nx_request_admit`, loan
attachment and all MMIO writes. It returns STATE, restores the incoming mask,
and leaves the hardware latch and software epoch untouched for normal IRQ
collection. Short-circuit stopped/closing state prevents unwanted MMIO access.
The fix adds one bounded volatile read per packet attempt, no extra mutable
state, acknowledgement, service call or hidden reactivation.

The regression covers Native IN/OUT nonzero and both EP0 directions, plus the
same selected bulk IN/OUT paths compiled against each actual SDK context. It
keeps ACTIVE deliberately set while publishing only the raw external latch,
so success cannot depend on ST silicon reset clearing. It asserts READY, no
borrow, no writes/FIFO/size/control/mask change, retained raw event/epoch and
clock. Both request and payload are fixture-owned. Real stop joins a possible
accepted RED request before row reuse, avoiding a dangling-loan test artifact.
Root recorded build0 and exactly3 failing cases in98 whole-program RED cases,
then12 whole-program GREEN /213cases with zero failures/errors/skips. Their
summary bytes are referenced and hashed, not executed again by this reviewer.
The obsolete Native Unapplied comments were removed without case deletion;
a matching SDK preparation comment was separately flagged for cosmetic cleanup.

No additional source blocker is outstanding. This ACCEPT remains a code-review
result. Ordinary full-index gates, ARM image costs, strict bilingual documents,
remote checks and physical HIL are separate evidence.
