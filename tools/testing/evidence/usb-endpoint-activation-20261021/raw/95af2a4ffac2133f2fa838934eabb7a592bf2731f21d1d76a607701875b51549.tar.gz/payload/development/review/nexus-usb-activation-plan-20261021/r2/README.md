# Factory test successor — test-only revision 2

This supersedes only the factory/generator test portion of the original planning
packet. The original packet and manifest remain unchanged. No patch is applied,
no primary/index is written, and no compiler/configure/tests are executed here.

Removed the Python test that asserted private endpoint/event array spellings and
the count of a private controller declaration. Its assertions mirrored generated
implementation and did not prove actual instance identity or side-effect-free
lookup. The remaining one Python method checks only the authored-output contract:
the public activation getter/header is emitted with capabilities true or false;
optional ROM-profile output still follows its opt-out.

The replacement is one real GoogleTest case against actual generated bindings:

- The returned activation face is stable and non-NULL for the selected controller.
- Its context is exactly the existing public USB device face's context; its ops
  is the actual shared table, and invalid typed IDs return NULL.
- All external system/clock/pin startup hooks expect zero calls. Actual USB MMIO
  access counters and modeled NVIC bytes remain unchanged, with controller
  started/clock-retained false.
- Clock/peripheral and USB hardware mappings are PROT_NONE during getter calls,
  so even direct MMIO reads cannot hide behind unchanged register values.
  A small local RAII guard restores both mappings on normal and fatal-assertion
  paths, including the expected initial NULL-getter RED before fixture teardown.

The existing STM32/GD factory programs include this new case without removing or
filtering any original lifecycle/profile/capability test. Two getter-only
capabilities-false executables use the same exact-moved fixture and the same
single case. They do not rerun the unrelated lifecycle suite or contain runtime
skips, SFINAE, feature-discovery branches or test-disabling macros. Current
authored Native configuration has no selected USB provider; adding a fabricated
Native provider solely for this test would enlarge the platform scope.

The shared fixture extraction moves the existing external hooks and UsbFactory
class byte-for-byte, bounded by `extern "C" {` and the first TEST_F. Only file
metadata/include guards are new; all existing test bodies remain unchanged.
`manifest.json` records before/successor hashes and the exact moved region hash.
The CMake fixture still starts from each canonical USB assembly, deriving only
an out-of-source test variant with an absolute board path and capabilities=false.
No canonical TOML, production IR or provider behavior is changed by the test patch.

`contract-tests-r2.patch` is the complete TEST-ONLY successor against the recorded
primary source: the original Native/SDK contract cases, one authored-output
Python method, exact shared fixture extraction, the actual getter case and two
getter-only target memberships. It replaces, rather than stacks on top of, the
original `contract-tests.patch`.

`inert-factory-getter-scaffold.patch` is a separately labeled declaration/inert
bootstrap: the generator emits the new public declaration and a getter returning
NULL for every ID. It emits no activation face/context, performs no registration
or hardware behavior, and advertises no implemented capability. Apply alongside
the original declaration-inert-scaffold.patch if root wants all real factory
cases to compile for runtime RED before implementing any provider/generator
activation behavior. The actual getter test must then fail on non-NULL identity,
with RAII restoring mappings before teardown. This is a future execution plan,
not an observed failing run.

The getter-only executables add exactly one runtime case per existing SDK. The
two original SDK factory target names and every original test body are retained.
Before production behavior, root will review the diff size, capture actual whole
program RED and have the extraction independently reviewed.

Root separately recorded actual generator runtime RED at
`/tmp/nexus-usb-activation-config-red-20261021/verified-red.json`: original two
control methods passed and the missing public getter produced six expected
failures across three part fixtures and both capabilities settings. This agent
has not re-executed it. Root delegated functional generator after-images to
`/root/activation_factory_implementation`; this packet changes no generator
behavior. The inert getter patch remains optional if root needs a default-NULL
factory bootstrap for a later whole-program GoogleTest RED capture.
