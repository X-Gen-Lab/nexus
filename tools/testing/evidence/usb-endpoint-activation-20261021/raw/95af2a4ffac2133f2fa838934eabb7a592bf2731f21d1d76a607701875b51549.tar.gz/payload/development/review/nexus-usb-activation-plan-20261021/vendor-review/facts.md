# USB nonzero endpoint activation: independent source facts

Read-only review of `/tmp/nexus-quality-20261019`, 2026-10-21. No primary
source/index edits, compiler, configure, tests or physical station execution.
This report supports planning the next generic endpoint mechanism. It does not
qualify hardware or close the external USB configuration/class path.

## 1. Three different states must remain distinct

1. **Active in a configuration:** ST `USBAEP` / GD `EPACT`, bit 15.
   An inactive nonzero endpoint ignores addressed tokens. ST explicitly says
   this produces a timeout; it is different from an active endpoint returning
   NAK while it has no admitted packet.
2. **One packet/transfer enabled:** ST `EPENA` / GD `EPEN`, bit 31. A packet
   start programs transfer size/count, then enables the endpoint and clears
   NAK. Activation itself is not packet admission or a buffer loan.
3. **Software storage released:** requires Nexus's independent hardware/IRQ/
   FIFO quiescence and final-access publication. Neither clearing active nor
   masking its interrupt proves that storage can be reclaimed.

Exact register facts:

| Field | ST F407 / GD F470 USBFS |
| --- | --- |
| MPS / MPL | bits 10:0 for nonzero endpoints |
| active | bit 15 |
| DATA PID | bit 16 for bulk/interrupt |
| NAK status | bit 17 |
| endpoint type | bits 19:18: bulk 2, interrupt 3 |
| IN FIFO number | bits 25:22; OUT bits 25:22 are reserved |
| clear/set NAK command | bits 26 / 27 |
| DATA0 command | bit 28 for bulk/interrupt; ISO has a different alias |
| disable / enable | bits 30 / 31 |

Locked definitions are `vendors/st/cmsis_device_f4/Include/stm32f407xx.h:14650`
through `:14697`, and
`vendors/gigadevice/gd32f4xx/Firmware/GD32F4xx_usb_library/driver/Include/drv_usb_regs.h:515`
through `:532`. Bit 29 must not be introduced for the selected bulk/interrupt
mechanism. EP0 has special MPS encoding/reserved PID fields and must not use a
generic nonzero activation operation.

## 2. Official ST activation and deactivation

ST RM0090 Rev22, §34.16.4, DIEPCTLx printed pp1299–1301 and DOEPCTLx
pp1303–1305:

- `USBAEP` represents membership of the current configuration/interface.
- Hardware clears `USBAEP` for every endpoint except EP0 after USB reset.
- Following SetConfiguration/SetInterface, the application programs endpoint
  characteristics and sets `USBAEP`.
- The first bulk/interrupt PID must be explicitly initialized after activation.
  `SD0PID` writes DATA0 into the read-only observed PID field.
- `EPDIS` is only valid when `EPENA` is already set. Software must wait for
  endpoint-disabled notification before treating that transfer as disabled.
  Hardware clears EPENA/EPDIS before reporting endpoint disabled.

Precise cached text anchors: `/tmp/nexus-f407-i2s2-slave-20261020/research/rm0090.txt`
`:80585–80619`, `:80664–80680`, `:80914–80931`.

ST §34.17.5, printed pp1342–1343, gives an explicit split:

- Activation programs MPS, active=1, start toggle, type and the IN TxFIFO
  number (`rm0090.txt:85222–85236`). The core then decodes tokens and responds.
- Deactivation clears active; later tokens are ignored
  (`rm0090.txt:85244–85250`).
- Configuration switching programs only endpoints valid in the new selection,
  deactivates obsolete directions, and unmasks active/masks inactive endpoint
  interrupts in DAINTMSK (`rm0090.txt:85204–85220`).

**Timing correction:** this reference explicitly configures required endpoints
**before programming the status IN packet**, at step 6. It does not require
activation after the status ACK. A future external policy can distinguish staged
hardware configuration from application readiness after status completion, but
must not describe after-ACK activation as a fact proved by this manual.

DAINTMSK is only an interrupt-delivery mask. The corresponding DAINT status can
still be set while masked (`rm0090.txt:80337–80359`, printed p1296). Therefore
masking alone is neither token withdrawal nor pending-event cleanup.

The official ST LL implementation is pinned at submodule commit
`b6f0ed3829f3829eb358a2e7417d80bba1a42db7`:

- `vendors/st/stm32f4_hal/Src/stm32f4xx_ll_usb.c:598–630`,
  `USB_ActivateEndpoint`: enables the endpoint's DAINT mask; if inactive,
  programs MPS/type/IN FIFO/DATA0/active. It does **not** set EPENA or borrow
  a transfer buffer.
- `:675–715`, `USB_DeactivateEndpoint`: if EPENA is set, writes SNAK then
  EPDIS; masks its interrupt and clears active/config fields. It returns
  `HAL_OK` without waiting for EPDISD, FIFO flush or any readback. This helper
  is evidence for register intent, not sufficient proof for Nexus settlement.
- `:1104–1125`, `USB_EPClearStall`: clears STALL and resets bulk/interrupt
  DATA0. It does **not** reactivate the endpoint.

The manual's transfer-disable sequence is stronger than that LL helper:

- IN: stop writes, SNAK, observe NAK effective, EPDIS, observe EPDISD and
  EPENA clear, then flush that endpoint's FIFO and observe flush completion
  (`rm0090.txt:85899–85926`, printed p1355).
- OUT: global OUT NAK, observe effective, then EPDIS+SNAK; observe EPDISD/
  EPENA clear before releasing global OUT NAK
  (`rm0090.txt:85493–85510`, printed p1349).

## 3. Official GD activation and deactivation

GD32F4xx User Manual Rev3.3 **chapter 28 / §28.7.3**, not chapter 29:

- DIEPxCTL pp988–990: active=0 ignores all tokens and gives no response.
  SD0PID clears DPID; EPEN controls transfer enable. Cached text
  `/tmp/nexus-usb-interrupt-plan-20261021/dcd-review/gd32-manual.txt:56524–56610`.
- DOEPxCTL pp992–994 has the same active/PID semantics, but reserves
  bits25:22 (`gd32-manual.txt:56817–56902`).
- §28.5.6 p941 separates endpoint characteristics/interrupt configuration from
  transfer length/count and setting EPEN
  (`gd32-manual.txt:53245–53268`).
- The p941 disable prose says the endpoint can be disabled when EPEN is
  cleared; it is not a sufficient software-command/ordering recipe by itself.
  The endpoint control register also defines the separate EPD request bit.
- EPDIS flags report software-requested endpoint disable for IN and OUT
  (`gd32-manual.txt:56989–56991`, `:57071–57073`, pp995–996).

**No GD bus-reset-clears-EPACT assertion is established by the reviewed text.**
Do not transplant the explicit ST reset fact into GD hardware status or HIL.
Nexus may deliberately clear active on reset as its own platform behavior, but
that would be a separately implemented and tested contract.

GD library version 3.3.3 is locked by
`vendors/gigadevice/gd32f4xx/source.lock.json`. Exact driver:
`Firmware/GD32F4xx_usb_library/driver/Source/drv_usb_dev.c` below its root:

- `:211–241`, `usb_transc0_active`, handles control EP0 separately and notes
  that endpoint0 is active after the USB clock is enabled.
- `:250–296`, `usb_transc_active`, programs inactive MPS/type/IN FIFO/DATA0/
  EPACT and then unmasks the endpoint interrupt. It does **not** set EPEN.
  Its shared raw expression also shifts the endpoint number into bits25:22
  for OUT, although the manual reserves those OUT bits. Use the official
  direction-specific register definition; do not copy that expression blindly.
- `:305–331`, `usb_transc_deactivate`, clears EPACT and masks its interrupt.
  It issues no EPD request, waits for no flag and flushes no FIFO. Returning
  USB_OK therefore proves no outstanding-buffer quiescence.
- `:510–531`, clear-stall resets DATA0 for bulk/interrupt and does not set
  EPACT. Reset/halt/submit should not silently substitute for activation.

Library policy is already outside the low-level driver: device core
`device/core/Source/usbd_core.c:102–128` resolves descriptor metadata then
calls `usb_transc_active`; `:140–155` calls deactivate. Standard-request
`device/core/Source/usbd_enum.c:681–723` invokes class init/deinit and owns the
configuration value/state. Nexus need not import that product/class layer.

## 4. Pinned Zephyr comparison

Downloaded only five small reference files, all at existing Nexus reference
commit `dccb09599635bdff17633fa7e9dab014b91dce90` (v4.4.2). Exact URL/hash/size
records are `zephyr-sources.json`; local copies are under `zephyr/` here.

- `include/zephyr/drivers/usb/udc.h:559–595`: public endpoint enable/disable
  configure readiness separately and exclude control IN/OUT. `:661–680`
  separately defines dequeue/releasing claimed buffers and requires a disabled
  endpoint. Deactivation is not an implicit buffer-return event.
- `drivers/usb/udc/udc_dwc2.c:1319–1387`: nonzero activation programs MPS,
  bulk/interrupt DATA0, type, dedicated FIFO, active and interrupt mask.
  EP0 dispatches to a different helper. No EPENA is introduced there.
- `:550–575`: packet start rejects inactive before FIFO write, then separately
  sets EPENA/CNAK. The source explains that writing an unassigned inactive
  endpoint FIFO could corrupt another endpoint's FIFO.
- `:1437–1539`: transfer disable handles NAK-effective/endpoint-disabled
  progress; OUT withdrawal is coordinated through global OUT NAK.
- `:1548–1581`: deactivate first requests disable, then clears active and
  masks endpoint interrupts. `:1675–1697` separately disables and returns
  queued buffers through completion events.
- **Do not copy weak error semantics:** the wait at `:1536–1539` only logs a
  100ms timeout; `udc_dwc2_ep_deactivate` subsequently returns 0. Nexus must
  keep its stronger no-proof/no-release contract rather than infer success.
- `subsys/usb/device_next/usbd_config.c:74–138` owns configuration switch,
  interface teardown/default setup and class enable outside the DCD.
  `usbd_ch9.c:113–165` invokes it from the standard-request handler, before
  later status completion handling (`:1256–1262`). This is also not evidence
  for mandatory after-ACK activation.

The useful precedent is separation of configuration policy, endpoint activation,
transfer enable and buffer dequeue. Zephyr's queues, worker/event objects,
allocation and runtime descriptor policy are not required for Nexus's selected
statically assembled, one-packet mechanism.

## 5. Consequences for the parent's small mechanism plan

- Expose only an already-selected nonzero direction; immutable MPS/type/FIFO
  remain authoritative. No runtime descriptors, interval scheduling, standard
  request decoder, extra queue or board routing inference is needed.
- Cold initialization can reserve/program FIFO layout while leaving nonzero
  directions inactive. EP0 remains available for control. Enabling later must
  initialize DATA0 and make the endpoint active/NAK-ready, not arm a packet.
- A minimal synchronous enable/disable can require no attached request and no
  pending packet/drain/reset. Return BUSY/STATE before effects otherwise;
  external code cancels, services and observes final settlement first. This
  avoids turning deactivate into an unbounded drain operation.
- Serialize task control against IRQ and admission under existing ownership/
  incoming-mask contracts. Validate before writes; read back active, PID,
  MPS/type/FIFO and endpoint interrupt selection before reporting success.
- If activation partially writes then readback fails, successful rollback must
  be proved. Otherwise keep admission closed and expose explicit recovery.
  A rejected/failed control does not revoke any pre-existing request loan.
- Per-direction operations are the smallest hardware-honest primitive. Multiple
  MMIO endpoints do not become atomic through a batch API. External policy can
  stage a set and recover on partial failure; do not promise bus-visible atomic
  configuration or roll back a live request by clearing a software flag.
- Reset, clear-halt and submit must not silently autoactivate. The existing
  inactive-admission regression is a permanent ownership/FIFO safety boundary.

## Source identity

`source-hashes.json` records exact inspected SDK, controller, design and manual
text bytes. GD PDF hash was streamed from its existing local cache; no PDF was
downloaded or parsed in this task. ST reference identity remains repository
`soc/stm32f407/references.json`:
`f3ff2322eec21f4e49081f68481b764506eee81dba6031bc767e2f8955b27cca`.
GD official PDF is
`c8e1d20d7cde338892d08dcb233345e03f7960256a60a36c755c576d9cd65c13`.

Official URLs:
<https://www.st.com/resource/en/reference_manual/dm00031020.pdf> and
<https://www.gd32mcu.com/data/documents/userManual/GD32F4xx_User_Manual_Rev3.3.pdf>.
