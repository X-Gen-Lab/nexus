# Declaration and inert dispatch scaffold — not activation implementation

`declaration-inert-scaffold.patch` is a separate, unapplied bootstrap patch.
Root explicitly requested this artifact so the contract GoogleTests can compile
and fail at runtime before any activation behavior is written. It adds:

- One public declaration header defining the optional two-pointer face and API.
- A thin dispatch wrapper with existing INVALID / absent-method UNSUPPORTED
  conventions, in the already built `io/src/usb_device.c` translation unit.
- A private extern declaration and a shared readonly `{ .set = NULL }` ops object.

There is no concrete setter, register write, active-bit manipulation, cold/reset
behavior change, factory generator/getter implementation, queue, worker or new
runtime state. For the test fixture's well-formed face, the NULL method returns
UNSUPPORTED. It does not advertise an implemented provider capability.

Apply this bootstrap plus `contract-tests.patch` only after the current frozen
increment has completed and root refreshes source identities. The 13 initial
Native GoogleTests require this shared symbol and API; the cold-start case also
records the current nonzero-active mismatch. The added SDK reset case below uses
the same declarations and inert table. Root must capture actual GoogleTest
runtime assertion failures on these sources before implementing the provider.
No missing-symbol/compile failure, skip, SFINAE branch or manually predicted RED
is evidence of runtime RED.

The proposed Python methods still use the original fixture's `generate()` helper
and therefore call `configure.configure`. They have not been run here; no owned
test loader or fragile copied test harness has been introduced. Their runtime
RED belongs to root's later normal configuration-test execution. No generator
change is included in this inert scaffold. A temporary default-NULL typed getter
is optional if root needs it to compile a later factory runtime case; these
GoogleTests do not require one, so no such getter is supplied.

This planning packet made no primary checkout/index writes and ran no compiler,
configure, GoogleTest, configuration test or HIL. The patch is a declaration and
inert-dispatch proposal, not an activation behavior after-image.
