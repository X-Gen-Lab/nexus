"""Read-only catalog byte/closure inspection, not a test framework or build."""
import ast
import hashlib
import json
import re
from pathlib import Path
import time

OWN=Path(__file__).resolve().parent
PACKET=Path('/tmp/nexus-usb-activation-api-catalogs-20261021/review-input.json')
ROOT=Path('/tmp/nexus-quality-20261019')

def sha(data):return hashlib.sha256(data).hexdigest()
def identity(path):
 data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def validate(record):
 result=identity(Path(record['path']))
 assert result==record,(result,record)
 return result

def chunks(text):
 parts=re.split(r'(\n[ \t]*\n)',text)
 return [(parts[i],parts[i+1] if i+1<len(parts) else '')for i in range(0,len(parts),2)]
def entry(block):
 message=None;translation=None;current=None
 for line in block.splitlines():
  line=line.strip()
  if line.startswith('msgid '):message=ast.literal_eval(line[6:]);current='id'
  elif line.startswith('msgstr '):translation=ast.literal_eval(line[7:]);current='str'
  elif line.startswith('"'):
   if current=='id':message+=ast.literal_eval(line)
   elif current=='str':translation+=ast.literal_eval(line)
 return message,translation

def catalog(path):
 text=path.read_text()
 data={};records=[];header=None
 assert '#, fuzzy' not in text
 for block,separator in chunks(text):
  key,value=entry(block)
  if key is None:continue
  assert key not in data
  data[key]=value
  if key=='':header=block
  else:records.append((key,value,block))
 metadata={line.split(':',1)[0]:line.split(':',1)[1].strip()for line in data.pop('').splitlines()if ':' in line}
 return text,metadata,data,records,header

def pot_keys(path):
 records=[]
 for block,separator in chunks(path.read_text()):
  key,value=entry(block)
  if key:records.append(key)
 assert len(set(records))==len(records)
 return set(records)

started=time.time_ns()
packet=json.loads(PACKET.read_text());inputs=[identity(PACKET)]
for field in ('extraction','public_header','public_header_XML','POT','source','unchanged_raw_blocks','patch'):
 inputs.append(validate(packet[field]))
extraction=json.loads(Path(packet['extraction']['path']).read_text())
assert extraction['all_passed'] and extraction['unchanged'] and extraction['before']==extraction['after']
assert len(extraction['commands'])==2
for command in extraction['commands']:
 assert command['exit_code']==0 and command['child_returncode']==0 and command['outcome']=='completed'
 receipt=Path(command['attempt_receipt']);inputs.append(identity(receipt));actual=json.loads(receipt.read_text())
 assert actual['command']==command['command'] and actual['exit_code']==0
 for name in ('stdout','stderr'):
  assert identity(Path(command[name]['path']))=={'path':command[name]['path'],'bytes':command[name]['bytes'],'sha256':command[name]['sha256']}
for relative,digest in extraction['before'].items():assert sha((ROOT/relative).read_bytes())==digest
keys=pot_keys(Path(packet['POT']['path']))
proof=json.loads(Path(packet['unchanged_raw_blocks']['path']).read_text())['blocks']
verified=[]
recommended_old='目标变更之前，必须显式取消并排空既有借用；失败从不撤销其他借用。'
recommended_new='目标变更之前，必须显式取消并排空该目标的既有借用；失败从不撤销其他借用。'
reviewed_successors=[]
for item in packet['files']:
 inputs.extend([validate(item['before']),validate(item['candidate'])])
 old_text,old_meta,old,old_blocks,old_header=catalog(Path(item['before']['path']))
 text,meta,data,records,header=catalog(Path(item['candidate']['path']))
 assert len(old)==1533 and len(data)==1544
 assert set(data)==keys and len(set(data)-set(old))==11 and not(set(old)-set(data))
 assert all(value for value in data.values())
 assert meta['X-Nexus-Source-SHA256']==packet['source']['sha256']
 assert old_meta['X-Nexus-Source-SHA256']=='73a3d84a77d809cc222cc4cf065cb50c88f594ccbcb2e74562cbd652ecf52898'
 assert meta['X-Nexus-Reviewed']=='false' and old_meta['X-Nexus-Reviewed']=='true'
 back_header=header.replace('X-Nexus-Reviewed: false','X-Nexus-Reviewed: true',1).replace(meta['X-Nexus-Source-SHA256'],old_meta['X-Nexus-Source-SHA256'],1)
 assert back_header==old_header
 assert all(data[k]==value for k,value in old.items())
 assert [k for k,value,block in records if k in old]==[k for k,value,block in old_blocks]
 language='en' if '/en/' in item['relative_path'] else 'zh_CN'
 preserved=[r for r in proof if r['language']==language]
 assert len(preserved)==1533
 position=0
 for index,((key,value,block),row)in enumerate(zip(old_blocks,preserved)):
  assert row['old_order']==index and row['candidate_identical'] is True
  assert row['msgid_sha256']==sha(key.encode()) and row['raw_block_sha256']==sha(block.encode()) and row['raw_block_bytes']==len(block.encode())
  found=text.find(block,position);assert found>=0;position=found+len(block)
 for row in [p for p in packet['pairs']if p['language']==language]:
  assert row['msgid'] in set(data)-set(old) and data[row['msgid']]==row['msgstr']
  if language=='en':assert row['msgid']==row['msgstr']
 successor=text
 if language=='zh_CN':
  assert successor.count(recommended_old)==1
  successor=successor.replace(recommended_old,recommended_new,1)
 assert successor.count('X-Nexus-Reviewed: false')==1
 successor=successor.replace('X-Nexus-Reviewed: false','X-Nexus-Reviewed: true',1)
 reviewed_successors.append({'relative_path':item['relative_path'],'candidate_sha256':item['candidate']['sha256'],'expected_final_sha256':sha(successor.encode()),'only_allowed_successor_changes':['X-Nexus-Reviewed false→true']+(['Target-loan clarification exact replacement recorded in semantic review']if language=='zh_CN'else[])})
 verified.append({'language':language,'old_messages':1533,'candidate_messages':1544,'new_messages':11,'obsolete_messages':0,'unchanged_raw_blocks':1533,'byte_order_preserved':True,'old_translations_identical':True,'new_source_hash_honest':True,'nonempty_nonfuzzy':True})
assert sum(row['unchanged_raw_blocks']for row in verified)==3066
report={'status':'ACCEPT','kind':'Independent read-only semantic and exact-byte API catalog review','started_ns':started,'finished_ns':time.time_ns(),'inputs':inputs,'verification':verified,'total_new_occurrences':22,'total_retained_raw_blocks':3066,'blocking_findings':[],'semantic_review':['EN eleven additions exactly retain authored English messages.','ZH retains optional selected nonzero endpoint scope and does not admit EP0 or packet submission.','The Task entry remains privileged and serialized with incoming IRQ masks clear; this is a precondition, not an action that masks IRQs.','Cold software epoch zero remains valid; epoch is not described as physical authorization.','No new request/buffer loan is created; target loan cancellation/drain remains explicit and failures never revoke other loans.','Pre-write INVALID/CONTEXT/STATE/BUSY rejection stays distinct from partial-effect IO, admission closure and explicit recovery.','Borrowed immutable face uses the existing controller context without claiming allocation or lifetime revocation.','Current API-page source digest is updated honestly; retained historical reference comments are not new-source execution claims.'],'nonblocking_clarification':{'language':'zh_CN','old':recommended_old,'recommended':recommended_new,'reason':'Explicitly scopes cancellation/drain to target loans so prose cannot be read as requiring controller-wide drain; other endpoint loans remain live. This clarifies the intended source contract without changing English or runtime support.'},'reviewed_successors':reviewed_successors,'qualification_limits':['This is file parsing/hash/message-closure and semantic review only.','No framework tests, compiler/configure, Doxygen, Sphinx/gettext or primary/index writes performed.','Existing two extraction commands are admitted only for API message provenance; no HTML/site, runtime, ARM, IO35 or HIL qualification follows.','Independent review permits only the recorded clarification plus Reviewed metadata transition; later header/API message changes require recheck.']}
output=OWN/'review.json';assert not output.exists();output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OWN/'review.md').write_text('Independent review: ACCEPT\n\nVerified two catalogs against the actual fresh API POT: 22 added pairs, zero obsolete/empty/fuzzy messages, and all3066 old raw message blocks retained byte-for-byte in order with unchanged old translations. Current API-page digest is updated honestly.\n\nThe eleven ZH additions preserve ownership, privileged serialized Task/IRQ entry, valid cold epoch0, pre-write rejection, partial IO/admission closure and explicit recovery. Recommended one nonblocking wording refinement: add “该目标的” before “既有借用” so target drain is not confused with controller-wide cancellation. Exact reviewed successor hashes are recorded in review.json.\n\nNo tests/builds/extraction or primary/index writes performed. This review is not HTML/site, runtime, ARM, IO35 or HIL qualification.\n')
print(json.dumps({'status':'ACCEPT','review':str(output),'sha256':sha(output.read_bytes()),'new_occurrences':22,'preserved_blocks':3066,'reviewed_successors':reviewed_successors},ensure_ascii=False))

if __name__!='__main__':raise RuntimeError('standalone inspection only')
