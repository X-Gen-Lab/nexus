# Raw USB reset before Task packet admission

Read-only inspection of current primary submit, request_valid, reset invalidation
and model reset leaves. No primary/index writes, implementation after-image,
compiler, configure or tests.

## Confirmed gap and narrow rule

Current submit checks software reset_pending and, only for nonzero endpoints,
the hardware active bit. Software reset_pending/epoch are updated by IRQ/service.
A raw USBRST bit12 already visible before that collection can therefore still
admit a packet when active remains set. This is directly relevant to a GD-style
leaf that publishes reset without automatically clearing active.

The guard must cover **EP0 too**. ST explicitly excludes EP0 from hardware
USBAEP reset clear. A previously valid published control_pending/epoch/stage can
therefore pass request_valid while raw reset is latched, admitting obsolete EP0
control traffic even on ST.

Under the existing saved-IRQ transaction, after software started/closing checks
and before request_admit or any TSIZ/EPENA/FIFO write, observe raw USBRST. If set,
return STATE. Preserve candidate READY, retain no new request/buffer reference,
perform no hardware write, leave the raw flag latched and do not change epoch or
existing loans. Ordinary IRQ/service still owns invalidation, reset events,
drain, deactivation and reset completion. This is one shared admission rule,
without a family-specific reset decoder or automatic activation.

## Suggested small regressions

**One Native case focused on EP0:** publish an ordinary valid GET_DESCRIPTOR
SETUP with IN DATA length1; prepare the fixture's request at the current control
epoch. Inject only `registers[0x14/4] |= 1U << 12`, leaving active state unchanged.
Submit to IN0 and require STATE, unchanged READY, target request NULL, unchanged
MMIO-write count/TSIZ/EPENA/Tx FIFO, unchanged software epoch and latched reset
flag. Then ordinary service may collect reset; it must not settle an unborrowed
READY candidate. Do not use a deliberately invalid epoch/stage, which would hide
the raw-reset defect behind existing validation.

**One parameterized SDK case**, compiled by the existing STM32 and GD programs,
with IN0, OUT0, IN1 and OUT1 parameters:

- Use each fresh existing SDK fixture and real shared provider. Its selected
  nonzero directions are explicitly activated by the owner.
- For EP0 publish a valid SETUP for the tested direction before preparing DATA
  at its current epoch; IN GET_DESCRIPTOR and OUT vendor-data length1 suffice.
  For nonzero use ordinary DATA/control_epoch0.
- Inject only the raw reset flag. Assert the target active bit is still set,
  proving that the active-bit check cannot explain rejection.
- Require STATE, READY/no request attachment, no MMIO writes, no FIFO data, no
  control-stage/epoch change and no new clock consumer. Existing clock ownership
  remains retained. Leave all other faults off and all admission preconditions
  otherwise valid.
- Finish through ordinary service/fixture stop. Store any request that might be
  accepted during actual RED in fixture-owned storage so teardown cannot access
  an expired local stack object.

These are one source case plus one parameterized source case, no new executable,
fault field, callback framework or product policy. The SDK variants test common
admission through both bindings without claiming either silicon's bus-reset
side effects. Record actual regression RED before changing production submit.

## Physical race limit

Local interrupt masking serializes software; it does not stop USB hardware.
Reset can arrive immediately after the observed raw-flag read and before/during
packet programming. The narrow guard closes reset already visible at its
observation point; it cannot make admission and bus reset wire-atomic. If such a
later reset follows accepted admission, the accepted loan remains owned until
the ordinary reset disable/FIFO/source proof publishes settlement. Never report
that accepted request as rejected retroactively or revoke its borrow merely
because the hardware reset event occurred.

No broader SETUP-policy, address or class change is proposed by this review.
