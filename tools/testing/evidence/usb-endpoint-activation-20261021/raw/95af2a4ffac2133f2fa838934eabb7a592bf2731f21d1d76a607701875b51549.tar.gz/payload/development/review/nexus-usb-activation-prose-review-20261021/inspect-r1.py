"""Independent read-only prose/code identity binding, not execution evidence."""
import hashlib
import json
from pathlib import Path
import time

ROOT=Path('/tmp/nexus-quality-20261019')
DRAFT=Path('/tmp/nexus-usb-activation-docs-draft-20261021')
OWN=Path(__file__).resolve().parent
MANIFEST=DRAFT/'final-prose-manifest.json'
PATCH=DRAFT/'final-prose.patch'
sha=lambda data:hashlib.sha256(data).hexdigest()
def record(path):
 data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
started=time.time_ns()
manifest_bytes=MANIFEST.read_bytes();manifest=json.loads(manifest_bytes)
patch_bytes=PATCH.read_bytes()
assert sha(patch_bytes)=='a626b7ee9c196d73aea5a3674a3a8150e4486b19c6a961fa49973aba9016aa6b'
assert record(PATCH)==manifest['patch']
assert {row['path']for row in manifest['files']}=={'docs/design/usb-device.md','io/README.md','docs/delivery/support.md'}
source=[];snapshots={}
for item in manifest['provider_inputs']:
 path=ROOT/item['path'];data=path.read_bytes();assert sha(data)==item['sha256']
 source.append(record(path));snapshots[path]=data
prose=[]
for item in manifest['files']:
 baseline=ROOT/item['path'];after=DRAFT/'after'/item['path']
 before_bytes=baseline.read_bytes();after_bytes=after.read_bytes()
 assert sha(before_bytes)==item['baseline_sha256']
 assert sha(after_bytes)==item['proposal_sha256'] and len(after_bytes)==item['proposal_bytes']
 snapshots[baseline]=before_bytes;snapshots[after]=after_bytes
 prose.append({'path':item['path'],'primary_baseline':record(baseline),'owned_afterimage':record(after)})
assert all(path.read_bytes()==data for path,data in snapshots.items())
assert MANIFEST.read_bytes()==manifest_bytes and PATCH.read_bytes()==patch_bytes
review={'status':'ACCEPT','kind':'Independent read-only activation prose/code semantic review','started_ns':started,'finished_ns':time.time_ns(),'patch_sha256':sha(patch_bytes),'manifest_sha256':sha(manifest_bytes),'inputs':[record(MANIFEST),record(PATCH)],'provider_inputs':source,'prose_inputs':prose,'blocking_findings':[],'semantic_review':[
 {'contract':'Optional activation face/getter and resource ownership','finding':'Separate two-pointer public face and shared readonly ops dispatch through existing controller context. Factory calls emit_activation outside the capabilities gate. Private header adds include/extern only; mutable struct fields remain unchanged. Prose separates shape from future ARM retention/cost proof.'},
 {'contract':'Cold start and per-direction masks','finding':'Initialize sets ACTIVE and endpoint mask only for EP0. endpoint_interrupt_bit selects one IN/OUT bit, set_endpoint_mask preserves every other bit and proves full expected mask readback. Enable unmasks only after control proof; disable masks before active withdrawal.'},
 {'contract':'Admission context, identity and software epoch','finding':'Task checks reject ISR/masked/unprivileged entry. Software started/clock/closing/reset/epoch and selected identity checks precede MMIO. Zero is not rejected as a cold epoch. Raw USBRST observed after software checks rejects STATE before writes; prose does not promise physical bus atomicity or restart-cache authority.'},
 {'contract':'Target loan ownership and preexisting flags','finding':'Target request/disable/setup work rejects BUSY. Endpoint enable/disable, defined pending flags, FIFO/flush/RX state reject before write. Other endpoint loans are not implicitly cancelled or settled. Existing flags are not cleared to turn BUSY into success.'},
 {'contract':'Post-command IN 0x50 hints','finding':'activation_hints accepts only IN bits0x50 after the command; other defined new flags fail the operation. It writes only observed hints then proves W1C clear. ep_flags masks defined0x5B and excludes readonly TXFE. The prose distinguishes these post-command hints from strict preexisting BUSY.'},
 {'contract':'DATA0, geometry and HALT idempotence','finding':'Fresh enable programs selected MPS/type/IN FIFO, DATA0 and NAK while leaving ENABLE clear and not writing TSIZ/payload. Already-active enable does not replay control or HALT/DATA0; corrupt active geometry closes with IO. Already-inactive disable does not reprogram geometry. Disable preserves PID and fresh re-enable clears halt only after proof.'},
 {'contract':'Bounded Task proof versus reset progress','finding':'Explicit activate/deactivate uses existing poll_limit wait_bits for control/W1C. Added reset_nonzero_endpoints calls deactivate_endpoint with false and uses single observations with later service retry. Prose correctly avoids claiming a new IRQ polling loop.'},
 {'contract':'Uniform software reset postcondition','finding':'progress requires no remaining request, successful FIFO flush and clear_halts before selected nonzero mask/active withdrawal; reset_pending clears only after remaining address readback. This is common software behavior, not an inferred GD automatic reset side effect. No reset/halt/submit autoactivation is claimed.'},
 {'contract':'Partial IO and explicit recovery','finding':'Failed mutator proof sets existing closing and best-effort target-only deactivation without falsifying unexpected EPENA withdrawal. Other loans/clock remain retained; explicit full stop still uses existing proof. Already-active integrity IO is separately documented as a no-control-write failure.'},
 {'contract':'External Chapter9 staging and rollback','finding':'Before-status endpoint staging matches the reviewed ST/Zephyr references; configured readiness and permission for ordinary packets remain external. Multiple setters are not a transaction. Superseding SETUP/status failure requires external cleanup/stop, and an observed host ACK cannot be undone by local rollback.'},
 {'contract':'Scope and qualification','finding':'Existing FIG16 reference retained; no new page/figure/status authority. Support row describes the same bounded mechanism. Prose retains complete IO35, class/configuration policy, electrical and physical HIL limits and makes no executed210-case, ARM-size, candidate or release claim.'}
],'observed_source_stable_during_identity_binding':True,'review_execution_limits':['No primary/index/afterimage writes performed.','No framework tests, compiler/configure, Doxygen/Sphinx/gettext or new execution qualification.','The root-reported12program210case GREEN remains separate external execution evidence; this review neither reruns nor substitutes for it.','Acceptance binds only these exact prose/provider bytes; later semantic implementation changes require review.']}
output=OWN/'review.json';assert not output.exists();output.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
(OWN/'review.md').write_text('Independent prose/code review: ACCEPT\n\nNo material mismatch found in the exact three-file proposal. Reviewed against provider v2, public wrapper/header and generated factory: cold EP0-only activation, direction masks, preexisting BUSY versus post-command0x50 hints, epoch0, target-loan ownership, partial IO/closing/recovery, DATA0/HALT idempotence, bounded Task waits versus single-observation reset withdrawal, and deliberate GD software reset cleanup all agree. External before-status staging/rollback and full IO35/HIL limits remain explicit.\n\nPatch/manifest and all six provider inputs plus three afterimages are bound in review.json. No tests/builds/extraction, primary/index or afterimage writes were performed. This is semantic inspection, not executed runtime/site/ARM/candidate/HIL qualification.\n')
print(json.dumps({'status':'ACCEPT','review':str(output),'sha256':sha(output.read_bytes()),'patch_sha256':sha(patch_bytes),'manifest_sha256':sha(manifest_bytes),'provider_inputs':len(source),'prose_afterimages':len(prose)}))
