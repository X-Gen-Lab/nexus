import hashlib,json,pathlib,subprocess,sys
ROOT=pathlib.Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(ROOT))
from tools.dev.process import run
from tools.documentation.install import environment
OUT=pathlib.Path('/dev/shm/nexus-usb-activation-final-gettext-20261021');OUT.mkdir(exist_ok=False)
rev=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
env=environment('/tmp/nexus-quality-doc-tools')
env.update(NEXUS_DOCS_REVISION=rev,NEXUS_DOCS_CODE_REVISION=rev,NEXUS_DOCS_VERSION='0.2.0',NEXUS_DOCS_LANGUAGES='en,zh_CN',NEXUS_DOCS_LANGUAGE='en',NEXUS_DOCS_DOXYGEN_XML=str(OUT/'api/xml'),NEXUS_DOCS_GETTEXT_ROOT=str(OUT/'gettext'),NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1',PYTHONDONTWRITEBYTECODE='1')
paths=['docs/design/usb-device.md','docs/delivery/support.md','io/README.md','docs/reference/api/io.md','io/include/nexus/io/usb_activation.h','io/include/nexus/io/usb_device.h','io/include/nexus/io/usb_profile.h']
before={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
doxy=OUT/'Doxyfile';doxy.write_text('@INCLUDE = '+str(ROOT/'Doxyfile')+'\nOUTPUT_DIRECTORY = '+str(OUT/'api')+'\nPROJECT_NUMBER = 0.2.0\nGENERATE_HTML = NO\n')
commands=[('doxygen',['/tmp/nexus-quality-doc-tools/bin/doxygen',str(doxy)]),('gettext',['/tmp/nexus-quality-doc-tools/venv/bin/python','-m','sphinx','-n','-W','--keep-going','-c',str(ROOT/'docs/sphinx'),'-d',str(OUT/'doctrees'),'-b','gettext',str(ROOT/'docs'),str(OUT/'gettext')])]
receipts=[]
for label,args in commands:
 result=run(args,cwd=ROOT,env=env,log=OUT/(label+'.raw'),timeout=300,stage='usb-activation-api-'+label);receipts.append(json.loads((OUT/(label+'.command.json')).read_text()));print(label,result.returncode,flush=True)
 if result.returncode:break
after={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
(OUT/'extraction.json').write_text(json.dumps({'source_base':rev,'source_dirty':True,'before':before,'after':after,'unchanged':before==after,'commands':receipts,'all_passed':all(r['exit_code']==0 for r in receipts),'qualification':False},indent=2)+'\n')
raise SystemExit(result.returncode)
