# Explicit fixture activation and R4 mask proof review

Read-only contract review of `implementation/fixtures/fixture-owner-activation.patch`,
its owned Native/SDK after-images, and `r4/mask-proof-hardening.patch`.
No compiler, configure, tests, primary/index changes or after-image writes.
Factory getter RAII/CMake review was not duplicated.

No material issue found:

- `ActivateSelected` belongs to the explicit test owner. It calls the real
  public activation operation for each selected nonzero direction after cold
  initialization and after the specific packet fixtures restart. It adds no
  platform startup behavior, decoder or product policy.
- Existing packet/interrupt tests gain the prerequisites for their intended
  active-direction contract. The two restart paths testing only control epoch
  and reset observability correctly do not gain unnecessary activation.
- New `UsbActivation::SetUp` still stops the inherited owner and cold-starts
  again without activation. Its cold-inactive, no-borrow and explicit activation
  cases remain intact. The explicit selected-direction table likewise calls
  activation itself rather than relying on fixture convenience.
- SDK reset/geometry cases use the real selected SDK binding. Their initial
  activation calls can be idempotent after ordinary packet fixture setup; reset
  still deliberately leaves hardware active and requires actual production
  withdrawal only after the held loan drains.
- The factory busy-loan test explicitly obtains the generated face and activates
  only the IN direction it submits. Existing storage/clock/drain assertions are
  retained.
- R4 now proves the complete unrelated EP_MASK value, including EP0 routes, on
  failed unmask rollback. Failed withdrawal and failed W1C preserve the full
  pre-call mask. The added zero Tx FIFO count assertions preserve the
  no-payload-write boundary on those errors.
- Both reset cases capture the complete mask before reset, withhold actual
  disable proof, and require the mask remain unchanged while the request is
  still retained. Existing later drain, inactive/masked postcondition and
  reactivation/ACK assertions remain; reset completion cannot be inferred from
  an event or epoch increment alone.

No original case or ownership assertion is removed. The narrower OUT-only mask
checks are replaced by strictly stronger complete unrelated-mask checks, and the
original OUT-route nonzero precondition remains. Test migrations and R4 are
separate patches based on the same R3 source; their content edits are disjoint,
so root should compose patches rather than overwrite one after-image with the
other.

This is static review only. Root's complete GREEN run and ordinary gates remain
the execution evidence.
