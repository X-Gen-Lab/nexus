"""Read-only full POT/catalog closure and semantic-review identity binding."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import re
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path('/tmp/nexus-quality-20261019')
OWN=Path(__file__).resolve().parent
PREP=Path('/tmp/nexus-usb-activation-final-catalogs-20261021')
PACKET=PREP/'review-input.json'
sha=lambda data:hashlib.sha256(data).hexdigest()
def rec(path):
 data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def check(record):
 assert rec(Path(record['path']))==record,record['path']
 return record

def blocks(text):
 chunks=re.split(r'(\n[ \t]*\n)',text)
 return [(chunks[i],chunks[i+1] if i+1<len(chunks) else '')for i in range(0,len(chunks),2)]
def key(block):
 value=None;active=False
 for line in block.splitlines():
  text=line.strip()
  if text.startswith('msgid '):value=ast.literal_eval(text[6:]);active=True
  elif text.startswith('msgstr '):active=False
  elif text.startswith('"') and active:value+=ast.literal_eval(text)
 return value

spec=importlib.util.spec_from_file_location('review_catalog_reader',ROOT/'tools/documentation/sphinx_ext.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
read=module.read_catalog
started=time.time_ns()
packet_bytes=PACKET.read_bytes();assert sha(packet_bytes)=='b314234b22348d690057afae4bf637f012b40f5bab05c975546ce658a94f6bb1'
packet=json.loads(packet_bytes);assert packet['patch']['sha256']=='19d50d0ca32584f65cc51b9d93a4cfb139a92b7a7b8402ce0221b2b2092d49a8'
inputs=[rec(PACKET)]
for field in ('extraction','actual_127_POT_inventory','patch','unchanged_raw_blocks','prose_semantic_review'):inputs.append(check(packet[field]))
extraction=json.loads(Path(packet['extraction']['path']).read_text())
assert extraction['all_passed'] and extraction['unchanged'] and extraction['before']==extraction['after']==packet['source_inputs_before_after']
assert len(extraction['commands'])==2
for command in extraction['commands']:
 assert command['exit_code']==0 and command['child_returncode']==0 and command['outcome']=='completed'
 receipt=Path(command['attempt_receipt']);actual=json.loads(receipt.read_text());assert actual['exit_code']==0 and actual['command']==command['command']
 inputs.append(rec(receipt))
 for field in ('stdout','stderr'):assert rec(Path(command[field]['path']))=={'path':command[field]['path'],'bytes':command[field]['bytes'],'sha256':command[field]['sha256']}
source_snapshots={}
for relative,digest in extraction['before'].items():
 data=(ROOT/relative).read_bytes();assert sha(data)==digest;source_snapshots[relative]=data
proof=json.loads(Path(packet['unchanged_raw_blocks']['path']).read_text())['blocks']
candidates={};counts=[];successors=[]
for item in packet['files']:
 for field in ('before','candidate','source','POT'):check(item[field])
 old_path=Path(item['before']['path']);candidate_path=Path(item['candidate']['path'])
 oldtext=old_path.read_text();text=candidate_path.read_text()
 oldmeta,old,oldfuzzy=read(old_path);meta,new,fuzzy=read(candidate_path);_,expected,_=read(Path(item['POT']['path']))
 assert not oldfuzzy and not fuzzy and all(new.values()) and set(new)==set(expected)
 newids=set(new)-set(old);obsolete=set(old)-set(new)
 assert newids==set(item['new_ids']) and obsolete==set(item['obsolete_ids'])
 assert all(new[k]==v for k,v in old.items()if k in new)
 assert oldmeta['X-Nexus-Reviewed']=='true' and meta['X-Nexus-Reviewed']=='false'
 assert meta['X-Nexus-Source-SHA256']==item['source']['sha256']
 assert oldmeta['X-Nexus-Source-SHA256']==item['header_sourcehash']['before']
 oldheader=next(b for b,s in blocks(oldtext)if key(b)=='')
 header=next(b for b,s in blocks(text)if key(b)=='')
 normalized=header.replace('X-Nexus-Reviewed: false','X-Nexus-Reviewed: true',1).replace(meta['X-Nexus-Source-SHA256'],oldmeta['X-Nexus-Source-SHA256'],1)
 assert normalized==oldheader
 retained=[(k,b)for b,s in blocks(oldtext)if (k:=key(b))not in (None,'') and k in new]
 new_order=[key(b)for b,s in blocks(text)if key(b)in old]
 assert new_order==[k for k,b in retained]
 rows=[r for r in proof if r['doc']==item['doc']and r['language']==item['language']]
 assert len(rows)==len(retained)==item['retained_raw_blocks']
 position=0
 for index,((k,b),row)in enumerate(zip(retained,rows)):
  assert row['old_order']==index and row['candidate_identical'] is True
  assert row['msgid_sha256']==sha(k.encode()) and row['raw_block_sha256']==sha(b.encode()) and row['raw_block_bytes']==len(b.encode())
  found=text.find(b,position);assert found>=0;position=found+len(b)
 for b,s in blocks(oldtext):
  if key(b)is None and b:assert b in text
 for pair in [p for p in packet['pairs']if p['doc']==item['doc']and p['language']==item['language']]:assert new[pair['msgid']]==pair['msgstr']
 assert text.count('X-Nexus-Reviewed: false')==1
 final=text.replace('X-Nexus-Reviewed: false','X-Nexus-Reviewed: true',1)
 successors.append({'path':item['relative_path'],'candidate_sha256':item['candidate']['sha256'],'expected_final_sha256':sha(final.encode()),'only_allowed_change':'X-Nexus-Reviewed false→true'})
 candidates[item['doc'],item['language']]=(candidate_path,item)
 counts.append({'doc':item['doc'],'language':item['language'],'messages':len(new),'new':len(newids),'obsolete':len(obsolete),'retained_raw_blocks':len(retained),'other_header_bytes_unchanged':True,'old_translation_bytes_and_order_preserved':True})
assert len(counts)==5 and sum(r['new']for r in counts)==22 and sum(r['obsolete']for r in counts)==6 and sum(r['retained_raw_blocks']for r in counts)==439
inventory=json.loads(Path(packet['actual_127_POT_inventory']['path']).read_text())
assert inventory['pages']==127 and inventory['language_records']==254
pot_root=Path(packet['extraction']['path']).parent/'gettext'
actual_pots=sorted(pot_root.rglob('*.pot'))
assert len(actual_pots)==len(inventory['POTs'])==127
assert {str(p)for p in actual_pots}=={row['path']for row in inventory['POTs']}
for row in inventory['POTs']:check(row)
records={(row['doc'],row['language']):row for row in inventory['records']}
assert len(records)==254
closure=[];observed_gaps=[];source_original=0;catalog_pairs=0;api_verified=[]
for pot in actual_pots:
 doc=pot.relative_to(pot_root).with_suffix('').as_posix()
 source=ROOT/'docs'/(doc+'.md')
 if not source.is_file():source=ROOT/'docs'/(doc+'.rst')
 assert source.is_file()
 source_bytes=source.read_bytes();source_digest=sha(source_bytes)
 _,expected,_=read(pot)
 for language in ('en','zh_CN'):
  row=records[doc,language]
  assert row['source_sha256']==source_digest and row['POT_sha256']==sha(pot.read_bytes()) and row['expected_messages']==len(expected)
  if row['catalog'] is None:
   assert row['source_original']is True and module.source_language(source_bytes.decode())==language
   assert not (ROOT/'docs/locale'/language/'LC_MESSAGES'/(doc+'.po')).exists()
   source_original+=1
   closure.append({'doc':doc,'language':language,'source_sha256':source_digest,'source_original':True,'status':'original-source-no-catalog'})
   continue
  catalog_pairs+=1;check(row['catalog']);oldmeta,old,oldfuzzy=read(Path(row['catalog']['path']))
  newids=set(expected)-set(old);obsolete=set(old)-set(expected)
  assert newids==set(row['new_ids']) and obsolete==set(row['obsolete_ids'])
  if newids or obsolete or oldmeta['X-Nexus-Source-SHA256']!=source_digest:observed_gaps.append((doc,language))
  chosen,item=candidates.get((doc,language),(Path(row['catalog']['path']),None))
  meta,messages,fuzzy=read(chosen)
  assert set(messages)==set(expected) and all(messages.values()) and not fuzzy
  assert meta['X-Nexus-Source-SHA256']==source_digest and meta['Language']==language
  assert meta['X-Nexus-Reviewed']==('false'if item else'true')
  if doc=='reference/api/io':
   assert not newids and not obsolete and item is None
   api_verified.append({'language':language,'catalog':rec(chosen),'messages':len(messages),'source_sha256':source_digest,'new':0,'obsolete':0,'unchanged':True})
  closure.append({'doc':doc,'language':language,'source_sha256':source_digest,'catalog':rec(chosen),'messages':len(messages),'message_closure':'complete','reviewed_flag':'pending independent-review transition'if item else'true'})
assert source_original==64 and catalog_pairs==190
assert sorted(observed_gaps)==sorted(candidates)==sorted(map(tuple,inventory['gap_pairs']))
assert len(api_verified)==2
assert PACKET.read_bytes()==packet_bytes
for relative,data in source_snapshots.items():assert (ROOT/relative).read_bytes()==data
for item in packet['files']:
 check(item['before']);check(item['candidate'])
closure_path=OWN/'overlay-closure.json';assert not closure_path.exists();closure_path.write_text(json.dumps({'classification':'Pure current final-POT/candidate-overlay message closure, not strict bilingual site execution','source_pages':127,'language_records':254,'catalog_records':190,'source_original_records':64,'only_gap_pairs':observed_gaps,'after_overlay_missing_extra_empty_fuzzy':0,'candidate_Reviewed_flags_still_false':5,'records':closure},ensure_ascii=False,indent=2)+'\n')
review={'status':'ACCEPT','review_input_sha256':sha(packet_bytes),'candidate_patch_sha256':packet['patch']['sha256'],'kind':'Independent final activation prose-catalog semantics and full actualPOT message-closure review','started_ns':started,'finished_ns':time.time_ns(),'inputs':inputs,'counts':counts,'totals':{'catalogs':5,'new_occurrences':22,'obsolete_occurrences':6,'retained_raw_blocks':439},'overlay_closure':rec(closure_path),'API_recheck':api_verified,'blocking_findings':[],'semantic_review':[
 'All14 new English USB design messages preserve the canonical Chinese support scope, optional independent activation face/getter, no new mutable state and measured-cost boundary.',
 'Privileged serialized Task entry with incoming IRQ masks clear, selected nonzero-only target, current software epoch including cold0, raw-reset pre-write refusal and no physical atomicity remain explicit.',
 'Target loan cancellation/drain/acquire SETTLED is required; other directions and their loans remain live. No translation turns activation into controller-wide cancellation or revokes storage on failure.',
 'Preexisting defined events strictly reject BUSY without clearing; only post-command known target IN0x50 hints can be W1C-cleared, with other new events leading to partialIO/closing.',
 'ColdEP0-only state, directional mask order, geometry/DATA0/HALT idempotence and bounded Task waits versus reset single-observation/service retry are preserved.',
 'Both-family post-reset withdrawal is attributed to actual common software after drain, without claiming automatic GD EPACT clear.',
 'Partial-effect IO preserves closing/clock/storage and demands explicit full stop, while stop may remain BUSY pending existing proofs.',
 'Chapter9 before-status staging, external configured readiness/packet gating, superseding SETUP/status failure rollback and inability to revoke a host-observed ACK retain their normative strength.',
 'The English support row retains exact PIO/EP0/bulk/interruptIN/48MHz bounds and external Chapter9 policy; it adds no Host/HS/DMA/ISO/class-stack claim.',
 'The three source-map Chinese paragraphs preserve the same optional shape, target ownership, reset, status ordering, external recovery and IO35/HIL limits. Normalized /design/usb-device.md link remains intact.',
 'All fullIO35, physical timing/electrical, clean candidate and release boundaries remain explicit. No translation adds executed runtime/ARM/site/HIL conclusions.',
 'Support/design source digests change honestly. Source-map page hash stays unchanged while actual included README messages extend its existing catalog; no fictitious README catalog is created.'
],'reviewed_successors':successors,'qualification_limits':['Pure hash/file/catalog parsing and semantic review only; no tests/compiler/configure/Doxygen/Sphinx/gettext or primary/afterimage/index writes.','The two existing actual extraction commands prove message provenance only; fresh strict bilingual HTML/site execution remains a later root action.','The candidate overlay has complete message sets with five deliberately unreviewed flags. Only the recorded false→true transitions are allowed after this review.','Runtime/ARM/SDK/HIL qualifications remain separate.']}
output=OWN/'review.json';assert not output.exists();output.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
(OWN/'review.md').write_text('Independent final catalog review: ACCEPT\n\nVerified the five exact candidate catalogs:22 new occurrences,6 obsolete,439 retained old raw message blocks with unchanged translations and byte order. Independent current127-POT/254-language-record overlay inspection found only those five original gaps; candidate message sets close all gaps.64 records use their actual original source,190 use catalogs. Both already-applied API catalogs have zero new/obsolete IDs and remain unchanged.\n\nEnglish USB design/support and Chinese included-source paragraphs preserve ownership, Task/IRQ, cold epoch0, preexisting BUSY versus post-command0x50, DATA0/HALT idempotence, software GD reset withdrawal, partialIO/closing/fullstop and external before-status staging/rollback. IO35 and physical/HIL limits stay explicit. Only Reviewed:false→true transitions are admitted.\n\nNo framework tests/builds/extraction or primary/index/afterimage writes performed. This is semantic/message closure inspection, not strict bilingual site or runtime/ARM/HIL qualification.\n')
print(json.dumps({'status':'ACCEPT','review':str(output),'sha256':sha(output.read_bytes()),'overlay':rec(closure_path),'catalogs':5,'new_occurrences':22,'obsolete_occurrences':6,'retained_blocks':439,'source_pages':127,'language_records':254},ensure_ascii=False))
