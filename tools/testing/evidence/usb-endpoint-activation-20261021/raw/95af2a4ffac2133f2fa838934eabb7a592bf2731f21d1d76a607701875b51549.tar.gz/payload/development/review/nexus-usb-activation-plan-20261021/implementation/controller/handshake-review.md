# Locked USB control-handshake timing review

Read-only manual/SDK review, 2026-10-21. No compiler, configure, tests, primary
or index writes. No controller after-image was changed by this reviewer.

## Strict preflight scope clarification

Root confirmed that the intended API requires preexisting `ep_flags == 0`;
otherwise the caller must service existing events first and retry. Thus the
previous review's finding1 is resolved by contract precision, without expanding
admission policy. The helper's0x50 allowance applies only to known IN hints
observed after this operation's own SNAK/control write. It does not authorize
admitting preexisting token-empty or NAK-effective flags. Keep this distinction
explicit in comments/docs; it preserves the no-write BUSY preflight contract.

## What the exact sources establish

ST RM0090 Rev22:

- **§34.16.1, printed p1254**, cached `rm0090.txt:77587–77589`: "All registers
  are implemented in the AHB clock domain."
- **§34.16.4, pp1299–1301**, `:80606–80619`, `:80664–80680`: SNAK sets NAK;
  SD0PID initializes DPID to DATA0. DPID and NAKSTS are observed state, whereas
  active/MPS/type/FIFO are programmed control characteristics.
- **DIEPINT, p1306**, `:81016–81024`: INEPNE means the core sampled NAK and
  the requested NAK took effect. It explicitly does **not** guarantee that a NAK
  handshake was sent on the USB wire.
- **§34.17.6, p1355**, `:85900–85917`: disabling an already-enabled IN endpoint
  requires SNAK, observing INEPNE, then EPDIS and observing EPDISD/EPENA clear.
  This is an acknowledgement sequence, not an immediate write-equals-effect
  assumption. The new setter never bypasses that existing drain sequence for
  a borrowed/enabled packet.
- **DAINTMSK, p1296**, `:80337–80359`: mask bits are ordinary rw CSR fields.
  Masking delivery does not clear the corresponding latched DAINT status.
- **GRSTCTL, pp1265–1266**, `:78360–78416`: eight clocks for RX flush and three
  PHY clocks after core reset are explicit, operation-specific requirements.
  They must not be copied into an invented SNAK/DATA0 latency bound.

GD32F4xx User Manual Rev3.3:

- **§28.7.3, pp988–990**, `gd32-manual.txt:56524–56610`: SNAK sets read-only
  NAKS; SD0PID clears observed DPID; EPACT is the endpoint-active control bit.
- **p994**, `:56966–56972`: IEPNE indicates that SNAK took effect and can be
  cleared by writing1 or by CNAK. General IN flag W1C behavior is at `:56917`.
- **§28.3, p929**, `:52577–52593`: USB and system/register domains are distinct
  in the block diagram. No fixed software-read count for SNAK/DATA0 is provided.

Neither exact manual states a maximum SNAK→NAKSTS or SD0PID→DPID completion
latency, nor a required number of AHB reads for either. Do not describe a chosen
software poll limit as a vendor-proved cycle bound or physical qualification.

Locked SDK behavior:

- ST LL `stm32f4xx_ll_usb.c:598–630` activation and `:1104–1125` clear-stall
  perform configuration/DATA0 writes without a status wait. They do not prove
  that Nexus's stronger state-readback contract completes after one DSB/read.
- ST LL `:935–984` stop-transfer uses a finite loop (10000 iterations) observing
  EPENA clear. Core reset `:1403–1439` separately polls AHB idle and CSRST.
  Those are examples of acknowledgement polling, not a DATA0 delay constant.
- GD `drv_usb_dev.c:250–296` activation and `:510–531` clear-stall likewise
  have no DATA0/NAK acknowledgement loop. Raw deactivate lacks Nexus drain
  proof, as already established in the earlier vendor review.

Exact source hashes are retained in `vendor-review/source-hashes.json` and the
implementation/native-model manifest. No large manual was downloaded or parsed
in this review.

## Recommended bounded observation

For the **serialized Task-only** explicit activation operation, reuse existing
`wait_bits`/`poll_limit` for the compound stable endpoint-control readback that
includes requested DATA0 and NAK status. Issue a command once; poll its observed
result. After acknowledging only an observed expected target hint, boundedly
observe the defined W1C bits clear. Do not reissue SNAK/DATA0/W1C on every poll,
add host-frame/SOF waits, or introduce a second timeout domain or budget.

For ACTIVE, immutable geometry and EP_MASK, the sources specify ordinary
programmed CSR values and no separate completion interrupt or delayed command
handshake. DSB followed by volatile readback is sufficient to verify the
programmed value. These fields can naturally participate in the same bounded
control-readback mask when status fields need observation; no additional
mandatory polling loop is justified for mask/active alone. Readback is not proof
of a wire-atomic configuration transition or that a host token has completed.

**Preserve the IRQ boundary:** the deactivation helper is also called by
`reset_nonzero_endpoints` from normal IRQ progress. Do not route its reset path
through the Task/cold `wait_bits` loop. IRQ/reset progress must issue/observe once,
retain reset_pending/clock on incomplete proof and retry through existing
service. Task-only bounded observation and nonblocking IRQ progress can share
pure register/proof helpers without adding private state or hot packet-path
polls.

For a direction already at NAK/DATA0, do not invent a requirement to wait for a
new INEPNE edge that the manuals do not promise. Observe required state, clear
and prove any expected hint actually seen, and leave later hints to ordinary
service. A DSB orders bus access; it is not a USB-domain completion event.

The parent is correcting the other review finding by independently attempting
safe ACTIVE withdrawal even when target-mask proof fails. IO/closing and the
full-stop clock/borrow proof must remain authoritative in that partial failure.
