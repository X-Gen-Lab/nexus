import hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(root))
from tools.dev.process import run
out=pathlib.Path(__file__).parent;expected=json.loads((out/'ordinary-input-freeze.json').read_text())
def verify(revision):
 for f in expected['files']:
  result=subprocess.run(['git','show',revision+':'+f['path']],cwd=root,capture_output=True)
  if f['kind']=='deleted':assert result.returncode!=0 and not (root/f['path']).exists()
  else:
   assert result.returncode==0 and hashlib.sha256(result.stdout).hexdigest()==f['sha256'];assert (root/f['path']).read_bytes()==result.stdout
verify('')
env=dict(os.environ,PRE_COMMIT_HOME='/tmp/nexus-quality-pre-commit',VIRTUALENV_OVERRIDE_APP_DATA='/tmp/nexus-quality-virtualenv',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1',PATH=str(root/'.venv/bin')+':/tmp/nexus-quality-arm/bin:/tmp/nexus-quality-doc-tools/bin:/usr/local/bin:/usr/bin:/bin')
result=run(['flock','/tmp/nexus-platform-compiler.lock','git','commit','--file',str(out/'commit-message.txt')],cwd=root,env=env,log=out/'ordinary-commit.raw',timeout=1800,stage='complete-unchanged-index-usb-activation-ordinary')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();record={'exit_code':result.returncode,'receipt':str(result.receipt_path),'head':head,'frozen_paths':len(expected['files'])}
if result.returncode==0:
 verify(head);tree=subprocess.check_output(['git','rev-parse',head+'^{tree}'],cwd=root,text=True).strip();assert tree==expected['index_tree'];record.update(tree=tree,exact_frozen_blobs_verified=True)
(out/'ordinary-result.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);raise SystemExit(result.returncode)
