"""Bind the frozen ordinary closure to exact accepted Git blobs; never run tests."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET

R = Path(__file__).resolve().parent
P = R / 'payload'
G = '/tmp/nexus-quality-20261019'
C = '34955a3900f3314c8af8d0068bc154d1afc868ba'
T = 'c589c6db1c7dc69eaf3cc37ca8b953f617d69f6e'


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()


def load(p): return json.loads(p.read_text())
def git(*a): return subprocess.check_output(['git','-C',G,*a]).decode().strip()
def put(p,d):
    assert not p.exists(), p
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')


frozen = load(R/'native-frozen.json')
inputs = load(P/'original-input-map.json')
freeze = load(P/'ordinary-root/ordinary-input-freeze.json')
source = load(P/'source/final-source-freeze-original.json')
master = load(P/'gate/master/receipt.json')
assert git('rev-parse',C+'^{tree}') == T == freeze['index_tree']
parent = git('rev-parse',C+'^')
assert parent == freeze['source_base'] == source['base'] == '6b10c814c21d94b069f5690300152f904ea14d22'
assert set(git('diff-tree','--no-commit-id','--name-only','-r',C).splitlines()) == {x['path'] for x in freeze['files']}
bindings = []
for row in freeze['files']:
    assert row['kind'] == 'file'
    process = subprocess.Popen(['git','-C',G,'show',C+':'+row['path']],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    digest = hashlib.sha256(); size = 0
    for block in iter(lambda: process.stdout.read(1024*1024),b''):
        digest.update(block); size += len(block)
    assert process.wait() == 0 and digest.hexdigest() == row['sha256'] and size == row['bytes'], row['path']
    bindings.append({**row,'git_blob':git('rev-parse',C+':'+row['path'])})
assert len(bindings) == 43
by_path = {x['path']:x for x in bindings}
assert len(source['files']) == 32
for path,digest in source['files'].items(): assert by_path[path]['sha256'] == digest
put(P/'source/committed-bindings.json',{'accepted_commit':C,'accepted_tree':T,'accepted_parent':parent,
    'recorded_precommit_builder_HEAD':parent,'recorded_precommit_staged_tree':T,
    'builder_scope':'Actual ordinary runs occurred before commit on dirty HEAD6b with frozen43-path index; receipts preserved byte-for-byte.',
    'clean_accepted_HEAD_build_claimed':False,'frozen_paths':len(bindings),'original_source_subset':source['files'],
    'original_source_subset_count':32,'files':bindings,
    'method':'Stream exact accepted Git blobs through SHA256/byte counts; never use later live working-tree or index bytes.',
    'tracked_archive_bodies_or_source_afterimages_copied':False})
(P/'source/commit.raw.txt').write_bytes(subprocess.check_output(['git','-C',G,'cat-file','commit',C]))
summary = load(P/'native-tdd/execution.json')
plan = load(P/'native-inputs/google-contracts.json')
commands = {p.name.removesuffix('.command.json'):load(p) for p in (P/'native-commands').glob('*.command.json')}
n = len(summary['suites'])
assert len(plan['executables']) == n and len(set(plan['executables'])) == n
expected = {'configure','build','tools-testing','tools-configure','tools-ci','tools-workflows'} | {f'{phase}-{i}' for phase in ('discovery','execution') for i in range(n)}
assert set(commands) == expected
for label,command in commands.items():
    actual = load(P/'native-attempts'/label/'receipt.json')
    assert {k:v for k,v in command.items() if k!='attempt_receipt'} == actual
    assert master['started_ns'] <= actual['started_ns'] <= actual['finished_ns'] <= master['finished_ns']
    assert actual['exit_code'] == 0 and actual['outcome']=='completed' and actual['withdrawal_stable'] and actual['withdrawal_complete']
    for key in ('stdout','stderr'):
        raw = P/inputs[actual[key]['path']]['payload']
        assert sha(raw)==actual[key]['sha256'] and raw.stat().st_size==actual[key]['bytes']
suites = {s['binary']:s for s in summary['suites']}; google = []
for i in range(n):
    command = commands[f'execution-{i}']; argv=command['command']; binary=Path(argv[0]).name
    assert argv == [plan['executables'][i],'--gtest_filter=*','--gtest_repeat=1','--gtest_also_run_disabled_tests',f'--gtest_output=xml:{G}/build/native-debug/tdd/google-{i}.xml']
    discovery = commands[f'discovery-{i}']
    assert discovery['command'] == [argv[0],'--gtest_filter=*','--gtest_list_tests']
    stdout=P/inputs[discovery['stdout']['path']]['payload']; suite=None; discovered=0
    for line in stdout.read_text().splitlines():
        text=line.split('#',1)[0].rstrip()
        if text and not text[0].isspace() and text.endswith('.'): suite=text
        elif suite is not None and text.startswith('  ') and text.strip(): discovered+=1
    xml=P/'native-tdd'/f'google-{i}.xml'; doc=ET.parse(xml).getroot(); cases=list(doc.iter('testcase'))
    assert doc.tag=='testsuites' and doc.get('name')=='AllTests'
    assert all(int(doc.get(k,0))==0 for k in ('failures','errors','disabled')) and not doc.findall('.//skipped')
    assert all(x.get('status')=='run' and x.get('result')=='completed' and not x.findall('failure') and not x.findall('error') for x in cases)
    assert len(cases)==int(doc.get('tests'))==discovered and discovered>0
    mtime=inputs[f'{G}/build/native-debug/tdd/google-{i}.xml']['mtime_ns']
    assert command['started_ns'] <= mtime <= command['finished_ns']
    s=suites[binary];assert s['tests']==s['passed']==discovered and all(s[k]==0 for k in ('failures','errors','skipped'))
    assert s['report_sha256']==sha(xml)
    google.append({'index':i,'binary':binary,'tests':discovered,'XML_sha256':sha(xml)})
assert sum(x['tests'] for x in google)==summary['passed']
tools={}
for name in ('testing','configure','ci','workflows'):
    report=load(P/'native-tdd'/f'tools-{name}.json');command=commands['tools-'+name]
    mtime=inputs[f'{G}/build/native-debug/tdd/tools-{name}.json']['mtime_ns']
    assert command['started_ns'] <= mtime <= command['finished_ns']
    assert report['status']=='passed' and report['discovered']==report['executed']
    assert all(report[k]==0 for k in ('failures','errors','skipped','expected_failures','unexpected_successes'))
    assert report==next(x for x in summary['tool_suites'] if x['suite']==name)
    tools[name]=report['executed']
property_inputs=load(P/'native-tdd/io-property-inputs.json');properties=load(P/'native-tdd/io-property-report.json')
assert properties['inputs']==property_inputs and properties['execution_summary_sha256']==sha(P/'native-tdd/execution.json')
for name,key in (('google-contracts.json','plan_sha256'),('compile_commands.json','compile_commands_sha256'),('io_lifecycle_matrix.json','catalogue_sha256')):
    assert sha(P/'native-inputs'/name)==property_inputs[key]
for key in ('stdout','stderr'):
    raw=P/inputs[master[key]['path']]['payload'];assert sha(raw)==master[key]['sha256']
assert (P/'ordinary-root/ordinary-commit.raw').read_bytes()==b''.join((P/inputs[master[k]['path']]['payload']).read_bytes() for k in ('stdout','stderr'))
facts={'status':'ACCEPTED_FROZEN_INDEX_ORDINARY_GATE','accepted_commit':C,'accepted_tree':T,
    'actual_precommit_builder_HEAD':parent,'actual_precommit_builder_staged_tree':T,'actual_precommit_builder_dirty':True,
    'clean_accepted_HEAD_build_claimed':False,'master_exit_code':master['exit_code'],
    'master_started_ns':master['started_ns'],'master_finished_ns':master['finished_ns'],
    'fresh_commands':len(commands),'Google_executables':n,'Google_passed':summary['passed'],
    'tools':tools,'tools_total':sum(tools.values()),'failures_errors_skips_disabled':0,
    'source_paths':len(bindings),'original_source_subset':32,'properties':len(properties['properties']),
    'unproven_properties':len(properties['unproven']),'formal_proof':properties['formal_proof'],
    'hardware_status':properties['hardware_status'],'historical_attempt_sweep':False,
    'raw_stream_storage':'SHA256 content blobs; original paths retained in original-input-map.json',
    'ordinary_scope':'Accepted complete frozen-index host gate bound to new commit by exact43 Git blobs; no clean-newHEAD, remote-CI, installed-SDK or hardware qualification inferred.'}
put(P/'capture-summary.json',facts);put(P/'google-derived-inventory.json',google)
for name in ('freeze.py','finish.py','native-frozen.json'):
    target=P/'provenance'/name;target.parent.mkdir(exist_ok=True);shutil.copy2(R/name,target);assert sha(target)==sha(R/name)
(P/'COLLECTION.txt').write_text(f"Accepted ordinary frozen-index gate for {C}, tree {T}. Actual build ran on dirty precommit HEAD {parent}; original receipt/source identities are unchanged. Exact43 committed blobs match frozen index; original32 source subset matches its original freeze. Fresh actual results derive {summary['passed']} Google cases/{n} executables, tools {sum(tools.values())}: {tools}. All current {len(commands)} commands lie within completed-zero actual master. No failures/errors/skips/disabled cases or effective filters. IO retains {len(properties['properties'])} bounded properties and {len(properties['unproven'])} unproven; no formal or hardware qualification. No historical attempt sweep, source/build/vendor tree or existing archive bodies. This successor capture belongs in a later docs-link increment, not self-acceptance.\n")
put(R/'capture-result.json',facts)
print(json.dumps(facts,indent=2))
