"""Freeze only the accepted ordinary master's current raw closure, after root GO."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import sys

sys.dont_write_bytecode = True
PRIMARY = Path('/tmp/nexus-quality-20261019')
TDD = PRIMARY / 'build/native-debug/tdd'
ORDINARY = Path('/tmp/nexus-usb-activation-ordinary-20261021')
OWNED = Path(__file__).resolve().parent
PAYLOAD = OWNED / 'payload'
EXPECTED_TREE = 'c589c6db1c7dc69eaf3cc37ca8b953f617d69f6e'
COPIED = {}


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def put(path, data):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def copy(source, relative):
    source = Path(source)
    assert source.is_file() and not any(p.is_symlink() for p in (source, *source.parents))
    assert not source.name.endswith(('.tar.gz', '.tar', '.tgz', '.zip', '.7z'))
    identity = {'sha256': sha(source), 'bytes': source.stat().st_size,
                'mtime_ns': source.stat().st_mtime_ns}
    target = PAYLOAD / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert sha(target) == identity['sha256'] and target.stat().st_size == identity['bytes']
    else:
        shutil.copy2(source, target)
    assert sha(target) == identity['sha256'] == sha(source)
    assert source.stat().st_size == identity['bytes']
    assert source.stat().st_mtime_ns == identity['mtime_ns']
    assert (source.stat().st_dev, source.stat().st_ino) != (target.stat().st_dev, target.stat().st_ino)
    assert target.stat().st_nlink == 1
    COPIED[str(source)] = {**identity, 'payload': relative, 'distinct_inode': True}


def receipt(path, prefix, lower=None, upper=None):
    path = Path(path)
    d = json.loads(path.read_text())
    assert d['outcome'] == 'completed' and d['exit_code'] == 0
    assert d['started_ns'] <= d['finished_ns'] and d['withdrawal_stable'] and d['withdrawal_complete']
    if lower is not None:
        assert lower <= d['started_ns'] <= d['finished_ns'] <= upper
    copy(path, prefix + '/receipt.json')
    for name in ('stdout', 'stderr'):
        raw = Path(d[name]['path'])
        assert sha(raw) == d[name]['sha256'] and raw.stat().st_size == d[name]['bytes']
        copy(raw, 'raw-blobs/' + d[name]['sha256'])
    return d


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument('--commit', required=True, help='actual accepted SHA supplied by root GO')
    args = args.parse_args()
    assert re.fullmatch('[0-9a-f]{40}', args.commit)
    assert not PAYLOAD.exists() and not (OWNED / 'native-frozen.json').exists()
    accepted = json.loads((ORDINARY / 'ordinary-result.json').read_text())
    freeze = json.loads((ORDINARY / 'ordinary-input-freeze.json').read_text())
    assert accepted['exit_code'] == 0 and accepted['head'] == args.commit
    assert accepted['tree'] == freeze['index_tree'] == EXPECTED_TREE
    assert accepted['exact_frozen_blobs_verified'] and len(freeze['files']) == 43
    master = receipt(accepted['receipt'], 'gate/master')
    pointer = json.loads((ORDINARY / 'ordinary-commit.command.json').read_text())
    assert pointer['attempt_receipt'] == accepted['receipt']
    assert {k:v for k,v in pointer.items() if k != 'attempt_receipt'} == master
    lower, upper = master['started_ns'], master['finished_ns']
    for name in ('ordinary-result.json','ordinary-input-freeze.json','ordinary-commit.command.json',
                 'ordinary-commit.raw','ordinary-launch.json','ordinary_supervisor.py','commit-message.txt'):
        copy(ORDINARY / name, 'ordinary-root/' + name)
    copy(Path('/tmp/nexus-usb-activation-root-20261021/final-source-freeze.json'), 'source/final-source-freeze-original.json')
    # These inputs live outside tdd and must be frozen before any reconfiguration.
    for source, relative in (
        (PRIMARY / 'build/native-debug/google-contracts.json', 'native-inputs/google-contracts.json'),
        (PRIMARY / 'build/native-debug/compile_commands.json', 'native-inputs/compile_commands.json'),
        (PRIMARY / 'tools/testing/io_lifecycle_matrix.json', 'native-inputs/io_lifecycle_matrix.json')):
        copy(source, relative)
    for name in ('execution.json','io-property-inputs.json','io-property-report.json',
                 'tools-testing.json','tools-configure.json','tools-ci.json','tools-workflows.json'):
        copy(TDD / name, 'native-tdd/' + name)
    summary = json.loads((PAYLOAD / 'native-tdd/execution.json').read_text())
    size = len(summary['suites'])
    current = {}
    for path in sorted(TDD.glob('*.command.json')):
        d = json.loads(path.read_text())
        if d.get('started_ns', 0) < lower:
            continue
        label = path.name.removesuffix('.command.json')
        actual = receipt(d['attempt_receipt'], 'native-attempts/' + label, lower, upper)
        assert {k:v for k,v in d.items() if k != 'attempt_receipt'} == actual
        copy(path, 'native-commands/' + path.name)
        current[label] = d
    expected = {'configure','build','tools-testing','tools-configure','tools-ci','tools-workflows'}
    expected |= {f'{kind}-{i}' for kind in ('discovery','execution') for i in range(size)}
    assert set(current) == expected
    for i in range(size):
        copy(TDD / f'google-{i}.xml', f'native-tdd/google-{i}.xml')
    inputs = json.loads((PAYLOAD / 'native-tdd/io-property-inputs.json').read_text())
    for name, key in (('google-contracts.json','plan_sha256'),
                      ('compile_commands.json','compile_commands_sha256'),
                      ('io_lifecycle_matrix.json','catalogue_sha256')):
        assert sha(PAYLOAD / 'native-inputs' / name) == inputs[key]
    put(PAYLOAD / 'original-input-map.json', COPIED)
    put(OWNED / 'native-frozen.json', {'status':'NATIVE_SAFE_TO_REUSE_RAW_INPUTS_FROZEN',
        'commit':args.commit,'tree':EXPECTED_TREE,'master_started_ns':lower,'master_finished_ns':upper,
        'current_commands_derived':len(current),'executable_suites_observed':size,
        'raw_blobs':len(list((PAYLOAD/'raw-blobs').iterdir())),
        'historical_attempts_swept':False,'source_build_vendor_or_existing_archive_bodies_copied':False,
        'counts_status':'derive and independently validate XML/tools from frozen bytes next',
        'payload':str(PAYLOAD),'input_map_sha256':sha(PAYLOAD/'original-input-map.json')})
    print((OWNED / 'native-frozen.json').read_text(), flush=True)


if __name__ == '__main__':
    main()
