# Exact F407 finite I2S2 slave-TX development evidence

This reference selects STM32F407VET6 or STM32F407ZGT6, baremetal,
HSE8/PLL168, external CK/WS and one finite stereo16 block. These are staged
development observations over commit `6032222cb099d7f5b4410b18f57f375126e87d7d`,
not a clean-source candidate or physical qualification. Firmware was linked,
not executed with a physical master, codec or Board.

Native executed all 35 current provider/System cases without failure or skip;
selection executed 28, coherent SDK-verification 42 and release-tool 57 cases.
The latter two total 99, not a complete v10 image-plan execution. The canonical
two-frame layout regression genuinely failed against the predecessor before
contiguous-row admission passed. Earlier 33-case history is retained separately.
Strict Wshadow and harness-setup failures are original rejected attempts, not
functional TDD RED; the test-only local-name correction is a separate phase.

Component retention executed 17 new checks within the complete 94-case scope.
The original actual CLI rejected a caller-owned face as no selected faces;
the corrected normal VE and ZG CLI audits each proved one caller face, one
read-only operations table and all four concrete methods. The audit proves
static retained ELF bytes, not runtime permissions or hardware behavior.

| Complete normal link context | Flash loaded | Flat BIN / footprint | SRAM including 2048 B MSP |
|---|---:|---:|---:|
| VE selected I2S2 | 10544 B | 10544 B | 2448 B |
| ZG selected I2S2 | 10544 B | 10544 B | 2448 B |
| Omitted default, no I2S symbols | 2979 B | 2980 B | 2112 B |
| One relocated development-SDK VE consumer | 10596 B | 10596 B | 2448 B |

These are complete linked configurations, not isolated driver-cost differences,
latency, stack high-water measurements or audio-rate characterization. The
consumer uses the public C11 interface; this does not claim SDK `-Werror`.

The single SDK execution used maintained export, physical prefix rename,
installed verification, the installed selected-consumer helper, public
`find_package`/normal firmware graph, selected-image audit and verification again.
The source and index observations before and after were equal. The 5999-file
snapshot is `acfc33470487eee4f5d1a118ba7b8eeed5847668291ea06e769909f1b1dab77c`,
with `publishable=false`; its consumer ELF is
`8211ecc0f6edcbca8a520bee704f34c25040681109d3ffbbf123dd9d945f7d59`.
This one VE consumer does not execute the full v10 50-root/53-image plan.
The complete SDK/build bytes were preserved, verified, independently restored
and compared before owned expanded copies were reclaimed; that preservation
is not a new compile or a portable execution claim.

## Original source-host receipts

The following absolute paths are original host locators, not checkout-relative
portable payloads. Hashes identify the retained actual receipts; final portable
qualification retains its own admission. No raw build tree is duplicated here.

| Actual receipt | SHA-256 |
|---|---|
| `/tmp/nexus-f407-i2s2-root-arm-evidence-20261020/execution.json` | `653b40d44cbf65108b037d1d444f291ef0841ffaf57772cf1d0c8d36bee277ba` |
| `/tmp/nexus-f407-i2s2-root-focused-r3-20261020/execution.json` | `a6c776371347a70441d1d7424761797fc98ee9e097a0ee9c988b5fa657b6a378` |
| `/tmp/nexus-f407-i2s2-root-arm-evidence-20261020/actual-retention-green.json` | `70ec3c9f666b859e2010ff60a016e72fa9a0c0d3aaf76c2b979fc932a91e8f41` |
| `/tmp/nexus-f407-i2s2-installed-sdk-evidence-20261020/execution.json` | `cfe70c49cc09395ca5e3207ad73ad10e1c7ea8cdbb46db8a9f7c5a211890ef90` |

API extraction/publication, the whole bilingual site and the final source commit
remain pending at this source-documentation preparation phase. Full clean-main
formal validation, the complete SDK plan, two fresh network-disabled OCI builds,
software-candidate sealing and physical HIL require their own actual evidence.
IO-41 stays `in_progress`/`not_qualified`; its original continuous-audio,
SAI/PDM and hardware exits are unchanged.
