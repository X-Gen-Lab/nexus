from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(root))
from tools.dev import process
from tools.evidence.identity import observe_git_source
out=Path(__file__).parent;work=Path('/dev/shm/nexus-f407-i2s2-normal-arm-20261020');assert not work.exists();work.mkdir()
before=observe_git_source(root);commands=[];record={'kind':'normal_f407_public_component_three_contexts','source_before':before,'commands':commands,'images':[],'status':'running','physical_status':'not_executed'}
(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
for label,assembly in [('ve','sky-i2s2-slave-tx.toml'),('zg','qiming-i2s2-slave-tx.toml'),('default','sky-baremetal-empty.toml')]:
 build=work/label
 argv=['cmake','-S',str(root/'tests/contracts/f407_i2s2_slave_tx'),'-B',str(build),'-G','Ninja','-DCMAKE_TOOLCHAIN_FILE='+str(root/'cmake/toolchains/arm-gcc.cmake'),'-DCMAKE_BUILD_TYPE=Release','-DNEXUS_SOURCE_ROOT='+str(root),'-DNEXUS_ASSEMBLY_FILE='+str(root/'tools/configure/assemblies'/assembly),'-DNEXUS_BUILD_TESTS=OFF','-DNEXUS_BUILD_WORKLOAD=OFF','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DPython3_EXECUTABLE='+str(root/'.venv/bin/python')]
 for phase,cmd in [('configure',argv),('build',['cmake','--build',str(build),'--target','f407_i2s2_public','--parallel','1'])]:
  result=process.run(cmd,cwd=root,env=os.environ.copy(),log=out/f'{label}-{phase}.log',timeout=300,stage='f407-i2s2-'+label+'-'+phase);commands.append(str(result.receipt_path));(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
  if result.returncode:record['status']='failed';(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(result.stderr[-4000:]);raise SystemExit(result.returncode)
 artifacts={}
 for ext in ['elf','bin','map','resources.json']:
  p=build/'bin'/('f407_i2s2_public.'+ext);artifacts[ext]={'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 resources=json.loads((build/'bin/f407_i2s2_public.resources.json').read_text());assert resources['status']=='passed'
 symbols=subprocess.check_output(['arm-none-eabi-nm','-S',str(build/'bin/f407_i2s2_public.elf')],text=True)
 (out/f'{label}-symbols.txt').write_text(symbols)
 if label=='default':assert 'nx_f407_i2s2_' not in symbols
 else:assert 'nx_f407_i2s2_slave_tx_ops' in symbols and 's_owner' in symbols and 's_tx' in symbols
 record['images'].append({'label':label,'assembly':assembly,'artifacts':artifacts,'resources':resources});(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
after=observe_git_source(root);record['source_after']=after;assert before==after;record['status']='passed';(out/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':'passed','contexts':[r['label'] for r in record['images']],'source_unchanged':True}))
