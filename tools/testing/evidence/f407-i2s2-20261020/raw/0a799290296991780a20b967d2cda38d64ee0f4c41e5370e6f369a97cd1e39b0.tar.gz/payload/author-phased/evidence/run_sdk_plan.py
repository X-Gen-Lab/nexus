"""Run the complete existing SDK-call and release modules over a sparse delta."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

OWN = Path(__file__).resolve().parents[1]
PRIMARY = Path('/tmp/nexus-quality-20261019')
phase = sys.argv[1]
final = '--final' in sys.argv
if '--inside-lock' not in sys.argv:
    raise SystemExit(subprocess.call([
        'flock', '-n', '-E', '75', '/tmp/nexus-platform-compiler.lock',
        sys.executable, '-B', __file__, *sys.argv[1:], '--inside-lock']))
sys.path.insert(0, str(PRIMARY))
sys.path.insert(0, str(PRIMARY / '.github/workflows'))
environment = dict(os.environ)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['PATH'] = (str(PRIMARY / '.venv/bin') +
    ':/tmp/nexus-quality-arm/bin:/tmp/nexus-quality-doc-tools/bin:/usr/local/bin:/usr/bin:/bin')
os.environ['NEXUS_BUILD_JOBS'] = '1'
os.environ['CMAKE_BUILD_PARALLEL_LEVEL'] = '1'
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
original_spec = importlib.util.spec_from_file_location
original_copy = shutil.copyfile
original_text, original_bytes = Path.read_text, Path.read_bytes
redirected = {
    PRIMARY / name: OWN / name for name in (
        'tools/configure/assemblies/sky-i2s2-slave-tx.toml',
        'cmake/package/verification/io_evolution/consumers/f407-i2s2-slave-tx.c')}


def selected_spec(name, location, *args, **kwargs):
    if final and Path(location) == PRIMARY / 'cmake/package/verify_consumers.py':
        location = OWN / 'cmake/package/verify_consumers.py'
    return original_spec(name, location, *args, **kwargs)


def copy(source, destination, *args, **kwargs):
    return original_copy(redirected.get(Path(source), source), destination, *args, **kwargs)


def read_text(path, *args, **kwargs):
    return original_text(redirected.get(path, path), *args, **kwargs)


def read_bytes(path, *args, **kwargs):
    return original_bytes(redirected.get(path, path), *args, **kwargs)


def load(name, path):
    spec = original_spec(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


transport_path = (OWN if final else PRIMARY) / 'tools/release/transport.py'
import tools.release
transport = load('tools.release.transport', transport_path)
tools.release.transport = transport
test_paths = [OWN / 'tools/testing/test_sdk_verification_call.py',
              OWN / '.github/workflows/test_release.py']
inputs = test_paths + list(redirected.values()) + [transport_path,
    (OWN if final else PRIMARY) / 'cmake/package/verify_consumers.py', Path(__file__).resolve()]
digest = lambda p: hashlib.sha256(original_bytes(p)).hexdigest()
before = {str(p): digest(p) for p in inputs}
suite = unittest.TestSuite()
for index, path in enumerate(test_paths):
    module = load('owned_sdk_plan_' + str(index), path)
    module.ROOT = PRIMARY
    if '--focused-red' in sys.argv:
        if index == 0:
            for method in ('test_producer_uses_the_standalone_transport_plan_without_a_copy',
                           'test_selected_owner_smokes_link_explicit_public_components'):
                suite.addTest(module.SDKConsumerParallelTests(method))
        else:
            suite.addTest(module.ConsumerTransportTests(
                'test_f407_i2s2_has_one_current_v10_public_owner_consumer'))
    else:
        suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
started = time.monotonic()
with patch.object(importlib.util, 'spec_from_file_location', selected_spec), \
        patch.object(shutil, 'copyfile', copy), \
        patch.object(Path, 'read_text', read_text), \
        patch.object(Path, 'read_bytes', read_bytes):
    result = unittest.TextTestRunner(verbosity=2).run(suite)
after = {str(p): digest(p) for p in inputs}
record = {'phase': phase, 'argv': sys.argv, 'sources_before': before,
          'sources_after': after, 'unchanged': before == after,
          'executed': result.testsRun, 'failures': len(result.failures),
          'errors': len(result.errors), 'skipped': len(result.skipped),
          'seconds': time.monotonic() - started,
          'scope': 'Full two existing contract modules; real verifier/transport, mocked external SDK/CMake processes',
          'sparse_inputs': {str(k): str(v) for k, v in redirected.items()},
          'exit': 0 if result.wasSuccessful() and result.testsRun and
          not result.skipped and before == after else 1}
(OWN / 'evidence' / (phase + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'phase': phase, 'exit': record['exit'], 'executed': result.testsRun}))
raise SystemExit(record['exit'])
