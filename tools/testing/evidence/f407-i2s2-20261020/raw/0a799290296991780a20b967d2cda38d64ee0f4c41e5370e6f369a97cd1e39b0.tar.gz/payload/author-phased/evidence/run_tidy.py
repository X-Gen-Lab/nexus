"""Focused required-check diagnostics using the actual successful C argv."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OWN = Path(__file__).resolve().parents[1]
PRIMARY = Path('/tmp/nexus-quality-20261019')
BUILD = Path('/dev/shm/nexus-f407-i2s2-tidy-20261020')
if '--inside-lock' not in sys.argv:
    raise SystemExit(subprocess.call([
        'flock', '-n', '-E', '75', '/tmp/nexus-platform-compiler.lock',
        sys.executable, '-B', __file__, '--inside-lock']))
BUILD.mkdir(exist_ok=True)
commands = json.loads((OWN / 'evidence/canonical-final-green.json').read_text())['commands']
units = [OWN / 'soc/stm32f407/drivers/i2s2_slave_tx.c',
         OWN / 'soc/stm32f407/system.c']
database = []
for unit in units:
    command = next(row['argv'] for row in commands if str(unit) in row['argv'])
    database.append({'directory': '/tmp', 'file': str(unit), 'arguments': command})
(BUILD / 'compile_commands.json').write_text(json.dumps(database, indent=2) + '\n')
tool = Path('/dev/shm/nexus-clang14-tool-20261020/prefix/usr/bin/clang-tidy-14')
environment = dict(os.environ)
environment['LD_LIBRARY_PATH'] = '/dev/shm/nexus-clang14-tool-20261020/prefix/usr/lib/x86_64-linux-gnu'
checks = ('-*,clang-analyzer-*,bugprone-*,cert-*,'
          '-clang-analyzer-security.insecureAPI.DeprecatedOrUnsafeBufferHandling,'
          '-clang-analyzer-optin.performance.Padding,-bugprone-easily-swappable-parameters,'
          '-bugprone-macro-parentheses,-bugprone-reserved-identifier,-cert-dcl37-c,-cert-dcl51-cpp')
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p): digest(p) for p in units}
results = []
for index, unit in enumerate(units):
    argv = [str(tool), str(unit), '-p', str(BUILD), '--checks=' + checks,
            '--warnings-as-errors=*', '--config-file=' + str(PRIMARY / '.clang-tidy'),
            '--header-filter=' + str(OWN) + '/(soc|components)/.*']
    start = time.monotonic()
    result = subprocess.run(argv, env=environment, capture_output=True)
    log = OWN / 'evidence' / ('focused-tidy-' + str(index) + '.txt')
    log.write_bytes(result.stdout + result.stderr)
    results.append({'argv': argv, 'exit': result.returncode,
                    'seconds': time.monotonic() - start, 'log': str(log),
                    'log_sha256': digest(log)})
after = {str(p): digest(p) for p in units}
record = {'scope': 'Focused actual Native MMIO C contexts; not full required CI analysis',
          'tool': {'path': str(tool), 'sha256': digest(tool)},
          'inputs_before': before, 'inputs_after': after,
          'unchanged': before == after, 'commands': results,
          'exit': 0 if before == after and all(row['exit'] == 0 for row in results) else 1}
(OWN / 'evidence/focused-tidy.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'exit': record['exit']}))
raise SystemExit(record['exit'])
