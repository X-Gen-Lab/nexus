"""Execute the existing SDK selection class against one sparse source delta."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import unittest
import types

PRIMARY = Path('/tmp/nexus-quality-20261019')
OWN = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PRIMARY))
sys.path.insert(0, str(PRIMARY / 'cmake/package'))
phase = sys.argv[1]
final = '--final' in sys.argv
inputs = [OWN / 'tests/contracts/test_source_sdk.py', Path(__file__).resolve()]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


if final:
    import tools.configure.providers
    path = OWN / 'tools/configure/providers/descriptor.py'
    descriptor = load('tools.configure.providers.descriptor', path)
    tools.configure.providers.descriptor = descriptor
    inputs.append(path)
    sdk_path = OWN / 'cmake/package/package_source_sdk.py'
else:
    sdk_path = PRIMARY / 'cmake/package/package_source_sdk.py'
inputs.append(sdk_path)
if final:
    # Execute the owned production bytes while __file__ binds only immutable
    # lock/fact reads to primary. No whole source view or dependency copy exists.
    sdk = types.ModuleType('package_source_sdk')
    sdk.__file__ = str(PRIMARY / 'cmake/package/package_source_sdk.py')
    sys.modules['package_source_sdk'] = sdk
    exec(compile(sdk_path.read_bytes(), str(sdk_path), 'exec'), sdk.__dict__)
else:
    sdk = load('package_source_sdk', sdk_path)
sdk.SOURCE_ROOT = PRIMARY
test = load('source_sdk_selected_f407', OWN / 'tests/contracts/test_source_sdk.py')
test.ROOT = PRIMARY
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p): digest(p) for p in inputs}
started = time.monotonic()
result = unittest.TextTestRunner(verbosity=2).run(
    unittest.defaultTestLoader.loadTestsFromTestCase(test.SourceSDKSelectionTests))
after = {str(p): digest(p) for p in inputs}
record = {'phase': phase, 'argv': sys.argv, 'sources_before': before,
          'sources_after': after, 'unchanged': before == after,
          'executed': result.testsRun, 'failures': len(result.failures),
          'errors': len(result.errors), 'skipped': len(result.skipped),
          'seconds': time.monotonic() - started,
          'scope': 'Existing selection/required closure class, not an SDK export or compile',
          'exit': 0 if result.wasSuccessful() and result.testsRun and
          not result.skipped and before == after else 1}
(OWN / 'evidence' / (phase + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'phase': phase, 'exit': record['exit'], 'executed': result.testsRun}))
raise SystemExit(record['exit'])
