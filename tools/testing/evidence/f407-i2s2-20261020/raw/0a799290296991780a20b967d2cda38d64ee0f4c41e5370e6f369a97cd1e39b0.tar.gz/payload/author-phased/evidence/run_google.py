"""Run this small source-bound Google harness only under the shared compiler lock."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET


ROOT = Path('/tmp/nexus-f407-i2s2-slave-20261020')
PRIMARY = Path('/tmp/nexus-quality-20261019')
BUILD = Path('/dev/shm/nexus-f407-i2s2-slave-20261020')
PHASE = sys.argv[1]
if '--inside-lock' not in sys.argv:
    raise SystemExit(subprocess.call([
        'flock', '-n', '-E', '75', '/tmp/nexus-platform-compiler.lock',
        sys.executable, '-B', __file__, PHASE, '--inside-lock']))

BUILD.mkdir(exist_ok=True)
units = [
    ROOT / 'soc/stm32f407/drivers/i2s2_slave_tx.c',
    PRIMARY / 'core/src/request.c',
    PRIMARY / 'core/src/time.c',
    PRIMARY / 'core/src/fault.c',
    PRIMARY / 'io/src/stream.c',
    PRIMARY / 'io/src/frame_stream.c',
    PRIMARY / 'io/src/dma.c',
    ROOT / 'soc/stm32f407/system.c',
    ROOT / 'tests/google/f407_i2s2_slave_tx_test.cpp',
]
inputs = units + [
    Path(__file__).resolve(),
    ROOT / 'components/f407_i2s2_slave_tx/include/nexus/components/f407_i2s2_slave_tx.h',
    ROOT / 'soc/stm32f407/private/stm32f407_i2s2_slave_tx.h',
    ROOT / 'tests/google/f407_i2s2_slave_tx_model.h',
    ROOT / 'soc/stm32f407/private/stm32f407_system.h',
]
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p): digest(p) for p in inputs}
includes = [ROOT / 'components/f407_i2s2_slave_tx/include',
            ROOT / 'soc/stm32f407/private', ROOT / 'tests/google',
            PRIMARY / 'core/include', PRIMARY / 'io/include',
            PRIMARY / 'arch/include', PRIMARY / 'soc/stm32f407/private',
            PRIMARY / 'build/native-debug/generated']
system = [PRIMARY / 'vendors/st/cmsis_device_f4/Include',
          PRIMARY / 'vendors/arm/CMSIS_5/CMSIS/Core/Include',
          PRIMARY / 'ext/googletest/googletest/include',
          PRIMARY / 'ext/googletest/googlemock/include']
common = ['-Wall', '-Wextra', '-Werror', '-Wconversion', '-pedantic', '-g',
          '-ffunction-sections', '-fdata-sections', '-DSTM32F407xx',
          '-DNEXUS_STM32_MODEL=1', '-DNX_F407_I2S_FLASH_BYTES=524288',
          '-include',
          str(ROOT / 'tests/google/f407_i2s2_slave_tx_model.h')]
for p in includes:
    common += ['-I', str(p)]
for p in system:
    common += ['-isystem', str(p)]
libraries = [PRIMARY / ('build/native-debug/lib/' + p)
             for p in ('libgmock_main.a', 'libgmock.a', 'libgtest.a')]
library_hashes = {str(p): digest(p) for p in libraries}
commands = []


def run(argv):
    start = time.monotonic()
    result = subprocess.run(argv, cwd='/tmp', stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    log = ROOT / 'evidence' / f'{PHASE}-{len(commands)}.txt'
    log.write_bytes(result.stdout)
    commands.append({'argv': argv, 'exit': result.returncode,
                     'seconds': time.monotonic() - start,
                     'log': str(log), 'log_sha256': digest(log)})
    return result.returncode


result = 0
objects = []
for index, source in enumerate(units):
    cpp = source.suffix == '.cpp'
    obj = BUILD / f'{index}.o'
    objects.append(str(obj))
    result = run(['g++' if cpp else 'gcc', '-std=c++17' if cpp else '-std=c11',
                  *common, '-c', str(source), '-o', str(obj)])
    if result:
        break
if not result:
    binary = BUILD / 'i2s2_test'
    result = run(['g++', *objects, '-Wl,--gc-sections',
                  *map(str, libraries), '-pthread', '-o', str(binary)])
    if not result:
        result = run([str(binary), '--gtest_color=no',
                      '--gtest_output=xml:' +
                      str(ROOT / 'evidence' / f'{PHASE}.xml')])
after = {str(p): digest(p) for p in inputs}
report = ROOT / 'evidence' / f'{PHASE}.xml'
cases = failures = errors = skipped = 0
if report.is_file() and len(commands) == len(units) + 2:
    tree = ET.parse(report).getroot()
    cases = len(tree.findall('.//testcase'))
    failures = len(tree.findall('.//failure'))
    errors = len(tree.findall('.//error'))
    skipped = len(tree.findall('.//skipped'))
if result == 0 and (cases == 0 or failures or errors or skipped):
    result = 1
receipt = {'phase': PHASE, 'commands': commands, 'exit': result,
           'inputs_before': before, 'inputs_after': after,
           'inputs_unchanged': before == after,
           'framework_libraries': library_hashes,
           'executed': cases, 'failures': failures, 'errors': errors,
           'skipped': skipped,
           'actual_runtime_red': cases > 0 and failures > 0 and not skipped,
           'setup_failed': len(commands) != len(units) + 2}
path = ROOT / 'evidence' / f'{PHASE}.json'
path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(path), 'exit': result,
                  'inputs_unchanged': before == after}))
raise SystemExit(result)
