"""Execute the two unchanged maintained schema contracts with one file input."""

import hashlib
import importlib
import io
import json
from pathlib import Path
import sys
import time
import unittest
from unittest.mock import patch


PRIMARY = Path('/tmp/nexus-quality-20261019')
CANDIDATE = Path('/tmp/nexus-f407-i2s2-slave-20261020')
OWN = CANDIDATE
sys.path[:0] = [str(CANDIDATE / 'tools/configure'),
                str(PRIMARY / 'tools/configure')]
import configure as gate
import authored
import ir
import kernel
import i2s2

gate.ROOT = PRIMARY
selected = OWN / 'tools/configure/assembly.schema.json'
original_read = Path.read_text


def read_selected(path, *args, **kwargs):
    # The unchanged tests read all normal facts from primary. Only their
    # maintained derived JSON input is this owned regular successor file.
    if path == PRIMARY / 'tools/configure/assembly.schema.json':
        return original_read(selected, *args, **kwargs)
    return original_read(path, *args, **kwargs)


names = [('test_toml', 'TomlConfigurationTests',
          'test_editor_schema_uses_resolver_field_model'),
         ('test_rtc_lptim', 'NativeTimeAssemblyTests',
          'test_editor_schema_matches_its_authoritative_generator')]
suite = unittest.TestSuite()
tests = []
for module, case, method in names:
    loaded = importlib.import_module(module)
    suite.addTest(getattr(loaded, case)(method))
    tests.append(Path(loaded.__file__))
inputs = [Path(m.__file__) for m in (gate, authored, ir, kernel, i2s2)] + tests
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
before = {str(p): digest(p) for p in inputs}
output = io.StringIO()
start = time.monotonic()
with patch.object(Path, 'read_text', read_selected):
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
phase = sys.argv[1]
log = OWN / 'evidence' / f'schema-{phase}.txt'
log.write_text(output.getvalue())
record = {'phase': phase, 'argv': sys.argv, 'tests': result.testsRun,
          'failures': len(result.failures), 'errors': len(result.errors),
          'skipped': len(result.skipped), 'seconds': time.monotonic() - start,
          'selected_json': str(selected), 'json_sha256': digest(selected),
          'inputs_before': before,
          'inputs_after': {str(p): digest(p) for p in inputs},
          'file_input_redirect': 'Only Path.read_text for exact primary '
              'tools/configure/assembly.schema.json uses owned regular JSON; '
              'unchanged original tests and all other primary facts are read.',
          'compiler_or_configure_executed': False,
          'log': str(log), 'log_sha256': digest(log)}
receipt = OWN / 'evidence' / f'schema-{phase}.json'
receipt.write_text(json.dumps(record, indent=2) + '\n')
print(output.getvalue())
print(json.dumps({'receipt': str(receipt), 'exit': 0 if result.wasSuccessful()
                  else 1}))
raise SystemExit(0 if result.wasSuccessful() else 1)
