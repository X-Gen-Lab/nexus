"""Run owned configuration modules against explicit read-only primary facts."""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import unittest


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    if not sys.dont_write_bytecode:
        os.execv(sys.executable,
                 [sys.executable, "-B", str(Path(__file__).resolve()), *sys.argv[1:]])
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase")
    parser.add_argument("--primary-root", type=Path,
                        default=Path("/tmp/nexus-quality-20261019"))
    arguments = parser.parse_args()
    if (not arguments.phase or
            any(character not in "abcdefghijklmnopqrstuvwxyz0123456789-_"
                for character in arguments.phase)):
        parser.error("phase must be a lowercase evidence filename")
    primary = arguments.primary_root.resolve()
    own = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(primary))
    import tools.configure

    names = ("i2s2", "ir", "authored", "configure")
    sources = [own / "tools/configure" / (name + ".py") for name in names]
    test_path = own / "tools/configure/test_f407_i2s2_configuration.py"
    sources.extend((test_path, Path(__file__).resolve()))
    component = own / "components/f407_i2s2_slave_tx/CMakeLists.txt"
    if component.is_file():
        sources.append(component)
    before = {str(path): digest(path) for path in sources}
    for name in names:
        path = own / "tools/configure" / (name + ".py")
        spec = importlib.util.spec_from_file_location("tools.configure." + name,
                                                      path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        setattr(tools.configure, name, module)
        spec.loader.exec_module(module)
        module.ROOT = primary
    spec = importlib.util.spec_from_file_location("f407_i2s2_configuration_test",
                                                  test_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.ROOT = primary
    started = time.monotonic()
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromModule(module))
    after = {str(path): digest(path) for path in sources}
    successful = (result.wasSuccessful() and result.testsRun > 0 and
                  not result.skipped and before == after)
    record = {
        "phase": arguments.phase,
        "argv": sys.argv,
        "python": sys.executable,
        "python_version": sys.version,
        "bytecode_disabled": sys.dont_write_bytecode,
        "primary_facts_root": str(primary),
        "owned_source_root": str(own),
        "sources_before": before,
        "sources_after": after,
        "sources_unchanged": before == after,
        "resolution_inputs": dict(sorted(module.INPUT_IDENTITIES.items())),
        "executed": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "seconds": time.monotonic() - started,
        "exit": 0 if successful else 1,
    }
    output = own / "evidence" / (arguments.phase + ".json")
    output.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"receipt": str(output), "exit": record["exit"],
                      "executed": result.testsRun,
                      "sources_unchanged": before == after}))
    return record["exit"]


if __name__ == "__main__":
    raise SystemExit(main())
