#!/usr/bin/env python3
"""One-shot bounded F407 evidence capture; final sealing waits for docs."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PAYLOAD = ROOT / 'payload'
AUTHOR = Path('/tmp/nexus-f407-i2s2-slave-20261020')
COPIED = {}

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def copy(src,dst,expected=None):
    src=Path(src)
    assert src.is_file() and not src.is_symlink() and not any(q.is_symlink() for q in src.parents),src
    h=sha(src)
    if expected is not None:assert h==expected,src
    dest=PAYLOAD/dst;dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():assert sha(dest)==h
    else:shutil.copyfile(src,dest)
    assert sha(dest)==h==sha(src),src
    COPIED[str(src)]={'payload':dst,'sha256':h,'bytes':dest.stat().st_size,'mtime_ns':src.stat().st_mtime_ns}
    return h

def put(name,data):
    p=PAYLOAD/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2)+'\n')

def capture_normal_artifacts():
    evidence=Path('/tmp/nexus-f407-i2s2-root-arm-evidence-20261020');phase=json.loads((evidence/'execution.json').read_text());rows=[]
    assert phase['status']=='passed' and phase['source_before']==phase['source_after']
    for image in phase['images']:
        label=image['label'];base=Path('/dev/shm/nexus-f407-i2s2-normal-arm-20261020')/label
        for role,row in image['artifacts'].items():
            src=Path(row['path']);copy(src,'normal-artifacts/'+label+'/'+src.name,row['sha256'])
        for rel in ('compile_commands.json','nexus/generated/resolved.json','nexus/generated/input_paths.json','nexus/generated/nexus_config.h','nexus/generated/selection.cmake'):
            src=base/rel;copy(src,'normal-artifacts/'+label+'/'+rel)
        rows.append({'label':label,'assembly':image['assembly'],'artifacts':image['artifacts'],'resources':image['resources']})
    copy(evidence/'execution.json','root-normal-arm/execution.json')
    put('normal-artifacts/phase-bindings.json',{'source_before':phase['source_before'],'source_after':phase['source_after'],'images':rows,'source_observation':'Use original frozen execution phase; no current primary source/index observation. Additional generated metadata is copied from these unchanged normal build directories only.','physical_status':'not_executed'})
    put('archive-input-map.json',COPIED)
    (ROOT/'critical-artifacts-frozen.json').write_text(json.dumps({'status':'normal_three_context_critical_artifacts_frozen','images':['ve','zg','default'],'payload':str(PAYLOAD),'scope':'Exact original execution artifact hashes, regular files; no build/configure/test execution or primary source/index mutation.'},indent=2)+'\n')
    print('CRITICAL_NORMAL_ARTIFACTS_FROZEN',flush=True)

def capture_tree(src,name):
    src=Path(src)
    for p in sorted(src.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(src)
        assert not p.is_symlink()
        # These roots contain only command/proof metadata, logs and preserved
        # final image artifacts. No full SDK, vendors or object/build tree.
        assert p.suffix not in ('.pdf','.o','.a','.gz'),p
        copy(p,name+'/'+rel.as_posix())

def validate_command_receipts():
    rows=[]
    for p in sorted(PAYLOAD.rglob('*.command.json')):
        d=json.loads(p.read_text())
        if not isinstance(d,dict) or 'attempt_receipt' not in d:continue
        original=Path(d['attempt_receipt']);mapped=COPIED.get(str(original))
        assert mapped is not None,original
        actual=json.loads((PAYLOAD/mapped['payload']).read_text())
        assert {k:v for k,v in d.items() if k!='attempt_receipt'}==actual
        assert actual['withdrawal_complete'] and actual['withdrawal_stable'] and actual['finished_ns']>=actual['started_ns']
        for channel in ('stdout','stderr'):
            raw=actual[channel];entry=COPIED.get(raw['path']);assert entry is not None and entry['sha256']==raw['sha256'] and entry['bytes']==raw['bytes']
        rows.append({'payload':str(p.relative_to(PAYLOAD)),'started_ns':d['started_ns'],'finished_ns':d['finished_ns'],'outcome':d['outcome'],'exit_code':d['exit_code'],'withdrawal_complete':True})
    put('actual-command-index.json',rows)
    return rows

def capture_execution():
    COPIED.update(json.loads((PAYLOAD/'archive-input-map.json').read_text()))
    manifest=AUTHOR/'evidence/raw-manifest-current.json';raw=json.loads(manifest.read_text());assert len(raw['files'])==260
    copy(manifest,'author-phased/raw-manifest-current.json')
    for row in raw['files']:
        src=AUTHOR/row['path'];assert src.stat().st_size==row['bytes'];copy(src,'author-phased/'+row['path'],row['sha256'])
    # Source/manual identity receipts, no production source bodies or PDFs.
    for rel in ('prelink-contiguous/manifest.json','sdk-v10-delivery/manifest.json','canonical-audio-successor/manifest.json','research/download.json','research/errata-download.json','research/datasheet-download.json'):
        copy(AUTHOR/rel,'author-phase-identities/'+rel)
    for p in sorted(Path('/tmp/nexus-f407-i2s2-production-review-20261020').glob('*.json')):copy(p,'independent-source-reviews/'+p.name)
    roots=[('nexus-f407-i2s2-root-arm-evidence-20261020','root-normal-arm'),('nexus-f407-i2s2-root-focused-20261020','root-strict-original'),('nexus-f407-i2s2-root-focused-r2-20261020','root-strict-r2'),('nexus-f407-i2s2-root-focused-r3-20261020','root-strict-r3'),('nexus-f407-i2s2-installed-sdk-evidence-20261020','installed-sdk')]
    for src,name in roots:capture_tree(Path('/tmp')/src,name)
    # Retention source bodies are deliberately excluded. Keep the exact small
    # reviewed patches/manifests and every already listed raw test member.
    retention=Path('/tmp/nexus-f407-component-retention-20261020')
    for rel,group in (('', 'retention-original93'),('successor-ops-reference','retention-successor94')):
        base=retention/rel;d=json.loads((base/'manifest.json').read_text())
        for n in ('manifest.json','baseline.json','component-retention.patch','run_overlay.py'):copy(base/n,group+'/'+n)
        for row in d['members']:
            src=Path(row['path']);assert src.stat().st_size==row['bytes'];copy(src,group+'/'+src.relative_to(base).as_posix(),row['sha256'])
    for src in ('/tmp/nexus-f407-component-retention-root-integration-20261020.json','/tmp/nexus-f407-i2s2-root-source-integration-20261020.json','/tmp/nexus-f407-i2s2-maintained-fixture-shadow-successor-20261020.json','/tmp/nexus-f407-i2s2-maintained-fixture-shadow-closed-20261020.json','/tmp/nexus-f407-i2s2-source-format-preflight-20261020.json','/tmp/nexus-f407-i2s2-root-visual-review-20261020.json'):
        copy(src,'root-phase-identities/'+Path(src).name)
    sdk=Path('/tmp/nexus-f407-i2s2-installed-sdk-evidence-20261020');execution=json.loads((sdk/'execution.json').read_text());assert execution['status']=='passed' and execution['sdk_publishable'] is False and execution['sdk_files']==5999 and execution['full_v10_plan_executed'] is False
    preserved=json.loads((sdk/'preserved-critical.json').read_text());assert len(preserved)==8
    for row in preserved:assert sha(row['preserved']['path'])==row['preserved']['sha256']==row['original']['sha256']
    archives=json.loads((sdk/'generated-archive-receipts.json').read_text());assert len(archives)==2
    for row in archives:
        assert row['all_inventory_bytes_equal'] and row['reclaimed_original_and_restore_only'] and row['verified']['status']==row['restore']['status']=='verified'
        assert sha(row['package']['archive']['path'])==row['package']['archive']['sha256']==row['verified']['archive_sha256']==row['restore']['archive_sha256']
    commands=validate_command_receipts()
    put('archive-input-map.json',COPIED)
    put('source-execution-phase-summary.json',{'status':'SOURCE_EXECUTION_FROZEN_PENDING_DOCS_AND_FINAL_SEAL','author_raw_files':260,'actual_command_receipts_validated':len(commands),'normal_images':['ve','zg','default'],'source_phase':'Root normal/strict/SDK records preserve their own dirty/staged source snapshots over committed MPU6032222. Never reobserve current source bytes as those earlier phases. Production C a446 and public42fc; canonical27d test later d9 test-only shadow rename belongs to its separate strict-build phase.','failure_classification':['Original functional staged23/25/30/33/35 RED/GREEN histories retained unchanged.','Author SDK99 mixed-source97PASS2FAIL remains NOT_GREEN historical; root coherentR3 later42SDK+57release=99PASS closes that execution gap.','Root strict original -Wshadow C++ build failure is a compile acceptance failure; no Google runtime RED claim.','Rootr2 successful strict build then wrong checked_binary argument is harness setup failure, not functional RED. Rootr3 actual35Google and selection28 succeed.','Actual first normal ELF retention CLI no-faces rejection retained;93/94 tool TDD and legal4-byte standalone ops-reference counterexample resolve it, then both VE/ZG actual CLI pass.'],'installed_sdk':{'snapshot_sha256':execution['snapshot_sha256'],'payload_files':5999,'publishable':False,'scope':'One relocated VE public consumer, not full v10 matrix. Existing full-prefix/build archives referenced only; no vendor/SDK payload duplicated.','external_archives':archives,'flash_load_bytes':10596,'static_sram_including_msp_bytes':2448},'normal_selected':{'ve_flash_load_bytes':10544,'zg_flash_load_bytes':10544,'static_sram_including_msp_bytes':2448,'main_stack_bytes':2048,'comparison_limit':'Different consumer/source roots and paths; no isolated Flash implementation delta or performance claim.'},'docs':'Not final at this capture. Root visual-review receipt is preserved with original identity and page predecessor; final page/PO/POT/FIG/meaning receipts must be added before a single maintained-store seal.','whole_ordinary_gate':'Future pending, not inferred from focused tests.','full_v10_matrix':'plan_not_executed','physical_hil':'not_executed','collector_executed_compiler_configure_build_tests':False,'primary_index_or_source_writes':False})
    summary={'status':'SOURCE_EXECUTION_FROZEN_WAITING_FINAL_DOCS','payload':str(PAYLOAD),'files':sum(p.is_file() for p in PAYLOAD.rglob('*')),'bytes':sum(p.stat().st_size for p in PAYLOAD.rglob('*') if p.is_file()),'author_raw_files':260,'normal_critical_contexts':3,'sdk_preserved_final_artifacts':8,'actual_command_receipts':len(commands),'final_seal_performed':False,'docs_pending':True}
    (ROOT/'prepared.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='normal':capture_normal_artifacts()
    elif sys.argv[1]=='execution':capture_execution()
    else:raise SystemExit('expected normal or execution; finalseal is intentionally not enabled until docs arrive')
