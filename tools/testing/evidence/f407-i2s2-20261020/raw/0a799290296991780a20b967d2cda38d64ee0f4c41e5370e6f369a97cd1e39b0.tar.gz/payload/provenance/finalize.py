#!/usr/bin/env python3
"""Capture the completed strict site, then seal once using maintained store."""
from pathlib import Path
import ast
import hashlib
import json
import runpy
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;E=runpy.run_path(str(ROOT/'collect.py'));P=ROOT/'payload';copy=E['copy'];put=E['put'];sha=E['sha'];M=E['COPIED'];M.update(json.loads((P/'archive-input-map.json').read_text()))
assert not (ROOT/'package.json').exists(), 'Never reseal an existing portable package'
accept_path=Path('/tmp/nexus-f407-final-full-site-acceptance-20261020.json');accept=json.loads(accept_path.read_text());build_path=Path(accept['build_manifest']);build=json.loads(build_path.read_text())
assert accept['status']==build['status']=='passed' and sha(build_path)==accept['build_manifest_sha256']=='18ded2de446932c8e5529e346c4c53fa5f73139946afd762d0df921db2b27d82'
assert accept['qualification'] is build['qualification'] is False and accept['physical_status']=='not_executed' and accept['languages']==build['languages']==['en','zh_CN']
assert accept['whole_site_source_check_status']==build['source_check']['status']=='passed' and build['source_check']['pages']==127 and accept['unchanged_frozen_input_count']==1626
copy(accept_path,'documentation-fullsite/root-acceptance.json')
copy(build_path,'documentation-fullsite/documentation-build.json',accept['build_manifest_sha256'])
wide_path=Path(accept['source_freeze']);wide=json.loads(wide_path.read_text());assert len(wide['files'])==1626 and wide['prior_sha256']==sha(P/'documentation-final/source-freeze.json')
copy(wide_path,'documentation-fullsite/all-inputs-broad-superset-freeze.json')
copy('/tmp/nexus-f407-i2s2-final-docs-20261020.log','documentation-fullsite/outer-command.log')
workspace=Path(build['workspace']);assert workspace.name=='7cc9ace47f4842c29bfaa7077c39d738'
sourcecheck=json.loads((workspace/'source-check.json').read_text());assert sourcecheck==build['source_check']
copy(workspace/'source-check.json','documentation-fullsite/source-check.json')
assert len(build['command_receipts'])==4
commands=[]
for original in build['command_receipts']:
    original=Path(original);d=json.loads(original.read_text());assert d['exit_code']==0 and d['outcome']=='completed' and d['withdrawal_complete'] and d['withdrawal_stable']
    label=original.parent.parent.name.removesuffix('.attempts');copy(original,'documentation-fullsite/'+label+'/actual-receipt.json')
    canonical=workspace/(label+'.command.json');c=json.loads(canonical.read_text());assert c['attempt_receipt']==str(original) and {k:v for k,v in c.items() if k!='attempt_receipt'}==d
    copy(canonical,'documentation-fullsite/'+label+'/command.json')
    for key in ('stdout','stderr'):
        row=d[key];assert Path(row['path']).stat().st_size==row['bytes'];copy(row['path'],'documentation-fullsite/'+label+'/'+key+'.txt',row['sha256'])
    commands.append({'stage':label,'started_ns':d['started_ns'],'finished_ns':d['finished_ns'],'exit_code':0,'withdrawal_complete':True,'receipt_sha256':sha(original)})
pots=sorted((workspace/'gettext').rglob('*.pot'));assert len(pots)==127
for f in pots:copy(f,'documentation-fullsite/gettext/'+f.relative_to(workspace/'gettext').as_posix())

def msgids(path):
    ids=[];field=None;value=''
    for line in path.read_text().splitlines():
        if line.startswith('msgid '):
            field='id';value=ast.literal_eval(line[6:])
        elif line.startswith('msgstr'):
            if field=='id' and value:ids.append(value)
            field=None;value=''
        elif field=='id' and line.startswith('"'):value+=ast.literal_eval(line)
    return ids
final=json.loads((P/'documentation-final/final-catalogs.json').read_text());closure=[]
for row in final['files']:
    name=row['relative_path'];language=name.split('/')[2];domain=Path(name).relative_to('docs/locale/'+language+'/LC_MESSAGES').with_suffix('.pot')
    pot=workspace/'gettext'/domain;catalog=P/'documentation-final/catalogs'/name
    a=msgids(pot);b=msgids(catalog);assert len(a)==len(set(a))==len(b)==len(set(b))==row['message_count'] and set(a)==set(b)
    assert 'X-Nexus-Reviewed: true' in catalog.read_text()
    closure.append({'catalog':name,'messages':len(a),'full_site_pot_sha256':sha(pot),'catalog_sha256':sha(catalog)})
put('documentation-fullsite/admission-summary.json',{'status':'passed_development_staged_dirty_phase','source':build['source'],'languages':['en','zh_CN'],'source_check_pages':127,'source_check':'passed','translations':build['translations'],'actual_commands':commands,'all_command_exits_zero':True,'frozen_input_count':1626,'frozen_input_scope':'Broad source/dependency superset with hashes only; includes unused inputs. Not an assertion every one of1626 files was parsed/rendered.','external_dependency_freeze_files':48,'final_catalogs_rebound_to_full_site_pots':closure,'whole_HTML_XML_copied':False,'ordinary_full_index_gate':'pending','full_v10_matrix':'plan_not_executed','physical_HIL':'not_executed','qualification':False})
put('archive-input-map.json',M)
base=(P/'documentation-final/source-bound-README.md').read_bytes();assert hashlib.sha256(base).hexdigest()=='84764e76aaf64b962e082448ec282ea6f143692e535c577799b0a4dcce571e96' and len(base)==4023
index='''\n\n## Compact archive and later validation phases\n\nThe source-bound text above is retained byte-for-byte (4023 bytes, SHA256\n`84764e76aaf64b962e082448ec282ea6f143692e535c577799b0a4dcce571e96`).\nThis index adds later evidence; it does not relabel earlier source snapshots.\n\n| Archive directory | Preserved evidence | Scope |\n|---|---|---|\n| `author-phased` | Original260 raw phase files, functional RED/GREEN and rejected setup/mixed-source attempts | Original identities/classifications unchanged |\n| `root-normal-arm`, `normal-artifacts` | VE/ZG selected and omitted/default normal public ARM graphs, exact ELF/BIN/map/resource/resolved/compile metadata | Linking and static retention, no physical execution |\n| `root-strict-original`, `root-strict-r2`, `root-strict-r3` | Original Wshadow compile rejection, successful corrected build/harness setup failure, then35 Google+28 selection+42 SDK+57 release passed | Compile/setup failures are not functional RED |\n| `retention-original93`, `retention-successor94` | Original93 and legal4-byte ops-reference RED→94 complete cases,17 new tests, exact patches and root integration | Both actual normal VE/ZG audits then pass |\n| `installed-sdk` | Eight critical artifacts, manifest/snapshot/source bindings, actual commands/postcheck and external archive receipts | One relocated development VE SDK consumer; full v10 plan not executed |\n| `mpu-static-fix` | Explicit16 sanitized remote members, equivalent bc193→cc643 fix, independent review,28 Google, fresh normal MPU ARM+retention | Earlier603 and installed-SDK source/resource phases remain separate |\n| `focused-tidy-r1-harness-setup`, `focused-tidy-r2` | Missing-environment setup error and10 distinct successful current analysis contexts | Original setup failure remains rejected |\n| `documentation-preliminary` | Actual first Doxygen0/gettext1 and repaired gettext0, both127-POT outputs | First multiline-link warning was not suppressed or relabeled |\n| `documentation-final` | Initial18-file doc patch, supported-link successor,12 final catalogs and107 independently reviewed new pairs, FIG30 PNGs/review and source-bound README |98 contract/API/ledger pairs plus9 navigation/atlas pairs |\n| `documentation-fullsite` | Completed actual Doxygen/gettext/English/Chinese commands, raw streams, source/translation reports and127 POTs | Strict maintained bilingual development site passed; ordinary full index gate pending |\n\nThe final strict site passed all127 source pages and complete bilingual\ntranslation admission. All four maintained commands exited0 with process\nwithdrawal complete. The1626-file frozen-input superset remained unchanged;\nit includes unused source and does not assert all1626 files render. Its48\nexternal dependencies, the original dirty/staged source identity over6032222,\nand qualification=false remain explicit. No whole HTML/XML tree is included.\n\nThe distinct MPU static-analysis successor has loaded Flash15310B (the prior603\nphase recorded15306B), flat BIN/footprint24880B, SRAM6000B including2048B MSP\nand heap0. Its fresh normal ELF is\n`70969a20482387fce9a19d47f9325461f8d7ddfa51ac4cfcd5a5c656fb801db5`.\nThese later observations do not overwrite the old MPU resources or the old\nF407 SDK snapshot.\n\nExisting full SDK and build archives4696d459… and9933432… are referenced by\ntheir original full restore/inventory verification receipts, not duplicated\nwith vendor payloads here. No current dirty source is substituted for an\nolder execution phase. The archive collector ran no compiler/configure/tests\nand changed no primary source/index. Final ordinary full-gate acceptance,\nformal clean main qualification, the complete v10 image matrix and physical\nHIL are not established by this archive.\n'''
archived_readme=base+index.encode();(P/'README.md').write_bytes(archived_readme)
put('collection-final-scope.json',{'status':'COMPLETED_DEVELOPMENT_PHASES_AND_STRICT_SITE_ARCHIVED','source_bound_README_sha256':hashlib.sha256(base).hexdigest(),'source_bound_README_prefix_bytes':len(base),'strict_site_build_manifest_sha256':sha(build_path),'catalog_manifest_sha256':sha(P/'documentation-final/final-catalogs.json'),'root_site_acceptance_sha256':sha(accept_path),'ordinary_full_gate':'pending','full_v10_matrix':'not_executed','HIL':'not_executed','compiler_configure_tests_rerun_by_collector':False,'source_index_writes':False,'external_archive_payloads_duplicated':False,'whole_HTML_XML_copied':False})
(P/'provenance').mkdir(exist_ok=True)
for name in ('collect.py','augment.py','augment_mpu_arm.py','augment_final_catalogs.py','finalize.py'):
    (P/'provenance'/name).write_bytes((ROOT/name).read_bytes())
# Validate copied payloads only. Do not reobserve later-dirty primary bytes as
# earlier source phases or reopen excluded remote raw-job/access material.
for source,row in M.items():
    p=P/row['payload'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],source
sys.path.insert(0,'/tmp/nexus-quality-20261019')
from tools.evidence.store import export_tree,verify_package
package=export_tree(P,ROOT/'store');(ROOT/'package.json').write_text(json.dumps(package,indent=2)+'\n');verified=verify_package(package);(ROOT/'verified.json').write_text(json.dumps(verified,indent=2)+'\n')
assert verified['status']=='verified' and verified['archive_sha256']==package['archive']['sha256']
archive_name=Path(package['archive']['path']).name
final_readme=archived_readme+('\nPortable raw archive: [raw/'+archive_name+'](raw/'+archive_name+').\n\nArchive SHA256: `'+package['archive']['sha256']+'`; '+str(package['archive']['size'])+' compressed bytes, '+str(package['files'])+' files, '+str(package['bytes'])+' uncompressed bytes. The maintained-store package descriptor and verification receipt accompany this archive.\n').encode()
assert final_readme[:len(base)]==base
(ROOT/'README.md').write_bytes(final_readme)
def identity(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
prefix={'source_bound_prefix_sha256':hashlib.sha256(base).hexdigest(),'source_bound_prefix_bytes':len(base),'prefix_unchanged':True,'archived_README':identity(P/'README.md'),'final_repository_README':identity(ROOT/'README.md'),'delta':'Append-only archive index, later strict-site/MPU successor development facts, and outer archive locator. No original source/host/resource fact edited.'};(ROOT/'README-prefix-addendum.json').write_text(json.dumps(prefix,indent=2)+'\n')
delivery={'status':'SEALED_AND_BYTE_VERIFIED','package':identity(ROOT/'package.json'),'verified':identity(ROOT/'verified.json'),'README':identity(ROOT/'README.md'),'README_prefix_addendum':identity(ROOT/'README-prefix-addendum.json'),'archive':package['archive'],'files':package['files'],'bytes':package['bytes'],'source_bound_README_prefix':prefix['source_bound_prefix_sha256'],'strict_site':{'status':'passed_development_dirty_staged_phase','build_manifest_sha256':sha(build_path),'source_pages':127,'languages':['en','zh_CN'],'command_exits':[0,0,0,0],'unchanged_frozen_input_superset':1626,'final_catalogs':12,'independently_reviewed_new_pairs':107,'qualification':False},'ordinary_full_index_gate':'pending','full_v10_matrix':'not_executed','physical_HIL':'not_executed','collector_compiler_configure_build_tests':False,'collector_primary_source_index_writes':False,'external_full_SDK_build_archives_duplicated':False,'whole_XML_HTML_copied':False};(ROOT/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
print(json.dumps({'delivery':identity(ROOT/'delivery.json'),**delivery}),flush=True)
