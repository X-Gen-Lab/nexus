#!/usr/bin/env python3
"""Add explicit completed gettext/static-fix phases; do not seal pending docs."""
from pathlib import Path
import hashlib
import json
import runpy
import sys
import xml.etree.ElementTree as ET
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
E=runpy.run_path(str(ROOT/'collect.py'))
PAYLOAD=ROOT/'payload';copy=E['copy'];put=E['put'];sha=E['sha'];mapped=E['COPIED']
mapped.update(json.loads((PAYLOAD/'archive-input-map.json').read_text()))
new_commands=[]
def receipt(path,label):
    path=Path(path);d=json.loads(path.read_text());attempt=Path(d['attempt_receipt']);a=json.loads(attempt.read_text())
    assert {k:v for k,v in d.items() if k!='attempt_receipt'}==a and a['withdrawal_complete'] and a['withdrawal_stable']
    copy(path,label+'/command.json');copy(attempt,label+'/actual-receipt.json')
    for key in ('stdout','stderr'):
        row=a[key];assert Path(row['path']).stat().st_size==row['bytes'];copy(row['path'],label+'/'+key+'.txt',row['sha256'])
    new_commands.append({'payload':label,'stage':a['stage'],'started_ns':a['started_ns'],'finished_ns':a['finished_ns'],'outcome':a['outcome'],'exit_code':a['exit_code'],'withdrawal_complete':True})
    return a

gettext=[]
for name,label in [('nexus-f407-primary-gettext-20261020','primary-gettext-r1'),('nexus-f407-primary-gettext-r2-20261020','primary-gettext-r2')]:
    root=Path('/dev/shm')/name;d=json.loads((root/'execution.json').read_text());copy(root/'execution.json','documentation-preliminary/'+label+'/execution.json')
    for command in sorted(root.glob('*.command.json')):receipt(command,'documentation-preliminary/'+label+'/'+command.name.removesuffix('.command.json'))
    # Exact emitted POTs and raw execution receipts only; never API XML,
    # doctrees, full HTML or a current PO under active meaning review.
    pots=list(sorted((root/'gettext').rglob('*.pot')));assert len(pots)==127
    if label.endswith('r2'):
        assert d['status']=='passed' and d['source_before']==d['source_after']
        expected={row['path']:row['sha256'] for row in d['pots']};assert set(expected)=={str(p) for p in pots}
    else:
        assert d['status']=='failed';expected={}
    for p in pots:copy(p,'documentation-preliminary/'+label+'/gettext/'+p.relative_to(root/'gettext').as_posix(),expected.get(str(p)))
    gettext.append({'phase':label,'status':d['status'],'pots':127,'raw_receipts_copied':len(list(root.glob('*.command.json'))),'scope':'Original extraction phase only; not whole-site acceptance. R1 Doxygen0 and gettext1 link warning retained; R2 gettext0 after supported single-line link/qualification prose repair and unchanged source snapshot.'})

remote=Path('/tmp/nexus-603-static-failure-20261020');handoff=json.loads((remote/'handoff.json').read_text());assert len(handoff['members'])==16
copy(remote/'handoff.json','mpu-static-fix/remote-explicit16/handoff.json')
for row in handoff['members']:
    p=Path(row['path']);rel=p.relative_to(remote);assert p.stat().st_size==row['bytes'];assert rel.as_posix() not in ('artifact-url','artifact-url.txt','raw-job.json')
    copy(p,'mpu-static-fix/remote-explicit16/'+rel.as_posix(),row['sha256'])
# The remote subset is deliberately partial. Never follow its original CI
# attempt paths or read any artifact access URL/full raw job.

first=Path('/tmp/nexus-f407-mpu-focused-tidy-20261020')
for name in ('execution.json','setup-failure.json'):copy(first/name,'focused-tidy-r1-harness-setup/'+name)
second=Path('/tmp/nexus-f407-mpu-focused-tidy-r2-20261020');td=json.loads((second/'execution.json').read_text());assert td['status']=='passed' and td['context_count']==len(td['selected'])==len(td['results'])==10 and td['source_before']==td['source_after']
copy(second/'execution.json','focused-tidy-r2/execution.json')
receipt(second/'version.command.json','focused-tidy-r2/version')
for row in td['results']:
    assert row['exit_code']==0
    n=str(row['context']);receipt(second/n/'analysis.command.json','focused-tidy-r2/'+n+'/analysis')
    copy(second/n/'compile_commands.json','focused-tidy-r2/'+n+'/compile_commands.json');copy(row['report'],'focused-tidy-r2/'+n+'/result.txt')

mpu=Path('/tmp/nexus-mpu-static-fix-focused-20261020');md=json.loads((mpu/'execution.json').read_text());assert md['status']=='passed' and md['source_before']==md['source_after']
copy(mpu/'execution.json','mpu-static-fix/focused/execution.json')
for p in sorted(mpu.glob('*.command.json')):receipt(p,'mpu-static-fix/focused/'+p.name.removesuffix('.command.json'))
x=ET.parse(mpu/'google.xml').getroot();assert int(x.get('tests'))==28 and all(int(x.get(k,0))==0 for k in ('failures','errors','disabled')) and not x.findall('.//skipped')
copy(mpu/'google.xml','mpu-static-fix/focused/google.xml')
put('documentation-preliminary/phase-index.json',gettext)
put('mpu-static-fix/phase-index.json',{'remote_scope':'Exactly the16 root-reviewed allowlisted members plus handoff; signed artifact URLs, raw-job.json, full source before-images,434MB artifact and unselected contexts are excluded. Original diagnostic handoff pending-focused status is historical and unchanged.','static_equivalence_delta':'os/freertos/mpu/gpio.c committed603 bc193 predecessor to cc643 equivalence fix; full hashes/patch and independent review are in the explicit16 members.','local_followup':{'tidy_contexts':10,'tidy_status':'passed','mpu_google':28,'mpu_status':'passed','first_tidy_harness':'missing environment setup failure, not functional RED'},'phase_limits':'These new phases do not relabel the old acfc SDK snapshot or normal F407 artifacts as rebuilt against the MPU static successor. Fresh root MPU ARM/source-binding receipt remains pending. Full bilingual site and final12PO review remain pending.','source_observation':'Only exact original completed phase metadata read; no current primary source/index observation.'})
put('additional-local-command-index.json',new_commands)
put('archive-input-map.json',mapped)
put('source-execution-addendum.json',{'status':'ADDITIVE_PHASES_FROZEN_FINAL_SITE_AND_PO_REVIEW_PENDING','gettext_pots':254,'remote_explicit_members':16,'local_tidy_contexts':10,'mpu_google':28,'new_local_maintained_commands':len(new_commands),'full_api_xml_html_copied':False,'active_review_PO_copied':False,'artifact_urls_or_raw_jobs_read_or_copied':False,'compiler_configure_tests_executed_by_collector':False,'primary_index_or_source_writes':False,'final_seal_performed':False})
prepared=json.loads((ROOT/'prepared.json').read_text());prepared.update({'status':'SOURCE_EXECUTION_AND_PRELIMINARY_DOC_STATIC_PHASES_FROZEN_WAITING_FINAL_SITE','files':sum(p.is_file() for p in PAYLOAD.rglob('*')),'bytes':sum(p.stat().st_size for p in PAYLOAD.rglob('*') if p.is_file()),'gettext_pots_added':254,'remote_explicit_members_added':16,'tidy_contexts_added':10,'mpu_google_added':28,'final_seal_performed':False,'docs_pending':True});(ROOT/'prepared.json').write_text(json.dumps(prepared,indent=2)+'\n')
print(json.dumps(prepared),flush=True)
