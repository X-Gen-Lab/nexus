#!/usr/bin/env python3
"""Capture final reviewed catalogs/FIG identities; active full site is excluded."""
from pathlib import Path
import hashlib
import json
import runpy
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;E=runpy.run_path(str(ROOT/'collect.py'));P=ROOT/'payload';copy=E['copy'];put=E['put'];sha=E['sha'];M=E['COPIED'];M.update(json.loads((P/'archive-input-map.json').read_text()))
docs=Path('/tmp/nexus-f407-i2s2-docs-final-20261020');primary=Path('/tmp/nexus-quality-20261019');final=json.loads((docs/'final-catalogs.json').read_text());assert final['catalog_count']==len(final['files'])==12 and final['new_translation_pairs']==107
assert sha(docs/'final-catalogs.json')=='82eb7911738edeb5f1349632c1c2694d0b9c4cc437dbca1710d3629b86193fe9'
for name in ('final-catalogs.json','final-catalogs.patch','catalog-review-input.json','catalog-independent-review.json','catalog-nav-atlas-independent-review.json','whole-r2-catalog-closure-before-review.json','r2-catalog-delta-inventory.json','r2-evidence-paragraph-meaning-approved.json','scope-commands-final-paragraph-meaning-review.json','final-evidence-paragraph.json','initial-source.json','initial-source.patch'):
    copy(docs/name,'documentation-final/'+name)
for key in ('review_input','independent_98_review','independent_9_review','full_r2_before_review_closure'):
    row=final[key];assert sha(row['path'])==row['sha256'] and Path(row['path']).stat().st_size==row['bytes']
for row in final['files']:
    f=row['final'];assert Path(f['path']).stat().st_size==f['bytes'];copy(f['path'],'documentation-final/catalogs/'+row['relative_path'],f['sha256'])
    # This is explicitly the new final documentation phase, never reobserved as
    # any earlier ARM/SDK source phase. Root already applied these exact bytes.
    assert sha(primary/row['relative_path'])==f['sha256']
    assert sha(row['source']['path'])==row['source']['sha256']
    assert sha(row['pot']['path'])==row['pot']['sha256']

freeze_path=Path('/tmp/nexus-f407-final-doc-source-freeze-20261020.json');freeze=json.loads(freeze_path.read_text());assert freeze['catalog_manifest_sha256']==sha(docs/'final-catalogs.json')
for row in freeze['files']:
    p=primary/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
for name,h in freeze['production_sources'].items():assert sha(primary/name)==h
copy(freeze_path,'documentation-final/source-freeze.json')
copy('/tmp/nexus-f407-doc-link-successor-20261020.json','documentation-final/root-supported-link-successor.json')
visual_path=Path('/tmp/nexus-f407-i2s2-root-visual-review-20261020.json');visual=json.loads(visual_path.read_text());copy(visual_path,'documentation-final/root-visual-review.json');assert visual['status']=='approved'
for language,row in visual['images'].items():
    assert Path(row['path']).stat().st_size==row['bytes'];copy(row['path'],'documentation-final/FIG30-'+language+'.png',row['sha256'])
initial=json.loads((docs/'initial-source.json').read_text());assert initial['patch']['sha256']==sha(docs/'initial-source.patch')==freeze['initial_source_patch_sha256']
source_successor=json.loads(Path(freeze['page_successor_receipt']).read_text())
# Freeze.files binds48 external documentation dependencies. The authored18
# are transitively bound by initial_source_patch_sha256 plus the one exact
# supported-link successor and finalcatalog source hashes, not mislabeled
# as additional entries in that48-dependency list.
current={row['path']:row['after']['sha256'] for row in initial['files']}
current['docs/design/f407-i2s2-slave-tx.md']=source_successor['after_sha256']
for row in freeze['files']:
    if row['path'] in current:assert current[row['path']]==row['sha256']
for row in final['files']:
    name=Path(row['source']['path']).relative_to(primary).as_posix()
    assert current[name]==row['source']['sha256']
for row in initial['files']:
    name=row['path'];after=row['after'];actual=primary/name
    if name=='docs/design/f407-i2s2-slave-tx.md':assert sha(actual)==source_successor['after_sha256']==current[name] and after['sha256']==source_successor['before_sha256']
    else:assert sha(actual)==after['sha256']==current[name]
    # Preserve the small authored page, typed API index, DOT/SVG/CSV and Doxy
    # inputs; global labels/atlas are already exact in the required initial
    # patch and frozen source map, so need no extra full source copy.
    if name=='docs/design/f407-i2s2-slave-tx.md' or name.endswith(('.dot','.svg')) or name in ('Doxyfile','docs/reference/api/extension-components.md','docs/design/io-evolution-execution.csv','docs/design/soc-refinement-execution.csv'):
        copy(actual,'documentation-final/sources/'+name,current[name])
readme=primary/'tools/testing/evidence/f407-i2s2-20261020/README.md';assert sha(readme)=='84764e76aaf64b962e082448ec282ea6f143692e535c577799b0a4dcce571e96'
copy(readme,'documentation-final/source-bound-README.md')
put('documentation-final/pre-site-capture.json',{'status':'FINAL_CATALOGS_AND_SOURCE_BOUND_INPUTS_FROZEN_FULLSITE_PENDING','catalogs':12,'independent_new_pairs':107,'review_split':{'primary_contract_api_ledger_pairs':98,'navigation_atlas_pairs':9},'source_freeze_sha256':sha(freeze_path),'staged_tree_before_site':freeze['staged_tree_before_site'],'page_sha256':current['docs/design/f407-i2s2-slave-tx.md'],'source_bound_README_sha256':sha(readme),'source_bound_README_bytes':readme.stat().st_size,'root_link_successor_note':'Original root supported-link receipt pending-meaning field is historical; subsequent48c92998 independent paragraph review and final107pair reviews are retained separately.','fig_pngs':'Exact two images match root actual visual/runtime meaning approval; no image regeneration by collector.','active_fullsite_outputs_read_as_PASS':False,'final_site':'Pending root actual successful completion notice; no active output is accepted.','source_observation_scope':'Only the explicitly new final docs source/index freeze is compared with current inputs; earlier ARM/SDK dirty snapshots remain unchanged.'})
put('archive-input-map.json',M)
prepared=json.loads((ROOT/'prepared.json').read_text());prepared.update({'status':'FINAL_DOC_CATALOGS_AND_SOURCES_FROZEN_WAITING_ROOT_ACTUAL_SITE_PASS','files':sum(p.is_file() for p in P.rglob('*')),'bytes':sum(p.stat().st_size for p in P.rglob('*') if p.is_file()),'input_map_sha256':sha(P/'archive-input-map.json'),'final_catalogs':12,'final_reviewed_new_pairs':107,'source_bound_README_sha256':sha(readme),'final_source_freeze_sha256':sha(freeze_path),'final_seal_performed':False,'docs_pending':True});(ROOT/'prepared.json').write_text(json.dumps(prepared,indent=2)+'\n')
print(json.dumps(prepared),flush=True)
