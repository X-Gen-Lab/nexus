#!/usr/bin/env python3
"""Preserve the distinct MPU static-fix normal ARM successor, without rerun."""
from pathlib import Path
import json
import runpy
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;E=runpy.run_path(str(ROOT/'collect.py'));P=ROOT/'payload';copy=E['copy'];put=E['put'];sha=E['sha'];M=E['COPIED'];M.update(json.loads((P/'archive-input-map.json').read_text()))
raw=Path('/tmp/nexus-u575-mpu-static-successor-arm-20261020');d=json.loads((raw/'execution.json').read_text());assert d['status']=='passed' and d['source_before']==d['source_after']
for p in sorted(raw.rglob('*')):
    if p.is_file():
        assert p.suffix not in ('.o','.a','.pdf','.gz')
        copy(p,'mpu-static-fix/normal-arm/'+p.relative_to(raw).as_posix())
commands=[]
for p in sorted(raw.glob('*.command.json')):
    command=json.loads(p.read_text());attempt=json.loads(Path(command['attempt_receipt']).read_text())
    assert {k:v for k,v in command.items() if k!='attempt_receipt'}==attempt and attempt['exit_code']==0 and attempt['outcome']=='completed' and attempt['withdrawal_complete'] and attempt['withdrawal_stable']
    for key in ('stdout','stderr'):
        row=attempt[key];assert sha(row['path'])==row['sha256'] and Path(row['path']).stat().st_size==row['bytes']
    commands.append({'command':p.name,'started_ns':attempt['started_ns'],'finished_ns':attempt['finished_ns'],'exit_code':0,'withdrawal_complete':True})
build=Path('/dev/shm/nexus-u575-mpu-static-successor-arm-20261020')
for row in d['artifacts']:
    p=Path(row['path']);assert p.stat().st_size==row['bytes'];copy(p,'mpu-static-fix/normal-arm/artifacts/'+p.name,row['sha256'])
for rel in ('compile_commands.json','nexus/generated/resolved.json','nexus/generated/bindings.c','nexus/generated/nexus_bindings.h','nexus/generated/nexus_config.h','nexus/generated/selection.cmake','nexus/generated/memory.ld','nexus/generated/resource-budget.json','nexus/generated/input_paths.json','nexus/generated/configuration_code_paths.json','nexus/generated/generator-identity.json'):
    copy(build/rel,'mpu-static-fix/normal-arm/generated-proof/'+rel)
resources=json.loads((build/'bin/u575_mpu_gpio_public.resources.json').read_text());m=resources['metrics'];assert resources['status']=='passed' and resources['physical_status']=='not_executed'
assert m['flash']['loaded_bytes']==15310 and m['flash']['footprint_bytes']==24880 and m['ram']['sram1']['reserved_bytes']==6000 and m['reservations']['msp']['bytes']==2048 and m['reservations']['heap']['bytes']==0
ret=json.loads((raw/'retention-execution.json').read_text());assert ret['status']=='passed' and ret['exit_code']==0
patch=json.loads((P/'mpu-static-fix/remote-explicit16/patch-manifest.json').read_text())
put('mpu-static-fix/normal-arm/phase-summary.json',{'status':'passed_distinct_static_fix_successor','source_before':d['source_before'],'source_after':d['source_after'],'source_delta':{'path':patch['path'],'before_sha256':patch['before_sha256'],'after_sha256':patch['after_sha256'],'semantics':'Reviewed equivalent refactor resolving two actual remote analyzer findings; not a newly invented functional RED.'},'commands':commands,'elf_sha256':resources['elf']['sha256'],'resource_phase':{'loaded_flash_bytes':15310,'prior603_loaded_flash_bytes':15306,'observed_loaded_flash_change_bytes':4,'bin_footprint_bytes':24880,'sram1_reserved_including_msp_bytes':6000,'msp_bytes':2048,'heap_bytes':0,'prior603_resources_overwritten':False},'retention':'Fresh actual normal selected MPU emitted-byte audit passed; original receipt/report retained.','related_focused_followup':{'google_tests':28,'distinct_tidy_contexts':10},'qualification_limit':'This distinct dirty/staged source phase does not rewrite the old603 development resources, oldacfc F407 installed SDK snapshot, or its full SDK source qualification. Full v10 matrix and physical HIL remain not executed.','collector_rebuilt_or_tested':False})
put('archive-input-map.json',M)
prepared=json.loads((ROOT/'prepared.json').read_text());prepared.update({'files':sum(p.is_file() for p in P.rglob('*')),'bytes':sum(p.stat().st_size for p in P.rglob('*') if p.is_file()),'input_map_sha256':sha(P/'archive-input-map.json'),'source_execution_addendum_sha256':sha(P/'source-execution-addendum.json'),'mpu_normal_arm_successor':'passed_distinct_phase_preserved','mpu_normal_arm_elf_sha256':resources['elf']['sha256'],'final_seal_performed':False,'docs_pending':True});(ROOT/'prepared.json').write_text(json.dumps(prepared,indent=2)+'\n')
print(json.dumps(prepared),flush=True)
