"""Run owned changed bytes against readonly primary toolkit dependencies."""

import sys
import types
import unittest
from pathlib import Path

PRIMARY = Path("/tmp/nexus-quality-20261019")
OWNED = Path(__file__).resolve().parent / "changed"
sys.path.insert(0, str(PRIMARY))

for name, relative in (
        ("tools.measurement.retention", "tools/measurement/retention.py"),
        ("owned_retention_tests", "tools/testing/test_provider_retention.py")):
    module = types.ModuleType(name)
    # Match real installed source-root resolution without modifying primary.
    module.__file__ = str(PRIMARY / relative)
    module.__package__ = name.rpartition(".")[0]
    sys.modules[name] = module
    exec(compile((OWNED / relative).read_bytes(), str(OWNED / relative), "exec"),
         module.__dict__)

unittest.main(module="owned_retention_tests", verbosity=2)
