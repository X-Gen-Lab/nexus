"""Preserve completed SDK/build bytes with the maintained store before reclaim."""
from pathlib import Path
import hashlib,json,shutil,sys,time
root=Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(root))
from tools.evidence import store
from tools.evidence.common import file_identity
out=Path(__file__).parent;result=json.loads((out/'consumer-execution/result.json').read_text());execution=json.loads((out/'execution.json').read_text());assert execution['status']=='passed' and execution['source_before']==execution['source_after']
base=Path('/dev/shm/nexus-f407-i2s2-installed-sdk-20261020');prefix=base/'relocated prefix';build=Path(result['artifacts']['elf']['path']).parent.parent;sdk=prefix/'share/nexus/src';manifest=json.loads((sdk/'.nexus-source-sdk.json').read_text());assert manifest['snapshot_sha256']==execution['snapshot_sha256'] and manifest['publishable'] is False
critical=out/'preserved-final-artifacts';critical.mkdir();paths={ext:Path(row['path']) for ext,row in result['artifacts'].items()};paths.update(resources=Path(result['resources']['path']),resolved=Path(result['resolved']['path']),retention=Path(result['retention']['path']),compile_commands=build/'compile_commands.json',sdk_manifest=sdk/'.nexus-source-sdk.json')
records=[]
for label,p in paths.items():
 target=critical/(label+p.suffix);shutil.copyfile(p,target);assert p.read_bytes()==target.read_bytes();records.append({'role':label,'original':file_identity(p),'preserved':file_identity(target)})
(out/'preserved-critical.json').write_text(json.dumps(records,indent=2)+'\n')
archive_records=[];cas=Path('/tmp/nexus-f407-i2s2-generated-cas-20261020')
for label,p in [('sdk',prefix),('build',build)]:
 assert p.is_dir() and not p.is_symlink()
 before=store.inventory(p);mtime={str(q.relative_to(p)):q.stat().st_mtime_ns for q in p.rglob('*')}
 package=store.export_tree(p,cas);verified=store.verify_package(package)
 restore=Path('/dev/shm/nexus-f407-i2s2-'+label+'-restore-check-20261020');assert not restore.exists();restored=store.restore_tree(package,restore)
 assert before==store.inventory(restore) and before==store.inventory(p)
 assert mtime=={str(q.relative_to(p)):q.stat().st_mtime_ns for q in p.rglob('*')}
 row={'role':label,'original_path':str(p),'package':package,'verified':verified,'restore':restored,'all_inventory_bytes_equal':True,'reclaimed_original_and_restore_only':False};archive_records.append(row);(out/'generated-archive-receipts.json').write_text(json.dumps(archive_records,indent=2)+'\n')
 shutil.rmtree(restore);shutil.rmtree(p);row['reclaimed_original_and_restore_only']=True;(out/'generated-archive-receipts.json').write_text(json.dumps(archive_records,indent=2)+'\n')
print(json.dumps({'status':'completed-generated-SDK-and-build-fully-preserved-restored-compared-before-reclaim','original_file_bytes_reclaimed':sum(r['package']['bytes'] for r in archive_records),'archives':[r['package']['archive']['sha256'] for r in archive_records],'critical_files':len(records)}))
