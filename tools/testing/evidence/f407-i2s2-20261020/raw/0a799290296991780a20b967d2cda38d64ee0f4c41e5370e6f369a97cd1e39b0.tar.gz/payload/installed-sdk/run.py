"""Run one real relocated development SDK consumer using installed helpers."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys
P=Path('/tmp/nexus-quality-20261019');W=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
phase=sys.argv[1]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def clean_env():
 e=os.environ.copy()
 for k in ('CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','OBJC_INCLUDE_PATH','CMAKE_INCLUDE_PATH','CMAKE_LIBRARY_PATH','LIBRARY_PATH','CFLAGS','CXXFLAGS','CPPFLAGS','ASFLAGS','LDFLAGS','CMAKE_PREFIX_PATH','CC','CXX','ASM','PYTHONPATH','PYTHONHOME'):e.pop(k,None)
 e.update(PATH=str(P/'.venv/bin')+':/tmp/nexus-quality-arm/bin:/tmp/nexus-quality-doc-tools/bin:/usr/local/bin:/usr/bin:/bin',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1',PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
 return e
env=clean_env();rows=[]
def execute(argv,timeout=300):
 log=W/('command-'+str(len(rows))+'.txt');r=process.run([str(x) for x in argv],cwd=W,env=env,log=log,timeout=timeout,stage='installed-f407-i2s2-'+str(len(rows)))
 rows.append(str(r.receipt_path));(W/'commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r.returncode:print(r.stdout+r.stderr,flush=True);raise SystemExit(r.returncode)
 return r.stdout
if phase=='consume':
 prefix=Path(sys.argv[2]);sdk=prefix/'share/nexus/src';sys.path.insert(0,str(sdk))
 from tools.dev import process
 spec=importlib.util.spec_from_file_location('installed_verification',sdk/'cmake/package/verify_consumers.py');v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
 work=Path(sys.argv[4]);work.mkdir();W=W/'consumer-execution';W.mkdir()
 source,build,cmd=v.prepare_selected_consumer(prefix,work,'f407 i2s2 slave tx','tools/configure/assemblies/sky-i2s2-slave-tx.toml','f407-i2s2-slave-tx',execute,expected_revision=sys.argv[3])
 cmd.extend(['-DNEXUS_ALLOW_SOURCE_SDK_FIXTURE=ON','-DPython3_EXECUTABLE='+sys.executable,'-DNEXUS_COMPILER_CACHE=OFF'])
 execute(cmd);execute(['cmake','--build',build,'--target','installed_selected','--parallel','1'])
 result=v.check_selected_image(sdk,source,build,execute);(W/'result.json').write_text(json.dumps(result,indent=2)+'\n');raise SystemExit(0)
sys.path.insert(0,str(P));from tools.dev import process
from tools.evidence.identity import observe_git_source
before=observe_git_source(P);(W/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
base=Path('/dev/shm/nexus-f407-i2s2-installed-sdk-20261020');base.mkdir();original=base/'original';prefix=base/'relocated prefix';sdk=prefix/'share/nexus/src';work=base/'external consumer'
record={'kind':'one_actual_maintained_selected_development_sdk_consumer','status':'failed','qualification':False,'physical_status':'not_executed','source_before':before,'full_v10_plan_executed':False,'source_state':'staged F407 role/component/audit over committed MPU6032222; not clean candidate'}
try:
 execute([sys.executable,'-B',P/'cmake/package/package_source_sdk.py','--source',P,'--output',original,'--development-fixture'])
 manifest_hash=digest(original/'share/nexus/src/.nexus-source-sdk.json');original.rename(prefix);assert not original.exists() and digest(sdk/'.nexus-source-sdk.json')==manifest_hash
 identity=json.loads((sdk/'.nexus-source-sdk.json').read_text());assert identity['publishable'] is False and identity['source_dirty'] is True
 record.update(manifest_sha256=manifest_hash,snapshot_sha256=identity['snapshot_sha256'],sdk_publishable=identity['publishable'],sdk_files=len(identity['files_sha256']))
 paths=['tools/measurement/retention.py','tools/configure/i2s2.py','soc/stm32f407/drivers/i2s2_slave_tx.c','soc/stm32f407/system.c','components/f407_i2s2_slave_tx/include/nexus/components/f407_i2s2_slave_tx.h','cmake/package/verify_consumers.py','cmake/package/verification/io_evolution/consumers/f407-i2s2-slave-tx.c','tools/release/transport.py']
 record['relocated_source_pairs']={p:{'primary':digest(P/p),'installed':digest(sdk/p)} for p in paths};assert all(x['primary']==x['installed'] for x in record['relocated_source_pairs'].values())
 execute([sys.executable,'-B',sdk/'cmake/package/package_source_sdk.py','--verify',sdk])
 execute([sys.executable,'-B',Path(__file__).resolve(),'consume',prefix,identity['source_revision'],work],timeout=600)
 execute([sys.executable,'-B',sdk/'cmake/package/package_source_sdk.py','--verify',sdk])
 after=observe_git_source(P);record['source_after']=after;assert before==after;record['status']='passed'
finally:
 (W/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('source_before','source_after','relocated_source_pairs')},indent=2))
