from pathlib import Path
import json,os,re,sys
root=Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(root))
from tools.dev import process
from tools.evidence.identity import observe_git_source
from scripts.ci.tdd_gate import checked_binary,discovered_count,validate_google_report
from scripts.validation.junit import prepare_report
out=Path(__file__).parent;before=observe_git_source(root);record={'kind':'real_primary_f407_component_and_sdk_contracts','source_before':before,'commands':[],'tools':[],'status':'running','physical_status':'not_executed'}
def save(): (out/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
def run(name,argv):
 r=process.run(argv,cwd=root,env=os.environ.copy(),log=out/(name+'.log'),timeout=600,stage='f407-i2s2-'+name);record['commands'].append(str(r.receipt_path));save()
 if r.returncode:record['status']='failed';save();print(r.stderr[-5000:]);raise SystemExit(r.returncode)
 return r
save()
prior=Path('/tmp/nexus-f407-i2s2-root-focused-r2-20261020');previous=json.loads((prior/'execution.json').read_text());assert before==previous['source_before'];record['commands'].extend(previous['commands']);record['maintained_build_receipts']='Actual successful r2 configure/build, unchanged source; no cached test reports';save()
manifest=json.loads((root/'build/native-debug/google-contracts.json').read_text());names=[x for x in manifest['executables'] if Path(x).name=='nexus_f407_i2s2_slave_tx_test'];assert len(names)==1;binary=checked_binary(names[0],root/'build/native-debug');listing=run('native-list',[str(binary),'--gtest_filter=*','--gtest_list_tests']);expected=discovered_count(listing.stdout);report=out/'google.xml';started=prepare_report(report)
run('native-execute',[str(binary),'--gtest_filter=*','--gtest_repeat=1','--gtest_also_run_disabled_tests','--gtest_output=xml:'+str(report)]);record['google']=validate_google_report(report,not_before_ns=started,expected_cases=expected);save()
for name,args in [('selection',['tests/contracts/test_source_sdk.py','SourceSDKSelectionTests','-v']),('sdk-verification',['-m','unittest','-v','tools.testing.test_sdk_verification_call']),('release',['-m','unittest','discover','-s','.github/workflows','-p','test_release.py','-v'])]:
 r=run(name,[str(root/'.venv/bin/python'),'-B',*args]);text=r.stdout+'\n'+r.stderr;matches=re.findall(r'Ran (\d+) tests? in',text);assert len(matches)==1,(name,matches);assert '\nOK\n' in text or text.rstrip().endswith('OK'),name;record['tools'].append({'suite':name,'executed':int(matches[0]),'status':'passed'});save()
after=observe_git_source(root);assert before==after;record['source_after']=after;record['status']='passed';save();print(json.dumps({'status':'passed','google':record['google']['passed'],'tools':record['tools'],'source_unchanged':True}))
