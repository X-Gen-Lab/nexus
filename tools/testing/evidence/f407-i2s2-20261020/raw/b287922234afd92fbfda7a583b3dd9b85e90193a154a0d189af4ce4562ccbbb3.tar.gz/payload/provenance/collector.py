#!/usr/bin/env python3
"""Seal only the first ordinary failure/test-only followup/recovery sidecar."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;P=ROOT/'payload';P.mkdir();PARENT=ROOT.parent;M={}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def copy(src,dst,h=None):
 src=Path(src);assert src.is_file() and not src.is_symlink() and not any(q.is_symlink() for q in src.parents)
 actual=sha(src);assert h is None or h==actual
 out=P/dst;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,out);assert sha(out)==actual==sha(src)
 M[str(src)]={'payload':dst,'sha256':actual,'bytes':out.stat().st_size}
def put(n,d):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def attempt(canonical,group,local_root=None):
 d=json.loads(Path(canonical).read_text());copy(canonical,group+'/command.json')
 def local(original):
  p=Path(original)
  if local_root is None:return p
  parts=p.parts;at=parts.index('tools-testing.attempts');return local_root/Path(*parts[at:])
 actual=local(d['attempt_receipt']);a=json.loads(actual.read_text());assert {k:v for k,v in d.items() if k!='attempt_receipt'}==a and a['withdrawal_complete'] and a['withdrawal_stable'];copy(actual,group+'/actual-receipt.json')
 for key in ('stdout','stderr'):
  row=a[key];p=local(row['path']);assert p.stat().st_size==row['bytes'];copy(p,group+'/'+key+'.txt',row['sha256'])
 return a
failed=Path('/tmp/nexus-f407-first-ordinary-failure-20261021');failure=json.loads((failed/'failure.json').read_text());assert failure['tools_executed']==1366 and failure['failures']==1 and failure['errors']==failure['skips']==0
for n in ('failure.json','tools-testing.txt','nexus-f407-final-index-freeze-20261021.json','nexus-f407-final-ordinary-commit-20261021.log'):copy(failed/n,'first-failed-gate/'+n)
a=attempt(failed/'tools-testing.command.json','first-failed-gate/testing',failed);assert a['exit_code']==1
review=Path('/tmp/nexus-storage-test-review-20261021');patch=json.loads((review/'patch-manifest.json').read_text());assert patch['patch_sha256']=='964d0c5d998668881c817a5edd3c0862640b4102ea7a828169e00be0f47a9f82'
for n in ('independent-review.json','independent-review-final.json','patch-manifest.json','storage-real-observer.patch'):copy(review/n,'test-only-followup/'+n,patch['patch_sha256'] if n.endswith('.patch') else None)
focused=Path('/tmp/nexus-storage-test-focused-20261021');d=json.loads((focused/'execution.json').read_text());assert d['status']=='passed' and d['executed']==21 and d['failures']==d['errors']==d['skipped']==0 and d['test_sha256']==patch['after_sha256'] and d['production_storage_sha256_unchanged']==patch['production_sha256']
copy(focused/'execution.json','focused21/execution.json');a=attempt(focused/'complete-module.command.json','focused21/actual');assert a['exit_code']==0
ret=Path('/tmp/nexus-examples-build-retirement-20261021');recovery=json.loads((ret/'retirement.json').read_text());assert recovery['source_git_untouched'] and recovery['inventory_equal'] and recovery['verification']['status']==recovery['full_restoration']['status']=='verified' and recovery['package']['files']==256 and recovery['package']['bytes']==135990659
assert recovery['tmp_free_before']==376504320 and recovery['tmp_free_after']==486637568 and recovery['source_repo_status_after']=='' and sha(recovery['package']['archive']['path'])==recovery['package']['archive']['sha256']
for n in ('retirement.json','package.json','inventory.json'):copy(ret/n,'space-recovery/'+n)
for n in ('nexus-examples-build-retirement-20261021.log','nexus-examples-build-retirement-20261021.py'):copy(Path('/tmp')/n,'space-recovery/'+n)
original=json.loads((PARENT/'package.json').read_text());assert original['archive']['sha256']=='0a799290296991780a20b967d2cda38d64ee0f4c41e5370e6f369a97cd1e39b0' and original['files']==1137 and sha(original['archive']['path'])==original['archive']['sha256']
old_readme=(PARENT/'README.md').read_bytes();assert hashlib.sha256(old_readme).hexdigest()=='b1ca9233d432bc9a70a79ab3f29061ee1b960ee0b54a2b7f0d01148625fc4a96' and len(old_readme)==8176
put('original-sealed-archive-reference.json',{'package':original,'original_verified':json.loads((PARENT/'verified.json').read_text()),'archive_unchanged':True,'original_final_README_sha256':hashlib.sha256(old_readme).hexdigest(),'original_final_README_prefix_bytes':len(old_readme),'original_archive_resealed':False})
put('admission-scope.json',{'status':'FIRST_GATE_FAILED_TEST_ONLY_FOLLOWUP21PASS_ORDINARY_R2_PENDING','first_ordinary':{'executed':1366,'passed':1365,'failures':1,'errors':0,'skipped':0,'later_stages':'not_executed','accepted':False,'attempt_started_ns':json.loads((failed/'tools-testing.command.json').read_text())['started_ns']},'test_only_followup':{'executed':21,'failures':0,'errors':0,'skipped':0,'production_storage_sha256_unchanged':patch['production_sha256'],'before_test_sha256':patch['before_sha256'],'after_test_sha256':patch['after_sha256'],'patch_sha256':patch['patch_sha256'],'no_budget_or_production_change':True},'space_recovery':'Existing external e0c92b1b archive fully byte-verified/restored/inventory-compared256files135990659B; only owned untracked normal generated build retired. No full build/vendor data copied here.','rendered_input_superset':'1626-input superset unchanged by this test-only fixture fix; no documentation re-extraction by collector.','ordinary_complete_R2':'pending','full_v10_matrix':'not_executed','physical_HIL':'not_executed','collector_compiler_configure_tests':False,'primary_source_index_writes':False,'historical_attempts_swept':False})
put('archive-input-map.json',M)
(P/'README.md').write_text('# F407 first ordinary-gate failure sidecar\n\nThe original1137-file archive0a799290 remains unchanged. This sidecar preserves only the actual first1366-test gate attempt (1365pass,1failure,0error,0skip), the independent test-only repair and complete21-case followup, and verified external storage-recovery references. No old MPU or other historical attempt directory was swept. Production storage.py7eca920d is unchanged; the original failed gate is not accepted or relabeled. Subsequent ordinary R2 remains pending. No compiler, configure, tests or primary/index edits were performed by the collector.\n')
copy(__file__,'provenance/collector.py')
sys.path.insert(0,'/tmp/nexus-quality-20261019')
from tools.evidence.store import export_tree,verify_package
package=export_tree(P,ROOT/'store');(ROOT/'package.json').write_text(json.dumps(package,indent=2)+'\n');v=verify_package(package);(ROOT/'verified.json').write_text(json.dumps(v,indent=2)+'\n');assert v['status']=='verified'
append=('\n\n## First ordinary-gate failure and test-only followup\n\nThe first ordinary gate executed1366 tools/testing cases:1365passed,1failed,\n0errors and0skips. Later stages were not executed in that attempt. The real\nfilesystem observer test assumed capacity admission when actual free storage\nwas below the unchanged default384MiB requirement; production storage.py\n`7eca920d…` correctly refused admission and remains unchanged. The independently\nreviewed test-only patch preserves real observer binding and adds deterministic\ndefault-budget refusal coverage; the complete storage test module then passed\nall21cases without failure or skip. This does not establish full-gate success.\n\nStorage recovery separately archived, fully restored and inventory-compared\n256files/135990659B before retiring only the owned untracked normal generated\nexamples build. Source/Git remained untouched; observed /tmpfree changed from\n376504320B to486637568B. External recovery archive e0c92b1b… is referenced,\nnot copied with build/vendor payloads. The original1137-file0a799290 archive\nis unchanged. No documentation rebuild is inferred or performed for this\ntest-only successor; the1626-input rendering superset is unchanged.\n\nSidecar raw archive: [raw/'+Path(package['archive']['path']).name+'](raw/'+Path(package['archive']['path']).name+').\nSHA256: `'+package['archive']['sha256']+'`. Ordinary complete R2 remains\n**pending**; full v10 execution and physical HIL remain not executed.\n').encode()
new_readme=old_readme+append;assert new_readme[:len(old_readme)]==old_readme;(PARENT/'README.md').write_bytes(new_readme)
def item(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
delivery={'status':'SIDECAR_SEALED_AND_BYTE_VERIFIED_ORDINARY_R2_PENDING','package':item(ROOT/'package.json'),'verified':item(ROOT/'verified.json'),'archive':package['archive'],'files':package['files'],'bytes':package['bytes'],'README':item(PARENT/'README.md'),'README_previous_prefix_sha256':hashlib.sha256(old_readme).hexdigest(),'README_previous_prefix_bytes':len(old_readme),'README_previous_prefix_unchanged':True,'original_1137_archive_sha256':original['archive']['sha256'],'original_archive_unchanged':True,'first_gate':'1366executed1365pass1fail0error0skip;notaccepted;laterstagesnotexecuted','focused_followup':'21pass0skip;testonly;production7ecaunchanged','external_recovery_archive':recovery['package']['archive'],'full_build_payload_copied':False,'ordinary_R2':'pending','collector_reran_compiler_tests_or_modified_primary_index':False};(ROOT/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n');print(json.dumps({'delivery':item(ROOT/'delivery.json'),**delivery}),flush=True)
