from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
root=Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(root));from tools.evidence import store
source=Path('/tmp/nexus-examples-completion-20261020/build/native-debug');owner=source.parents[1];out=Path('/tmp/nexus-examples-build-retirement-20261021');out.mkdir(exist_ok=False);cas=Path('/tmp/nexus-examples-generated-cas-20261021');restored=Path('/dev/shm/nexus-examples-native-restored-20261021')
assert not source.is_symlink() and all(not p.is_symlink() for p in source.parents)
assert 'CMAKE_HOME_DIRECTORY:INTERNAL='+str(owner) in (source/'CMakeCache.txt').read_text();assert (source/'CMakeFiles').is_dir();assert not subprocess.check_output(['git','ls-files','--',str(source.relative_to(owner))],cwd=owner)
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=owner)
records=store.inventory(source);assert not any(set(Path(r['path']).parts)&{'.git','vendors','ext'} for r in records)
for p in Path('/proc').glob('[0-9]*/cwd'):
 try:
  q=p.resolve(); assert q!=source and not q.is_relative_to(source),str(p)
 except (FileNotFoundError,PermissionError,ProcessLookupError):pass
before_space=os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize
package=store.export_tree(source,cas);verification=store.verify_package(package);restoration=store.restore_tree(package,restored);assert store.inventory(restored)==records;assert store.inventory(source)==records
(out/'package.json').write_text(json.dumps(package,indent=2)+'\n');(out/'inventory.json').write_text(json.dumps(records,indent=2)+'\n')
r={'schema_version':1,'status':'verified_ready_to_retire_generated_build_only','source':str(source),'source_repo':str(owner),'source_git_untouched':True,'ownership':'Untracked normal CMake output: exact CMAKE_HOME_DIRECTORY, CMakeFiles, no tracked paths, no symlinks/Git/vendor source directories and no process cwd inside.','package':package,'verification':verification,'full_restoration':restoration,'inventory_equal':True,'tmp_free_before':before_space,'rebuild_or_runtime_qualification':False};(out/'retirement.json').write_text(json.dumps(r,indent=2)+'\n')
shutil.rmtree(restored);shutil.rmtree(source);r['status']='retired_after_full_archive_verification_restoration_inventory_compare';r['tmp_free_after']=os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize;r['source_repo_status_after']=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=owner,text=True);assert not r['source_repo_status_after'];(out/'retirement.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
