#!/usr/bin/env python3
"""Preserve the completed MPU ordinary gate once; never run the gate."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PRIMARY = Path('/tmp/nexus-quality-20261019')
TDD = PRIMARY / 'build/native-debug/tdd'
PAYLOAD = ROOT / 'payload'
COMMIT = '56a66e05014d760fbbd8d3e2e3b5909e86e80da6'
TREE = '6aff81836de5b85ec71883e36dcdd2c6d5b262dd'
LOWER = 1792542280594176171
COPIED = {}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write(name, data):
    p = PAYLOAD / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)

def put(name, data):
    write(name, (json.dumps(data, indent=2) + '\n').encode())

def copy(path, name):
    p = Path(path)
    assert p.is_file() and not p.is_symlink() and not any(q.is_symlink() for q in p.parents), p
    h = sha(p)
    target = PAYLOAD / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert sha(target) == h
    else:
        shutil.copyfile(p, target)
    assert sha(target) == h == sha(p), p
    COPIED[str(p)] = {'payload': name, 'sha256': h, 'bytes': target.stat().st_size}
    return h

def capture_receipt(path, label, fresh=True):
    p = Path(path)
    d = json.loads(p.read_text())
    assert d['finished_ns'] >= d['started_ns'] and d['withdrawal_stable'] and d['withdrawal_complete']
    if fresh:
        assert d['started_ns'] >= LOWER and d['outcome'] == 'completed' and d['exit_code'] == 0
    copy(p, label + '/receipt.json')
    for key in ('stdout', 'stderr'):
        row = d[key]
        raw = Path(row['path'])
        assert sha(raw) == row['sha256'] and raw.stat().st_size == row['bytes']
        copy(raw, 'raw-blobs/' + row['sha256'])
    return d

def capture_native():
    assert not (ROOT / 'native-frozen.json').exists()
    canonical = {}
    for p in sorted(TDD.glob('*.command.json')):
        d = json.loads(p.read_text())
        if d.get('started_ns', 0) < LOWER:
            continue
        label = p.name.removesuffix('.command.json')
        attempt = capture_receipt(d['attempt_receipt'], 'gate/r2/attempts/' + label)
        assert {k:v for k,v in d.items() if k != 'attempt_receipt'} == attempt
        copy(p, 'gate/r2/commands/' + p.name)
        canonical[label] = d
    expected = {'configure', 'build', 'tools-testing', 'tools-configure', 'tools-ci', 'tools-workflows'} | {f'{phase}-{i}' for phase in ('discovery','execution') for i in range(348)}
    assert len(canonical) == 702 and set(canonical) == expected
    summary = json.loads((TDD / 'execution.json').read_text())
    assert summary['passed'] == 6288 and len(summary['suites']) == 348
    suites = {s['binary']:s for s in summary['suites']}
    google = []
    for i in range(348):
        cmd = canonical[f'execution-{i}']; argv = cmd['command']; binary = Path(argv[0]).name
        assert argv[1:4] == ['--gtest_filter=*','--gtest_repeat=1','--gtest_also_run_disabled_tests'] and len(argv) == 5
        assert canonical[f'discovery-{i}']['command'] == [argv[0], '--gtest_filter=*', '--gtest_list_tests']
        p = TDD / f'google-{i}.xml'; assert cmd['started_ns'] <= p.stat().st_mtime_ns <= cmd['finished_ns']
        x = ET.parse(p).getroot(); n = int(x.get('tests'))
        assert all(int(x.get(k,0)) == 0 for k in ('failures','errors','disabled')) and not x.findall('.//skipped') and len(x.findall('.//testcase')) == n
        s = suites[binary]; assert s['tests'] == s['passed'] == n and all(s[k] == 0 for k in ('failures','errors','skipped')) and sha(p) == s['report_sha256']
        copy(p, 'gate/r2/google/' + p.name)
        google.append({'index':i,'binary':binary,'tests':n,'xml_sha256':s['report_sha256'],'started_ns':cmd['started_ns'],'finished_ns':cmd['finished_ns']})
    assert sum(g['tests'] for g in google) == 6288
    tools = {'testing':1367,'configure':967,'ci':485,'workflows':127}
    for name, n in tools.items():
        p = TDD / f'tools-{name}.json'; d = json.loads(p.read_text()); cmd = canonical['tools-' + name]
        assert cmd['started_ns'] <= p.stat().st_mtime_ns <= cmd['finished_ns'] and d['status'] == 'passed' and d['discovered'] == d['executed'] == n
        assert all(d[k] == 0 for k in ('skipped','failures','errors','expected_failures','unexpected_successes')) and d == next(s for s in summary['tool_suites'] if s['suite'] == name)
        copy(p, 'gate/r2/tools/' + p.name)
    copy(TDD / 'execution.json', 'gate/r2/execution.json')
    catalogue = PRIMARY / 'build/native-debug/google-contracts.json'; assert len(json.loads(catalogue.read_text())['executables']) == 348
    copy(catalogue, 'gate/r2/google-contracts.json')
    for name in ('io-property-inputs.json','io-property-report.json'):
        p = TDD / name; assert LOWER <= p.stat().st_mtime_ns
        if name == 'io-property-report.json':
            audit = json.loads(p.read_text())
            assert audit['execution_summary_sha256'] == sha(TDD / 'execution.json')
            assert audit['inputs'] == json.loads((TDD / 'io-property-inputs.json').read_text())
        copy(p, 'gate/r2/' + name)
    result = {'commit':COMMIT,'tree':TREE,'minimum_started_ns':LOWER,'fresh_commands':702,'first_started_ns':min(d['started_ns'] for d in canonical.values()),'last_finished_ns':max(d['finished_ns'] for d in canonical.values()),'google_executables':348,'google_tests':6288,'tools':tools,'tool_total':sum(tools.values()),'all_failures_errors_skips':0,'google':google,'gate_rerun':False,'deduplication':'Immutable stdout/stderr stored once by SHA256 in raw-blobs; original receipts and input map retain original locations.'}
    put('gate/r2/admission-summary.json', result)
    put('archive-input-map.json', COPIED)
    (ROOT / 'native-frozen.json').write_text(json.dumps({'status':'actual_fresh_native_evidence_frozen','commit':COMMIT,'commands':702,'google':6288,'binaries':348,'tools':2946,'minimum_started_ns':LOWER,'payload':str(PAYLOAD)},indent=2)+'\n')
    print('NATIVE_FROZEN', flush=True)

def git(*args):
    return subprocess.check_output(['git','-C',str(PRIMARY),*args])

def capture_accepted_context():
    COPIED.update(json.loads((PAYLOAD/'archive-input-map.json').read_text()))
    acceptance_path=Path('/tmp/nexus-f407-final-ordinary-acceptance-20261021.json')
    accepted=json.loads(acceptance_path.read_text());freeze_path=Path(accepted['input_freeze']);freeze=json.loads(freeze_path.read_text())
    assert accepted['commit']==COMMIT and accepted['tree']==TREE==freeze['staged_tree'] and accepted['source_files_bound_to_exact_commit']==len(freeze['files'])==81
    assert git('rev-parse',COMMIT+'^{tree}').decode().strip()==TREE and git('rev-parse',COMMIT+'^').decode().strip()==freeze['head']
    names=set(git('diff-tree','--no-commit-id','--name-only','-r',COMMIT).decode().splitlines());assert names=={r['path'] for r in freeze['files']}
    bindings=[]
    for row in freeze['files']:
        blob=git('show',COMMIT+':'+row['path']);h=hashlib.sha256(blob).hexdigest();assert h==row['sha256'] and len(blob)==row['bytes']
        bindings.append({'path':row['path'],'sha256':h,'bytes':len(blob),'blob':git('rev-parse',COMMIT+':'+row['path']).decode().strip()})
    put('source/committed-bindings.json',{'commit':COMMIT,'tree':TREE,'parent':freeze['head'],'files':bindings,'method':'Only exact git show56a66 committed blobs against original R2 freeze81. Current branch, working tree and index are not observed or relabeled.'})
    write('source/commit.raw.txt',git('cat-file','commit',COMMIT))
    copy(freeze_path,'source/r2-input-freeze-original.json');copy(acceptance_path,'gate/ordinary-acceptance.json');copy(accepted['commit_log'],'gate/r2-full-hook-and-commit.log')
    put('archive-input-map.json',COPIED)
    put('collection-scope.json',{'status':'ACCEPTED_ORDINARY_R2','commit':COMMIT,'tree':TREE,'frozen_source_paths':81,'minimum_fresh_command_started_ns':LOWER,'native_command_count':702,'google_executables':348,'google_passed':6288,'tools':{'testing':1367,'configure':967,'ci':485,'workflows':127,'total':2946},'failure_error_skip_counts':0,'source_proof':'Exact committed56a66 plus original81-file R2freeze; no later dirty source observations.','historical_attempts_swept':False,'pre_gate_archives_and_README_modified':False,'compiler_configure_tests_rerun':False,'primary_index_or_source_mutation':False,'qualification':accepted['qualification'],'physical_status':'not_executed'})
    collection = ('# Accepted F407 ordinary R2 gate evidence\n\n'
      'Commit56a66e05014d760fbbd8d3e2e3b5909e86e80da6, tree6aff81836de5b85ec71883e36dcdd2c6d5b262dd. '
      'All81 original frozen file hashes are compared with exact committed Git blobs; later source/branch/index observations are excluded.\n\n'
      'Only702 current native-debug/tdd command pointers and their actual immutable attempt/stdout/stderr are captured, with348 Google XML reports/6288 passed cases and2946 passed tool cases '
      '(1367 testing,967 configure,485 CI,127 workflows), no failures/errors/skips. Discovery and execution include all tests. '
      'Bounded IO-property preinputs/report bind the actual execution summary; this remains host development evidence, not formal semantics or hardware timing.\n\n'
      'Streams are stored once by SHA256 in raw-blobs; archive-input-map.json retains each original path. No historical attempt directory was swept. '
      'This packet does not alter the original1137-file source/docs archive, its first-failure sidecar or any README. It executes no compiler/configure/tests and writes no primary/index files. '
      'Ordinary complete-index hooks passed; clean-main formal qualification, a complete SDK image plan, software-candidate promotion and physical HIL remain unestablished.\n')
    (ROOT/'COLLECTION.md').write_text(collection);write('COLLECTION.md',collection.encode())
    write('provenance/collector.py',Path(__file__).read_bytes())

def seal():
    sys.path.insert(0,str(PRIMARY))
    from tools.evidence.store import export_tree,verify_package
    assert not (ROOT/'package.json').exists()
    package=export_tree(PAYLOAD,ROOT/'store');(ROOT/'package.json').write_text(json.dumps(package,indent=2)+'\n')
    verified=verify_package(package);(ROOT/'verified.json').write_text(json.dumps(verified,indent=2)+'\n');assert verified['status']=='verified'
    def identity(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
    delivery={'status':'SEALED_BYTE_VERIFIED_ACCEPTED_ORDINARY_R2','commit':COMMIT,'tree':TREE,'package':identity(ROOT/'package.json'),'verified':identity(ROOT/'verified.json'),'collection':identity(ROOT/'COLLECTION.md'),'archive':package['archive'],'files':package['files'],'bytes':package['bytes'],'source_paths_bound_via_git_show':81,'current_commands':702,'google_executables':348,'google_passed':6288,'tools_total':2946,'all_failures_errors_skips':0,'historical_attempts_swept':False,'primary_index_or_README_mutations':False,'compiler_configure_tests_executed_by_collector':False,'formal_clean_main_complete_SDK_matrix_or_HIL_qualification':False}
    (ROOT/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n');print(json.dumps({'delivery':identity(ROOT/'delivery.json'),**delivery}),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='native':capture_native()
    elif sys.argv[1]=='context':capture_accepted_context()
    elif sys.argv[1]=='seal':seal()
    else:raise SystemExit('expected native,context,seal')
