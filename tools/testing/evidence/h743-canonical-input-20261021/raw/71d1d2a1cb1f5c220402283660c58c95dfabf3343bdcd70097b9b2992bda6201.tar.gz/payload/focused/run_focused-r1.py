import importlib.util,json,os,pathlib,sys
ROOT=pathlib.Path('/tmp/nexus-quality-20261019')
sys.path.insert(0,str(ROOT))
from tools.dev.process import run
OUT=pathlib.Path(__file__).parent
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT)+':'+str(ROOT/'tools/configure'),NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1')
rows=[('canonical-green',['tools.configure.test_matrix.MaintainedMatrixTests.test_h743_flash_reference_has_one_canonical_high_profile','test_source_sdk.SourceSDKSelectionTests.test_h743_flash_uses_one_required_canonical_sdk_input','test_release.ConsumerTransportTests.test_complete_v10_plan_with_same_roots_and_images_is_rejected','test_platform_ci.SoftwareQualificationWorkflowTests.test_canonical_h743_flash_path_keeps_the_existing_source_guard'])]
env['PYTHONPATH']+=':'+str(ROOT/'tests/contracts')+':'+str(ROOT/'.github/workflows')
# Resolve the existing class owning the unchanged source-guard test.
import ast
p=ROOT/'.github/workflows/test_platform_ci.py'
tree=ast.parse(p.read_text())
name=next(c.name for c in tree.body if isinstance(c,ast.ClassDef) and any(isinstance(m,ast.FunctionDef) and m.name=='test_canonical_h743_flash_path_keeps_the_existing_source_guard' for m in c.body))
rows[0][1][-1]='test_platform_ci.'+name+'.test_canonical_h743_flash_path_keeps_the_existing_source_guard'
rows += [('configure-affected',['tools.configure.test_matrix','tools.configure.test_selected_contract_authority','tools.configure.test_h743_flash_ram_emission']),('tool-affected',['tools.testing.test_h743_flash_ram_closure','tools.testing.test_sdk_verification_call']),('sdk-selection',['test_source_sdk.SourceSDKSelectionTests']),('release',['test_release']),('qualification-guard',['test_platform_ci.'+name])]
receipts=[]
for label,tests in rows:
    code=run([sys.executable,'-B','-m','unittest','-v',*tests],cwd=ROOT,env=env,log=OUT/(label+'.raw'),timeout=600,stage='h743-canonical-'+label)
    record=json.loads((OUT/(label+'.command.json')).read_text()); receipts.append(record)
    print(label,code,flush=True)
    if code: break
(OUT/'execution.json').write_text(json.dumps({'source_base':os.popen('git -C '+str(ROOT)+' rev-parse HEAD').read().strip(),'source_dirty':True,'commands':receipts,'all_passed':all(r['exit_code']==0 for r in receipts),'physical_status':'not_executed'},indent=2)+'\n')
raise SystemExit(code)
