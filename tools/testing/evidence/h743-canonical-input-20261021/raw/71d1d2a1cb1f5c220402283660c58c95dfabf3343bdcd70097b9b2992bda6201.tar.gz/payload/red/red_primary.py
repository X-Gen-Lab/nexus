"""Execute the exact newly prepared methods against actual primary inputs only."""
from pathlib import Path
import ast
import hashlib
import importlib
import json
import sys
import unittest

sys.dont_write_bytecode = True
PRIMARY = Path('/tmp/nexus-quality-20261019')
OWNED = Path('/tmp/nexus-h743-flash-canonical-increment-20261021')
sys.path.insert(0, str(PRIMARY))
from tools.configure import configure, matrix
sys.path.insert(0, str(PRIMARY / 'cmake/package'))
source_sdk = importlib.import_module('package_source_sdk')
consumer_gate = importlib.import_module('verify_consumers')
from tools.release import transport
namespace = dict(Path=Path, json=json, configure=configure, matrix=matrix,
                 source_sdk=source_sdk, consumer_gate=consumer_gate, ROOT=PRIMARY)
choices = json.loads((OWNED / 'harness/new-methods.json').read_text())
suite = unittest.TestSuite()
methods = []
for relative, names in choices.items():
    text = (OWNED / 'after' / relative).read_text()
    tree = ast.parse(text)
    for name in names:
        selected = [node for node in ast.walk(tree)
                    if isinstance(node, ast.FunctionDef) and node.name == name]
        if len(selected) != 1:
            raise SystemExit('One exact maintained new method required')
        method = selected[0]
        module = ast.Module(body=[method], type_ignores=[])
        ast.fix_missing_locations(module)
        compiled = compile(module, str(OWNED / 'after' / relative), 'exec')
        scope = dict(namespace)
        exec(compiled, scope)
        case = type('CanonicalH743RedContract', (unittest.TestCase,),
                    {name: scope[name]})
        suite.addTest(case(name))
        methods.append({'target': relative, 'method': name,
                        'method_sha256': hashlib.sha256(ast.get_source_segment(text, method).encode()).hexdigest()})

class ActualPrimaryControl(unittest.TestCase):
    def test_current_source_has_exact_previous_consumer_scope(self):
        self.assertEqual((len(transport.FIXTURES), len(transport.IMAGES)), (50, 53))
        self.assertEqual(transport.CONSUMER_POLICY, 'nexus-sdk-consumers-v10')
        self.assertIn(('h743 high',
            'cmake/package/verification/io_evolution/h743-high-peripherals.toml',
            'h743-high'), transport.SELECTED_CONSUMERS)
        self.assertEqual(configure.ROOT, PRIMARY)

suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(ActualPrimaryControl))
result = unittest.TextTestRunner(verbosity=2).run(suite)
record = {'kind': 'actual_primary_RED_contract_observation',
          'primary': str(PRIMARY), 'new_methods': methods,
          'tests_run': result.testsRun, 'failures': len(result.failures),
          'errors': len(result.errors), 'skipped': len(result.skipped),
          'new_source_applied': False, 'compilers_or_cmake_executed': False,
          'software_qualified': False, 'physical_status': 'not_executed'}
(OWNED / 'harness/red-observation.json').write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(0 if result.wasSuccessful() else 1)
