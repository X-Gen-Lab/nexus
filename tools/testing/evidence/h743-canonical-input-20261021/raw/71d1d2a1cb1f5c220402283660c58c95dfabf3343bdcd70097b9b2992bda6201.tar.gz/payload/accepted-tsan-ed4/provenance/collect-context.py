#!/usr/bin/env python3
"""Add exact accepted context to the already frozen Native payload; do not seal."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('capture_native', ROOT / 'collect-native.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
FIX = Path('/tmp/nexus-f407-tsan-fix-20261021')
P = m.PAYLOAD
m.COPIED.update(json.loads((P / 'archive-input-map.json').read_text()))

def git(*args):
    return subprocess.check_output(['git', '-C', str(m.PRIMARY), *args])

assert (ROOT / 'native-frozen.json').is_file()
assert not (ROOT / 'capture-manifest.json').exists()
accepted = json.loads((FIX / 'ordinary-r2-result.json').read_text())
freeze = json.loads((FIX / 'ordinary-input-freeze.json').read_text())
assert accepted == {'exit_code': 0, 'receipt': '/tmp/nexus-f407-tsan-fix-20261021/ordinary-commit-r2.attempts/1792544774836972063-b3e4c6438ff049c180d233269854814a/receipt.json', 'head': m.COMMIT, 'expected_file_count': 5, 'interrupted_r1_reused': False, 'exact_frozen_blobs_verified': True}
assert git('rev-parse', m.COMMIT + '^{tree}').decode().strip() == m.TREE
assert git('rev-parse', m.COMMIT + '^').decode().strip() == freeze['head']
assert len(freeze['files']) == 5
assert set(git('diff-tree', '--no-commit-id', '--name-only', '-r', m.COMMIT).decode().splitlines()) == {r['path'] for r in freeze['files']}
bindings = []
for row in freeze['files']:
    data = git('show', m.COMMIT + ':' + row['path'])
    digest = hashlib.sha256(data).hexdigest()
    assert digest == row['sha256'] and len(data) == row['bytes']
    bindings.append({'path': row['path'], 'sha256': digest, 'bytes': len(data), 'git_blob': git('rev-parse', m.COMMIT + ':' + row['path']).decode().strip()})
m.put('source/committed-bindings.json', {'commit': m.COMMIT, 'tree': m.TREE, 'parent': freeze['head'], 'files': bindings, 'method': 'Exact git show of accepted ed4 commit, compared with all five original frozen inputs. No current branch, working tree or index is observed or relabeled.', 'source_archive_payloads_duplicated': False})
m.write('source/commit.raw.txt', git('cat-file', 'commit', m.COMMIT))
m.copy(FIX / 'ordinary-input-freeze.json', 'source/r2-input-freeze-original.json')
m.copy(FIX / 'ordinary-r2-result.json', 'gate/ordinary-acceptance.json')
master_pointer = json.loads((FIX / 'ordinary-commit-r2.command.json').read_text())
assert master_pointer['attempt_receipt'] == accepted['receipt']
master = m.capture_receipt(accepted['receipt'], 'gate/r2/master')
assert {k: v for k, v in master_pointer.items() if k != 'attempt_receipt'} == master
assert master['withdrawn_processes'] == []
m.copy(FIX / 'ordinary-commit-r2.command.json', 'gate/r2/master/command.json')
raw = FIX / 'ordinary-commit-r2.raw'
assert raw.read_bytes() == Path(master['stdout']['path']).read_bytes() + Path(master['stderr']['path']).read_bytes()
m.copy(raw, 'gate/r2/master/combined-raw.txt')
native = json.loads((P / 'gate/r2/admission-summary.json').read_text())
assert native['fresh_commands'] == 702 and master['started_ns'] <= native['first_started_ns'] <= native['last_finished_ns'] <= master['finished_ns']
commands = {p.name.removesuffix('.command.json'): json.loads(p.read_text()) for p in (P / 'gate/r2/commands').glob('*.command.json')}
assert len(commands) == 702 and all(master['started_ns'] <= r['started_ns'] <= r['finished_ns'] <= master['finished_ns'] for r in commands.values())
interrupted = FIX / 'interrupted-ordinary-r1'
r1_note = json.loads((interrupted / 'interruption.json').read_text())
r1_receipt = json.loads((interrupted / 'receipt.json').read_text())
assert r1_note['status'] == 'environment_interrupted_not_accepted' and r1_note['test_result_reuse'] is False
assert r1_note['other_domains_or_full_google_executed_in_this_attempt'] is False and r1_note['new_commit_created'] is False
assert r1_receipt['outcome'] == 'running' and r1_receipt['exit_code'] is None and 'finished_ns' not in r1_receipt
r1_names = ('interruption.json', 'receipt.json', 'stdout.txt', 'stderr.txt', 'ordinary-input-freeze.json', 'tools-testing.json', 'tools-testing.command.json', 'ordinary-commit.log')
for name in r1_names:
    m.copy(interrupted / name, 'interrupted/r1/' + name)
m.put('interrupted/r1/qualification.json', {'status': 'environment_interrupted_not_accepted', 'original_parent_exit_acceptance': False, 'receipt_outcome': 'running', 'receipt_exit_code': None, 'receipt_finished_ns_present': False, 'raw_scope': 'Preserved interruption snapshots only; no accepted completion receipt exists for R1.', 'tool_report_is_gate_acceptance': False, 'results_reused_for_r2': False, 'r2_is_fresh': True, 'r2_cutoff_ns': m.LOWER})
scope = {'status': 'FROZEN_ACCEPTED_ORDINARY_TSAN_FIX_R2_PAYLOAD_UNSEALED', 'commit': m.COMMIT, 'tree': m.TREE, 'parent': freeze['head'], 'source_paths_bound_via_exact_git_show': 5, 'ordinary_master_exit_code': 0, 'ordinary_master_receipt': accepted['receipt'], 'minimum_fresh_command_started_ns': m.LOWER, 'native_command_count': 702, 'native_first_started_ns': native['first_started_ns'], 'native_last_finished_ns': native['last_finished_ns'], 'google_executables': 348, 'google_passed': 6288, 'tools': {'testing': 1367, 'configure': 967, 'ci': 485, 'workflows': 127, 'total': 2946}, 'all_failures_errors_skips': 0, 'r1_environment_interruption_not_accepted': True, 'r1_results_reused': False, 'historical_attempt_directories_swept': False, 'source_tar_and_56_packages_duplicated': False, 'primary_source_index_or_readme_modified': False, 'compiler_configure_tests_executed_by_collector': False, 'sealed': False, 'qualification': 'Accepted ordinary complete-index host gate for exact ed4 commit. Targeted TSan repair evidence remains separately bound by its committed package hashes. Whole-project TSan acceptance, clean-main formal qualification, complete SDK image qualification, remote CI acceptance for a new head, and physical HIL are not established.'}
m.put('collection-scope.json', scope)
collection = ('Accepted TSan-fix ordinary R2 gate capture, payload only; not sealed.\n\n'
    'Commit ed4f479f055fc8c52b9d808bde21f2c6bfdbd157; tree f150ff5686a34106c6a09c68901a59c6cb474b1a. '
    'The accepted commit parent is 56a66e05014d760fbbd8d3e2e3b5909e86e80da6. All five original frozen input byte counts and SHA256 hashes match exact git show blobs. '
    'The current dirty source, branch and index are never used to assign accepted source identity. The existing 31,185-byte TSan archive and prior 56 packages are not copied.\n\n'
    'The actual ordinary R2 master receipt completed with exit 0; original command pointer, receipt, stdout, stderr and combined raw are preserved. '
    'Only the current 702 Native command pointers and their actual completed immutable attempt receipts and raw streams are captured: 348 discovery plus 348 execution commands, configure, build, and four tool suites. '
    'All 702 began after cutoff 1792544774836972063 and lie inside the accepted master interval. The 348 XML reports contain 6288 passing Google cases. '
    'Tools passed 1367 testing, 967 configure, 485 CI and 127 workflows, total 2946, with zero failures, errors or skips. '
    'Execution summary, Google executable discovery catalogue, and bounded IO property inputs/report are preserved; the report binds the execution summary.\n\n'
    'R1 was interrupted by an environment restart. Its original receipt remains running, with null exit code and no finish time. '
    'The explicitly selected R1 snapshots are retained only to explain the interruption: no R1 parent exit acceptance exists, no R1 result was reused, and R2 is fresh. '
    'No historical attempt directory was swept. Raw streams are deduplicated by SHA256, with original paths retained in archive-input-map.json.\n\n'
    'This collector executes no compiler, configure command or tests and changes no primary source, index or README. '
    'Ordinary host gate acceptance does not establish whole-project TSan acceptance, clean-main formal qualification, complete SDK image qualification, remote CI acceptance for a new head, or physical HIL. '
    'The parent will include this unsealed payload once in the H743 canonical compact archive with the separately captured actual phase.\n')
m.write('COLLECTION.txt', collection.encode())
m.write('provenance/collect-native.py', (ROOT / 'collect-native.py').read_bytes())
m.write('provenance/collect-context.py', Path(__file__).read_bytes())
m.copy(ROOT / 'native-frozen.json', 'provenance/native-frozen.json')
m.put('archive-input-map.json', m.COPIED)
files = []
for path in sorted(P.rglob('*')):
    if not path.is_file():
        continue
    assert not path.is_symlink() and path.stat().st_nlink == 1
    files.append({'path': str(path.relative_to(P)), 'bytes': path.stat().st_size, 'sha256': m.sha(path)})
assert not any(row['path'].endswith(('.tar', '.tar.gz', '.tgz', '.zip')) for row in files)
assert len(list((P / 'gate/r2/commands').glob('*.command.json'))) == 702
assert len(list((P / 'gate/r2/attempts').glob('*/receipt.json'))) == 702
assert len(list((P / 'gate/r2/google').glob('*.xml'))) == 348
inventory = {'schema': 1, 'scope': 'Every payload regular file except payload-inventory.json and capture-manifest.json, which describe this inventory without a self-hash cycle.', 'files': files, 'file_count': len(files), 'bytes': sum(r['bytes'] for r in files)}
m.put('payload-inventory.json', inventory)
manifest = {**scope, 'payload': str(P), 'payload_inventory': {'path': 'payload-inventory.json', 'sha256': m.sha(P / 'payload-inventory.json'), 'bytes': (P / 'payload-inventory.json').stat().st_size}, 'inventoried_files': inventory['file_count'], 'inventoried_bytes': inventory['bytes'], 'actual_native_receipts': 702, 'actual_master_receipts': 1, 'actual_google_xml': 348, 'deduplicated_raw_blobs': len(list((P / 'raw-blobs').iterdir())), 'native_tdd_safe_to_reuse': True, 'no_hardlinks': True}
m.put('capture-manifest.json', manifest)
(ROOT / 'capture-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'status': manifest['status'], 'manifest': str(ROOT / 'capture-manifest.json'), 'payload': str(P), 'inventory_sha256': manifest['payload_inventory']['sha256'], 'inventoried_files': inventory['file_count'], 'inventoried_bytes': inventory['bytes'], 'native_commands': 702, 'master_receipts': 1, 'xml': 348}, indent=2))
