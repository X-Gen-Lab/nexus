#!/usr/bin/env python3
"""One retained canonical H743 link; preparation has not executed this script.

Uses only the maintained CMake graph and process/provenance helpers. Dirty
source is explicitly admitted as development evidence, never qualification.
Run under the repository-wide external compiler lock; the script never nests it.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tomllib

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--expected-commit', required=True)
parser.add_argument('--expected-assembly-sha256', required=True)
parser.add_argument('--arm-bin', type=Path, default=Path('/tmp/nexus-quality-arm/bin'))
args = parser.parse_args()
source = args.source.resolve(strict=True)
output = args.output.absolute()
if (output != output.resolve() or output.exists()
        or output.is_relative_to(source) or source.is_relative_to(output)):
    raise SystemExit('New canonical output disjoint from source is required')
if not re.fullmatch('[0-9a-f]{40}', args.expected_commit):
    raise SystemExit('An exact observed source HEAD is required')
if not re.fullmatch('[0-9a-f]{64}', args.expected_assembly_sha256):
    raise SystemExit('An exact observed canonical assembly SHA256 is required')
sys.dont_write_bytecode = True
sys.path.insert(0, str(source))
from tools.dev import process, provenance
from tools.evidence.common import file_identity
from tools.evidence.identity import observe_git_source, resolved_identity, resolved_input_files

assembly = source / 'tools/configure/assemblies/h743-high-peripherals.toml'
if file_identity(assembly)['sha256'] != args.expected_assembly_sha256:
    raise SystemExit('Canonical assembly bytes differ from requested input')
authored = tomllib.loads(assembly.read_text())
if (authored.get('schema') != 2 or authored.get('backend') != 'baremetal'
        or authored.get('clock') != 'hsi64-pll384-cache-off'
        or authored.get('flash', {}).get('storage', {}).get('mode') != 'poll-word'):
    raise SystemExit('This script admits only the maintained exact Flash selection')
if (source / 'cmake/package/verification/io_evolution/h743-high-peripherals.toml').exists():
    raise SystemExit('Old authored assembly must not remain as a second authority')
identity = observe_git_source(source)
if identity['commit'] != args.expected_commit:
    raise SystemExit('Observed HEAD differs from requested source')
if any(line.startswith(('-', '+', 'U')) for line in identity['submodules']):
    raise SystemExit('Required initialized submodules must match their Git identities')

def freeze_production():
    """Read regular tracked build inputs, not a new source/configuration graph."""
    selected = {}
    paths = subprocess.check_output(['git', '-C', str(source), 'ls-files', '-z']).split(b'\0')
    for raw in paths:
        if not raw:
            continue
        relative = os.fsdecode(raw)
        # Documentation is separately source-bound; evidence archives are not
        # compiler inputs. Other tracked regular files are conservatively bound.
        if relative.startswith(('docs/', 'tools/testing/evidence/')):
            continue
        path = source / relative
        if not path.is_file():
            continue
        if path.is_symlink() or any(p.is_symlink() for p in path.parents):
            raise SystemExit('Ambiguous tracked build input: ' + relative)
        selected[relative] = file_identity(path)
    # The moved canonical input can still be untracked during development.
    selected[assembly.relative_to(source).as_posix()] = file_identity(assembly)
    return selected

before = freeze_production()
environment = process.execution_environment(os.environ)
environment['PATH'] = os.pathsep.join((str(source / '.venv/bin'), str(args.arm_bin.resolve()), environment.get('PATH', '')))
environment.update(PYTHONDONTWRITEBYTECODE='1', NEXUS_BUILD_JOBS='1', CMAKE_BUILD_PARALLEL_LEVEL='1', CTEST_PARALLEL_LEVEL='1')
for tool in ('cmake', 'ninja', 'arm-none-eabi-gcc', 'arm-none-eabi-objdump'):
    if shutil.which(tool, path=environment['PATH']) is None:
        raise SystemExit('Required existing tool unavailable: ' + tool)
output.mkdir()
(output / '.nexus-h743-canonical-link-owner').write_text('owned retained canonical H743 development link\n')
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
record = {'kind': 'canonical_h743_development_link', 'source_before': identity,
          'production_inputs_before': before, 'canonical_assembly': file_identity(assembly),
          'commands': [], 'status': 'running', 'qualification': False,
          'physical_status': 'not_executed',
          'limits': ['ARM link/static byte proof only; no MCU execution',
                     'not an installed-SDK consumer or full consumer matrix',
                     'not a formal plan, offline two-build candidate or full IO-24 exit']}
write(output / 'execution.json', record)

def execute(argv, label, timeout=300):
    result = process.run([str(x) for x in argv], cwd=source, env=environment,
                         log=output / (label + '.raw'), timeout=timeout,
                         stage='h743-canonical-' + label)
    record['commands'].append(str(result.receipt_path))
    write(output / 'execution.json', record)
    if result.returncode:
        record['status'] = 'failed'
        write(output / 'execution.json', record)
        raise SystemExit(result.returncode)
    return result

build = output / 'build'
configure = ['cmake', '-S', source, '-B', build, '-G', 'Ninja',
             '-DCMAKE_TOOLCHAIN_FILE=' + str(source / 'cmake/toolchains/arm-gcc.cmake'),
             '-DCMAKE_BUILD_TYPE=Release', '-DNEXUS_ASSEMBLY_FILE=' + str(assembly),
             '-DNEXUS_BUILD_TESTS=OFF', '-DNEXUS_BUILD_WORKLOAD=OFF',
             '-DNEXUS_IO_EVOLUTION_FIXTURE=ON', '-DNEXUS_COMPILER_CACHE=OFF',
             '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
             '-DPython3_EXECUTABLE=' + str(source / '.venv/bin/python'),
             '-DNEXUS_IO_EVOLUTION_FIXTURE_MAIN=' + str(source / 'tests/contracts/io_evolution_assembly/controller_main.c')]
configure = [str(x) for x in configure]
result = execute(configure, 'configure')
provenance.capture(source, build, result.receipt_path, action='configure', expected_command=configure, expected_cwd=source)
resolved, _ = resolved_identity(build / 'generated/resolved.json')
record['resolved_inputs'] = resolved_input_files(build / 'generated/resolved.json', resolved)
if not any(Path(item['file']['path']) == assembly for item in record['resolved_inputs']):
    raise SystemExit('Actual resolution did not consume the requested canonical assembly')
argv = ['cmake', '--build', str(build), '--target', 'io_evolution_fixture', '--parallel', '1']
result = execute(argv, 'build')
provenance.capture(source, build, result.receipt_path, action='build', expected_command=argv, expected_cwd=source)
execute([sys.executable, '-B', source / 'tools/measurement/retention.py',
         '--elf', build / 'bin/io_evolution_fixture.elf',
         '--bindings', build / 'generated/bindings.c',
         '--resolved', build / 'generated/resolved.json',
         '--output', build / 'bin/provider-retention-resolved.json'], 'retention')
resources = json.loads((build / 'bin/io_evolution_fixture.resources.json').read_text())
retention = json.loads((build / 'bin/provider-retention-resolved.json').read_text())
audit = json.loads((build / 'bin/io_evolution_fixture.h743-flash-ram.json').read_text())
static = audit['static_closure']
memory = static['constant_memory']
assert resources['status'] == retention['status'] == audit['status'] == 'passed'
assert not resources['violations']
assert audit['clock_profile'] == 'hsi64-pll384-cache-off'
assert audit['qualification'] is False and audit['physical_execution'] == 'not_executed'
assert len(audit['stack_usage']) == 4
assert audit['ram_layout']['status'] == audit['cpu_bridge']['status'] == static['status'] == 'passed'
assert static['return_gate']['status'] == static['return_gate']['device_protocol'] == 'proved'
assert memory['all_data_operands'] == 'proved'
assert memory['unresolved_read_sites'] == memory['unresolved_write_sites'] == []
assert static['program_invocations']['maximum_invocations'] == 1
assert static['program_invocations']['maximum_dynamic_word_stores'] == 8
assert static['stack_required_bytes'] <= static['stack_available_bytes']
flash_faces = [face for face in retention['faces'] if face['type'] == 'nx_flash_port_t']
assert len(flash_faces) == 1
flash_tables = [table for table in retention['tables'] if table['name'] == flash_faces[0]['operations']]
assert len(flash_tables) == 1 and flash_tables[0]['methods']
record['flash_face'] = flash_faces[0]
record['flash_operations'] = flash_tables[0]
record['artifacts'] = {suffix: file_identity(build / 'bin' / ('io_evolution_fixture.' + suffix))
                       for suffix in ('elf', 'bin', 'map', 'resources.json', 'h743-flash-ram.json')}
assert all(item['size'] > 0 for item in record['artifacts'].values())
record['resources'] = resources['metrics']
record['source_after'] = observe_git_source(source)
record['production_inputs_after'] = freeze_production()
record['resolved_inputs_after'] = resolved_input_files(build / 'generated/resolved.json', resolved)
assert record['source_before'] == record['source_after'], 'Source identity changed during link'
assert before == record['production_inputs_after'], 'Build-input bytes changed during link'
assert record['resolved_inputs'] == record['resolved_inputs_after']
record['status'] = 'passed'
write(output / 'execution.json', record)
print(str(output / 'execution.json'))
