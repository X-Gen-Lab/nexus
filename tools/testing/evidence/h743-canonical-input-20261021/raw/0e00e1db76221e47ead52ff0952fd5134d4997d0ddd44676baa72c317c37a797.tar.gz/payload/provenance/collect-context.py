#!/usr/bin/env python3
"""Add exact accepted H743 context to frozen Native evidence, payload only."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('capture_native', ROOT / 'collect-native.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
ACCEPT = Path('/tmp/nexus-h743-canonical-root-20261021')
P = m.PAYLOAD
m.COPIED.update(json.loads((P / 'archive-input-map.json').read_text()))

def git(*args):
    return subprocess.check_output(['git', '-C', str(m.PRIMARY), *args])

assert (ROOT / 'native-frozen.json').is_file()
assert not (ROOT / 'capture-manifest.json').exists()
accepted = json.loads((ACCEPT / 'ordinary-result.json').read_text())
freeze = json.loads((ACCEPT / 'ordinary-input-freeze.json').read_text())
final = json.loads((ACCEPT / 'final-acceptance.json').read_text())
assert accepted == {'exit_code': 0, 'receipt': '/tmp/nexus-h743-canonical-root-20261021/ordinary-commit.attempts/1792546140045216702-ec96092f00db4534adceade5bc07e762/receipt.json', 'head': m.COMMIT, 'frozen_paths': 32, 'tree': m.TREE, 'exact_frozen_blobs_verified': True}
assert git('rev-parse', m.COMMIT + '^{tree}').decode().strip() == m.TREE == freeze['index_tree']
assert git('rev-parse', m.COMMIT + '^').decode().strip() == freeze['source_base']
assert len(freeze['files']) == 32
assert set(git('diff-tree', '--no-commit-id', '--name-only', '-r', m.COMMIT).decode().splitlines()) == {r['path'] for r in freeze['files']}
bindings = []
for row in freeze['files']:
    if row['kind'] == 'deleted':
        probe = subprocess.run(['git', '-C', str(m.PRIMARY), 'cat-file', '-e', m.COMMIT + ':' + row['path']], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        assert probe.returncode != 0
        parent_data = git('show', freeze['source_base'] + ':' + row['path'])
        bindings.append({'path': row['path'], 'kind': 'deleted', 'absent_from_accepted_commit': True, 'parent_git_blob': git('rev-parse', freeze['source_base'] + ':' + row['path']).decode().strip(), 'parent_bytes': len(parent_data), 'parent_sha256': hashlib.sha256(parent_data).hexdigest()})
    else:
        assert row['kind'] == 'file'
        data = git('show', m.COMMIT + ':' + row['path'])
        digest = hashlib.sha256(data).hexdigest()
        assert digest == row['sha256'] and len(data) == row['bytes']
        bindings.append({'path': row['path'], 'kind': 'file', 'sha256': digest, 'bytes': len(data), 'git_blob': git('rev-parse', m.COMMIT + ':' + row['path']).decode().strip()})
assert sum(r['kind'] == 'deleted' for r in bindings) == 1
m.put('source/committed-bindings.json', {'commit': m.COMMIT, 'tree': m.TREE, 'parent': freeze['source_base'], 'frozen_paths': 32, 'present_blobs': 31, 'deletions': 1, 'files': bindings, 'method': 'Exact git show of accepted 430 commit, compared with all 32 original frozen paths; deleted old TOML proven absent with its prior parent blob recorded. Current branch, working tree and index are not observed or relabeled.', 'tracked_archive_bodies_duplicated': False, 'whole_source_or_vendor_copied': False})
m.write('source/commit.raw.txt', git('cat-file', 'commit', m.COMMIT))
m.copy(ACCEPT / 'ordinary-input-freeze.json', 'source/input-freeze-original.json')
m.copy(ACCEPT / 'ordinary-result.json', 'gate/ordinary-acceptance.json')
m.copy(ACCEPT / 'final-acceptance.json', 'gate/final-acceptance-original.json')
master_pointer = json.loads((ACCEPT / 'ordinary-commit.command.json').read_text())
assert master_pointer['attempt_receipt'] == accepted['receipt']
master = m.capture_receipt(accepted['receipt'], 'gate/ordinary/master')
assert {k: v for k, v in master_pointer.items() if k != 'attempt_receipt'} == master
assert master['withdrawn_processes'] == []
m.copy(ACCEPT / 'ordinary-commit.command.json', 'gate/ordinary/master/command.json')
raw = ACCEPT / 'ordinary-commit.raw'
assert raw.read_bytes() == Path(master['stdout']['path']).read_bytes() + Path(master['stderr']['path']).read_bytes()
m.copy(raw, 'gate/ordinary/master/combined-raw.txt')
native = json.loads((P / 'gate/ordinary/admission-summary.json').read_text())
assert native['fresh_commands'] == 702 and master['started_ns'] <= native['first_started_ns'] <= native['last_finished_ns'] <= master['finished_ns']
commands = {f.name.removesuffix('.command.json'): json.loads(f.read_text()) for f in (P / 'gate/ordinary/commands').glob('*.command.json')}
assert len(commands) == 702 and all(master['started_ns'] <= r['started_ns'] <= r['finished_ns'] <= master['finished_ns'] for r in commands.values())
expected_tools = {'testing':1368, 'configure':969, 'ci':485, 'workflows':129}
assert final['commit'] == m.COMMIT and final['tree'] == m.TREE and final['google'] == 6288 and final['executables'] == 348 and final['tools'] == sum(expected_tools.values()) == 2951
assert {r['suite']:r['executed'] for r in final['tool_domains']} == expected_tools == native['tools']
assert final['ordinary_result'] == str(ACCEPT / 'ordinary-result.json')
assert '2950' in final['post_result_inventory_note'] and '2951' in final['post_result_inventory_note'] and 'No production or test failure' in final['post_result_inventory_note']
m.put('gate/post-result-consumer-note.json', {'status': 'reporting_count_guess_corrected', 'initial_guessed_tool_count': 2950, 'actual_accepted_tool_count': 2951, 'test_or_production_failure': False, 'gate_red': False, 'test_results_changed_or_rerun_for_count_guess': False, 'actual_tool_domains': expected_tools, 'original_note': final['post_result_inventory_note']})
scope = {'status': 'FROZEN_ACCEPTED_H743_CANONICAL_ORDINARY_PAYLOAD_UNSEALED', 'commit': m.COMMIT, 'tree': m.TREE, 'parent': freeze['source_base'], 'source_frozen_paths': 32, 'source_present_blobs_bound_via_exact_git_show': 31, 'source_deletions_proven': 1, 'ordinary_master_exit_code': 0, 'ordinary_master_receipt': accepted['receipt'], 'minimum_fresh_command_started_ns': m.LOWER, 'native_command_count': 702, 'native_first_started_ns': native['first_started_ns'], 'native_last_finished_ns': native['last_finished_ns'], 'google_executables': 348, 'google_passed': 6288, 'tools': {**expected_tools, 'total': 2951}, 'all_failures_errors_skips': 0, 'initial_2950_consumer_guess_was_test_failure': False, 'historical_attempt_directories_swept': False, 'tracked_archive_bodies_duplicated': False, 'whole_source_or_vendor_copied': False, 'primary_source_index_or_readme_modified': False, 'compiler_configure_tests_executed_by_collector': False, 'sealed': False, 'qualification': 'Accepted ordinary complete-index host gate for exact 430 commit. Existing h743-canonical-input archive remains a pre-gate snapshot. Earlier dirty-development ARM/focused phases retain their original source identities. Installed-SDK matrix qualification, clean-main formal candidate qualification, remote CI acceptance for a new head, physical MCU execution, and full IO-24 hardware exit are not established.'}
m.put('collection-scope.json', scope)
collection = ('Accepted H743 canonical ordinary gate capture, payload only; not sealed.\n\n'
    'Commit 430b0aea19fc3304b5b6f76dcec8419448027357; tree 3d4eef6bb2bf2656ccf5628d04cf5160f884e6ce; parent ed4f479f055fc8c52b9d808bde21f2c6bfdbd157. '
    'The original 32 frozen changed paths exactly match the committed path set. All 31 present files match exact git show SHA256 and byte counts; the old TOML is proven deleted and its prior parent blob is recorded. '
    'No current branch, dirty source or index is used for accepted source identity. Neither of the two already tracked archive bodies, the source tree, nor vendor is copied.\n\n'
    'The actual ordinary master receipt completed with exit 0; original command pointer, receipt, stdout, stderr and combined raw are preserved. '
    'Only the current 702 Native command pointers and actual completed immutable attempt receipts/raw streams are captured: 348 discovery, 348 execution, configure, build, and four tool suites. '
    'All commands began after cutoff 1792546140045216702 and lie inside the accepted master interval. The 348 XML reports contain 6288 passing Google cases. '
    'Tools passed 1368 testing, 969 configure, 485 CI and 129 workflows, total 2951, with zero failures, errors or skips. '
    'The initial post-result consumer assumed 2950 and failed its count assumption. This was a reporting error, not a test RED or production failure; the actual reports total 2951. '
    'Execution summary, Google executable discovery catalogue and bounded IO property inputs/report are preserved, with the IO report bound to the actual summary.\n\n'
    'No historical attempt directory was swept. Raw streams are deduplicated by SHA256; archive-input-map.json retains original paths. '
    'This collector executes no compiler, configure command or tests and changes no primary source, index or README. '
    'The existing h743-canonical-input archive remains a pre-gate snapshot; this later accepted gate is a separate phase. Earlier dirty-development ARM/focused source identities remain intact. '
    'Ordinary host gate acceptance does not establish installed-SDK matrix qualification, clean-main formal candidate qualification, remote CI acceptance for a new head, physical MCU execution or full IO-24 hardware exit. '
    'The parent will include this unsealed payload once in the next functional increment compact archive.\n')
m.write('COLLECTION.txt', collection.encode())
m.write('provenance/collect-native.py', (ROOT / 'collect-native.py').read_bytes())
m.write('provenance/collect-context.py', Path(__file__).read_bytes())
m.copy(ROOT / 'native-frozen.json', 'provenance/native-frozen.json')
m.put('archive-input-map.json', m.COPIED)
files = []
for path in sorted(P.rglob('*')):
    if not path.is_file():
        continue
    assert not path.is_symlink() and path.stat().st_nlink == 1
    files.append({'path': str(path.relative_to(P)), 'bytes': path.stat().st_size, 'sha256': m.sha(path)})
assert not any(row['path'].endswith(('.tar', '.tar.gz', '.tgz', '.zip')) for row in files)
assert len(list((P / 'gate/ordinary/commands').glob('*.command.json'))) == 702
assert len(list((P / 'gate/ordinary/attempts').glob('*/receipt.json'))) == 702
assert len(list((P / 'gate/ordinary/google').glob('*.xml'))) == 348
inventory = {'schema': 1, 'scope': 'Every payload regular file except payload-inventory.json and capture-manifest.json, which describe this inventory without a self-hash cycle.', 'files': files, 'file_count': len(files), 'bytes': sum(r['bytes'] for r in files)}
m.put('payload-inventory.json', inventory)
manifest = {**scope, 'payload': str(P), 'payload_inventory': {'path': 'payload-inventory.json', 'sha256': m.sha(P / 'payload-inventory.json'), 'bytes': (P / 'payload-inventory.json').stat().st_size}, 'inventoried_files': inventory['file_count'], 'inventoried_bytes': inventory['bytes'], 'actual_native_receipts': 702, 'actual_master_receipts': 1, 'actual_google_xml': 348, 'deduplicated_raw_blobs': len(list((P / 'raw-blobs').iterdir())), 'native_tdd_safe_to_reuse': True, 'no_hardlinks': True}
m.put('capture-manifest.json', manifest)
(ROOT / 'capture-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'status': manifest['status'], 'manifest': str(ROOT / 'capture-manifest.json'), 'payload': str(P), 'inventory_sha256': manifest['payload_inventory']['sha256'], 'inventoried_files': inventory['file_count'], 'inventoried_bytes': inventory['bytes'], 'native_commands': 702, 'master_receipts': 1, 'xml': 348}, indent=2))
