#!/usr/bin/env python3
"""Preserve accepted H743 canonical ordinary gate payload only; never run the gate."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PRIMARY = Path('/tmp/nexus-quality-20261019')
TDD = PRIMARY / 'build/native-debug/tdd'
PAYLOAD = ROOT / 'payload'
COMMIT = '430b0aea19fc3304b5b6f76dcec8419448027357'
TREE = '3d4eef6bb2bf2656ccf5628d04cf5160f884e6ce'
LOWER = 1792546140045216702
COPIED = {}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write(name, data):
    p = PAYLOAD / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)

def put(name, data):
    write(name, (json.dumps(data, indent=2) + '\n').encode())

def copy(path, name):
    p = Path(path)
    assert p.is_file() and not p.is_symlink() and not any(q.is_symlink() for q in p.parents), p
    h = sha(p)
    target = PAYLOAD / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert sha(target) == h
    else:
        shutil.copyfile(p, target)
    assert sha(target) == h == sha(p), p
    COPIED[str(p)] = {'payload': name, 'sha256': h, 'bytes': target.stat().st_size}
    return h

def capture_receipt(path, label, fresh=True):
    p = Path(path)
    d = json.loads(p.read_text())
    assert d['finished_ns'] >= d['started_ns'] and d['withdrawal_stable'] and d['withdrawal_complete']
    if fresh:
        assert d['started_ns'] >= LOWER and d['outcome'] == 'completed' and d['exit_code'] == 0
    copy(p, label + '/receipt.json')
    for key in ('stdout', 'stderr'):
        row = d[key]
        raw = Path(row['path'])
        assert sha(raw) == row['sha256'] and raw.stat().st_size == row['bytes']
        copy(raw, 'raw-blobs/' + row['sha256'])
    return d

def capture_native():
    assert not (ROOT / 'native-frozen.json').exists()
    canonical = {}
    for p in sorted(TDD.glob('*.command.json')):
        d = json.loads(p.read_text())
        if d.get('started_ns', 0) < LOWER:
            continue
        label = p.name.removesuffix('.command.json')
        attempt = capture_receipt(d['attempt_receipt'], 'gate/ordinary/attempts/' + label)
        assert {k:v for k,v in d.items() if k != 'attempt_receipt'} == attempt
        copy(p, 'gate/ordinary/commands/' + p.name)
        canonical[label] = d
    expected = {'configure', 'build', 'tools-testing', 'tools-configure', 'tools-ci', 'tools-workflows'} | {f'{phase}-{i}' for phase in ('discovery','execution') for i in range(348)}
    assert len(canonical) == 702 and set(canonical) == expected
    summary = json.loads((TDD / 'execution.json').read_text())
    assert summary['passed'] == 6288 and len(summary['suites']) == 348
    suites = {s['binary']:s for s in summary['suites']}
    google = []
    for i in range(348):
        cmd = canonical[f'execution-{i}']; argv = cmd['command']; binary = Path(argv[0]).name
        assert argv[1:4] == ['--gtest_filter=*','--gtest_repeat=1','--gtest_also_run_disabled_tests'] and len(argv) == 5
        assert canonical[f'discovery-{i}']['command'] == [argv[0], '--gtest_filter=*', '--gtest_list_tests']
        p = TDD / f'google-{i}.xml'; assert cmd['started_ns'] <= p.stat().st_mtime_ns <= cmd['finished_ns']
        x = ET.parse(p).getroot(); n = int(x.get('tests'))
        assert all(int(x.get(k,0)) == 0 for k in ('failures','errors','disabled')) and not x.findall('.//skipped') and len(x.findall('.//testcase')) == n
        s = suites[binary]; assert s['tests'] == s['passed'] == n and all(s[k] == 0 for k in ('failures','errors','skipped')) and sha(p) == s['report_sha256']
        copy(p, 'gate/ordinary/google/' + p.name)
        google.append({'index':i,'binary':binary,'tests':n,'xml_sha256':s['report_sha256'],'started_ns':cmd['started_ns'],'finished_ns':cmd['finished_ns']})
    assert sum(g['tests'] for g in google) == 6288
    tools = {'testing':1368,'configure':969,'ci':485,'workflows':129}
    for name, n in tools.items():
        p = TDD / f'tools-{name}.json'; d = json.loads(p.read_text()); cmd = canonical['tools-' + name]
        assert cmd['started_ns'] <= p.stat().st_mtime_ns <= cmd['finished_ns'] and d['status'] == 'passed' and d['discovered'] == d['executed'] == n
        assert all(d[k] == 0 for k in ('skipped','failures','errors','expected_failures','unexpected_successes')) and d == next(s for s in summary['tool_suites'] if s['suite'] == name)
        copy(p, 'gate/ordinary/tools/' + p.name)
    copy(TDD / 'execution.json', 'gate/ordinary/execution.json')
    catalogue = PRIMARY / 'build/native-debug/google-contracts.json'; assert len(json.loads(catalogue.read_text())['executables']) == 348
    copy(catalogue, 'gate/ordinary/google-contracts.json')
    for name in ('io-property-inputs.json','io-property-report.json'):
        p = TDD / name; assert LOWER <= p.stat().st_mtime_ns
        if name == 'io-property-report.json':
            audit = json.loads(p.read_text())
            assert audit['execution_summary_sha256'] == sha(TDD / 'execution.json')
            assert audit['inputs'] == json.loads((TDD / 'io-property-inputs.json').read_text())
        copy(p, 'gate/ordinary/' + name)
    result = {'commit':COMMIT,'tree':TREE,'minimum_started_ns':LOWER,'fresh_commands':702,'first_started_ns':min(d['started_ns'] for d in canonical.values()),'last_finished_ns':max(d['finished_ns'] for d in canonical.values()),'google_executables':348,'google_tests':6288,'tools':tools,'tool_total':sum(tools.values()),'all_failures_errors_skips':0,'google':google,'gate_rerun':False,'deduplication':'Immutable stdout/stderr stored once by SHA256 in raw-blobs; original receipts and input map retain original locations.'}
    put('gate/ordinary/admission-summary.json', result)
    put('archive-input-map.json', COPIED)
    (ROOT / 'native-frozen.json').write_text(json.dumps({'status':'actual_fresh_native_evidence_frozen','commit':COMMIT,'commands':702,'google':6288,'binaries':348,'tools':2951,'minimum_started_ns':LOWER,'payload':str(PAYLOAD)},indent=2)+'\n')
    print('NATIVE_FROZEN', flush=True)

if __name__ == '__main__':
    capture_native()
