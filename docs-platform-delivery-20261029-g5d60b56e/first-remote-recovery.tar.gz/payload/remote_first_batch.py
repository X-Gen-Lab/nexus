"""Download exact-commit bytes and use unchanged preserved verifiers.
This one-shot transport observer does not edit original reports or confer qualification.
"""
import hashlib,json,os,shutil,sys,tarfile,time,subprocess
from pathlib import Path,PurePosixPath
from urllib.request import Request,urlopen
from urllib.parse import quote
ROOT=Path('/workspace/nexus');LOG=ROOT/'build/c-cold-20261028/integration/assets-publication'
sys.path.insert(0,str(ROOT))
from tools.dev.process import run
SHA='2bdaae87a621f8d8c2f185569c0fdc608848c0a4'
PREFIX='docs-platform-delivery-20261029-g5d60b56e'
LOCAL=Path('/dev/shm/nexus-assets-final')
OUT=Path('/dev/shm/nexus-assets-remote-first-2bdaae87')
assert not OUT.exists();OUT.mkdir()
PAYLOAD=OUT/PREFIX;PAYLOAD.mkdir()
observations=[]

def checksum(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def retrieve(relative,destination,expected_size,expected_sha):
 url='https://raw.githubusercontent.com/X-Gen-Lab/nexus/'+SHA+'/'+quote(relative,safe='/')
 receipt={'path':relative,'url':url,'expected_size':expected_size,'expected_sha256':expected_sha,'attempts':[]}
 observations.append(receipt)
 for attempt in range(1,4):
  temp=destination.with_name(destination.name+'.incoming-'+str(attempt));started=time.monotonic()
  item={'attempt':attempt}
  try:
   with urlopen(Request(url,headers={'User-Agent':'Nexus-immutable-delivery-restore'}),timeout=60) as response,temp.open('xb') as output:
    status=response.status;assert status==200
    h=hashlib.sha256();size=0
    while block:=response.read(1024**2):
     size+=len(block)
     if size>expected_size:raise ValueError('Remote file exceeded original byte identity')
     h.update(block);output.write(block)
   if size!=expected_size or h.hexdigest()!=expected_sha:raise ValueError('Remote file byte identity mismatch')
   temp.replace(destination);item.update(status='downloaded_verified',http_status=status,bytes=size,sha256=h.hexdigest(),duration_s=time.monotonic()-started)
   receipt['attempts'].append(item);receipt['status']='verified';break
  except Exception as error:
   item.update(status='failed',error_type=type(error).__name__,error=str(error),duration_s=time.monotonic()-started)
   receipt['attempts'].append(item)
   if temp.exists():temp.unlink()
   if attempt==3:
    (LOG/'remote-download-first-observations.json').write_text(json.dumps({'storage_commit':SHA,'observations':observations},indent=2)+'\n');raise
   time.sleep(1)
 (LOG/'remote-download-first-observations.json').write_text(json.dumps({'storage_commit':SHA,'observations':observations},indent=2)+'\n')

for relative in ['assets.json','verify_assets.py']:
 p=LOCAL/relative
 retrieve(relative,OUT/relative,p.stat().st_size,checksum(p))
registry=json.loads((OUT/'assets.json').read_text());before=json.loads((LOG/'assets-registry-before.json').read_text())
assert registry['members'][:112]==before['members']
assert {k:v for k,v in registry.items() if k!='members'}=={k:v for k,v in before.items() if k!='members'}
new=[x for x in registry['members'] if x['path'].startswith(PREFIX+'/')]
assert len(new)==20
for entry in new:
 destination=OUT/entry['path'];destination.parent.mkdir(parents=True,exist_ok=True)
 retrieve(entry['path'],destination,entry['bytes'],entry['sha256'])
leaf=json.loads((PAYLOAD/'delivery-index.json').read_text());assert leaf['platform']['commit']=='5d60b56e09686776c72ce95dfa9384357e57d2bf'
assert leaf['examples']['commit']=='9d7d4d3430b8555766aba5bc7c76d5b49f8fd67d'
# Reassemble only transport fragments, checking original full archive identity.
for package in leaf['archives']:
 target=PAYLOAD/package['archive']['path']
 if len(package['parts'])>1:
  assert not target.exists()
  with target.open('xb') as output:
   for part in package['parts']:
    source=PAYLOAD/part['path'];assert source.stat().st_size==part['bytes'] and checksum(source)==part['sha256']
    with source.open('rb') as stream:shutil.copyfileobj(stream,output,1024**2)
 assert target.stat().st_size==package['archive']['bytes'] and checksum(target)==package['archive']['sha256']
# The verifier tool bytes are trusted by independent original P source hashes.
TOOLS=OUT/'verification-tools';TOOLS.mkdir()
archive=PAYLOAD/leaf['verifiers']['archive']['path'];assert checksum(archive)==leaf['verifiers']['archive']['sha256']
expected={x['path']:x for x in leaf['verifiers']['source_files']};seen=set()
with tarfile.open(archive,'r:gz') as stream:
 for member in stream:
  name=PurePosixPath(member.name);assert not name.is_absolute() and '..' not in name.parts
  destination=TOOLS/str(name)
  if member.isdir():destination.mkdir(parents=True,exist_ok=True);continue
  assert member.isfile() and member.name in expected and member.name not in seen
  seen.add(member.name);data=stream.extractfile(member).read();item=expected[member.name]
  assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
  destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data);destination.chmod(member.mode&0o777)
assert seen==set(expected)
# A clean new download is used; never reference original workspace archives.
store=TOOLS/'tools/evidence/store.py';results=[]
for package in leaf['archives']:
 role=package['role'];archive=PAYLOAD/package['archive']['path'];envelope=PAYLOAD/package['original_package']
 prefix='first-'+('docs' if role=='strict_bilingual_documentation' else 'docs-raw' if role=='strict_docs_actual_build_and_tool_execution' else 'examples' if role=='complete_examples_scope_all_and_actual_execution' else 'product')
 r=run([sys.executable,'-B',str(store),'verify','--package',str(envelope),'--archive',str(archive),'--report',str(LOG/(prefix+'-remote-store-verify.json'))],cwd=OUT,env=os.environ.copy(),log=LOG/(prefix+'-remote-store-verify.log'),timeout=600,stage='remote_store_verify')
 assert r.returncode==0
 destination=OUT/(prefix+'-restored')
 if role=='strict_bilingual_documentation':
  code=('import sys,json; from pathlib import Path; sys.path.insert(0,'+repr(str(TOOLS))+'); from tools.documentation import delivery; '
        'a=Path('+repr(str(archive))+'); d=Path('+repr(str(destination))+'); h='+repr(leaf['documents']['manifest_sha256'])+'; '
        'delivery.verify(a,expected_manifest_sha256=h); r=delivery.restore(a,d,expected_manifest_sha256=h); '
        'delivery.verify(d,expected_manifest_sha256=h); print(json.dumps({"status":"verified_archive_restore_reverify","release_id":r["release_id"],"languages":r["languages"],"manifest_sha256":h}))')
  r=run([sys.executable,'-B','-c',code],cwd=OUT,env=os.environ.copy(),log=LOG/(prefix+'-remote-docs-restore.log'),timeout=600,stage='remote_docs_restore')
 else:
  r=run([sys.executable,'-B',str(store),'restore','--package',str(envelope),'--archive',str(archive),'--destination',str(destination),'--report',str(LOG/(prefix+'-remote-store-restore.json'))],cwd=OUT,env=os.environ.copy(),log=LOG/(prefix+'-remote-store-restore.log'),timeout=600,stage='remote_store_restore')
 assert r.returncode==0
 # The unchanged maintained verifier already checks every restored name/mode/hash.
 # Record its actual successful receipt, then release only this fresh duplicate.
 results.append({'role':role,'archive_sha256':package['archive']['sha256'],'verify_exit_code':0,'restore_exit_code':0,'destination':str(destination),'verified_by':'unchanged_source_P_store_or_documentation_delivery_verifier','expanded_duplicate_cleanup_after_verified':True})
 shutil.rmtree(destination)
record={'kind':'actual_exact_git_commit_external_artifact_retention_and_restore','storage_repository':'X-Gen-Lab/nexus','storage_branch_discovery':'documentation-assets','storage_commit':SHA,'storage_parent':'e7d32687a598db753747f4905cb03afec3163b1d','namespace':PREFIX,'platform_commit':leaf['platform']['commit'],'examples_commit':leaf['examples']['commit'],'downloaded_new_members':len(new),'downloaded_new_member_bytes':sum(x['bytes'] for x in new),'registry_and_verifier_additionally_downloaded':True,'all_remote_byte_identities_verified':True,'original112members_and_header_preserved':True,'archives_independently_verified_and_restored':results,'original_envelope_bytes_unchanged':True,'original_execution_paths_rewritten':False,'new_qualification_or_test_execution':False,'physical_status':'not_executed','oci_recipe_independently_reconstructed':False,'official_release_published':False,'site_deployment_established':False,'candidate_seals_included':False,'full159_final_execution_included':False,'remote_downloads':str(LOG/'remote-download-first-observations.json'),'all_execution_receipts_directory':str(LOG),'download_root':str(OUT),'fresh_restore_duplicates_cleaned_only_after_maintained_full_verification':True,'disk':{s:shutil.disk_usage(s)._asdict() for s in ['/workspace','/dev/shm']}}
(LOG/'first-external-retention-and-restore.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'storage_commit':SHA,'new_members':len(new),'bytes':record['downloaded_new_member_bytes'],'archive_count':len(results),'actual_remote_restore':'passed'}))
