"""Ignored one-shot transport staging; no qualification/report identities are rewritten."""
import hashlib,json,os,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/workspace/nexus')
ASSETS=Path('/dev/shm/nexus-assets-final')
PREFIX='docs-platform-delivery-20261029-g5d60b56e'
D=ASSETS/PREFIX
BASE='e7d32687a598db753747f4905cb03afec3163b1d'
P='5d60b56e09686776c72ce95dfa9384357e57d2bf'
E='9d7d4d3430b8555766aba5bc7c76d5b49f8fd67d'
LOG=ROOT/'build/c-cold-20261028/integration/assets-publication'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ASSETS,text=True).strip()==BASE
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=ASSETS,text=True)==''
assert not D.exists()
D.mkdir()
original=json.loads((ASSETS/'assets.json').read_text())
assert len(original['members'])==112
old_bytes=(ASSETS/'assets.json').read_bytes()
(LOG/'assets-registry-before.json').write_bytes(old_bytes)

def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def copy(src,name):
 src=Path(src);assert src.is_file() and not src.is_symlink()
 dst=D/name;assert not dst.exists();shutil.copyfile(src,dst)
 assert dst.stat().st_size==src.stat().st_size and sha(dst)==sha(src)
 return dst

def archive(src,name,role,envelope):
 src=Path(src); env=json.loads(Path(envelope).read_text())
 assert src.stat().st_size==env['archive']['size'] and sha(src)==env['archive']['sha256']
 parts=[]
 if src.stat().st_size<=32*1024**2:
  p=copy(src,name); parts=[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}]
 else:
  with src.open('rb') as stream:
   index=0
   while block:=stream.read(32*1024**2):
    p=D/(name+'.part'+str(index).zfill(4));p.write_bytes(block)
    parts.append({'path':p.name,'bytes':len(block),'sha256':hashlib.sha256(block).hexdigest()});index+=1
  whole=hashlib.sha256()
  for part in parts:
   with (D/part['path']).open('rb') as stream:
    while block:=stream.read(1024**2):whole.update(block)
  assert whole.hexdigest()==env['archive']['sha256']
 return {'role':role,'original_package':Path(envelope).name,'archive':{'path':name,'bytes':src.stat().st_size,'sha256':env['archive']['sha256']},'parts':parts,'original_envelope_unchanged':True}

docs=ROOT/'build/c-cold-20261028/docs/final-5d60b56e'
examples=ROOT/'build/c-cold-20261028/examples/final-9d7d4d34'
for name in ['handoff.json','package.json','package-preservation.json','raw-build-package.json']:
 copy(docs/name,'docs-'+name)
for name in ['examples-build-package.json','user-product-package.json','final-package-index.json','final-handoff.json','final-delivery-summary.json','transport-receipt.json']:
 copy(examples/name,name)
packages=[]
packages.append(archive(docs/'0.2.0-docs-g5d60b56e0968.tar.gz','0.2.0-docs-g5d60b56e0968.tar.gz','strict_bilingual_documentation',docs/'package-preservation.json'))
packages[-1]['original_package']='docs-package-preservation.json'
packages.append(archive(docs/'raw-build-store/a390e33d57e05ca04ae9dbdbbaa250a4d71214a98b779489915887d71d56ae6c.tar.gz','docs-build-evidence.tar.gz','strict_docs_actual_build_and_tool_execution',docs/'raw-build-package.json'))
packages[-1]['original_package']='docs-raw-build-package.json'
for name,filename,role in [('examples-build','d0bce642ecbdf56b7930c2a15adaa9e0ac8ec95cbd7e61367f9aedc31a137606.tar.gz','complete_examples_scope_all_and_actual_execution'),('user-product','6d1b0e0790ce6aaf2bc7b9fb6130f91bdd919b96112fb6ece4c4912986a0ce1e.tar.gz','actual_external_created_product_and_installed_sdk_execution')]:
 packages.append(archive(examples/'store'/filename,name+'.tar.gz',role,examples/(name+'-package.json')))
with tarfile.open(docs/'0.2.0-docs-g5d60b56e0968.tar.gz','r:gz') as stream:
 member=stream.getmember('documentation-manifest.json');assert member.isfile() and member.size<2*1024**2
 (D/'documentation-manifest.json').write_bytes(stream.extractfile(member).read())
assert sha(D/'documentation-manifest.json')=='7cf0d25a072c100245a5d66dc28fe28d0d092a5a92a2faf89a735b215d447a2f'
verifier_paths=['LICENSE','tools/evidence/store.py','tools/evidence/common.py','tools/evidence/identity.py','tools/configure/metadata.py','tools/documentation/delivery.py']
verifier_archive=D/'verification-tools-g5d60b56e.tar.gz'
subprocess.run(['git','archive','--format=tar.gz','--output',str(verifier_archive),P,*verifier_paths],cwd=ROOT,check=True)
verifiers=[]
for name in verifier_paths:
 actual=subprocess.check_output(['git','show',P+':'+name],cwd=ROOT)
 verifiers.append({'path':name,'bytes':len(actual),'sha256':hashlib.sha256(actual).hexdigest()})
leaf={'schema_version':1,'kind':'existing_delivery_artifact_navigation','batch':'verified_docs_and_examples_only','platform':{'repository':'X-Gen-Lab/nexus','commit':P,'tree':'be71adaac61fc3cbf6a92f5f63e8c2a8ac84cb8b'},'examples':{'repository':'X-Gen-Lab/nexus-examples','commit':E,'platform_gitlink':P},'original_storage_parent':BASE,'qualification':False,'physical_status':'not_executed','oci_recipe_independently_reconstructed':False,'official_platform_release':'not_published','rendered_site_publication':'not_established_by_this_git_asset_retention','full_159_stage_final_execution':'pending_separate_final_receipt','eight_final_software_candidates':'pending_separate_seals','documents':{'languages':['en','zh_CN'],'pages':132,'language_page_records':264,'tool_tests':355,'qualification_references':[],'manifest_sha256':sha(D/'documentation-manifest.json')},'examples_actual_scope':{'commands':104,'presets':17,'standalones':9,'arm_images':41,'starters':4,'created_external_product_and_run':'passed'},'archives':packages,'verifiers':{'archive':{'path':verifier_archive.name,'bytes':verifier_archive.stat().st_size,'sha256':sha(verifier_archive)},'source_commit':P,'source_files':verifiers},'limits':['Original package/envelope/handoff absolute paths remain original evidence; store verify/restore use explicit --archive relocation without rewriting them.','This batch does not contain a completed159-stage plan, final8sealed candidates, GitHub Actions run, signed firmware, physical HIL or independent OCI recipe reconstruction.','Original copied handoffs retain historical local-only publication flags and references to evidence not selected in this batch. This leaf only navigates the exact archives listed here.','The cumulative root registry historical documentation_commit is not the identity of new payloads; use this leaf and original source-bound package manifests.','Append-only branch retention is separate from the guarded official SourceSDK GitHub Release and actual rendered-site deployment.']}
(D/'delivery-index.json').write_text(json.dumps(leaf,indent=2,ensure_ascii=False)+'\n')
(D/'README.txt').write_text('''Nexus exact-source docs and examples delivery artifacts / 精确源码文档与示例交付\n\nPlatform P: '''+P+'''\nExamples E: '''+E+''' (platform gitlink P)\n\nOnly completed strict bilingual documentation and complete examples/software\nexecution are retained in this first append-only batch. delivery-index.json\nrecords exact scopes, original envelopes, full archive identities and ordered\nparts. This is artifact navigation, not another task or qualification authority.\n\n本批仅保留已通过的中英文文档与示例；159阶段最终验收及8个候选稍后分别追加。\n实板HIL未执行，OCI recipe未独立重建；不宣称正式版本Release或Pages部署。\n\nDownload every listed member using ONE exact immutable storage commit URL.\nVerify each member against the cumulative assets.json registry, join ordered\narchive parts from delivery-index.json, then check full original size/SHA256.\nDo not infer identities from the moving branch name. Do not modify the original\nenvelope path fields; use store.py --archive /actual/downloaded/archive.tar.gz.\n\nThe verification-tools archive contains only exact P stdlib verifier source and\nLICENSE. Validate its hash, safely extract it into an independent tools root,\nand invoke the maintained tools/evidence/store.py verify/restore operations\nwith the original package JSON and explicit --archive location. For docs, use\ntools.documentation.delivery.verify/restore with expected_manifest_sha256 from\ndelivery-index.json. Original source/tools remain available at exact P URLs.\n\nExample (after hash verification and joining examples-build.tar.gz parts):\n  python3 -B verification-tools/tools/evidence/store.py verify \\\n    --package examples-build-package.json --archive examples-build.tar.gz \\\n    --report examples-verify.json\n  python3 -B verification-tools/tools/evidence/store.py restore \\\n    --package examples-build-package.json --archive examples-build.tar.gz \\\n    --destination /new/independent/examples --report examples-restore.json\n\nA successful byte restore is not a new test/qualification execution. Original\nabsolute argv and result paths are preserved; no historical plan is rewritten.\n''',encoding='utf-8')
entries=[]
for path in sorted(D.iterdir()):
 assert path.is_file() and not path.is_symlink();assert path.stat().st_size<=32*1024**2
 entries.append({'path':path.relative_to(ASSETS).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)})
(D/'SHA256SUMS').write_text(''.join(x['sha256']+'  '+Path(x['path']).name+'\n' for x in entries))
entries.append({'path':PREFIX+'/SHA256SUMS','bytes':(D/'SHA256SUMS').stat().st_size,'sha256':sha(D/'SHA256SUMS')})
assert len({x['path'] for x in original['members']+entries})==len(original['members'])+len(entries)
updated={**original,'members':original['members']+entries}
assert {k:v for k,v in updated.items() if k!='members'}=={k:v for k,v in original.items() if k!='members'}
(ASSETS/'assets.json').write_text(json.dumps(updated,indent=2,ensure_ascii=False)+'\n')
# Hook installation is repository-local and executes the unchanged branch verifier.
for key in ['user.name','user.email']:
 value=subprocess.check_output(['git','config','--get',key],cwd=ROOT,text=True).strip();subprocess.run(['git','config','--local',key,value],cwd=ASSETS,check=True)
hook=ASSETS/'.git/hooks/pre-commit'
assert not hook.exists()
hook.write_text('#!/bin/sh\nset -eu\npython3 -B verify_assets.py\n')
hook.chmod(0o755)
record={'kind':'first_batch_asset_stage','base':BASE,'namespace':PREFIX,'new_members':entries,'new_member_count':len(entries),'new_bytes':sum(x['bytes'] for x in entries),'old_members_unchanged':updated['members'][:112]==original['members'],'old_header_unchanged':True,'archives_original_bytes_unchanged':True,'source_commit':P,'examples_commit':E,'disk':{s:shutil.disk_usage(s)._asdict() for s in ['/workspace','/dev/shm']},'local_hook':{'path':str(hook),'sha256':sha(hook),'command':'python3 -B verify_assets.py','tracked_verifier_unchanged':True}}
(LOG/'stage-first-batch.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'new_member_count':len(entries),'new_bytes':record['new_bytes'],'tmpfs_free':record['disk']['/dev/shm']['free']}))
