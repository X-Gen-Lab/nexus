Main still uses the earlier Runtime API examples. This brings the maintained static factory/TOML applications and five-board reference presets onto main, pinned to the first Nexus 0.1.0 Source SDK developer preview.

The SDK Gitlink and lock both select final Nexus main `58297516d707fdee117bd27b5df6af09d72edd2e` (tree `06feab8ef3e89df60b4cdc5671c66ab0e3c08c21`). The examples application project keeps its independent `1.0.0` version. The release guide records the current source boundary and keeps earlier source counts explicitly historical.

- Native execution: 44 Python tests, 8 CTests and 43 GoogleTest cases across three programs passed, with no failures or skips.
- ARM compilation/linking: all 10 maintained presets passed, producing 20 application ELF/BIN/map sets. Both application resource budgets passed for every preset, and all 10 HIL station plans remain unbound.
- The normal format/text, complete pinned-SDK Native TDD, and Conventional Commit hooks passed. Their reviewed source tree is identical to this commit tree.
- Physical HIL, timing, electrical behavior, reset and power-cut tests were not executed. This is software preview integration, with no physical board qualification claim.

This PR includes the existing integration history currently represented by PRs #1 and #2, plus the release pin and documentation update. Those PRs remain open. GitHub Actions for this head will independently validate the formal pin; historical CI does not qualify it.
