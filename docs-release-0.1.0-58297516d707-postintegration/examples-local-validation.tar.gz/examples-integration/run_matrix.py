from pathlib import Path
import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
ROOT=Path('/tmp/nexus-release-0.1.0-20261015/examples')
OUT=Path('/tmp/nexus-release-0.1.0-20261015/examples-integration')
SDK=ROOT/'external/nexus'
C='58297516d707fdee117bd27b5df6af09d72edd2e'
ENV=os.environ.copy()
ENV.update(json.loads((OUT/'execution-environment.json').read_text())['task_environment'])
ENV['NEXUS_SOURCE']=str(SDK)
PY=str(ROOT/'.venv/bin/python')
RECORDS=[]
START=time.time()
def git(*args,cwd=ROOT):
    return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
def save(status):
    (OUT/'matrix-execution.json').write_text(json.dumps({'kind':'examples_nexus_0_1_0_integration_execution','status':status,'sdk_commit':C,'sdk_tree':git('rev-parse','HEAD^{tree}',cwd=SDK),'examples_base_commit':git('rev-parse','HEAD'),'index_tree':INDEX,'elapsed_seconds':time.time()-START,'commands':RECORDS,'physical_status':'not_executed','offline_reproducibility':'not_claimed'},indent=2)+'\n')
def run(name,argv):
    log=OUT/(name+'.log')
    print('START '+name,flush=True)
    stamp=time.time()
    with log.open('wb') as f:
        try:
            r=subprocess.run(argv,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT,check=False,timeout=1200)
            code=r.returncode
        except subprocess.TimeoutExpired:
            code=124
    RECORDS.append({'name':name,'argv':argv,'cwd':str(ROOT),'exit_code':code,'elapsed_seconds':time.time()-stamp,'log':str(log),'log_bytes':log.stat().st_size,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
    save('running' if code==0 else 'failed')
    print('END '+name+' exit='+str(code),flush=True)
    if code:raise RuntimeError('Command failed: '+name+'; '+str(log))
INDEX=git('write-tree')
try:
    run('source-before',[PY,'scripts/test_repository.py','--report',str(OUT/'source-before.json')])
    run('style-all',[PY,'scripts/check_style.py','--all','--report',str(ROOT/'build/quality/style.json')])
    run('python-tools',[PY,'-B','-m','unittest','discover','-s','scripts','-p','test_*.py','-v'])
    run('native-debug',[PY,'scripts/build.py','--preset','native-debug','--test','--parallel','2'])
    presets=json.loads((ROOT/'CMakePresets.json').read_text())['configurePresets']
    arms=[r['name'] for r in presets if not r.get('hidden') and r['name']!='native-debug']
    for preset in arms:
        run(preset,[PY,'scripts/build.py','--preset',preset,'--parallel','2'])
        build=ROOT/'build'/preset
        for target in ('platform_reference','uart_owner_runtime'):
            run(preset+'-'+target+'-resources',[PY,str(SDK/'tools/measurement/resources.py'),'--elf',str(build/'bin'/(target+'.elf')),'--resolved',str(build/'nexus/generated/resolved.json'),'--budget',str(build/'nexus/generated/resource-budget.json'),'--report',str(build/(target+'-release-resource-budget.json'))])
        fixture=next(value for prefix,value in (('stm32-qiming-','stm32f407_qiming_v31'),('stm32-sky-','stm32f407ve_sky_qingchun'),('gd32-liangshan-','gd32f470_liangshan'),('stm32-h743-','stm32h743_nucleo_zi2'),('stm32-u575-','stm32u575_nucleo_zi_q')) if preset.startswith(prefix))
        run(preset+'-hil-preparation',[PY,'-B',str(SDK/'tools/hil/prepare.py'),'--fixture',str(SDK/'tools/hil/fixtures'/(fixture+'.json')),'--resolved',str(build/'nexus/generated/resolved.json'),'--report',str(build/'release-hil-preparation.json')])
    run('source-after',[PY,'scripts/test_repository.py','--report',str(OUT/'source-after.json')])
    if (OUT/'source-before.json').read_bytes()!=(OUT/'source-after.json').read_bytes():raise RuntimeError('SDKsourceidentitychanged')
    if git('write-tree')!=INDEX:raise RuntimeError('Indexchanged')
    ctest=ET.parse(ROOT/'build/native-debug/ctest-results.xml').getroot()
    google=[]
    for report in sorted((ROOT/'build/native-debug/tests').glob('*google-execution/google-results.xml')):
        cases=list(ET.parse(report).getroot().iter('testcase'))
        google.append({'report':str(report),'cases':len(cases),'failures':sum(c.find('failure') is not None or c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases),'sha256':hashlib.sha256(report.read_bytes()).hexdigest()})
    summary={'kind':'examples_nexus_0_1_0_matrix_summary','status':'passed','sdk_commit':C,'sdk_tree':git('rev-parse','HEAD^{tree}',cwd=SDK),'examples_index_tree':INDEX,'examples_base_commit':git('rev-parse','HEAD'),'ctest_entries':len(list(ctest.iter('testcase'))),'google_programs':len(google),'google_cases':sum(r['cases'] for r in google),'google_reports':google,'arm_presets':arms,'arm_images':2*len(arms),'unbound_hil_plans':len(arms),'wrapper_commands':len(RECORDS),'physical_status':'not_executed','qualification_boundary':'Actual staged examples tree and clean exact finalNexusC; subsequent normalcommit hook reruns Native/tools against unchangedindex. No offline reproducibility or hardware claim.'}
    (OUT/'matrix-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    save('passed')
    print(json.dumps(summary),flush=True)
except Exception as error:
    save('failed')
    print(str(error),file=sys.stderr,flush=True)
    raise SystemExit(1)
