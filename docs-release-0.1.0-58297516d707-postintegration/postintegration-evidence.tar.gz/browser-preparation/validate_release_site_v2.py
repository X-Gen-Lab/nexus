"""Independent offline browser acceptance of an immutable delivered documentation payload."""
from __future__ import annotations
import argparse, collections, hashlib, importlib.metadata, json, mimetypes, re
import subprocess, sys, time
from pathlib import Path, PurePosixPath
from urllib.parse import quote, unquote, urlsplit

ORIGIN = 'http://127.0.0.1:18765'  # No server is started; offline routing supplies bytes.
LANGUAGES = ('en', 'zh_CN')
FOCUS = ('design/source-compatibility', 'status/index', 'status/release-0.1.0',
         'reference/documentation-delivery', 'design/documentation-system')
PLAYWRIGHT_ROOT = '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages'
MAX_FILES, MAX_BYTES = 50000, 1024 * 1024 * 1024


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()


def safe_name(name):
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name:
        raise ValueError('unsafe payload path')
    parts = name.split('/')
    if any(part in ('', '.', '..') for part in parts) or name.startswith('/'):
        raise ValueError('unsafe payload path: ' + name)
    return name


def inventory(site):
    result, total = {}, 0
    for path in sorted(site.rglob('*')):
        if path.is_symlink():
            raise ValueError('symlink in delivered payload: ' + str(path))
        if not path.is_file():
            continue
        name = safe_name(path.relative_to(site).as_posix())
        size = path.stat().st_size
        result[name] = {'bytes': size, 'sha256': sha(path)}
        total += size
        if len(result) > MAX_FILES or total > MAX_BYTES:
            raise ValueError('payload exceeds bounded browser input budget')
    return result


def load_registry(site, build, commit, expected_pages):
    if build.get('status') != 'passed' or build.get('languages') != list(LANGUAGES):
        raise ValueError('passed bilingual build metadata is required')
    source = build.get('source', {})
    if source.get('commit') != commit or source.get('dirty') is not False:
        raise ValueError('build must bind the requested exact clean source commit')
    translations = build.get('translations', {})
    if translations.get('status') != 'passed' or translations.get('errors'):
        raise ValueError('build translation admission is not passed')
    expected = {language: {} for language in LANGUAGES}
    for row in translations.get('records', []):
        name, language = row['page'], row['requested_language']
        safe_name(name)
        if language not in expected or name in expected[language]:
            raise ValueError('duplicate or unknown locale registry record')
        if row['status'] not in ('original', 'reviewed') or row['actual_language'] != language:
            raise ValueError('registry has a stale/missing/fallback current page')
        if row['source_language'] not in LANGUAGES:
            raise ValueError('unknown canonical language')
        if row['status'] == 'original' and row['source_language'] != language:
            raise ValueError('original status must use its actual canonical language')
        expected[language][name] = row
    names = sorted(expected['en'])
    if not names or set(names) != set(expected['zh_CN']):
        raise ValueError('locale page registries differ or are empty')
    if expected_pages is not None and len(names) != expected_pages:
        raise ValueError('observed page count differs from requested acceptance count')
    for language in LANGUAGES:
        path = site / language / '_static/nexus-search-data.js'
        raw = path.read_text(encoding='utf-8').strip()
        prefix = 'window.NEXUS_SEARCH_DATA = '
        if not raw.startswith(prefix) or not raw.endswith(';'):
            raise ValueError('unknown search registry wrapper')
        data = json.loads(raw[len(prefix):-1])
        if (data.get('schema_version') != 1 or data.get('revision') != commit
                or data.get('requested_language') != language):
            raise ValueError('search registry source/language mismatch')
        if set(data['records']) != {name + '.html' for name in names}:
            raise ValueError('search and build page registries differ')
        for name in names:
            actual = data['records'][name + '.html']
            for key in ('source_language', 'requested_language', 'actual_language', 'status'):
                if actual[key] != expected[language][name][key]:
                    raise ValueError('search/page language metadata mismatch: ' + name)
    for name in FOCUS:
        if name not in names:
            raise ValueError('required changed page absent: ' + name)
    return names, expected


GEOMETRY = '''() => {
 const banner = document.querySelector('.nexus-page-identity');
 const content = document.querySelector('.nexus-canonical-content');
 return {title:document.title,h1:document.querySelector('h1')?.innerText,
 html_lang:document.documentElement.lang,content_lang:content?.lang,
 identity:banner ? {source_language:banner.dataset.nexusSourceLanguage,
 requested_language:banner.dataset.nexusRequestedLanguage,
 actual_language:banner.dataset.nexusActualLanguage,status:banner.dataset.nexusTranslationStatus}:null,
 visible_status:banner?.querySelector('strong')?.innerText,
 source_href:banner?.querySelector('a')?.href,
 width:innerWidth,scroll_width:document.documentElement.scrollWidth,
 visual_scale:visualViewport.scale,dpr:devicePixelRatio,online:navigator.onLine,
 image_count:document.images.length,
 broken_images:[...document.images].filter(n=>!n.complete||n.naturalWidth<=0).map(n=>n.getAttribute('src')),
 overflow_regions:[...document.querySelectorAll('pre,table')].filter(n=>n.scrollWidth>n.clientWidth+1).map(n=>{
 let scrollable=false; for(let p=n;p&&p!==document.body;p=p.parentElement){
 const x=getComputedStyle(p).overflowX; if(x==='auto'||x==='scroll'){scrollable=true;break;}}
 return {tag:n.tagName,width:n.clientWidth,scroll_width:n.scrollWidth,scrollable};}).slice(0,20)};
}'''
READY = '''async () => {await document.fonts.ready;
 await Promise.all([...document.images].map(n=>n.decode().catch(()=>null)));
 await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));}'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--site', type=Path, required=True, help='verified final CI documentation payload root')
    parser.add_argument('--commit', required=True, help='exact final main C: full 40-character source commit')
    parser.add_argument('--output', type=Path, required=True, help='new, empty result directory outside site')
    parser.add_argument('--manifest-sha256', help='required archive manifest digest when a packaged site is supplied')
    parser.add_argument('--expected-pages', type=int, help='optional expected count; actual count derives from payload registries')
    parser.add_argument('--browser', type=Path, default=Path('/usr/bin/chromium'))
    parser.add_argument('--timeout', type=int, default=600, help='total bounded execution seconds')
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.commit) or not 1 <= args.timeout <= 1800:
        parser.error('commit must be full lowercase SHA-1 and timeout must be 1..1800')
    if sys.version_info[:2] != (3, 12):
        parser.error('use the qualified Python 3.12 executable')
    site, output = args.site.resolve(), args.output.resolve()
    if not site.is_dir() or any(p.is_symlink() for p in (args.site, *args.site.parents, args.output, *args.output.parents)):
        parser.error('real site/output directories without symlink ancestors are required')
    if output.is_relative_to(site) or site.is_relative_to(output):
        parser.error('results must not overlap the delivered site')
    if output.exists() and any(output.iterdir()):
        parser.error('output must be new or empty; prior results are never overwritten')
    output.mkdir(parents=True, exist_ok=True)
    report = {'schema_version': 1, 'harness_version': 2, 'status': 'running', 'scope': 'independent_final_release_browser_acceptance',
              'expected_commit': args.commit, 'site': str(site), 'records': [], 'errors': [],
              'offline_policy': 'All contexts have actual browser offline=True; only verified local bytes are route-fulfilled. No HTTP server or file:// access.',
              'zoom_policy': 'zoom200 uses observed Chromium visualViewport scale=2 (pinch zoom); reflow200 uses 720x500 CSS pixels at DPR2, an explicit 200% layout equivalent for 1440x1000 pixels.',
              'physical_status': 'not_executed', 'new_firmware_qualification': False}
    started = time.monotonic()
    def save():
        report['elapsed_seconds'] = round(time.monotonic() - started, 3)
        (output / 'browser-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    def error(message):
        if len(report['errors']) < 1000:
            report['errors'].append(message)
    def budget():
        if time.monotonic() - started > args.timeout:
            raise TimeoutError('total browser acceptance time budget exceeded')
    try:
        initial = inventory(site)
        report['payload_inventory_sha256'] = hashlib.sha256(canonical(initial)).hexdigest()
        report['payload_file_count'] = len(initial)
        (output / 'verified-payload-inventory.json').write_text(json.dumps(initial, sort_keys=True, indent=2) + '\n')
        build = json.loads((site / 'documentation-build.json').read_text())
        names, expected = load_registry(site, build, args.commit, args.expected_pages)
        report.update(current_page_count=len(names), locale_state_count=2*len(names),
                      expected_baseline_page_loads=4*len(names), build_metadata=build,
                      build_metadata_sha256=initial['documentation-build.json']['sha256'])
        manifest_path = site / 'documentation-manifest.json'
        if args.manifest_sha256 and not manifest_path.is_file():
            raise ValueError('requested package manifest is absent')
        if manifest_path.is_file():
            manifest = json.loads(manifest_path.read_text())
            if args.manifest_sha256 and sha(manifest_path) != args.manifest_sha256:
                raise ValueError('package manifest does not match supplied digest')
            declared = {safe_name(r['path']): {'bytes': r['bytes'], 'sha256': r['sha256']} for r in manifest['files']}
            if len(declared) != len(manifest['files']):
                raise ValueError('duplicate manifest paths')
            actual = {k:v for k,v in initial.items() if k not in ('documentation-manifest.json', 'SHA256SUMS')}
            if declared != actual or manifest['documentation_source']['commit'] != args.commit:
                raise ValueError('package manifest bytes/source do not match final payload')
            report['package_manifest_sha256'] = sha(manifest_path)
        canonical_svgs = sorted(k for k in initial if re.fullmatch(r'sources/diagrams/[^/]+\.svg', k))
        stems = {PurePosixPath(k).name for k in canonical_svgs}
        if len(stems) != 17:
            raise ValueError('expected all 17 actual canonical SVGs, independently of 15-row main atlas CSV')
        svg_paths = canonical_svgs[:]
        for language in LANGUAGES:
            localized = {k for k in initial if k.startswith('sources/diagrams/localized/' + language + '/') and k.endswith('.svg')}
            wanted = {'sources/diagrams/localized/' + language + '/' + name for name in stems}
            if localized != wanted:
                raise ValueError('canonical/localized SVG sets differ: ' + language)
            svg_paths.extend(sorted(localized))
        sys.path.insert(0, PLAYWRIGHT_ROOT)
        import playwright
        from playwright.sync_api import sync_playwright
        browser_binary = Path('/usr/lib/chromium/chromium') if args.browser == Path('/usr/bin/chromium') else args.browser.resolve()
        report['tools'] = {'python_executable': sys.executable, 'python_version': sys.version,
                           'python_sha256': sha(Path(sys.executable)), 'playwright_version': importlib.metadata.version('playwright'),
                           'playwright_module': playwright.__file__, 'playwright_module_sha256': sha(Path(playwright.__file__)),
                           'browser_launcher': str(args.browser), 'browser_launcher_sha256': sha(args.browser),
                           'browser_binary': str(browser_binary), 'browser_binary_sha256': sha(browser_binary),
                           'script_path': str(Path(__file__).resolve()), 'script_sha256': sha(Path(__file__))}
        reads, cache, rejected = {}, {}, []
        offline_sessions = {}
        report['postnavigation_network_state'] = {'api': 'Network.overrideNetworkState', 'offline': True, 'latency': 0, 'downloadThroughput': 0, 'uploadThroughput': 0, 'connectionType': 'none', 'reapplications': 0}
        diagnostic = Path(__file__).with_name('offline-diagnostic-postnavigation.json')
        report['offline_mechanism_diagnostic'] = {'path': str(diagnostic), 'sha256': sha(diagnostic)}
        def fulfill(route):
            try:
                parsed = urlsplit(route.request.url)
                if parsed.scheme != 'http' or parsed.netloc != '127.0.0.1:18765' or route.request.method not in ('GET', 'HEAD'):
                    raise ValueError('blocked nonlocal request: ' + route.request.url)
                decoded = unquote(parsed.path)
                name = safe_name(decoded[1:] if decoded.startswith('/') else decoded)
                if name not in initial:
                    raise ValueError('missing/unlisted local resource: ' + name)
                if name not in cache:
                    raw = (site/name).read_bytes()
                    if len(raw) != initial[name]['bytes'] or hashlib.sha256(raw).hexdigest() != initial[name]['sha256']:
                        raise ValueError('resource changed after inventory: ' + name)
                    cache[name] = raw
                reads[name] = reads.get(name, 0) + 1
                route.fulfill(status=200, body=cache[name], content_type=mimetypes.guess_type(name)[0] or 'application/octet-stream')
            except Exception as failure:
                rejected.append(str(failure)); error(str(failure)); route.abort()
        def context_for(browser, viewport, dpr=1):
            context = browser.new_context(viewport=viewport, device_scale_factor=dpr, offline=True,
                                          service_workers='block', reduced_motion='reduce')
            context.route('**/*', fulfill)
            page = context.new_page()
            page.set_default_timeout(15000)
            offline_sessions[page] = context.new_cdp_session(page)
            offline_sessions[page].send('Network.enable')
            page.on('pageerror', lambda failure: error('pageerror: ' + str(failure)))
            return context, page
        def enforce_offline_state(page):
            # Chromium 151 resets the visible connection state on fulfilled navigation.
            # Network enforcement stays offline; reapply the real CDP state, never JS.
            offline_sessions[page].send('Network.overrideNetworkState', {'offline': True, 'latency': 0, 'downloadThroughput': 0, 'uploadThroughput': 0, 'connectionType': 'none'})
            report['postnavigation_network_state']['reapplications'] += 1
        def visit(page, language, name, mode, session=None):
            budget()
            response = page.goto(ORIGIN + '/' + language + '/' + quote(name, safe='/') + '.html', wait_until='load', timeout=20000)
            enforce_offline_state(page)
            page.evaluate(READY)
            if session:
                session.send('Emulation.setPageScaleFactor', {'pageScaleFactor': 2})
            data = page.evaluate(GEOMETRY)
            row = expected[language][name]
            scope = mode + '/' + language + '/' + name
            if response is None or response.status != 200 or not data['h1']:
                error(scope + ': missing successful rendered document/h1')
            for key in ('source_language', 'requested_language', 'actual_language', 'status'):
                if not data['identity'] or data['identity'].get(key) != row[key]:
                    error(scope + ': rendered identity mismatch: ' + key)
            if data['content_lang'] != row['actual_language'].replace('_', '-') or data['html_lang'] != language.replace('_', '-'):
                error(scope + ': actual content or UI language mismatch')
            if not data['source_href'] or '/blob/' + args.commit + '/' not in urlsplit(data['source_href']).path:
                error(scope + ': rendered source link does not bind final commit')
            expected_label = {'original':'原文','reviewed':'已审查'}[row['status']] if language == 'zh_CN' else row['status']
            if data['visible_status'] != expected_label:
                error(scope + ': visible translation status mismatch')
            if data['online'] is not False:
                error(scope + ': actual browser offline state was not observed')
            if mode != 'zoom200' and data['scroll_width'] > data['width'] + 1:
                error(scope + ': whole-page horizontal overflow')
            if data['broken_images']:
                error(scope + ': broken images: ' + repr(data['broken_images']))
            if mode in ('narrow', 'reflow200') and any(not x['scrollable'] for x in data['overflow_regions']):
                error(scope + ': overflowing code/table without accessible internal scrolling')
            if session and abs(data['visual_scale'] - 2) > 0.01:
                error(scope + ': actual visual zoom=2 was not observed')
            report['records'].append({'mode': mode, 'language': language, 'page': name, **data})
            return data
        with sync_playwright() as driver:
            browser = driver.chromium.launch(executable_path=str(args.browser), headless=True,
                        args=['--no-sandbox', '--disable-dev-shm-usage', '--disable-background-networking', '--disable-component-update'])
            report['tools']['chromium_version'] = browser.version
            for mode, viewport in (('desktop', {'width':1440,'height':1000}), ('narrow', {'width':390,'height':844})):
                context, page = context_for(browser, viewport)
                for language in LANGUAGES:
                    for name in names:
                        visit(page, language, name, mode)
                        if mode == 'narrow' and name == 'status/release-0.1.0':
                            page.screenshot(path=str(output/(mode+'-'+language+'-release.png')))
                    save()
                context.close()
            report['observed_baseline_page_loads'] = sum(r['mode'] in ('desktop','narrow') for r in report['records'])
            for mode, viewport, dpr in (('zoom200', {'width':1440,'height':1000}, 1), ('reflow200', {'width':720,'height':500}, 2)):
                context, page = context_for(browser, viewport, dpr)
                session = context.new_cdp_session(page) if mode == 'zoom200' else None
                for language in LANGUAGES:
                    for name in FOCUS:
                        visit(page, language, name, mode, session)
                        if (mode,language,name) in (('zoom200','en','design/source-compatibility'),('reflow200','zh_CN','reference/documentation-delivery')):
                            page.screenshot(path=str(output/(mode+'-'+language+'-'+name.replace('/','-')+'.png')))
                context.close()
            context, page = context_for(browser, {'width':1440,'height':1000})
            for language, query in (('en','factory'), ('zh_CN','借用')):
                budget()
                page.goto(ORIGIN+'/'+language+'/search.html?q='+quote(query), wait_until='load')
                enforce_offline_state(page)
                page.wait_for_function("document.querySelectorAll('#search-results li.nexus-search-result .nexus-search-identity').length>0")
                results = page.locator('#search-results li.nexus-search-result').evaluate_all('''nodes=>nodes.slice(0,10).map(n=>({text:n.innerText,href:n.querySelector('a')?.href,requested:n.dataset.nexusRequestedLanguage,actual:n.dataset.nexusActualLanguage,status:n.dataset.nexusTranslation}))''')
                for result in results:
                    if result['requested'] != language or result['actual'] != language or result['status'] not in ('original','reviewed'):
                        error(language + ': search result identity mismatch')
                    result_url=urlsplit(result['href']);key=unquote(result_url.path).removeprefix('/'+language+'/').removesuffix('.html')
                    if result_url.netloc != '127.0.0.1:18765' or key not in expected[language]:
                        error(language + ': unsafe or unknown search result link')
                    elif result['status'] != expected[language][key]['status']:
                        error(language + ': search status differs from page registry')
                report['records'].append({'mode':'search','language':language,'query':query,'results':results,'online':page.evaluate('navigator.onLine')})
                page.screenshot(path=str(output/('search-'+language+'.png')))
            for language in LANGUAGES:
                other = 'zh_CN' if language == 'en' else 'en'
                visit(page, language, 'status/release-0.1.0', 'language-switch-source')
                page.locator('.nexus-page-identity a[lang="'+other.replace('_','-')+'"]').click()
                page.wait_for_load_state('load');enforce_offline_state(page);page.evaluate(READY)
                data = page.evaluate(GEOMETRY)
                if urlsplit(page.url).path != '/'+other+'/status/release-0.1.0.html' or data['identity'] != {k:expected[other]['status/release-0.1.0'][k] for k in ('source_language','requested_language','actual_language','status')}:
                    error('actual language switch failed to preserve counterpart identity')
                report['records'].append({'mode':'language-switch','from':language,'to':other,'url':page.url,**data})
            for name in svg_paths:
                budget()
                page.goto(ORIGIN+'/'+quote(name, safe='/'), wait_until='load')
                enforce_offline_state(page)
                data=page.evaluate('''()=>{const s=document.documentElement;let b=null;try{b=s.getBBox()}catch(e){}return {root:s.tagName,viewBox:s.getAttribute('viewBox'),paths:document.querySelectorAll('path').length,bbox:b?{x:b.x,y:b.y,width:b.width,height:b.height}:null,external:[...document.querySelectorAll('[href]')].map(n=>n.getAttribute('href')).filter(h=>h&&!h.startsWith('#')),online:navigator.onLine}}''')
                if data['root'] != 'svg' or not data['paths'] or not data['bbox'] or data['bbox']['width'] <= 0 or data['bbox']['height'] <= 0 or data['external'] or data['online'] is not False:
                    error('SVG actual browser rendering failed: '+name)
                report['records'].append({'mode':'standalone-svg','path':name,**data})
            context.close();browser.close()
        report['verified_local_resource_reads'] = reads
        report['rejected_requests'] = rejected
        report['rendered_svg_count'] = len(svg_paths)
        if report['observed_baseline_page_loads'] != report['expected_baseline_page_loads']:
            error('baseline load coverage incomplete')
        final = inventory(site)
        if final != initial:
            error('payload changed during browser acceptance')
        report['final_payload_inventory_sha256'] = hashlib.sha256(canonical(final)).hexdigest()
    except Exception as failure:
        error(type(failure).__name__ + ': ' + str(failure))
    report['status'] = 'failed' if report['errors'] else 'passed'
    save()
    print(json.dumps({'status':report['status'],'records':len(report['records']),'errors':report['errors'][:20],'receipt':str(output/'browser-report.json')}, ensure_ascii=False))
    return 1 if report['errors'] else 0


if __name__ == '__main__':
    raise SystemExit(main())
