"""Actual Chromium offline/CDP mechanism diagnostic; never spoof navigator state."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hashlib,json,sys,threading,time
sys.path.insert(0,'/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages')
from playwright.sync_api import sync_playwright
BASE=Path('/tmp/nexus-release-0.1.0-20261015/browser-preparation')
requests=[]
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        requests.append(self.path)
        raw=json.dumps({'network_request_observed':True,'path':self.path}).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
    def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
origin='http://127.0.0.1:'+str(server.server_port)
report={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.executable,'origin':origin,'navigator_property_injection':False,'server_records':requests,'cases':[],'site_source_mutations':False}
body='<!doctype html><html><meta charset="utf-8"><title>Offline diagnostic</title><body>Verified local fulfillment only</body></html>'
conditions={'offline':True,'latency':0,'downloadThroughput':0,'uploadThroughput':0,'connectionType':'none'}
cases=[('online-positive-control',False,[]),('context-offline-true',True,[]),('context-offline-then-public-reset',True,[('PUBLIC.set_offline',{})]),('legacy-emulateNetworkConditions',True,[('Network.enable',{}),('Network.emulateNetworkConditions',conditions)]),('overrideNetworkState',True,[('Network.enable',{}),('Network.overrideNetworkState',conditions)]),('rules-and-override',True,[('Network.enable',{}),('Network.emulateNetworkConditionsByRule',{'offline':True,'matchedNetworkConditions':[]}),('Network.overrideNetworkState',conditions)])]
try:
    with sync_playwright() as driver:
        browser=driver.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
        report['chromium_version']=browser.version
        for name,offline,commands in cases:
            context=browser.new_context(offline=offline,service_workers='block')
            # Only the local document is route-fulfilled. /probe is genuinely unrouted.
            context.route(origin+'/fulfilled.html',lambda route:route.fulfill(status=200,body=body,content_type='text/html'))
            page=context.new_page();page.set_default_timeout(5000)
            row={'case':name,'constructor_offline':offline,'about_blank_online':page.evaluate('navigator.onLine'),'commands':[]}
            session=context.new_cdp_session(page)
            for method,parameters in commands:
                try:
                    if method=='PUBLIC.set_offline':
                        context.set_offline(False);context.set_offline(True);response={}
                    else:response=session.send(method,parameters)
                    row['commands'].append({'method':method,'parameters':parameters,'result':response})
                except Exception as error:row['commands'].append({'method':method,'parameters':parameters,'error':str(error)})
            row['after_commands_online']=page.evaluate('navigator.onLine')
            page.goto(origin+'/fulfilled.html',wait_until='load')
            row['fulfilled_document_online']=page.evaluate('navigator.onLine')
            probe='/probe?case='+name
            row['unrouted_negative_probe']=page.evaluate('''async url=>{try{const response=await fetch(url,{cache:'no-store'});return {resolved:true,status:response.status,text:await response.text()}}catch(error){return {resolved:false,error:String(error)}}}''',origin+probe)
            row['actual_server_probe_requests']=requests.count(probe)
            row['final_online']=page.evaluate('navigator.onLine')
            row['offline_state_and_negative_probe_confirmed']=(offline and row['fulfilled_document_online'] is False and row['final_online'] is False and row['unrouted_negative_probe']['resolved'] is False and row['actual_server_probe_requests']==0 and not any('error' in c for c in row['commands']))
            report['cases'].append(row);context.close()
        browser.close()
finally:server.shutdown();server.server_close()
report['mechanism_diagnostic_completed']=True
report['positive_control_confirmed']=report['cases'][0]['unrouted_negative_probe']['resolved'] and report['cases'][0]['actual_server_probe_requests']==1
(BASE/'offline-diagnostic.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'positive_control':report['positive_control_confirmed'],'cases':[{'case':r['case'],'navigator_online':r['final_online'],'probe_resolved':r['unrouted_negative_probe']['resolved'],'server_requests':r['actual_server_probe_requests'],'offline_confirmed':r['offline_state_and_negative_probe_confirmed']} for r in report['cases']]},ensure_ascii=False))
