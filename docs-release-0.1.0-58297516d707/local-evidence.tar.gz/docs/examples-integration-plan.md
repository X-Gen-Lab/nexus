# Isolated examples update plan

Fresh read-only GitHub audit on 2026-10-15 found main `ae922194fe001555d6cca2c299cd0c5acd18c139`, open PR #1 at `799ea75a08756234751dcf44c6c3ff80da4d6b92` targeting main, and open PR #2 at `a501fbd6ee69172594cd51c15ba7307621cec924` targeting PR #1. PR #2 contains the current five-board implementation and its latest successful CI is run 38258781053. Repository visibility is private. Root owns remote merges and release access/publication decisions.

Prepared `/tmp/nexus-release-0.1.0-20261015/examples`, branch `codex/release-0.1.0`, at the exact PR #2 head. The original `/workspace/nexus-examples` remains on its original branch and its index/outer-status/nested-status hashes are unchanged. Its 353 tracked historical object-file deletions inside external/nexus were not reset, stashed, copied as fixes or cleaned.

1. Wait for root's final Nexus main commit **C** and obtain `C^{tree}`. Do not pin an intermediate release-branch source. Do not modify the original dirty checkout.
2. Populate only the new worktree's empty external/nexus with an independently owned clean Git checkout of C. Use normal immutable Git object/dependency reuse without sharing a mutable checkout; preserve the declared HTTPS origin and initialize the exact recursive dependencies in that new checkout. Do not reuse the original dirty external/nexus directory or point a mutable symlink at it.
3. Keep examples' independent `project(nexus_examples VERSION 1.0.0)` unchanged. There are no live Nexus-1.0.0 version assertions in scripts/assemblies. Historical documentation and source-header versions remain historical. Update only the Nexus Gitlink and `dependencies/nexus.lock.json` commit/tree together, plus narrowly scoped current integration notes identifying the 0.1.0 developer preview and fresh receipts. Do not rewrite old result indices.
4. Ensure the new checkout uses the existing normal examples pre-commit/commit-msg hooks and SDK-locked tools. Worktrees share the original repository's normal hooks; avoid silently retargeting those shared hooks to a temporary interpreter or disabling them. The hooks run style/text, Conventional Commits, formal lock/Gitlink/clean-source verification, the complete Python suite, complete Native CTest and all discovered Google cases. No SKIP/NEXUS_SKIP_TDD, filters or skipped reports.
5. Execute the maintained independent source check, full tools, Native and ARM matrix under recorded actual tools, preserving argv/exits/logs and source/config/artifact identities. Existing entry points from repository root:

```sh
python scripts/test_repository.py --report build/release-dependency-identity.json
python scripts/check_style.py --all --report build/quality/style.json
python -m unittest discover -s scripts -p 'test_*.py' -v
python scripts/build.py --preset native-debug --test --parallel 2
python scripts/build.py --preset stm32-qiming-baremetal --parallel 2
python scripts/build.py --preset stm32-qiming-freertos --parallel 2
python scripts/build.py --preset stm32-sky-baremetal --parallel 2
python scripts/build.py --preset stm32-sky-freertos --parallel 2
python scripts/build.py --preset gd32-liangshan-baremetal --parallel 2
python scripts/build.py --preset gd32-liangshan-freertos --parallel 2
```

The first six ARM builds are the requested three-board/two-backend scope. Because the maintained examples source also contains H743/U575 consumers, a whole-pin update should additionally execute `stm32-h743-nucleo-baremetal`, `stm32-h743-nucleo-freertos`, `stm32-u575-nucleo-baremetal` and `stm32-u575-nucleo-freertos`; do not infer their integration from the older pin. Each ARM build creates platform_reference and uart_owner_runtime ELF/BIN/map/resource records. The CI workflow lines 164-193 show explicit resource checks for both images and unbound HIL preparations. Preparations remain software tooling and never equipment execution.

6. Have an independent agent review the exact pin, narrow notes and actual receipts. Explicitly stage only reviewed intended files/Gitlink, then commit through the repository's normal installed hooks. Preserve the resulting new examples commit identity; do not relabel the old 3de85238/a501fbd6 records. Root decides and performs remote branch/PR-chain integration after this review.

No final C has been supplied. The new worktree is clean, its SDK submodule remains uninitialized, and no lock/Gitlink update, test/build/install, staging, commit or remote mutation has been performed. Read-only remote observations and worktree before/after records are in this directory.
