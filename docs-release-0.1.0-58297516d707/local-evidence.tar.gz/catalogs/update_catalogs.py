from pathlib import Path
import ast,hashlib,json,re,sys,textwrap
ROOT=Path('/workspace/nexus-build-system-20261012')
BASE=Path('/tmp/nexus-release-0.1.0-20261015/catalogs')
sys.path.insert(0,str(ROOT))
from tools.documentation.sphinx_ext import read_catalog

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def field(name,value):
    if len(value)<65 and '\n' not in value:return name+' '+json.dumps(value,ensure_ascii=False)
    chunks=textwrap.wrap(value,72,break_long_words=False,break_on_hyphens=False,replace_whitespace=False,drop_whitespace=False)
    return name+' ""\n'+'\n'.join(json.dumps(x,ensure_ascii=False) for x in chunks)
def pair(key,value):return field('msgid',key)+'\n'+field('msgstr',value)
def block_key(block):
    active=False;result=''
    for line in block.splitlines():
        if line.startswith('msgid '):result=ast.literal_eval(line[6:]);active=True
        elif active and line.startswith('"'):result+=ast.literal_eval(line)
        elif active:break
    return result if active else None

def update(docname,language,added):
    source=ROOT/'docs'/(docname+'.md');pot=BASE/'gettext'/(docname+'.pot')
    path=ROOT/'docs/locale'/language/'LC_MESSAGES'/(docname+'.po')
    old_text=path.read_text() if path.exists() else ''
    old=read_catalog(path)[1] if path.exists() else {}
    before_hash=sha(path) if path.exists() else None
    if path.exists():
        backup=BASE/'catalogs-before'/language/(docname+'.po');backup.parent.mkdir(parents=True,exist_ok=True);backup.write_text(old_text)
    ids=read_catalog(pot)[1]
    blocks={block_key(block):block for block in re.split(r'\n\s*\n',old_text) if block_key(block) is not None}
    metadata=('Project-Id-Version: Nexus source documentation\nLanguage: '+language+'\nMIME-Version: 1.0\nContent-Type: text/plain; charset=UTF-8\nContent-Transfer-Encoding: 8bit\nX-Nexus-Reviewed: false\nX-Nexus-Source-SHA256: '+sha(source)+'\n')
    header='# Translation updates awaiting independent semantic review.\n'+pair('',metadata)
    if '' in blocks:
        header=re.sub(r'X-Nexus-Reviewed: (true|false)', 'X-Nexus-Reviewed: false',blocks[''])
        header=re.sub(r'X-Nexus-Source-SHA256: [0-9a-f]{64}','X-Nexus-Source-SHA256: '+sha(source),header)
    out=[header];new_pairs=[]
    for key in ids:
        if key in old:
            value=old[key];out.append(blocks[key])
        else:
            value=added[key];assert value
            out.append(pair(key,value));new_pairs.append({'msgid':key,'msgstr':value})
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text('\n\n'.join(out)+'\n')
    metadata,current,fuzzy=read_catalog(path)
    assert set(ids)==set(current) and all(current.values()) and not fuzzy
    preserved=[key for key in ids if key in old]
    assert all(current[key]==old[key] for key in preserved)
    return {'docname':docname,'language':language,'path':str(path.relative_to(ROOT)),'canonical_source_sha256':sha(source),'pot_sha256':sha(pot),'before_sha256':before_hash,'pending_catalog_sha256':sha(path),'message_count':len(ids),'preserved_message_count':len(preserved),'removed_obsolete_msgids':list(old.keys()-ids.keys()),'new_pairs':new_pairs}

release_zh=[
'Nexus 0.1.0 Source SDK 开发者预览版',
'Nexus 0.1.0 是首个公开的平台 Source SDK 开发者预览版，日期为 2026-10-15（Asia/Shanghai）。接入消费工程前，请使用本页核对软件范围、必需输入和发行证据。所有 MCU 实板 HIL 结果仍为 `not_executed`。',
'源码与兼容性',
'发行资产清单和 SDK manifest 标识实际发布的 commit／tree 与字节。文档包独立记录 `documentation_source`、`code_source` 和历史 `qualified_code`；发布不会把旧软件资格转移到新源码。这些身份规则见[软件验证](software-verification.md)。',
'`dependencies/platform-compatibility.json` 是唯一人工维护的语义版本策略。CMake、生成头文件和已安装包元数据从中派生 `0.1.0`。消费方请求 `find_package(Nexus 0.1.0 EXACT CONFIG REQUIRED)`。源码接口 epoch `1`、authored TOML schema `2` 和仅源码 SDK 的精确匹配保持各自独立且不变的合同。SDK 不承诺稳定二进制 ABI；平台、生成 bindings 和消费工程须使用相同的配置、编译器与 ABI 选择编译。',
'公开发行前的源码快照使用 `1.0.0`。它们保留历史源码身份，不会变成 0.1.0 包。2026-01-12 的第一阶段更新日志是早期开发里程碑；2026-10-15 发行盘点时未观察到对应的公开平台 GitHub tag／release。',
'维护的软件范围',
'平台',
'明确的后端范围',
'参考边界',
'Native',
'Native、ThreadX',
'Linux/POSIX 模型和选定的真实 host 内核路径',
'F407ZG 启明、F407VE 天空星、F470ZG 梁山派',
'裸机、FreeRTOS、ThreadX',
'精确的三块首发 Board 装配及其维护模式',
'G474 MB1367 来源参考',
'裸机、FreeRTOS',
'固定 HSE24/170 MHz、TIM2、GPIO、IRQ LPUART 和选定 EXTI 夹具',
'H743 NUCLEO 来源参考',
'固定 HSI32/64 与 Cache 配置；GPIO、TIM2、IRQ UART 和有限 TX DMA',
'U575 单域 NUCLEO 来源参考',
'预先配置 TZEN=0/SWAP_BANK=0、MSIS4、GPIO、TIM2 和 IRQ UART',
'独立的 U575 双域 Runtime 参考',
'无 OS',
'固定 TZEN=1 归属和有界同步复制 GPIO 消息',
'[精确支持记录](../delivery/support.md)和[派生能力矩阵](../delivery/capabilities.md)仍是料号、路线、控制器模式和未知 Board 事实的权威。H743 RX DMA、运行中调频、保持连续计时的深 STOP，以及通用 U575 双域 factory／NS RTOS／异步借用均不属于本预览版已实现的参考范围。G474 的 M4 不授权 ThreadX Board 后端。',
'CPU-only Runtime 覆盖 M0/M0+/M3/M4/M7/M23/M33/M55/M85 软件 profile，不创建 SoC、Board、启动、路线、链接布局或 factory。裸机和 FreeRTOS 的 profile 覆盖范围不扩大 Native／M4 ThreadX 子集。详见 [CPU 支持合同](../delivery/cortex-m.md)。',
'必需的包与工具输入',
'使用干净且已提交的源码 SDK，并包含完整固定递归依赖、已审查厂商导入和许可／notice 闭包。其 `.nexus-source-sdk.json` 记录源码 commit／tree、依赖身份、完整文件哈希和导出的 CMake 包哈希。脏工作树的 `--development-fixture` 不可发布。',
'维护的软件交付路径使用 Linux x86_64。请阅读本次发行实际的工具版本和命令 receipt，确认所执行的 Python、CMake、Ninja、Native 编译器、GNU Arm 发行物和任何 OCI 身份。仅有最低版本声明和锁文件不能证明安装、消费工程执行或离线复现。较早的 Linux／CP312 证据不建立 CP311 离线安装或 Windows/macOS 集成执行。',
'从 checkout 开始时，使用[源码设置指南](../guides/source-checkout.md)。对于已安装前缀，遵循[搬移后 SDK 教程](../tutorials/source-sdk.md)及包内维护的核验命令。消费工程配置必须拒绝已变更的 manifest、错误源码 pin、不同的精确版本或无效装配，不能静默选择另一块 Board 或其他模式。',
'核验发行字节与实际结果',
'阅读发行资产清单，保留公开归档的大小和 SHA-256，并在解包至新目录前核验下载归档。保留这些哈希以及不可变源码和资产位置。',
'针对该精确前缀执行 SDK 的完整 manifest 核验器和真正独立、搬移后的消费工程。检查记录的 argv、退出码和原始日志。Native 执行与 ARM 链接／资源检查分别建立范围；缺少工具、空报告或仅跳过的结果均不能通过。',
'将源码、配置、依赖、实际执行的工具与产物哈希逐一对应到资格声明。若提供参考固件，检查其精确 ELF／BIN／map 和资源记录。只有针对相同绑定输入实际执行两次全新断网构建，才能声明离线可复现。',
'若提供 provenance bundle，阅读实际 bundle 及其 subject 身份。文件摘要检测字节变化；无签名校验和不构成发布者认证或产品发行签名。',
'物理验收须独立进行。软件模型、ARM 链接、SDK 消费工程和文档发布不会观察 Board 接线、供电、硅片修订、时钟精度、IRQ/DMA 时序、Cache 一致性或 TrustZone 隔离。',
'这些是核验要求，不是编造的执行 receipt。本次发行的实际结果文件决定哪些软件范围已执行。已有失败尝试和历史源码 ID 保持不变。',
'历史候选可取得性与剩余验收',
'正式构建系统基线仍为 `cc6a065c`；较早 SoC 基线独立记录。其八个无签名 H743／U575 候选只选择 HSI64／Cache off 或 MSIS4／TZEN=0、empty／IRQ-UART 以及裸机／FreeRTOS。它们不使本次新发行源码或更广的 Cache／DMA／双域夹具获得资格。',
'2026-10-15，八个候选归档在{download}`原始结果索引 <../delivery/build-system-results.json>`记录的路径均不可取得。其 `candidate-archives` 目录是指向不存在的搬移路径 `/tmp/nexus-docs-polish-20261014/relocated-historical-cache/candidate-archives` 的符号链接。历史归档核验 receipt 仍是原执行的证据，但不会使归档字节当前可取得。原索引未被改写。将这些历史归档作为可下载发行资产提供前，须恢复并重新核验逐字节相同的副本。',
'该基线的完整 72 阶段单次调用、OCI recipe 重建、CP311 离线安装、Windows/macOS 集成和外部示例升级在该记录中仍未执行。边界明确的源码预览版可以保留这些限制。源码／接口变更仍需适用的全新软件检查；旧测试数量不能替代这些检查。',
'每项 MCU 实板测试仍为 `not_executed`。Board 电气行为、实测时序／功耗、Flash 掉电恢复、DMA／Cache 一致性和物理安全隔离都需要真实且通过准入的 station 记录。应用、私有 PCB 事实、安全输出、恢复策略、认证和产品验收仍由外部工程负责。本开发者预览版不建立产品安全认证、签名产品资格或 LTS 承诺。详见[实板状态](hardware.md)和[软件／物理资格合同](../reference/platforms/qualification.md)。',
]
release_ids=list(read_catalog(BASE/'gettext/status/release-0.1.0.pot')[1]);assert len(release_ids)==len(release_zh)
compat_ids=read_catalog(BASE/'gettext/design/source-compatibility.pot')[1]
compat_new=[key for key in compat_ids if key not in read_catalog(ROOT/'docs/locale/en/LC_MESSAGES/design/source-compatibility.po')[1]]
assert len(compat_new)==3
compat_en={
'`0.1.0`':'`0.1.0`',
'唯一人工维护值来自兼容性 JSON；CMake、生成头文件和包元数据派生并保持一致':'The sole authored value comes from the compatibility JSON; CMake, generated headers and package metadata derive it and remain consistent.',
}
paragraph=next(key for key in compat_new if key.startswith('`0.1.0` 是'))
compat_en[paragraph]='`0.1.0` is the first public Source SDK developer preview, dated 2026-10-15 (Asia/Shanghai). The `1.0.0` value in earlier source snapshots was a prepublication version. This version normalization does not change epoch `1`, exact matching or authored schema `2`, and does not transfer old SDK/candidate qualification to new source. The old `0.1.0` wording for the 2026-01-12 Phase 1 entry remains a historical milestone. See [release status](../status/release-0.1.0.md) for the current release scope and actual evidence; the release manifest identifies the exact source/tree.'
records=[update('design/source-compatibility','en',compat_en),update('design/source-compatibility','zh_CN',{key:key for key in compat_new}),update('status/index','en',{}),update('status/index','zh_CN',{}),update('status/release-0.1.0','zh_CN',dict(zip(release_ids,release_zh)))]
(BASE/'translation-review-inputs.json').write_text(json.dumps({'status':'independent_review_pending','new_firmware_qualification':False,'records':records},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:v for k,v in row.items() if k in ('path','message_count','preserved_message_count','new_pairs')} for row in records],ensure_ascii=False,indent=2))
