from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path('/workspace/nexus-build-system-20261012')
BASE=Path('/tmp/nexus-release-0.1.0-20261015/catalogs/refresh-2')
PREFIX=Path('/workspace/nexus-docs-implementation-20261014/tool-lock/prefix-qualified')
sys.path.insert(0,str(ROOT))
from tools.documentation import check,install,sphinx_ext
from tools.dev import process

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():
    paths=list(check.sources(ROOT))
    paths += [ROOT/'Doxyfile', ROOT/'docs/sphinx/conf.py',ROOT/'tools/documentation/sphinx_ext.py']
    paths += [ROOT/p for p in ('core/README.md','arch/README.md','io/README.md','os/README.md','components/README.md')]
    return {str(p.relative_to(ROOT)):digest(p) for p in sorted(set(paths))}
def record(name,value): (BASE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
env=install.environment(PREFIX)
env['PYTHONDONTWRITEBYTECODE']='1'
source_before=inputs()
record('source-inputs-before.json',source_before)
record('tool-observation.json',install.diagnose(PREFIX))
policy=json.loads((ROOT/'dependencies/platform-compatibility.json').read_text())
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
doxy=BASE/'Doxyfile'
doxy.write_text('@INCLUDE = "'+str(ROOT/'Doxyfile')+'"\nOUTPUT_DIRECTORY = "'+str(BASE/'api')+'"\nPROJECT_NUMBER = "'+policy['semantic_version']+'"\nGENERATE_HTML = NO\n')
commands=[[str(PREFIX/'bin/doxygen'),str(doxy)], [str(PREFIX/'venv/bin/python'),'-m','sphinx','-n','-W','--keep-going','-c',str(ROOT/'docs/sphinx'),'-d',str(BASE/'doctrees'),'-b','gettext',str(ROOT/'docs'),str(BASE/'gettext')]]
env.update(NEXUS_DOCS_REVISION=revision,NEXUS_DOCS_CODE_REVISION=revision,NEXUS_DOCS_VERSION=policy['semantic_version'],NEXUS_DOCS_LANGUAGES='en,zh_CN',NEXUS_DOCS_LANGUAGE='en',NEXUS_DOCS_DOXYGEN_XML=str(BASE/'api/xml'),NEXUS_DOCS_GETTEXT_ROOT=str(BASE/'gettext'))
receipts=[]
for name,command in zip(('doxygen','gettext'),commands):
    result=process.run(command,cwd=ROOT,env=env,log=BASE/(name+'.log'),timeout=600,stage='release-catalog-'+name)
    receipts.append({'stage':name,'receipt':str(result.receipt_path),'exit':result.returncode,'command':command})
    record('extraction-commands.json',receipts)
    print(name,result.returncode,result.receipt_path,flush=True)
    if result.returncode:print(result.stdout[-6000:],result.stderr[-6000:]);raise SystemExit(result.returncode)
source_after=inputs()
record('source-inputs-after.json',source_after)
if source_before!=source_after:raise SystemExit('Canonical source inputs changed during extraction')
report=check.validate_translations(ROOT,pot_root=BASE/'gettext')
record('admission-before.json',report)
record('pot-inventory.json',[{'path':str(p.relative_to(BASE/'gettext')),'sha256':digest(p),'messages':len(sphinx_ext.read_catalog(p)[1])} for p in sorted((BASE/'gettext').rglob('*.pot'))])
print('pages',len(list(check.sources(ROOT))),'locale_records',len(report['records']),'errors',report['errors'],flush=True)
