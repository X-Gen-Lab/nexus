from pathlib import Path
import hashlib,json,sys
script=Path('/tmp/nexus-release-0.1.0-20261015/catalogs/update_catalogs.py').read_text().split('\nrelease_zh=[',1)[0]
exec(compile(script,'catalog-functions','exec'))
BASE=Path('/tmp/nexus-release-0.1.0-20261015/catalogs/refresh-2')
policy='严格 loader 读取唯一人工维护的兼容性 JSON；CMake 派生同值，不另写版本常量'
policy_en='The strict loader reads the sole authored compatibility JSON; CMake derives the same value without another version constant.'
delivery_ids=read_catalog(BASE/'gettext/reference/documentation-delivery.pot')[1]
delivery_old=read_catalog(ROOT/'docs/locale/en/LC_MESSAGES/reference/documentation-delivery.po')[1]
new=[key for key in delivery_ids if key not in delivery_old];assert len(new)==1
delivery_en='The existing strict policy loader reads the version from `dependencies/platform-compatibility.json`, which is the sole authored version authority. CMake calls the same loader to derive the version rather than inferring it from the `project(nexus VERSION ...)` text. The manifest also records the policy digest, interface epoch and schema epochs; inconsistent versions, duplicate JSON keys and invalid constants are rejected. A separate explicit `release_id` identifies the release; `1.0.0-docs-g<commit>` is a format example and does not imply the current platform version. This identity permits only letters, digits, dots, underscores and hyphens, and cannot contain a directory or URL.'
rows=[update('design/documentation-system','en',{policy:policy_en}),update('design/documentation-system','zh_CN',{policy:policy}),update('reference/documentation-delivery','en',{new[0]:delivery_en})]
for row in rows:
    path=ROOT/row['path'];path.write_text(path.read_text().rstrip()+'\n');row['pending_catalog_sha256']=sha(path)
(BASE/'translation-review-inputs.json').write_text(json.dumps({'status':'independent_review_pending','new_firmware_qualification':False,'records':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:v for k,v in row.items() if k in ('path','message_count','preserved_message_count','new_pairs')} for row in rows],ensure_ascii=False,indent=2))
