var searchData=
[
  ['validate_0',['validate',['../structnx__uart__rs485__config__t.html#a73e9b2c6926ed2407c6286871f1aa003',1,'nx_uart_rs485_config_t']]],
  ['value_1',['value',['../structnx__arch__irq__state__t.html#abe25af14a3df558bf7cec5f80726cd06',1,'nx_arch_irq_state_t::value'],['../structnx__usb__setup__t.html#a5cf1fc3d04a16c4fbba7997d682e543b',1,'nx_usb_setup_t::value'],['../structnx__diagnostic__event__t.html#ab93cf0a2596138e1927f69eef0768eb0',1,'nx_diagnostic_event_t::value'],['../structnx__user__io__reply__t.html#af3732bd4a681f69505fb5f565882c48a',1,'nx_user_io_reply_t::value'],['../structnx__amp__word__t.html#a47a7b14335b17050070c9617a6f58cd8',1,'nx_amp_word_t::value']]],
  ['values_2',['values',['../structnx__modbus__rtu__t.html#a495c01f04c1b55ec27e225beaff00c64',1,'nx_modbus_rtu_t']]],
  ['verdict_3',['verdict',['../structnx__io__timestamp__budget__result__t.html#a24a5f5e399287b4a1101e5ea78396e46',1,'nx_io_timestamp_budget_result_t']]],
  ['verify_5fflags_4',['verify_flags',['../structnx__tls__diagnostic__t.html#afba4fa470791e268057361baee43fc3a',1,'nx_tls_diagnostic_t']]],
  ['vlan_5',['vlan',['../structnx__eth__frames__rx__loan__t.html#a22fbbe1023c939002d4a0b8f4deffdd7',1,'nx_eth_frames_rx_loan_t']]]
];
