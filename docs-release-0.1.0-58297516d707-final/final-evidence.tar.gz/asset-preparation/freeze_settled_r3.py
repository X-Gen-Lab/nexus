#!/usr/bin/env python3
"""Freeze only the completed R3 receipt's explicit safe evidence list."""
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/tmp/nexus-release-0.1.0-20261015')
PREP = ROOT / 'asset-preparation'
PREFIX = 'release-monitor/recovery-51bebd47/'
RECEIPT_NAME = PREFIX + '38687802092-completed-runtime-receipt.json'
RECEIPT_SHA256 = '23f1903b96ac0908a56372187c36662d61f10ebe34d2695ef1dc322e07ae37c7'
C = '58297516d707fdee117bd27b5df6af09d72edd2e'
E2 = '51bebd47dd63dce90c7fded1efafef27cd20fd3e'
sha = lambda data: hashlib.sha256(data).hexdigest()

def main():
    receipt_data = (ROOT / RECEIPT_NAME).read_bytes()
    assert sha(receipt_data) == RECEIPT_SHA256
    receipt = json.loads(receipt_data)
    assert receipt['run_id'] == 38687802092
    assert receipt['source_commit'] == C and receipt['builder_commit'] == E2
    assert receipt['run_status'] == 'completed' and receipt['run_conclusion'] == 'success'
    assert {r['name'] for r in receipt['required_jobs']} == {'guard', 'source-sdk', 'publish'}
    assert all(r['status'] == 'completed' and r['conclusion'] == 'success' for r in receipt['required_jobs'])
    assert set(receipt['intentional_skips']) == {'platform', 'contracts'}
    assert receipt['base_asset_count'] == 13 and receipt['base_asset_bytes'] == 155701930
    assert receipt['release']['id'] == 413457393
    assert receipt['release']['draft'] is False and receipt['release']['prerelease'] is True
    assert receipt['release']['target_commitish'] == C
    assert len(receipt['public_asset_metadata']) == 13
    assert sum(row['size'] for row in receipt['public_asset_metadata']) == 155701930
    assert len({row['name'] for row in receipt['public_asset_metadata']}) == 13
    for row in receipt['public_asset_metadata']:
        assert row['state'] == 'uploaded'
        assert row['browser_download_url'] == 'https://github.com/X-Gen-Lab/nexus/releases/download/v0.1.0/' + row['name']
        assert row['digest'].startswith('sha256:') and len(row['digest']) == 71
    spec = importlib.util.spec_from_file_location('scan', PREP / 'prepare_local_evidence.py')
    scan = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scan)
    selected = {RECEIPT_NAME: receipt_data}
    assert len(receipt['evidence']) == 9
    for row in receipt['evidence']:
        path = Path(row['path'])
        name = path.relative_to(ROOT).as_posix()
        assert name.startswith(PREFIX) and name not in selected
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        assert len(data) == row['size'] and sha(data) == row['sha256']
        selected[name] = data
    out = PREP / 'settled-r3'
    payload = out / 'payload'
    payload.mkdir(parents=True, exist_ok=False)
    records = []
    for name, data in sorted(selected.items()):
        scan.reject_transport_secrets(name, data)
        target = payload / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        records.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                        'origin': 'unchanged_original_completed_runtime_record'})
    manifest = {'schema_version': 1, 'kind': 'settled_completed_r3_runtime_preparation',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': C, 'builder_commit': E2, 'run_id': 38687802092,
        'release_id': 413457393, 'members': records, 'member_count': len(records),
        'public_asset_count': 13, 'public_asset_bytes': 155701930,
        'signed_url_and_credential_scan': 'passed',
        'scope': 'Actual R3 guard, SDK, attestation, cryptographic verification and public publication execution metadata/logs; the monitor does not perform independent asset download/cryptography/strict relocated consumers. Final independent SDK restore and final cleanup are outside this subset.',
        'independent_restoration_qualified_by_this_subset': False,
        'physical_hil': 'not_executed'}
    manifest_path = out / 'settled-r3-allowlist.json'
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    archive_path = out / 'settled-r3-evidence.tar.gz'
    with archive_path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for row in records:
                    data = (payload / row['path']).read_bytes()
                    info = tarfile.TarInfo(row['path'])
                    info.size = len(data); info.mode = 0o600; info.mtime = 0
                    info.uid = info.gid = 0
                    archive.addfile(info, io.BytesIO(data))
    result = {'status': 'prepared_runtime_subset_only', 'members': len(records),
        'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size,
        'archive_sha256': sha(archive_path.read_bytes()),
        'manifest_sha256': sha(manifest_path.read_bytes()),
        'assets_source_index_refs_mutated': False,
        'independent_restoration_or_final_cleanup_qualified': False}
    (out / 'preparation-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))

if __name__ == '__main__':
    main()
