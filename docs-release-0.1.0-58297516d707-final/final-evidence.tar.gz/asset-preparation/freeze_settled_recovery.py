#!/usr/bin/env python3
"""Freeze an explicit settled recovery evidence subset; no asset/source mutation."""
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile

ROOT = Path('/tmp/nexus-release-0.1.0-20261015')
PREP = ROOT / 'asset-preparation'
REPO = Path('/workspace/nexus-build-system-20261012')
C = '58297516d707fdee117bd27b5df6af09d72edd2e'
E1 = 'fcaedcabd2e65cd8bf00f426f36250f8654bfbee'
E2 = '51bebd47dd63dce90c7fded1efafef27cd20fd3e'
sha = lambda data: hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def main():
    out = PREP / 'settled-e1-e2'
    payload = out / 'payload'
    payload.mkdir(parents=True, exist_ok=False)
    names = []
    def add(prefix, filenames):
        names.extend(prefix + name for name in filenames)
    add('delivery-recovery-review/', [
        'independent-attach-probes.json', 'independent-source-review.json',
        'independent-transport-probes.json', 'independent_attach_probes.py',
        'independent_transport_probes.py', 'release-reviewed-snapshot.yml',
        'release-tests.log', 'reviewed-diff.patch',
        'test-release-reviewed-snapshot.py', 'transport-reviewed-snapshot.py',
        'workflows-independent-final.json', 'workflows-independent-final.log',
        'workflows-independent.json', 'workflows-independent.log'])
    add('delivery-hook-evidence/', [
        'docs-staged.json', 'hook-tdd.json', 'hook-tdd.tar.gz',
        'receipt.json', 'style-gate.json'])
    add('', ['delivery-normal-commit.json', 'delivery-normal-commit.log',
             'delivery-recovery-dispatch.json'])
    add('release-monitor/', [
        'transport-all-current.log', 'transport-green.log',
        'transport-implementation-review.json', 'transport-red.log',
        'transport-style.json', 'transport-tracked-style.json',
        'transport-venv-green.log'])
    add('release-monitor/recovery-fcaedcab/', [
        '38686564636-decoded-attestation.json', '38686564636-jobs.json',
        '38686564636-publisher-skip-triage.json', '38686564636-run.json',
        '38686564636-safe-artifacts.json',
        'actual-attestation/delivery/attestation/bundle.json',
        'actual-attestation/job-identities/source-sdk-attestation/identity.json',
        'actual-attestation/job-identities/source-sdk-attestation/python-version.log',
        'builder-source-binding.json', 'guard-checkout-C.log', 'monitor.py',
        'publisher-cancel-red.log', 'publisher-condition-green.log',
        'publisher-condition-implementation-review.json',
        'publisher-condition-style.json', 'publisher-skip-green.log',
        'publisher-skip-red.log', 'publisher-skip-style.json',
        'source-sdk-checkout-C-and-attestation.log'])
    add('', ['publisher-condition-normal-commit.json',
             'publisher-condition-normal-commit.log',
             'publisher-condition-dispatch.json'])
    add('publisher-condition-hook-evidence/', [
        'hook-tdd.tar.gz', 'hook-tdd.json', 'receipt.json',
        'docs-staged.json', 'style-gate.json'])
    add('release-monitor/recovery-51bebd47/', [
        'independent-publisher-condition-review.json'])
    assert len(names) == 57 and len(set(names)) == 57
    spec = importlib.util.spec_from_file_location('scan', PREP / 'prepare_local_evidence.py')
    scan = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scan)
    records = []
    for name in sorted(names):
        path = ROOT / name
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        scan.reject_transport_secrets(name, data)
        target = payload / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        records.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                        'origin': 'unchanged_original_session_file'})
    review_name = 'release-monitor/recovery-51bebd47/independent-publisher-condition-review.json'
    assert sha((payload / review_name).read_bytes()) == '5e2dce1d73afa9217ea0e60265d6523b70b390286e356b6632cc6ddafdf3c815'
    bound = []
    for stage, commit, review_path in (
            ('E1', E1, 'delivery-recovery-review/independent-source-review.json'),
            ('E2', E2, review_name)):
        review = json.loads((payload / review_path).read_bytes())
        for row in review['reviewed_files']:
            data = git('show', commit + ':' + row['path'])
            assert len(data) == row.get('bytes', row.get('size'))
            assert sha(data) == row['sha256']
            bound.append({'stage': stage, 'commit': commit,
                          'path': row['path'], 'bytes': len(data),
                          'sha256': sha(data), 'matches_independent_review': True})
            if stage == 'E2' and row['path'] != 'tools/release/transport.py':
                name = 'source-snapshots/E2/' + row['path']
                target = payload / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
                records.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                                'origin': 'immutable_committed_git_blob_at_' + commit})
    for label, start, end in (('E1', C, E1), ('E2', E1, E2)):
        data = git('diff', '--binary', start, end, '--',
                   '.github/workflows/release.yml',
                   '.github/workflows/test_release.py', 'tools/release/transport.py')
        name = 'source-snapshots/' + label + '-committed-changes.patch'
        (payload / name).write_bytes(data)
        records.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                        'origin': 'new_derivative_git_diff_' + start + '_to_' + end})
    hook_observations = []
    for prefix, expected_count in (('delivery-hook-evidence', 14293),
                                   ('publisher-condition-hook-evidence', 15733)):
        receipt = json.loads((payload / prefix / 'receipt.json').read_bytes())
        archive_path = payload / prefix / 'hook-tdd.tar.gz'
        data = archive_path.read_bytes()
        assert len(data) == receipt['archive_bytes'] and sha(data) == receipt['archive_sha256']
        count = 0
        with tarfile.open(archive_path, 'r:gz') as archive:
            for member in archive:
                count += 1
                relative = PurePosixPath(member.name)
                assert not relative.is_absolute() and '..' not in relative.parts
                assert member.isfile() or member.isdir()
                if member.isfile():
                    assert len(archive.extractfile(member).read()) == member.size
        assert count == expected_count == receipt['archive_members']
        hook_observations.append({'path': prefix + '/hook-tdd.tar.gz',
                                  'bytes': len(data), 'sha256': sha(data),
                                  'raw_members_read': count,
                                  'google_cases': receipt['google_cases'],
                                  'committed_builder': receipt['committed_builder']})
    binding = {'kind': 'settled_recovery_committed_source_binding',
        'source_commit_C': C, 'builder_E1': E1, 'builder_E2': E2,
        'builder_E2_tree': git('rev-parse', E2 + '^{tree}').decode().strip(),
        'review_bound_git_blobs': bound, 'normal_hook_archives_read': hook_observations,
        'original_empty_review_diff_preserved': {
            'path': 'delivery-recovery-review/reviewed-diff.patch',
            'bytes': 0, 'sha256': sha(b''),
            'explanation': 'Original empty file remains unchanged; newly generated committed diffs are distinct derivative records.'},
        'scope': 'Settled E1/E2 source reviews, actual local normal hooks, and R2 SDK/attestation success with publication skipped. R3 publication, independent SDK restoration and final cleanup are not admitted by this subset.',
        'physical_hil': 'not_executed'}
    data = (json.dumps(binding, indent=2) + '\n').encode()
    name = 'source-snapshots/settled-source-binding.json'
    (payload / name).write_bytes(data)
    records.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                    'origin': 'new_local_read_only_git_and_archive_binding_observation'})
    records.sort(key=lambda row: row['path'])
    assert len(records) == 62
    for row in records:
        data = (payload / row['path']).read_bytes()
        scan.reject_transport_secrets(row['path'], data)
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
    manifest = {'schema_version': 1, 'kind': 'settled_recovery_subset_preparation',
        'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'source_commit': C, 'builder_E1': E1, 'builder_E2': E2,
        'members': records, 'member_count': len(records),
        'signed_url_and_credential_scan': 'passed',
        'source_index_refs_assets_mutated': False,
        'scope': binding['scope'], 'public_release_qualification_by_this_subset': False}
    (out / 'settled-allowlist.json').write_text(json.dumps(manifest, indent=2) + '\n')
    archive_path = out / 'settled-e1-e2-evidence.tar.gz'
    with archive_path.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for row in records:
                    data = (payload / row['path']).read_bytes()
                    info = tarfile.TarInfo(row['path'])
                    info.size = len(data); info.mode = 0o600; info.mtime = 0
                    info.uid = info.gid = 0
                    archive.addfile(info, io.BytesIO(data))
    print(json.dumps({'status': 'prepared_subset_only', 'members': len(records),
        'original_files': 57, 'new_derivative_records': 5,
        'archive': str(archive_path), 'archive_bytes': archive_path.stat().st_size,
        'archive_sha256': sha(archive_path.read_bytes()),
        'normal_hook_members_read': [r['raw_members_read'] for r in hook_observations],
        'assets_mutated': False, 'r3_or_final_cleanup_qualified': False}))

if __name__ == '__main__':
    main()
