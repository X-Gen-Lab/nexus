"""Close superseded PRs and delete only exact, fully contained remote tips."""
import datetime
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/nexus-build-system-20261012')
BASE = Path('/tmp/nexus-release-0.1.0-20261015')
C = '58297516d707fdee117bd27b5df6af09d72edd2e'
E = '51bebd47dd63dce90c7fded1efafef27cd20fd3e'
RUN = 38687802092
PLAN = json.loads((BASE / 'cleanup-plan/fresh-root-cleanup-execution-input.json').read_text())
OUT = BASE / 'cleanup-results/platform-cleanup.json'
RECORD = {'kind': 'platform_superseded_pr_and_exact_lease_cleanup', 'source_commit': C,
          'builder_commit': E, 'release_run_id': RUN, 'status': 'running',
          'pr_actions': [], 'remote_deletions': [], 'local_branch_or_worktree_mutations': False}

def save():
    RECORD['updated_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    OUT.write_text(json.dumps(RECORD, indent=2) + '\n')

def command(args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()

def api(path, payload=None):
    args = ['gh', 'api', 'repos/X-Gen-Lab/nexus/' + path]
    if payload is not None:
        args += ['--method', 'PATCH', '--input', '-']
    return json.loads(subprocess.check_output(args, input=json.dumps(payload) if payload is not None else None, cwd=ROOT, text=True))

def main_guard():
    assert api('git/ref/heads/main')['object']['sha'] == C
    assert api('git/ref/heads/delivery/0.1.0')['object']['sha'] == E
    tag = api('git/ref/tags/v0.1.0')['object']
    assert tag['type'] == 'tag' and tag['sha'] == 'd4e8395310d0fc5fbc84032513c1b4beb03d5fd5'
    assert api('git/tags/' + tag['sha'])['object']['sha'] == C

main_guard()
release = api('releases/tags/v0.1.0')
assert release['id'] == 413457393 and not release['draft'] and release['prerelease']
assert release['target_commitish'] == C and len(release['assets']) == 13
run = api('actions/runs/' + str(RUN))
assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['head_sha'] == E and run['run_attempt'] == 1
jobs = api('actions/runs/' + str(RUN) + '/attempts/1/jobs?per_page=100')['jobs']
for name in ['guard', 'source-sdk', 'publish']:
    selected = [job for job in jobs if job['name'] == name]
    assert len(selected) == 1 and selected[0]['status'] == 'completed' and selected[0]['conclusion'] == 'success'
local_heads = command(['git', 'for-each-ref', '--format=%(refname) %(objectname)', 'refs/heads'])
worktrees = command(['git', 'worktree', 'list', '--porcelain'])
RECORD['publication_gate'] = {'release_id': release['id'], 'draft': release['draft'], 'prerelease': release['prerelease'], 'actual_publisher_success': True}
RECORD['local_heads_before'] = local_heads
RECORD['worktrees_before'] = worktrees
save()
by_pr = {item['pr']: item for item in PLAN['records']}
assert len(by_pr) == 6
for number in PLAN['close_order']:
    item = by_pr[number]
    main_guard()
    observed = api('pulls/' + str(number))
    assert observed['head']['sha'] == item['expected_sha']
    assert observed['head']['ref'] == item['ref'].removeprefix('refs/heads/')
    assert observed['base']['ref'] == item['base_ref']
    subprocess.run(['git', 'merge-base', '--is-ancestor', item['expected_sha'], C], cwd=ROOT, check=True)
    if observed['state'] == 'open':
        updated = api('pulls/' + str(number), {'state': 'closed'})
        assert updated['state'] == 'closed' and updated['head']['sha'] == item['expected_sha']
        action = 'closed_superseded_already_contained_pr'
    else:
        action = 'preserved_existing_closed_or_merged_state'
    RECORD['pr_actions'].append({'number': number, 'head': item['expected_sha'], 'action': action,
                                 'contained_by_merge_pr': 9, 'comments_posted': False})
    save()
for item in PLAN['records']:
    main_guard()
    ref = item['ref']; expected = item['expected_sha']
    assert ref not in PLAN['mandatory_keep_remote_refs']
    assert ref.startswith('refs/heads/codex/')
    observed = api('git/ref/' + ref.removeprefix('refs/'))
    assert observed['object']['sha'] == expected
    observed_pr = api('pulls/' + str(item['pr']))
    assert observed_pr['state'] == 'closed' and observed_pr['head']['sha'] == expected
    subprocess.run(['git', 'merge-base', '--is-ancestor', expected, C], cwd=ROOT, check=True)
    assert command(['git', 'rev-list', '--count', C + '..' + expected]) == '0'
    argv = ['git', 'push', '--force-with-lease=' + ref + ':' + expected, 'origin', ':' + ref]
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True)
    RECORD['remote_deletions'].append({'ref': ref, 'expected_sha': expected, 'ancestor_of_main': True,
        'commits_not_in_main': 0, 'argv': argv, 'exit_code': result.returncode,
        'stdout': result.stdout, 'stderr': result.stderr})
    save()
    assert result.returncode == 0
    assert command(['git', 'ls-remote', '--heads', 'origin', ref]) == ''
main_guard()
kept = {}
for ref in PLAN['mandatory_keep_remote_refs']:
    kept[ref] = api('git/ref/' + ref.removeprefix('refs/'))['object']['sha']
assert command(['git', 'for-each-ref', '--format=%(refname) %(objectname)', 'refs/heads']) == local_heads
assert command(['git', 'worktree', 'list', '--porcelain']) == worktrees
RECORD.update(status='passed', mandatory_keep_remote_refs=kept, local_heads_unchanged=True,
              local_worktree_registrations_unchanged=True, preserved_merged_prs=[3, 4, 9])
save()
print(json.dumps({'status': RECORD['status'], 'closed': len(RECORD['pr_actions']), 'remote_deletions': len(RECORD['remote_deletions']), 'receipt': str(OUT)}))
