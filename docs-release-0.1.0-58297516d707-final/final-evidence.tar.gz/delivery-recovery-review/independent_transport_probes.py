"""Independent hostile transport fixtures; never run or extract archived files."""
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile

BASE = Path(__file__).resolve().parent
ROOT = Path('/workspace/nexus-build-system-20261012')
C = '58297516d707fdee117bd27b5df6af09d72edd2e'
spec = importlib.util.spec_from_file_location('reviewed_transport', BASE / 'transport-reviewed-snapshot.py')
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)
spec = importlib.util.spec_from_file_location('nexus_consumer_fixture', ROOT / 'cmake/package/verify_consumers.py')
consumers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(consumers)
RESULTS = []

def fixture(base):
    raw = base / 'raw consumer files'
    raw.mkdir()
    (raw / transport.RAW_OWNER).write_text('owned SDK consumer verification\n')
    for kind in sorted(transport.FIXTURES):
        label = kind.removesuffix(' source/.git')
        consumers.prepare_consumer(base / 'prefix', raw, label,
            lambda cmd: subprocess.run(cmd, check=True, capture_output=True),
            version='0.1.0')
    (raw / 'command-00.log').write_bytes(b'fixture git init only\n')
    (raw / 'executable').write_bytes(b'preserved executable bytes\x00\xff\n')
    (raw / 'executable').chmod(0o755)
    (raw / 'empty file').touch()
    (raw / 'empty directory').mkdir()
    (raw / 'verification.json').write_text(json.dumps({
        'kind': 'source_sdk_consumer_verification', 'status': 'passed',
        'source_revision': C, 'physical_status': 'not_executed',
        'commands': [{'argv': ['git', 'init'], 'exit_code': 0,
                      'log': 'command-00.log'}]}))
    (raw / 'verification.json').chmod(0o600)
    return raw

def reject(label, change, phase='pack'):
    with tempfile.TemporaryDirectory(prefix='probe-', dir=BASE) as directory:
        base = Path(directory)
        raw = fixture(base)
        output = base / 'transport'
        if phase == 'verify':
            transport.pack(raw, output, C)
        change(base, raw, output)
        try:
            if phase == 'verify':
                transport.verify(output, C)
            else:
                transport.pack(raw, output, C)
        except (ValueError, OSError, tarfile.TarError, KeyError, TypeError) as error:
            RESULTS.append({'case': label, 'outcome': 'rejected',
                            'error_type': type(error).__name__, 'reason': str(error)})
        else:
            raise AssertionError('Hostile fixture accepted: ' + label)

def rewritten_archive(output, alter):
    archive = output / transport.ARCHIVE
    with tarfile.open(archive) as stream:
        entries = [(copy.copy(member), stream.extractfile(member).read()
                    if member.isfile() else None) for member in stream]
    entries = alter(entries)
    with tarfile.open(archive, 'w:gz') as stream:
        for member, data in entries:
            stream.addfile(member, io.BytesIO(data) if data is not None else None)
    manifest = json.loads((output / transport.MANIFEST).read_text())
    manifest['archive'] = transport.byte_identity(archive)
    (output / transport.MANIFEST).write_text(json.dumps(manifest))

with tempfile.TemporaryDirectory(prefix='positive-', dir=BASE) as directory:
    base = Path(directory)
    raw = fixture(base)
    files, dirs = transport.scan(raw)
    output = base / 'transport'
    manifest = transport.pack(raw, output, C)
    with tarfile.open(output / transport.ARCHIVE) as stream:
        observed = {member.name: (member.mode, stream.extractfile(member).read())
                    for member in stream if member.isfile()}
    expected = {key: (value['mode'], (raw / key).read_bytes())
                for key, value in files.items()}
    assert observed == expected
    assert manifest['directories'] == dirs
    for file in output.iterdir():
        file.chmod(0o644)
    assert transport.verify(output, C) == manifest
    RESULTS.append({'case': 'all raw files, empty files, executable modes and directories',
                    'outcome': 'preserved', 'files': len(files), 'directories': len(dirs),
                    'git_fixtures': len(list(raw.rglob('.git'))),
                    'transport_mode_reset': 'verified'})

reject('raw symlink file', lambda b,r,o: (r/'link').symlink_to(r/'verification.json'))
reject('raw symlink directory', lambda b,r,o: (r/'dirlink').symlink_to(r/'native source', target_is_directory=True))
reject('raw hardlink', lambda b,r,o: os.link(r/'verification.json', r/'hardlink'))
reject('raw FIFO', lambda b,r,o: os.mkfifo(r/'fifo'))
reject('unowned raw', lambda b,r,o: (r/transport.RAW_OWNER).unlink())
reject('occupied output', lambda b,r,o: o.mkdir())
for filename, data in [('credentials', b'secret-placeholder'),
                       ('config', b'[remote "origin"]\nurl=secret-placeholder\n'),
                       ('index', b'index'), ('hooks/pre-commit', b'active hook'),
                       ('objects/ab/hash', b'committed history')]:
    def mutate(base, raw, output, filename=filename, data=data):
        selected = raw / 'native source/.git' / filename
        selected.parent.mkdir(parents=True, exist_ok=True)
        selected.write_bytes(data)
    reject('nonempty Git metadata: ' + filename, mutate)

reject('changed outer report', lambda b,r,o: (o/'verification.json').write_text('{}'), 'verify')
reject('unbound archive corruption', lambda b,r,o: (o/transport.ARCHIVE).write_bytes(b'corrupt'), 'verify')

def append_entry(entries, member, data=None):
    return entries + [(member, data)]

def archive_probe(label, alter):
    reject(label, lambda b,r,o: rewritten_archive(o, alter), 'verify')

archive_probe('rebound path traversal', lambda entries: append_entry(entries, tarfile.TarInfo('../escape')))
archive_probe('rebound duplicate existing member', lambda entries: entries + [entries[0]])
def linked(entries):
    member = tarfile.TarInfo('extra-link')
    member.type, member.linkname = tarfile.SYMTYPE, '/tmp/escape'
    return append_entry(entries, member)
archive_probe('rebound archive symlink', linked)
archive_probe('rebound omitted original file', lambda entries: [item for item in entries if item[0].name != 'executable'])
def changed_mode(entries):
    for member, data in entries:
        if member.name == 'executable': member.mode = 0o644
    return entries
archive_probe('rebound executable mode loss', changed_mode)
def changed_bytes(entries):
    return [(member, b'x' * len(data) if member.name == 'executable' else data)
            for member, data in entries]
archive_probe('rebound same-size byte corruption', changed_bytes)

record = {'kind': 'independent_delivery_recovery_transport_probes',
          'source_commit': C, 'status': 'passed',
          'transport_snapshot_sha256': hashlib.sha256((BASE/'transport-reviewed-snapshot.py').read_bytes()).hexdigest(),
          'cases': RESULTS,
          'scope': 'Hostile local transport fixtures; no hosted execution, attestation or hardware qualification claimed.'}
(BASE/'independent-transport-probes.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({'status': 'passed', 'cases': len(RESULTS), 'snapshot_sha256': record['transport_snapshot_sha256']}))
