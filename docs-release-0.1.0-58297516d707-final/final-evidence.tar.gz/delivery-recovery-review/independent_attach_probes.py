"""Exercise release receipt admission without any GitHub or source writes."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('probes', BASE/'independent_transport_probes.py')
probes = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probes)
transport, C = probes.transport, probes.C
RESULTS = []

def fixture(base):
    raw = probes.fixture(base)
    inputs = base/'inputs'
    transport.pack(raw, inputs/'sdk/delivery/sdk-consumers', C)
    output = base/'assets'
    output.mkdir()
    asset = output/'source-sdk-identity.json'
    asset.write_bytes(b'original source C identity bytes\n')
    manifest = {'source_commit': C, 'tag': 'v0.1.0', 'source_sdk_run_id': 321,
        'assets': [{'name': asset.name, 'size': asset.stat().st_size,
                    'sha256': hashlib.sha256(asset.read_bytes()).hexdigest()}]}
    (output/'release-manifest.json').write_text(json.dumps(manifest))
    args = {'output': output, 'inputs': inputs, 'source_commit': C,
        'builder_commit': 'b'*40,
        'workflow_ref': 'X-Gen-Lab/nexus/.github/workflows/release.yml@refs/heads/delivery/0.1.0',
        'run_id': 321, 'attempt': 1}
    return args, manifest

for label in ('positive', 'source mismatch', 'builder malformed', 'unauthorized branch',
              'run mismatch', 'attempt zero', 'extra asset', 'altered original asset',
              'duplicate original asset name', 'asset path traversal', 'wrong tag'):
    with tempfile.TemporaryDirectory(prefix='attach-', dir=BASE) as directory:
        args, manifest = fixture(Path(directory))
        output = args['output']
        original = (output/'source-sdk-identity.json').read_bytes()
        if label == 'source mismatch': args['source_commit'] = 'a'*40
        elif label == 'builder malformed': args['builder_commit'] = 'branch-name'
        elif label == 'unauthorized branch': args['workflow_ref'] = args['workflow_ref'].replace('delivery/0.1.0', 'unreviewed')
        elif label == 'run mismatch': args['run_id'] = 999
        elif label == 'attempt zero': args['attempt'] = 0
        elif label == 'extra asset': (output/'unknown').write_bytes(b'unknown')
        elif label == 'altered original asset': (output/'source-sdk-identity.json').write_bytes(b'changed')
        elif label == 'duplicate original asset name': manifest['assets'].append(manifest['assets'][0])
        elif label == 'asset path traversal': manifest['assets'][0]['name'] = '../escape'
        elif label == 'wrong tag': manifest['tag'] = 'v0.2.0'
        (output/'release-manifest.json').write_text(json.dumps(manifest))
        try:
            transport.attach(**args)
        except (ValueError, OSError, TypeError, KeyError) as error:
            if label == 'positive': raise
            RESULTS.append({'case': label, 'outcome': 'rejected',
                            'reason': str(error), 'error_type': type(error).__name__})
        else:
            assert label == 'positive', label
            assert (output/'source-sdk-identity.json').read_bytes() == original
            extended = json.loads((output/'release-manifest.json').read_text())
            receipt = json.loads((output/'delivery-workflow.json').read_text())
            assert receipt['source_commit'] == C
            assert receipt['builder_commit'] == 'b'*40
            assert receipt['original_failed_run_id'] == 38684283007
            assert {entry['name'] for entry in extended['assets']} == {'delivery-workflow.json', 'source-sdk-identity.json'}
            for entry in extended['assets']:
                assert entry['sha256'] == hashlib.sha256((output/entry['name']).read_bytes()).hexdigest()
            RESULTS.append({'case': label, 'outcome': 'admitted',
                            'original_asset_bytes': 'unchanged', 'complete_asset_closure': 'verified'})

record = {'kind': 'independent_delivery_recovery_attach_probes', 'status': 'passed',
          'source_commit': C, 'cases': RESULTS,
          'transport_snapshot_sha256': hashlib.sha256((BASE/'transport-reviewed-snapshot.py').read_bytes()).hexdigest(),
          'scope': 'Local manifest and receipt behavior only; no hosted attestation or publication asserted.'}
(BASE/'independent-attach-probes.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({'status': 'passed', 'attach_cases': len(RESULTS)}))
