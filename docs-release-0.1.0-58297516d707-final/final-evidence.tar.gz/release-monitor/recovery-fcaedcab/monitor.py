import datetime,json,subprocess,time
from pathlib import Path
base=Path(__file__).parent
repo='X-Gen-Lab/nexus';run=38686564636
previous=None
for poll in range(80):
 records={}
 for suffix,endpoint in [('run',f'repos/{repo}/actions/runs/{run}'),('jobs',f'repos/{repo}/actions/runs/{run}/jobs?per_page=100')]:
  result=subprocess.run(['gh','api',endpoint],capture_output=True,text=True,timeout=45)
  if result.returncode:
   print(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'query_failure':suffix,'exit_code':result.returncode}),flush=True)
   continue
  data=json.loads(result.stdout);records[suffix]=data
  (base/f'{run}-{suffix}.json').write_text(json.dumps(data,indent=2)+'\n')
 if len(records)==2:
  status={'run_status':records['run']['status'],'run_conclusion':records['run']['conclusion'],'jobs':[]}
  for job in records['jobs']['jobs']:
   status['jobs'].append({'id':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion'],'steps':[{'name':step['name'],'status':step['status'],'conclusion':step['conclusion']} for step in job.get('steps',[])]})
  if status!=previous:
   print(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**status}),flush=True)
   previous=status
  if records['run']['status']=='completed':break
 time.sleep(30)
