#include "/workspace/nexus/tests/contracts/legacy_devices_model.h"
