"""Snapshot recipes declare versions without inheriting artifact qualification."""

import json
from pathlib import Path
import re
import tempfile
import unittest

from tools.evidence import recipe
from tools.evidence.common import EvidenceError


class BuildRecipeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.requirements = self.root / "requirements.txt"
        self.requirements.write_text("fixture==1.0 --hash=sha256:" + "a" * 64 + "\n")
        self.observed = {"suite": "trixie", "image_config_id": "sha256:" + "b" * 64,
                         "apt_packages": {name: "1.0-1" for name in recipe.APT_PACKAGES}}

    def tearDown(self):
        self.temporary.cleanup()

    def emitted_recipe(self):
        lock = recipe.create(self.observed, "python:3.12-slim@sha256:" + "c" * 64,
                             "20261012T000000Z", self.requirements)
        return recipe.emit(lock, "dependencies/requirements.txt")

    def test_all_networked_layers_mount_required_proxy_ca(self):
        instructions = re.sub(r"\\\n\s*", " ", self.emitted_recipe()).splitlines()
        networked = [line for line in instructions if line.startswith("RUN ")
                     and ("apt-get" in line or "python -m pip" in line)]
        self.assertEqual(len(networked), 2)
        for line in networked:
            with self.subTest(instruction=line.split(" && ")[0]):
                self.assertIn("--mount=type=secret,id=proxy_ca,required=true",
                              line)

    def test_apt_update_and_install_select_mounted_https_ca(self):
        text = re.sub(r"\\\n\s*", " ", self.emitted_recipe())
        commands = re.findall(r"apt-get\s+[^&\n]+", text)
        self.assertEqual(len(commands), 2)
        for command in commands:
            with self.subTest(command=command):
                self.assertIn(
                    "-o Acquire::https::CaInfo=/run/secrets/proxy_ca", command)

    def test_public_ca_mount_is_readable_by_sandboxed_network_clients(self):
        text = re.sub(r"\\\n\s*", " ", self.emitted_recipe())
        networked = [line for line in text.splitlines()
                     if line.startswith("RUN ")
                     and ("apt-get" in line or "python -m pip" in line)]
        self.assertEqual(len(networked), 2)
        for instruction in networked:
            client = "apt" if "apt-get" in instruction else "pip"
            with self.subTest(client=client):
                mounts = re.findall(r"--mount=([^ ]+)", instruction)
                self.assertEqual(len(mounts), 1)
                options = dict(item.split("=", 1)
                               for item in mounts[0].split(","))
                self.assertEqual(options["type"], "secret")
                self.assertEqual(options["id"], "proxy_ca")
                self.assertEqual(options["required"], "true")
                # BuildKit defaults secrets to 0400; APT drops to the _apt UID.
                mode = int(options.get("mode", "0400"), 8)
                self.assertEqual(mode, 0o444,
                                 "Public CA must be read-only for every UID")

    def test_checked_in_dockerfile_matches_verified_declared_recipe(self):
        root = Path(__file__).resolve().parents[2]
        lock_path = root / "dependencies/build-recipe.lock.json"
        lock = json.loads(lock_path.read_text())
        requirements = "dependencies/python-tools-linux-cp312.txt"
        recipe.verify(lock, root / requirements)
        generated = recipe.emit(lock, requirements)
        self.assertEqual((root / "tools/dev/Dockerfile").read_text(), generated)

    def test_recipe_output_cannot_replace_requirements_input(self):
        observed = self.root / "observed.json"
        observed.write_text(json.dumps(self.observed))
        original = self.requirements.read_bytes()
        result = recipe.main(["create", "--observed", str(observed),
                              "--base-image", "python:3.12-slim@sha256:" + "c" * 64,
                              "--snapshot", "20261012T000000Z",
                              "--requirements", str(self.requirements),
                              "--lock", str(self.requirements)])
        self.assertEqual(result, 1)
        self.assertEqual(self.requirements.read_bytes(), original)

    def test_fixed_snapshot_exact_versions_and_hash_lock_are_consumed(self):
        lock = recipe.create(self.observed, "python:3.12-slim@sha256:" + "c" * 64,
                             "20261012T000000Z", self.requirements)
        text = recipe.emit(lock, "dependencies/requirements.txt")
        self.assertIn("https://snapshot.debian.org/archive/debian/20261012T000000Z", text)
        self.assertIn("gcc=1.0-1", text)
        self.assertIn("--require-hashes", text)
        self.assertFalse(lock["recipe_reproducible"])
        recipe.verify(lock, self.requirements)

    def test_reject_unpinned_base_snapshot_packages_and_changed_hash_file(self):
        with self.assertRaises(EvidenceError):
            recipe.create(self.observed, "python:3.12-slim", "latest", self.requirements)
        observed = dict(self.observed, apt_packages={"gcc": "latest"})
        with self.assertRaises(EvidenceError):
            recipe.create(observed, "python:3.12-slim@sha256:" + "c" * 64,
                          "20261012T000000Z", self.requirements)
        lock = recipe.create(self.observed, "python:3.12-slim@sha256:" + "c" * 64,
                             "20261012T000000Z", self.requirements)
        self.requirements.write_text("changed")
        with self.assertRaises(EvidenceError):
            recipe.verify(lock, self.requirements)

    def test_unknown_fields_and_false_reproduction_claim_rejected(self):
        lock = recipe.create(self.observed, "python:3.12-slim@sha256:" + "c" * 64,
                             "20261012T000000Z", self.requirements)
        with self.assertRaises(EvidenceError):
            recipe.validate(dict(lock, hidden="extra"))
        with self.assertRaises(EvidenceError):
            recipe.validate(dict(lock, recipe_reproducible=True))


if __name__ == "__main__":
    unittest.main()
