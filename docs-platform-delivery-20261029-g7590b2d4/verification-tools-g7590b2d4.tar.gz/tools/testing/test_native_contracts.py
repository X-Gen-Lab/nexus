"""Keep the Native CI executable boundary on actual unaliased build bytes."""

import json
from pathlib import Path
import tempfile
import unittest

from scripts.ci import native_contracts
from scripts.ci import test_native_contracts as fixtures


class NativeBinaryBoundaryTests(unittest.TestCase):
    def setUp(self):
        directory = tempfile.TemporaryDirectory(prefix="native binary boundary ")
        self.addCleanup(directory.cleanup)
        self.root = Path(directory.name)
        self.build = self.root / "build"
        self.build.mkdir()
        self.first = self.build / "first"
        self.second = self.build / "second"
        self.first.write_bytes(b"first executable fixture\n")
        self.second.write_bytes(b"second executable fixture\n")

    def plan(self, paths):
        (self.build / "google-contracts.json").write_text(json.dumps({
            "schema": 1, "executables": [str(path) for path in paths],
        }) + "\n")

    def rejected(self, paths):
        self.plan(paths)
        with self.assertRaises(ValueError):
            native_contracts.google_binaries(self.build)

    def test_regular_binary_order_is_preserved(self):
        self.plan([self.second, self.first])
        self.assertEqual(native_contracts.google_binaries(self.build),
                         [self.second, self.first])

    def test_file_symlink_to_real_binary_inside_build_is_rejected(self):
        alias = self.build / "alias"
        alias.symlink_to(self.first)
        self.rejected([alias, self.second])

    def test_directory_symlink_to_real_directory_inside_build_is_rejected(self):
        directory = self.build / "real"
        directory.mkdir()
        binary = directory / "third"
        binary.write_bytes(b"real nested fixture\n")
        alias = self.build / "alias"
        alias.symlink_to(directory, target_is_directory=True)
        self.rejected([alias / "third", self.second])

    def test_regular_binary_outside_build_is_rejected(self):
        outside = self.root / "outside"
        outside.write_bytes(b"outside fixture\n")
        self.rejected([outside, self.second])

    def test_parent_component_escape_is_rejected(self):
        outside = self.root / "outside"
        outside.write_bytes(b"outside fixture\n")
        self.rejected([self.build / ".." / "outside", self.second])

    def test_missing_binary_is_rejected(self):
        self.rejected([self.build / "missing", self.second])

    def test_nonregular_directory_is_rejected(self):
        directory = self.build / "directory"
        directory.mkdir()
        self.rejected([directory, self.second])

    def test_distinct_binaries_with_ambiguous_report_names_are_rejected(self):
        directory = self.build / "nested"
        directory.mkdir()
        duplicate = directory / self.first.name
        duplicate.write_bytes(b"different real fixture\n")
        self.rejected([self.first, duplicate])

    def test_malformed_empty_or_repeated_manifest_is_rejected(self):
        for document in (
            {"schema": 2, "executables": [str(self.first)]},
            {"schema": 1, "executables": []},
            {"schema": 1, "executables": None},
            {"schema": 1, "executables": [str(self.first), 7]},
            {"schema": 1, "executables": [str(self.first), str(self.first)]},
        ):
            with self.subTest(document=document):
                (self.build / "google-contracts.json").write_text(
                    json.dumps(document) + "\n")
                with self.assertRaises(ValueError):
                    native_contracts.google_binaries(self.build)


class NativeAliasedExecutionTests(unittest.TestCase):
    def setUp(self):
        # Reuse only the disposable external CTest/Google fixture. The actual
        # Native CI admission, discovery and execution remain unmocked.
        self.fixture = fixtures.NativeExecutionTests(
            methodName="test_all_ctest_and_google_cases_execute_once_with_clean_settings")
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)

    def reject_before_discovery(self, alias):
        (self.fixture.build / "google-contracts.json").write_text(json.dumps({
            "schema": 1,
            "executables": [str(alias), str(self.fixture.binaries[1])],
        }) + "\n")
        result, output = self.fixture.execute()
        self.assertEqual(result, 1, output)
        self.assertFalse(self.fixture.summary.exists(), output)
        self.assertFalse((self.fixture.output / "ctest-plan.txt").exists(), output)
        for binary in self.fixture.binaries:
            self.assertFalse(binary.with_suffix(".count").exists(), output)

    def test_file_alias_cannot_execute_or_publish_native_success(self):
        alias = self.fixture.build / "alias-first"
        alias.symlink_to(self.fixture.binaries[0])
        self.reject_before_discovery(alias)

    def test_parent_alias_cannot_execute_or_publish_native_success(self):
        alias = self.fixture.build / "alias-parent"
        alias.symlink_to(self.fixture.build, target_is_directory=True)
        self.reject_before_discovery(alias / self.fixture.binaries[0].name)


if __name__ == "__main__":
    unittest.main()
