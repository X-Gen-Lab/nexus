"""Fixed G474 capability, route and cold emitter boundary contracts."""
import importlib
from dataclasses import replace
import json
from pathlib import Path
import unittest

from tools.configure import bindings, configure
from tools.configure.ir import ControllerIR
from tools.configure.providers.common import ConfigurationError
from tools.configure.selection import validate_clock_profiles


ROOT = Path(__file__).resolve().parents[5]


def uart(**changes):
    values = {"id": "console", "binding": "uart1", "kind": "uart",
              "controller": "LPUART1", "mode": "irq-bytes", "baud": 115200,
              "rx_profile": "bytes", "rx_capacity": 64, "irq_priority": 5,
              "calls_os": False, "pins": [
                  {"pin": "PA2", "function": "tx", "af": 12},
                  {"pin": "PA3", "function": "rx", "af": 12}]}
    return {**values, **changes}


def gpio(**changes):
    return {**{"id": "led", "binding": "led0", "kind": "gpio",
              "controller": "GPIOA", "mode": "output", "mask": 32,
              "initial": 0, "pins": [
                  {"pin": "PA5", "function": "output", "af": 0}]},
            **changes}


def fixture_controller(values, provider="stm32g474"):
    """Provide explicit resolved route facts for isolated constructor tests."""
    return ControllerIR.create({"route": "fixture-route", "mask": 0,
                                "initial": 0, **values}, provider)


def Result(*items, backend="baremetal"):
    """Use actual resolved profile facts with isolated constructor selections."""
    profile = ("mainstream-freertos.toml" if backend == "freertos"
               else "empty.toml")
    result = configure.resolve_ir(ROOT / "tests/contracts/g474_assembly" /
                                  profile)
    return replace(result, controllers=tuple(
        fixture_controller(item) for item in items))


class G474ProviderTests(unittest.TestCase):
    def setUp(self):
        self.provider = importlib.import_module("soc.stm32.stm32g474.configure")

    def test_cpu_contract_matches_official_irq_extent(self):
        self.assertEqual(self.provider.PREFIX, "stm32g474")
        self.assertEqual(self.provider.CPU_ABI,
                         {"arch": "cortex-m4", "fpu": "fpv4-sp-d16",
                          "float_abi": "hard"})
        self.assertEqual(self.provider.EXTERNAL_IRQ_COUNT, 102)
        self.assertEqual(self.provider.IRQ_PRIORITY_BITS, 4)
        self.assertEqual(self.provider.FREERTOS_PORT, "GCC/ARM_CM4F")
        self.assertTrue(self.provider.CPU_FEATURES["dsp"])

    def test_cpu_and_clock_capabilities_are_immutable(self):
        with self.assertRaises(TypeError):
            self.provider.CPU_ABI["arch"] = "cortex-m0"
        with self.assertRaises(TypeError):
            self.provider.CLOCK_PROFILES["hse24-pll170"]["core_hz"] = 168000000

    def test_uart_gpio_and_exact_exti_are_the_maintained_mode_set(self):
        for kind, mode in (("gpio", "input"), ("gpio", "output"),
                           ("uart", "irq-bytes"), ("exti", "edge-event")):
            self.assertEqual(self.provider.mode_implementation(kind, mode), kind)
        for kind, mode in (("uart", "irq-byte-event"), ("uart", "irq-blocks"),
                           ("uart", "dma-tx"), ("spi", "dma"),
                           ("flash", "poll-byte"), ("can", "classic-irq")):
            with self.subTest(kind=kind, mode=mode):
                with self.assertRaises(ConfigurationError):
                    self.provider.mode_implementation(kind, mode)

    def test_baud_is_checked_against_actual_presc16_divisor(self):
        for value in (2594, 9600, 115200, 1000000):
            self.provider.validate_selection(uart(baud=value), uart())
        for value in (True, 0, 2593, 1000001):
            with self.subTest(baud=value):
                with self.assertRaises(ConfigurationError):
                    self.provider.validate_selection(uart(baud=value), uart())

    def test_nonbyte_profile_and_unimplemented_priority_are_rejected(self):
        for changes in ({"rx_profile": "events"}, {"rx_profile": "blocks"},
                        {"irq_priority": 4}, {"irq_priority": True}):
            with self.subTest(changes=changes):
                with self.assertRaises(ConfigurationError):
                    self.provider.validate_selection(uart(**changes), uart())

    def test_only_actual_lpuart1_and_fixed_af12_route_are_accepted(self):
        for route in (uart(controller="USART2"), uart(pins=[
                {"pin": "PA2", "function": "tx", "af": 7},
                {"pin": "PA3", "function": "rx", "af": 7}])):
            with self.assertRaises(ConfigurationError):
                self.provider.validate_selection(uart(), route)

    def test_only_gpioa_and_exact_authorized_mask_are_accepted(self):
        self.provider.validate_selection(gpio(), gpio())
        for changes in ({"controller": "GPIOB"}, {"mask": 64},
                        {"initial": 64}, {"mask": True}):
            with self.subTest(changes=changes):
                with self.assertRaises(ConfigurationError):
                    self.provider.validate_selection(gpio(**changes),
                                                     gpio(**changes))

    def test_only_exact_adc_dma_resource_and_route_are_maintained(self):
        for call in (lambda: self.provider.validate_dma_resource(
                "dma:DMA1:stream0:channel0"),
                     lambda: self.provider.dma_irq("DMA1:stream0:channel0"),
                     lambda: self.provider.validate_dma(
                         uart(), "irq-bytes", lambda item: item)):
            with self.assertRaises(ConfigurationError):
                call()
        self.assertEqual(self.provider.validate_dma_resource(
            "dma:DMA1:stream1:channel5"), (1, 1, 5))
        self.assertEqual(self.provider.dma_irq("DMA1:stream1:channel5"),
                         "irq:DMA1_Channel1")
        self.assertFalse(self.provider.shares_irq("uart", "irq:LPUART1"))

    def test_clock_metadata_cannot_drift_from_fixed_implementation(self):
        facts = json.loads((ROOT / "soc/stm32/stm32g474/soc.json").read_text())
        validate_clock_profiles(facts, self.provider)
        facts["clock_profiles"]["hse24-pll170"]["apb1_hz"] = 85000000
        with self.assertRaises(ConfigurationError):
            validate_clock_profiles(facts, self.provider)

    def test_memory_domains_count_once_and_exclude_ccm_from_dma(self):
        facts = json.loads((ROOT / "soc/stm32/stm32g474/soc.json").read_text())
        variant = facts["variants"]["STM32G474RET6"]
        self.assertEqual(sum(item["size"] for item in variant["memory"]),
                         128 * 1024)
        self.assertEqual(variant["memory"], [
            {"id": "sram1-sram2", "origin": 0x20000000, "size": 98304,
             "dma": True, "linker": True},
            {"id": "ccm-sram", "origin": 0x10000000, "size": 32768,
             "dma": False, "linker": False}])
        self.assertEqual(variant["flash"]["erase_blocks"], [2048] * 256)
        self.assertEqual(facts["reserved_resources"],
                         ["timer:TIM2", "irq:TIM2_IRQn",
                          "pin:PF0", "pin:PF1", "pin:PG10"])

    def test_reference_board_is_explicit_about_physical_uncertainty(self):
        board = json.loads((ROOT / "boards/stm32g474re_hse24_reference/"
                            "board.json").read_text())
        self.assertEqual(board["id"], "stm32g474re-hse24-reference")
        self.assertEqual(board["clocks"]["hse_hz"], 24000000)
        self.assertIsNone(board["physical_pcb_revision"])
        self.assertTrue(any("not inspected" in text for text in board["unknowns"]))
        self.assertTrue(any("HIL" in text for text in board["unknowns"]))
        self.assertEqual(board["bindings"][0]["initial"], 0)

    def test_uart_ctor_connects_static_ring_to_concrete_c_admission(self):
        item = fixture_controller(uart())
        construction = self.provider.constructor(item, Result(uart()), {}, {}, ())
        source = "\n".join(construction.definitions)
        self.assertIn("static const nx_stm32g474_uart_config_t", source)
        self.assertIn("LPUART1, s_nx_rx_console, 64u, 115200u, LPUART1_IRQn", source)
        self.assertIn("GPIOA, GPIOA, 2u, 3u, 12u", source)
        self.assertIn("static uint8_t s_nx_rx_console[64];", source)
        self.assertEqual(construction.initialize.render(),
                         "nx_stm32g474_uart_prepare(&s_nx_port_console, &s_nx_config_console)")
        self.assertTrue(construction.retain_on_failed_init)
        self.assertEqual(tuple(call.render() for call in construction.stop),
                         ("nx_uart_port_stop(&s_nx_face_console)",))
        self.assertIn("LPUART1_IRQHandler", source)
        self.assertNotIn("DMA", source)
        # Retained-state, ring and MMIO refusal behavior executes in real
        # G474 provider/factory GoogleTest fixtures, not generated helper text.

    def test_constructor_projection_cannot_bypass_fixed_mode_validation(self):
        for changes in ({"mode": "irq-byte-event"}, {"rx_profile": "events"},
                        {"irq_priority": 0}, {"controller": "USART2"}):
            with self.subTest(changes=changes):
                with self.assertRaises(ConfigurationError):
                    self.provider.constructor(uart(**changes), Result(), {}, {}, ())

    def test_foreign_typed_provider_decision_cannot_be_reinterpreted(self):
        item = fixture_controller(uart(), "stm32f407")
        with self.assertRaisesRegex(ConfigurationError, "provider"):
            self.provider.constructor(item, Result(), {}, {}, ())

    def test_uart_ctor_uses_selected_kernel_policy_without_hidden_os(self):
        for backend, policy, ceiling in (("baremetal", "NONE", 0),
                                          ("freertos", "BASEPRI", 5)):
            result = Result(uart(), backend=backend)
            source = "\n".join(self.provider.constructor(
                result.controllers[0], result, {}, {}, ()).definitions)
            self.assertIn(f"NX_IRQ_KERNEL_{policy}, 102u, 4u, {ceiling}u", source)
            self.assertNotIn("xTaskCreate", source)

    def test_empty_profile_retains_no_io_lease_or_provider_source(self):
        result = configure.resolve_ir(
            ROOT / "tests/contracts/g474_assembly/empty.toml")
        self.assertEqual(self.provider.state_declarations(result), [])
        self.assertEqual(self.provider.start_resources(result), [])
        self.assertEqual(self.provider.shared_irqs(result), [])
        self.assertNotIn("gpioa", "\n".join(self.provider.stop_system(result)))

    def test_static_pin_lease_connects_before_system_and_controller_calls(self):
        result = configure.resolve_ir(ROOT / "tests/contracts/g474_assembly/io.toml")
        source = bindings.emit(result)[1]
        self.assertIn("static uint16_t s_nx_platform_pin_state[3u]", source)
        self.assertIn("static const nx_stm32g474_platform_pin_t", source)
        start = source[source.index("nx_platform_start_result_t nx_platform_start(void)"):]
        self.assertLess(start.index("nx_stm32g474_platform_preflight("),
                        start.index("nx_stm32g474_platform_pins_acquire("))
        self.assertLess(start.index("nx_stm32g474_platform_pins_acquire("),
                        start.index("nx_stm32g474_system_start("))
        self.assertLess(start.index("nx_stm32g474_system_start("),
                        start.index("nx_stm32g474_gpio_prepare("))
        stop = source[source.index("static nx_result_t nx_platform_stop_impl("):]
        self.assertLess(stop.index("nx_stm32g474_platform_pins_release("),
                        stop.index("nx_stm32g474_platform_resources_stop("))
        self.assertNotIn("NX_G474_WRITE(", source)
        # Actual capture, withdrawal/readback, failed restore and retry are
        # exercised by G474PinStateFactory and the other generated factories.

    def test_gpios_and_uart_use_real_readonly_tables_without_forwarders(self):
        for values in (gpio(), uart()):
            item = fixture_controller(values)
            self.assertEqual(self.provider.operations(item),
                             f"nx_stm32g474_{item.kind}_ops")
            self.assertEqual(self.provider.instance_declarations(item, Result()), [])


if __name__ == "__main__":
    unittest.main()
