"""Exact H743 selected peripheral capability regression contracts."""
import unittest
from pathlib import Path
import tempfile
import tomllib

from soc.stm32.stm32h743 import configure as stm32h743
from tools.configure.providers.common import ConfigurationError
from tools.configure.configure import resolve_bindings
from tools.configure import configure


class H743PeripheralCapabilityTests(unittest.TestCase):
    def spi_assembly(self, directory, profile, controller_rate, endpoint_rate):
        root = Path(__file__).resolve().parents[5]
        original = (root / "tests/contracts/h743_assembly/peripherals.toml").read_text()
        self.assertIn('\n[pwm.wave3]', original)
        original = original.split('\n[pwm.wave3]', 1)[0]
        original = original.replace('../../../boards/stm32h743zi_hsi_reference',
                                    str(root / "boards/stm32h743zi_hsi_reference"))
        original = original.replace('hsi64-fixed-cache-off', profile)
        controller, endpoint = original.split('\n[spi_device.device4]\n', 1)
        self.assertEqual(1, controller.count('max_hz = 1000000'))
        self.assertEqual(1, endpoint.count('max_hz = 1000000'))
        controller = controller.replace('max_hz = 1000000',
                                        f'max_hz = {controller_rate}', 1)
        endpoint = endpoint.replace('max_hz = 1000000',
                                    f'max_hz = {endpoint_rate}', 1)
        original = controller + '\n[spi_device.device4]\n' + endpoint
        authored = tomllib.loads(original)
        self.assertEqual(controller_rate, authored['spi']['bus4']['max_hz'])
        self.assertEqual(endpoint_rate,
                         authored['spi_device']['device4']['max_hz'])
        self.assertEqual(profile, authored['clock'])
        source = Path(directory) / "assembly.toml"
        source.write_text(original)
        return source

    def test_spi_unreachable_profile_rates_reject_controller_and_endpoint(self):
        cases = (("hsi64-fixed-cache-off", 250000),
                 ("hsi64-fixed-cache-on", 253906),
                 ("hsi64-pll384-cache-off", 388476))
        for profile, rate in cases:
            for location in ("controller", "endpoint"):
                with self.subTest(profile=profile, rate=rate, location=location), \
                        tempfile.TemporaryDirectory() as directory:
                    controller = rate if location == "controller" else 1000000
                    source = self.spi_assembly(directory, profile, controller, rate)
                    output = Path(directory) / "output"
                    with self.assertRaisesRegex(ConfigurationError, "divider"):
                        configure.configure(source, output)
                    self.assertFalse((output / "bindings.c").exists())

    def test_spi_first_reachable_rates_preserve_nominal_kernel_identity(self):
        cases = (("hsi64-fixed-cache-off", 253907, 64000000),
                 ("hsi64-fixed-cache-on", 254000, 64000000),
                 ("hsi32-fixed-cache-off", 250000, 32000000),
                 ("hsi32-fixed-cache-on", 250000, 32000000),
                 ("hsi64-pll384-cache-off", 388477, 96000000))
        for profile, rate, nominal in cases:
            with self.subTest(profile=profile, rate=rate), \
                    tempfile.TemporaryDirectory() as directory:
                source = self.spi_assembly(directory, profile, rate, rate)
                output = Path(directory) / "output"
                configure.configure(source, output)
                bindings = (output / "bindings.c").read_text()
                self.assertIn(f".clock_hz = {nominal}u", bindings)
                self.assertIn(
                    f"{{ &s_nx_endpoint_device4, &s_nx_cs_device4, "
                    f"GPIOE, 2048u, {rate}u, 0u }}", bindings)
                self.assertIn("nx_stm32h743_spi_prepare(&s_nx_port_bus4, "
                              "&s_nx_config_bus4)", bindings)

    def test_sram1_requires_explicit_budget_and_extends_only_selected_dma(self):
        root = Path(__file__).resolve().parents[5]
        original = (root / "tests/contracts/h743_assembly/rx.toml").read_text()
        original = original.replace('../../../boards/stm32h743_nucleo_zi2',
                                    str(root / "boards/stm32h743_nucleo_zi2"))
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "assembly.toml"
            source.write_text(original + '\n[memory.regions.sram1]\nlimit_bytes=256\n')
            ir = configure.resolve_ir(source)
            domains = {item["id"]: item for item in ir.memory}
            self.assertTrue(domains["sram1"]["linker"])
            self.assertFalse(domains["sram2"]["linker"])
            self.assertFalse(domains["dtcm"]["linker"])
            output = Path(directory) / "generated"
            configure.configure(source, output)
            self.assertIn(".nx_sram1_data", (output / "memory.ld").read_text())
            bindings = (output / "bindings.c").read_text()
            self.assertIn("(uintptr_t)0x30000000u", bindings)

    def test_flash_programming_voltage_is_an_explicit_board_input(self):
        routes = {"internal": {"kind": "flash", "controller": "FLASH",
                               "variants": ["part"], "pins": []}}
        board = {"bindings": [{"id": "flash0", "controller": "FLASH",
                               "route": "internal", "supply_mv": 3300}]}
        self.assertEqual(resolve_bindings(board, routes, "part")["flash0"]
                         ["supply_mv"], 3300)
        for value in (0, 5001, True, "3300"):
            with self.subTest(value=value):
                board["bindings"][0]["supply_mv"] = value
                with self.assertRaises(ConfigurationError):
                    resolve_bindings(board, routes, "part")

    def test_adc_analog_supply_is_explicit_and_separate_from_reference(self):
        root = Path(__file__).resolve().parents[5]
        source = root / "tests/contracts/h743_assembly/peripherals.toml"
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "generated"
            configure.configure(source, output)
            bindings = (output / "bindings.c").read_text()
            self.assertIn(".supply_mv = 3300u", bindings)
            self.assertIn(".receive_reload_one = true", bindings)
            self.assertIn(".ignore_master_berr = true", bindings)
        routes = {"analog": {"kind": "adc", "controller": "ADC1",
                             "variants": ["part"], "pins": []}}
        board = {"bindings": [{"id": "adc1", "controller": "ADC1",
                               "route": "analog", "supply_mv": 3300}]}
        self.assertEqual(resolve_bindings(board, routes, "part")["adc1"]
                         ["supply_mv"], 3300)

    def test_selected_modes_have_concrete_implementations(self):
        for kind, mode in (("spi", "short-poll"), ("pwm", "fixed-pwm"),
                           ("exti", "edge-event"), ("watchdog", "independent")):
            with self.subTest(kind=kind):
                self.assertEqual(stm32h743.mode_implementation(kind, mode), kind)

    def test_unimplemented_modes_are_not_inferred_from_chip_potential(self):
        for kind, mode in (("spi", "dma-linked"), ("pwm", "advanced"),
                           ("exti", "debounce"), ("watchdog", "window")):
            with self.subTest(kind=kind):
                with self.assertRaises(ConfigurationError):
                    stm32h743.mode_implementation(kind, mode)


if __name__ == "__main__":
    unittest.main()
