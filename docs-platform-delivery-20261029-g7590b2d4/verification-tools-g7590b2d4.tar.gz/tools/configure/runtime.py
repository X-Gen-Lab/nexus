#!/usr/bin/env python3
"""Resolve one external CPU runtime assembly without inventing a SoC or board."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import sys
import tomllib
from types import MappingProxyType

# Direct CLI execution binds only this checkout or relocated SDK.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from tools.configure import cpu, kernel, metadata, factory, bundle, dependencies, sdk
from tools.configure.ir import freeze


ROOT = Path(__file__).resolve().parents[2]


class RuntimeError(ValueError):
    """The assembly or output ownership contract was rejected."""


@dataclass(frozen=True)
class RuntimeIR:
    profile: object
    platform_metadata: object
    kernel: object
    backend: str
    optimization: str
    clock_hz: int
    input_sha256: str
    configuration_sha256: str
    inputs: object
    snapshots: object


def _path(path):
    result = Path(os.path.abspath(path))
    if any(part.is_symlink() for part in (result, *result.parents)):
        raise RuntimeError(f"Runtime path must not contain a symlink: {result}")
    return result


def _fields(value, fields, context, optional=()):
    if not isinstance(value, dict):
        raise RuntimeError(f"{context}: object required")
    missing = fields - value.keys()
    unknown = value.keys() - fields - set(optional)
    if missing or unknown:
        raise RuntimeError(f"{context}: missing {sorted(missing)}, unknown {sorted(unknown)}")


def resolve(assembly):
    """Return immutable validated input identities and CPU contracts."""
    try:
        assembly = _path(assembly)
        sdk.verify(ROOT)
        policy_path = _path(ROOT / metadata.POLICY)
        policy_bytes, _ = metadata.snapshot(policy_path)
        platform_metadata = metadata.policy_contract(
            metadata.parse_json(policy_bytes),
            expected_factory_epoch=factory.FACTORY_ABI_EPOCH)
        authored = assembly.read_bytes()
        choices = tomllib.loads(authored.decode("utf-8"))
        _fields(choices, {"schema_version", "cpu_facts", "backend", "optimization"},
                "Runtime assembly", {"os"})
        if type(choices["schema_version"]) is not int or choices["schema_version"] != 1:
            raise RuntimeError("Unsupported runtime assembly schema")
        relative = choices["cpu_facts"]
        if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
            raise RuntimeError("cpu_facts must be a nonempty assembly-relative path")
        facts_path = _path(assembly.parent / relative)
        content = facts_path.read_bytes()
        facts = json.loads(content, object_pairs_hook=cpu.unique_keys)
        _fields(facts, {"schema_version", "cpu", "irq", "clock_hz"}, "CPU package")
        if type(facts["schema_version"]) is not int or facts["schema_version"] != 1:
            raise RuntimeError("Unsupported CPU facts schema")
        hz = facts["clock_hz"]
        if type(hz) is not int or not 1 <= hz <= 0xFFFFFFFF:
            raise RuntimeError("CPU clock_hz must be a positive uint32 fact")
        if choices["backend"] not in {"baremetal", "freertos", "threadx"}:
            raise RuntimeError("Unsupported runtime backend")
        if choices["optimization"] not in {"O0", "Og", "O2", "Os", "O3"}:
            raise RuntimeError("Unsupported runtime optimization")
        profile = cpu.resolve(facts["cpu"], facts["irq"], choices["backend"])
        policy = kernel.resolve(choices.get("os"), profile, hz)
        if policy is not None and getattr(policy, "user_io", "none") != "none":
            raise RuntimeError("GPIO user I/O requires exact platform memory reservations")
        if policy is not None and getattr(policy, "lowpower_port", None) == "timebase":
            raise RuntimeError("CPU-only lowpower runtime requires reviewed SoC timer facts")
        profile = kernel.bind(profile, policy)
        digest = hashlib.sha256()
        for label, data in ((b"assembly", authored), (b"cpu-facts", content),
                            (b"platform-metadata", policy_bytes)):
            digest.update(label + b"\0" + len(data).to_bytes(8, "big") + data)
        inputhash = digest.hexdigest()
        record = {"schema_version": 1, "platform_metadata": platform_metadata,
                  "cpu_profile": profile.to_dict(),
                  "kernel_profile": policy.to_dict() if policy is not None else None,
                  "clock_hz": hz, "optimization": choices["optimization"],
                  "input_sha256": inputhash}
        configuration = hashlib.sha256(json.dumps(
            record, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        return RuntimeIR(profile, freeze(platform_metadata), policy,
                         choices["backend"], choices["optimization"], hz,
                         inputhash, configuration,
                         MappingProxyType({"assembly": str(assembly),
                                           "cpu_facts": str(facts_path),
                                           "platform_metadata": str(policy_path)}),
                         MappingProxyType({str(assembly): authored,
                                           str(facts_path): content,
                                           str(policy_path): policy_bytes}))
    except (OSError, ValueError, TypeError, KeyError) as error:
        if isinstance(error, RuntimeError):
            raise
        raise RuntimeError(str(error)) from error


def configure(assembly, output):
    """Withdraw old output before resolution; preserve unchanged output times."""
    try:
        assembly, output = _path(assembly), _path(output)
        if output == assembly or output in assembly.parents:
            raise RuntimeError("Runtime output must not replace an input or source parent")
        # Check input containment before deleting any old owned bundle. A
        # marker proves output ownership, never permission to erase inputs.
        try:
            authored = tomllib.loads(assembly.read_text(encoding="utf-8"))
            relative = authored.get("cpu_facts")
        except (OSError, ValueError):
            relative = None
        if isinstance(relative, str):
            source = Path(os.path.abspath(assembly.parent / relative)).resolve()
            if output == source or output in source.parents:
                raise RuntimeError("Runtime output must not replace input facts or their parent")
        policy_source = _path(ROOT / metadata.POLICY)
        if output == policy_source or output in policy_source.parents:
            raise RuntimeError("Runtime output must not replace platform metadata")
        inputs = [assembly, ROOT, policy_source]
        if isinstance(relative, str):
            inputs.append(source)
        def fail(message):
            raise RuntimeError(message)
        with bundle.transaction(output, ".nexus-runtime-bundle",
                                inputs=inputs, fail=fail) as temporary:
            code_paths, code_identity = dependencies.snapshot(
                mode="runtime", sdk=sdk.installed(ROOT))
            result = resolve(assembly)
            dependencies.verify(code_paths, code_identity)
            emitted = cpu.emit_profile(result.profile, temporary,
                                   clock_hz=result.clock_hz,
                                   optimization=result.optimization,
                                   inputhash=result.input_sha256,
                                   kernel_profile=result.kernel,
                                   platform_metadata=result.platform_metadata)
            if emitted["configuration_sha256"] != result.configuration_sha256:
                raise RuntimeError("Resolved runtime identity changed during emission")
            with (temporary / "selection.cmake").open("a", encoding="utf-8") as stream:
                stream.write('set(NEXUS_SOC_FAMILY "cpu-runtime")\n')
            (temporary / "input_paths.json").write_text(
                json.dumps(dict(result.inputs), indent=2, sort_keys=True) + "\n",
                encoding="utf-8")
            (temporary / ".nexus-runtime-bundle").write_text(
                "Nexus authored CPU runtime bundle\n", encoding="utf-8")
            dependencies.emit(temporary, code_paths, code_identity)
            for source, snapshot in result.snapshots.items():
                if _path(source).read_bytes() != snapshot:
                    raise RuntimeError("Runtime inputs changed during generation")
            dependencies.verify(code_paths, code_identity)
        return result
    except (OSError, ValueError, TypeError, KeyError) as error:
        if isinstance(error, RuntimeError):
            raise
        raise RuntimeError(str(error)) from error


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--assembly", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        configure(args.assembly, args.output)
        return 0
    except RuntimeError as error:
        print(f"Runtime configuration rejected: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
