#include "/workspace/nexus/tests/google/i2c_register_model.h"
