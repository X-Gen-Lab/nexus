#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/i2c_async_register_model.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
