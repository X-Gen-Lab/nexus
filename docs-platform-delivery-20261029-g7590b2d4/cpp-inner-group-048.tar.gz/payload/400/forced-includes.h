#include "/workspace/nexus/tests/google/i2c_async_register_model.h"
