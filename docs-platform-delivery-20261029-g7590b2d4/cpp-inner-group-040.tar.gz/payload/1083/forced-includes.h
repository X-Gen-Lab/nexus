#include "/workspace/nexus/tests/google/gd32_uart_cold_factory_model.h"
