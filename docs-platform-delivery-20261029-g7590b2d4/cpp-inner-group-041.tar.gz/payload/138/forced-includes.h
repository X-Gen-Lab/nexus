#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
#include "/workspace/nexus/tests/contracts/stm32_model/constructor_model.h"
