#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/u575_stop2_clock_bridge.h"
