#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/stm32_i2c_cold_model.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
