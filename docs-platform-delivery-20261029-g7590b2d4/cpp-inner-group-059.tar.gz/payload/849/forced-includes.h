#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/ethernet_frames_model.h"
