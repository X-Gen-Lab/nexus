/**
 * \file            nexus_factory.h
 * \brief           Typed lookup of statically selected instances.
 * \author          Nexus Team
 */
#ifndef NEXUS_FACTORY_H
#define NEXUS_FACTORY_H
#include <stddef.h>
#include <stdint.h>
#include "nexus/io/fwd.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef uint16_t nx_gpio_id_t;
enum {
    NX_GPIO_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id);
typedef uint16_t nx_uart_id_t;
enum {
    NX_UART_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id);
typedef uint16_t nx_spi_id_t;
enum {
    NX_SPI_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id);
typedef uint16_t nx_i2c_id_t;
enum {
    NX_I2C_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id);
typedef uint16_t nx_flash_id_t;
enum {
    NX_FLASH_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id);
typedef uint16_t nx_watchdog_id_t;
enum {
    NX_WATCHDOG_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id);
typedef uint16_t nx_exti_id_t;
enum {
    NX_EXTI_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id);
typedef uint16_t nx_pwm_id_t;
enum {
    NX_PWM_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id);
typedef uint16_t nx_adc_id_t;
enum {
    NX_ADC_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id);
typedef uint16_t nx_can_id_t;
enum {
    NX_CAN_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_can_port_t* nx_factory_can(nx_can_id_t id);
typedef uint16_t nx_usb_device_id_t;
enum {
    NX_USB_DEVICE_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id);
typedef uint16_t nx_eth_id_t;
enum {
    NX_ETH_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id);
typedef uint16_t nx_timer_capture_id_t;
enum {
    NX_TIMER_CAPTURE_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id);
typedef uint16_t nx_advanced_pwm_id_t;
enum {
    NX_ADVANCED_PWM_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id);
typedef uint16_t nx_pwm_group_id_t;
enum {
    NX_PWM_GROUP_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id);
typedef uint16_t nx_encoder_id_t;
enum {
    NX_ENCODER_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id);
typedef uint16_t nx_pwm_adc_id_t;
enum {
    NX_PWM_ADC_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id);
typedef uint16_t nx_can_fd_id_t;
enum {
    NX_CAN_FD_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id);
typedef uint16_t nx_adc_group_id_t;
enum {
    NX_ADC_GROUP_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id);
typedef uint16_t nx_eth_frames_id_t;
enum {
    NX_ETH_FRAMES_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id);
typedef uint16_t nx_rtc_id_t;
enum {
    NX_RTC_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id);
typedef uint16_t nx_lptim_id_t;
enum {
    NX_LPTIM_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id);
typedef uint16_t nx_spi_device_id_t;
enum {
    NX_SPI_DEVICE_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id);
typedef uint16_t nx_i2c_device_id_t;
enum {
    NX_I2C_DEVICE_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id);
typedef uint16_t nx_usb_endpoint_id_t;
enum {
    NX_USB_ENDPOINT_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id);
typedef uint16_t nx_mdio_id_t;
enum {
    NX_MDIO_ID_COUNT = 0
};
/**
 * \brief           Return static identity without initialization.
 *
 * \param[in]       id: Generated assembly-local identity.
 *
 * \return          Fixed borrowed face, or NULL for an invalid ID.
 *
 * \note            Task/ISR safe; no allocation, locks or hardware
 *                  access. Identity exists before startup. Operations
 *                  require successful startup and quiescent shutdown.
 */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id);
/** \brief Fixed controller activation identity, or NULL.
 * \note Task/ISR safe; no start, locks or hardware access.
 */
const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id);
#ifdef __cplusplus
}
#endif
#endif
