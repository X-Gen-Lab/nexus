/dev/shm/nexus-final-software-d742cdb5-20261029/cache_control_compile/cortex-m0-O2-absent.o: \
 /workspace/nexus/arch/arm/cortex_m/nx_arch_cache_control.c \
 /workspace/nexus/arch/include/nexus/arch/arch.h \
 /workspace/nexus/arch/include/nexus/arch/cache_control.h \
 /workspace/nexus/arch/arm/cortex_m/private/mechanisms.h \
 /workspace/nexus/arch/include/nexus/arch/features.h
