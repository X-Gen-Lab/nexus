	.arch armv8.1-m.main
	.fpu fpv5-d16
	.arch_extension dsp
	.arch_extension fp
	.arch_extension fp.dp
	.eabi_attribute 5, "cortex-m55"
	.eabi_attribute 20, 1
	.eabi_attribute 21, 1
	.eabi_attribute 23, 3
	.eabi_attribute 24, 1
	.eabi_attribute 25, 1
	.eabi_attribute 26, 1
	.eabi_attribute 30, 2
	.eabi_attribute 34, 1
	.eabi_attribute 38, 1
	.eabi_attribute 18, 4
	.file	"nx_arch_cortex_m.c"
	.text
	.align	1
	.p2align 2,,3
	.global	nx_arch_irq_save
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_irq_save, %function
nx_arch_irq_save:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax unified
@ 80 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r0, primask
	cpsid i
	dsb
	isb
@ 0 "" 2
	.thumb
	.syntax unified
	bx	lr
	.size	nx_arch_irq_save, .-nx_arch_irq_save
	.align	1
	.p2align 2,,3
	.global	nx_arch_irq_restore
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_irq_restore, %function
nx_arch_irq_restore:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax unified
@ 85 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	dsb
	msr primask, r0
	isb
@ 0 "" 2
	.thumb
	.syntax unified
	bx	lr
	.size	nx_arch_irq_restore, .-nx_arch_irq_restore
	.align	1
	.p2align 2,,3
	.global	nx_arch_irq_masks
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_irq_masks, %function
nx_arch_irq_masks:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	push	{r4}
	.syntax unified
@ 94 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r4, primask
@ 0 "" 2
@ 98 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r1, basepri
@ 0 "" 2
@ 99 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r2, faultmask
@ 0 "" 2
	.thumb
	.syntax unified
	strd	r4, r1, [r0]
	str	r2, [r0, #8]
	ldr	r4, [sp], #4
	bx	lr
	.size	nx_arch_irq_masks, .-nx_arch_irq_masks
	.align	1
	.p2align 2,,3
	.global	nx_arch_irq_is_masked
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_irq_is_masked, %function
nx_arch_irq_is_masked:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax unified
@ 94 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r3, primask
@ 0 "" 2
@ 98 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r2, basepri
@ 0 "" 2
@ 99 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r0, faultmask
@ 0 "" 2
	.thumb
	.syntax unified
	and	r3, r3, #1
	orrs	r3, r3, r2
	and	r0, r0, #1
	cmp	r3, #0
	it	ne
	orrne	r0, r0, #1
	bx	lr
	.size	nx_arch_irq_is_masked, .-nx_arch_irq_is_masked
	.align	1
	.p2align 2,,3
	.global	nx_arch_exception_number
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_exception_number, %function
nx_arch_exception_number:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax unified
@ 95 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r0, ipsr
@ 0 "" 2
	.thumb
	.syntax unified
	bx	lr
	.size	nx_arch_exception_number, .-nx_arch_exception_number
	.align	1
	.p2align 2,,3
	.global	nx_arch_is_privileged
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_is_privileged, %function
nx_arch_is_privileged:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax unified
@ 95 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r3, ipsr
@ 0 "" 2
	.thumb
	.syntax unified
	cbnz	r3, .L10
	.syntax unified
@ 96 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r0, control
@ 0 "" 2
	.thumb
	.syntax unified
	mvns	r0, r0
	and	r0, r0, #1
	bx	lr
.L10:
	movs	r0, #1
	bx	lr
	.size	nx_arch_is_privileged, .-nx_arch_is_privileged
	.align	1
	.p2align 2,,3
	.global	nx_arch_in_isr
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_in_isr, %function
nx_arch_in_isr:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax unified
@ 95 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r0, ipsr
@ 0 "" 2
	.thumb
	.syntax unified
	subs	r0, r0, #0
	it	ne
	movne	r0, #1
	bx	lr
	.size	nx_arch_in_isr, .-nx_arch_in_isr
	.align	1
	.p2align 2,,3
	.global	nx_arch_dmb
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_dmb, %function
nx_arch_dmb:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax unified
@ 103 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	dmb
@ 0 "" 2
	.thumb
	.syntax unified
	bx	lr
	.size	nx_arch_dmb, .-nx_arch_dmb
	.align	1
	.p2align 2,,3
	.global	nx_arch_dsb
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_dsb, %function
nx_arch_dsb:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax unified
@ 106 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	dsb
@ 0 "" 2
	.thumb
	.syntax unified
	bx	lr
	.size	nx_arch_dsb, .-nx_arch_dsb
	.align	1
	.p2align 2,,3
	.global	nx_arch_isb
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_isb, %function
nx_arch_isb:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax unified
@ 109 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	isb
@ 0 "" 2
	.thumb
	.syntax unified
	bx	lr
	.size	nx_arch_isb, .-nx_arch_isb
	.align	1
	.p2align 2,,3
	.global	nx_arch_cycle_snapshot
	.syntax unified
	.thumb
	.thumb_func
	.type	nx_arch_cycle_snapshot, %function
nx_arch_cycle_snapshot:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	mov	r3, r0
	cbz	r0, .L19
	.syntax unified
@ 95 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r2, ipsr
@ 0 "" 2
	.thumb
	.syntax unified
	cbz	r2, .L18
.L21:
	mov	r2, #-536813568
	ldr	r2, [r2, #3580]
	lsls	r1, r2, #7
	bpl	.L19
	ldr	r2, .L29
	ldr	r1, .L29+4
	ldr	r0, [r2]
	ands	r0, r0, r1
	cmp	r0, #1
	bne	.L19
	ldr	r2, [r2, #4]
	str	r2, [r3]
	bx	lr
.L18:
	.syntax unified
@ 96 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r2, control
@ 0 "" 2
	.thumb
	.syntax unified
	lsls	r2, r2, #31
	bpl	.L21
.L19:
	movs	r0, #0
	bx	lr
.L30:
	.align	2
.L29:
	.word	-536866816
	.word	33554433
	.size	nx_arch_cycle_snapshot, .-nx_arch_cycle_snapshot
	.ident	"GCC: (Arm GNU Toolchain 14.3.Rel1 (Build arm-14.174)) 14.3.1 20250623"
