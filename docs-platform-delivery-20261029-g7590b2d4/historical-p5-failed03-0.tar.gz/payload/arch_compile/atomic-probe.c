#include <stdatomic.h>
_Static_assert(sizeof(unsigned) == 4, "32-bit atomic probe required");
unsigned snapshot(const unsigned* p) {
    return __atomic_load_n(p, __ATOMIC_ACQUIRE);
}
void publish(unsigned* p, unsigned value) {
    __atomic_store_n(p, value, __ATOMIC_RELEASE);
}
unsigned increment(unsigned* p) {
    return __atomic_fetch_add(p, 1, __ATOMIC_RELEASE);
}
