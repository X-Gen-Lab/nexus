	.cpu cortex-m0plus
	.arch armv6s-m
	.fpu softvfp
	.eabi_attribute 20, 1
	.eabi_attribute 21, 1
	.eabi_attribute 23, 3
	.eabi_attribute 24, 1
	.eabi_attribute 25, 1
	.eabi_attribute 26, 1
	.eabi_attribute 30, 2
	.eabi_attribute 34, 0
	.eabi_attribute 18, 4
	.file	"nx_arch_cortex_m.c"
	.text
	.align	1
	.p2align 2,,3
	.global	nx_arch_irq_save
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_irq_save, %function
nx_arch_irq_save:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 80 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r0, primask
	cpsid i
	dsb
	isb
@ 0 "" 2
	.thumb
	.syntax unified
	@ sp needed
	bx	lr
	.size	nx_arch_irq_save, .-nx_arch_irq_save
	.align	1
	.p2align 2,,3
	.global	nx_arch_irq_restore
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_irq_restore, %function
nx_arch_irq_restore:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 85 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	dsb
	msr primask, r0
	isb
@ 0 "" 2
	.thumb
	.syntax unified
	@ sp needed
	bx	lr
	.size	nx_arch_irq_restore, .-nx_arch_irq_restore
	.align	1
	.p2align 2,,3
	.global	nx_arch_irq_masks
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_irq_masks, %function
nx_arch_irq_masks:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 94 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r3, primask
@ 0 "" 2
	.thumb
	.syntax unified
	str	r3, [r0]
	movs	r3, #0
	@ sp needed
	str	r3, [r0, #4]
	str	r3, [r0, #8]
	bx	lr
	.size	nx_arch_irq_masks, .-nx_arch_irq_masks
	.align	1
	.p2align 2,,3
	.global	nx_arch_irq_is_masked
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_irq_is_masked, %function
nx_arch_irq_is_masked:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 94 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r3, primask
@ 0 "" 2
	.thumb
	.syntax unified
	movs	r0, #1
	@ sp needed
	ands	r0, r3
	bx	lr
	.size	nx_arch_irq_is_masked, .-nx_arch_irq_is_masked
	.align	1
	.p2align 2,,3
	.global	nx_arch_exception_number
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_exception_number, %function
nx_arch_exception_number:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 95 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r0, ipsr
@ 0 "" 2
	.thumb
	.syntax unified
	@ sp needed
	bx	lr
	.size	nx_arch_exception_number, .-nx_arch_exception_number
	.align	1
	.p2align 2,,3
	.global	nx_arch_is_privileged
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_is_privileged, %function
nx_arch_is_privileged:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 95 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r3, ipsr
@ 0 "" 2
	.thumb
	.syntax unified
	movs	r0, #1
	cmp	r3, #0
	bne	.L8
	.syntax divided
@ 96 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r3, control
@ 0 "" 2
	.thumb
	.syntax unified
	bics	r0, r3
.L8:
	@ sp needed
	bx	lr
	.size	nx_arch_is_privileged, .-nx_arch_is_privileged
	.align	1
	.p2align 2,,3
	.global	nx_arch_in_isr
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_in_isr, %function
nx_arch_in_isr:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 95 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	mrs r0, ipsr
@ 0 "" 2
	.thumb
	.syntax unified
	subs	r3, r0, #1
	sbcs	r0, r0, r3
	@ sp needed
	uxtb	r0, r0
	bx	lr
	.size	nx_arch_in_isr, .-nx_arch_in_isr
	.align	1
	.p2align 2,,3
	.global	nx_arch_dmb
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_dmb, %function
nx_arch_dmb:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 103 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	dmb
@ 0 "" 2
	.thumb
	.syntax unified
	@ sp needed
	bx	lr
	.size	nx_arch_dmb, .-nx_arch_dmb
	.align	1
	.p2align 2,,3
	.global	nx_arch_dsb
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_dsb, %function
nx_arch_dsb:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 106 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	dsb
@ 0 "" 2
	.thumb
	.syntax unified
	@ sp needed
	bx	lr
	.size	nx_arch_dsb, .-nx_arch_dsb
	.align	1
	.p2align 2,,3
	.global	nx_arch_isb
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_isb, %function
nx_arch_isb:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	.syntax divided
@ 109 "/workspace/nexus/arch/arm/cortex_m/private/compiler.h" 1
	isb
@ 0 "" 2
	.thumb
	.syntax unified
	@ sp needed
	bx	lr
	.size	nx_arch_isb, .-nx_arch_isb
	.align	1
	.p2align 2,,3
	.global	nx_arch_cycle_snapshot
	.syntax unified
	.code	16
	.thumb_func
	.type	nx_arch_cycle_snapshot, %function
nx_arch_cycle_snapshot:
	@ args = 0, pretend = 0, frame = 0
	@ frame_needed = 0, uses_anonymous_args = 0
	@ link register save eliminated.
	movs	r0, #0
	@ sp needed
	bx	lr
	.size	nx_arch_cycle_snapshot, .-nx_arch_cycle_snapshot
	.ident	"GCC: (Arm GNU Toolchain 14.3.Rel1 (Build arm-14.174)) 14.3.1 20250623"
