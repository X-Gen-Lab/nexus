#include "/workspace/nexus/tests/google/stm32_uart_cold_factory_model.h"
