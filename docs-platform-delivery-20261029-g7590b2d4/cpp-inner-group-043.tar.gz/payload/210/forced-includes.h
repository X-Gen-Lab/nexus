#include "/workspace/nexus/tests/google/gd32_cold_pins_model.h"
