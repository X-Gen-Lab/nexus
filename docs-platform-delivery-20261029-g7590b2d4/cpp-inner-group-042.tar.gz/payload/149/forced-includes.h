#include "/workspace/nexus/tests/google/stm32_platform_cold_model.h"
