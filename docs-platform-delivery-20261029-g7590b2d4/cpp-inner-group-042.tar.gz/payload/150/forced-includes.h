#include "/workspace/nexus/tests/google/stm32_platform_cold_model.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
