#include "/workspace/nexus/tests/google/stm32_control_cold_model.h"
