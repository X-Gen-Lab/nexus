#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/h743_i2c_v2_model.h"
