#include "/workspace/nexus/tests/google/spi_multi_controller_model.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
