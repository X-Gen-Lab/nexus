/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#include "stm32g474_provider.h"
#include "stm32g474_platform_cold.h"
#include "stm32g474_adc_group.h"
#include "stm32_identity.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static uint32_t s_nx_platform_peripheral_apb1enr1_added;
static uint32_t s_nx_platform_peripheral_ahb2enr_added;
static bool s_nx_platform_adc_mux_owned;
static nx_stm32g474_adc_group_state_t s_nx_port_samples;
static const nx_adc_group_port_t s_nx_face_samples = {
    &nx_stm32g474_adc_group_ops, &s_nx_port_samples
};
const nx_adc_group_port_t* const nx_binding_samples = &s_nx_face_samples;
static const nx_stm32_identity_registers_t s_nx_silicon_source_samples_registers = {
    &DBGMCU->IDCODE, (const volatile uint16_t*)FLASHSIZE_BASE
};
static const nx_silicon_source_t s_nx_silicon_source_samples = {
    &s_nx_silicon_source_samples_registers, nx_stm32_identity_read
};
static const nx_silicon_revision_rule_t s_nx_silicon_policy_samples_rule = {
    8195u, NX_SILICON_REVISION_REVIEWED,
    2u
};
static const nx_silicon_admission_policy_t s_nx_silicon_policy_samples = {
    .device_id = 1129u,
    .flash_bytes = 524288u,
    .rules = &s_nx_silicon_policy_samples_rule, .rule_count = 1u,
    .applied_workarounds = 6u,
    .review_sha256 = { 0x94u, 0x72u, 0x2du, 0x90u, 0xa9u, 0xacu, 0xbau, 0x67u, 0xc6u, 0xd7u, 0x40u, 0xadu, 0x5cu, 0xceu, 0xaeu, 0x79u, 0xc6u, 0xa8u, 0xccu, 0x3cu, 0xfeu, 0x11u, 0xf4u, 0xc2u, 0x42u, 0xf7u, 0x51u, 0x54u, 0x56u, 0x23u, 0xfcu, 0x99u },
    .allow_unreviewed = false
};
static const nx_stm32g474_adc_group_profile_t s_nx_adc_group_profile_samples = {
    &s_nx_silicon_policy_samples, 1u
};
static const uint8_t s_nx_channels_samples[] = { 2u, 1u };
static const uint8_t s_nx_samples_samples[] = { 0u, 0u };
static const nx_stm32g474_adc_group_config_t s_nx_config_samples = {
    .regions = NULL, .region_count = 0u,
    .channels = s_nx_channels_samples,
    .sample_times = s_nx_samples_samples,
    .channel_count = 2u,
    .silicon_source = &s_nx_silicon_source_samples, .profile = &s_nx_adc_group_profile_samples,
    .period_us = 50u,
    .trigger_identity = 1u,
    .reference_mv = 3300u, .poll_limit = 1000000u,
    .group = NX_ADC_INJECTED,
    .trigger = NX_ADC_TRIGGER_TIMER,
    .watchdog = false,
    .watchdog_low = 0u, .watchdog_high = 0u,
    .priority = 5u, .exclusive = true
};
void ADC1_2_IRQHandler(void);
/** \brief Observe selected ADC group OVR/AWD/JEOS facts. */
void ADC1_2_IRQHandler(void) { nx_stm32g474_adc_group_adc_irq(&s_nx_port_samples); }
static uint16_t s_nx_platform_pin_state[2u];
static nx_stm32g474_platform_pins_t s_nx_platform_pins;
static const nx_stm32g474_platform_pin_t s_nx_platform_pin_config[] = {
    { GPIOA, &s_nx_platform_pin_state[0u], 0u, 0u },
    { GPIOA, &s_nx_platform_pin_state[1u], 0u, 1u },
};
static const nx_stm32g474_platform_config_t s_nx_platform_config = {
    .pins = s_nx_platform_pin_config, .pin_count = 2u,
    .admit_apb1 = RCC_APB1ENR1_TIM6EN,
    .admit_apb1_2 = 0u,
    .admit_apb2 = 0u,
    .admit_ahb1 = 0u,
    .admit_ahb2 = RCC_AHB2ENR_ADC12EN | RCC_AHB2ENR_ADC345EN,
    .admit_reset_apb1 = RCC_APB1RSTR1_TIM6RST,
    .admit_mux = RCC_CCIPR_ADC12SEL,
    .irq_masks = {
        NX_G474_PLATFORM_IRQ_MASK(ADC1_2_IRQn, 0u),
        NX_G474_PLATFORM_IRQ_MASK(ADC1_2_IRQn, 1u),
        NX_G474_PLATFORM_IRQ_MASK(ADC1_2_IRQn, 2u),
        NX_G474_PLATFORM_IRQ_MASK(ADC1_2_IRQn, 3u),
    },
    .exti_lines = 0u,
    .clocks_apb1 = RCC_APB1ENR1_TIM6EN,
    .added_apb1 = &s_nx_platform_peripheral_apb1enr1_added,
    .clocks_apb1_2 = 0u,
    .added_apb1_2 = NULL,
    .clocks_apb2 = 0u,
    .added_apb2 = NULL,
    .clocks_ahb1 = 0u,
    .added_ahb1 = NULL,
    .clocks_ahb2 = RCC_AHB2ENR_ADC12EN,
    .added_ahb2 = &s_nx_platform_peripheral_ahb2enr_added,
    .added_syscfg = NULL,
    .owned_i2c_mux = NULL,
    .owned_adc_mux = &s_nx_platform_adc_mux_owned,
    .control_group = false, .dma_channel1 = false,
    .strict_dma_channel1 = false, .flash = false
};
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = nx_stm32g474_adc_group_close(&s_nx_port_samples);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_result_t pins = nx_stm32g474_platform_pins_release(&s_nx_platform_config, &s_nx_platform_pins);
    if (pins != NX_SUCCESS) { return pins; }
    nx_result_t resources = nx_stm32g474_platform_resources_stop(&s_nx_platform_config);
    if (resources != NX_SUCCESS) { return resources; }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started) {
        nx_result_t system = nx_stm32g474_system_stop(&g_nx_stm32g474_system, 1000000u);
        if (system != NX_SUCCESS) { return system; }
    }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    {
        nx_silicon_admission_t observed;
        result.primary = nx_silicon_preflight(&s_nx_silicon_source_samples,
                                               &s_nx_silicon_policy_samples,
                                               &observed);
        if (result.primary != NX_SUCCESS) { return result; }
    }
    result.primary = nx_stm32g474_system_preflight(&g_nx_stm32g474_system);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32g474_platform_preflight(&s_nx_platform_config);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32g474_validate_identity();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32g474_platform_pins_acquire(&s_nx_platform_config, &s_nx_platform_pins);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_stm32g474_platform_gpio_clocks_release(&s_nx_platform_pins);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    nx_stm32g474_start_result_t system = nx_stm32g474_system_start(&g_nx_stm32g474_system, 1000000u);
    if (system.primary != NX_SUCCESS) {
        result.primary = system.primary;
        result.cleanup = system.cleanup;
        result.remaining_effects = system.remaining_effects;
        nx_result_t pins = nx_stm32g474_platform_pins_abort(&s_nx_platform_pins);
        if (pins != NX_SUCCESS) { result.cleanup = pins; result.remaining_effects = 1u; }
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    result.primary = nx_stm32g474_platform_resources_start(&s_nx_platform_config);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = nx_stm32g474_adc_group_initialize(&s_nx_port_samples, &s_nx_config_samples);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        case NX_ADC_GROUP_ID_SAMPLES:
            return nx_binding_samples;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_adc_group_samples = {
    NX_FACTORY_CAP_IRQ, 1U, 4U, 2U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id) {
    switch (id) {
        case NX_ADC_GROUP_ID_SAMPLES:
            return &s_nx_capability_adc_group_samples;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure lookup; no start or hardware access. */
const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
