/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#include "stm32h743_cold.h"
#include "stm32h743_platform_cold.h"
#include "stm32h743_flash_ram.h"
#include "stm32h743_clock.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static const nx_flash_sector_t g_nx_stm32h743_flash_geometry_sectors[] = {
    { 0u, 131072u },
    { 131072u, 131072u },
    { 262144u, 131072u },
    { 393216u, 131072u },
    { 524288u, 131072u },
    { 655360u, 131072u },
    { 786432u, 131072u },
    { 917504u, 131072u },
    { 1048576u, 131072u },
    { 1179648u, 131072u },
    { 1310720u, 131072u },
    { 1441792u, 131072u },
    { 1572864u, 131072u },
    { 1703936u, 131072u },
    { 1835008u, 131072u },
    { 1966080u, 131072u },
};
const nx_flash_geometry_t g_nx_stm32h743_flash_geometry = {
    .base_address = 0x08000000u,
    .size = 2097152u,
    .program_unit = 32u,
    .sectors = g_nx_stm32h743_flash_geometry_sectors,
    .sector_count = 16u,
    .program_flags = NX_FLASH_PROGRAM_REQUIRES_FRESH_ERASE
};
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static nx_stm32h743_pll384_state_t s_nx_high_clock;
static uint32_t s_nx_gpio_clocks_added;
static uint32_t s_nx_uart_clocks_added;
static uint32_t s_nx_extra_apb2enr_added;
static uint32_t s_nx_extra_apb1lenr_added;
static uint32_t s_nx_extra_ahb1enr_added;
static nx_stm32h743_gpio_lease_t s_nx_gpioa_lease;
static nx_stm32h743_gpio_lease_t s_nx_gpiob_lease;
static nx_stm32h743_gpio_lease_t s_nx_gpiod_lease;
static nx_stm32h743_gpio_lease_t s_nx_gpioe_lease;
static const nx_stm32h743_gpio_lease_config_t s_nx_gpio_leases[] = {
    { GPIOA, &s_nx_gpioa_lease, 72u, 0u },
    { GPIOB, &s_nx_gpiob_lease, 769u, 1u },
    { GPIOD, &s_nx_gpiod_lease, 768u, 3u },
    { GPIOE, &s_nx_gpioe_lease, 30720u, 4u },
};
static const nx_stm32h743_platform_config_t s_nx_platform_config = {
    .ports = s_nx_gpio_leases, .port_count = 4u,
    .gpio_added = &s_nx_gpio_clocks_added,
    .uart_added = &s_nx_uart_clocks_added,
    .dma_added = NULL,
    .apb2 = { RCC_APB2ENR_SPI4EN, &s_nx_extra_apb2enr_added },
    .apb1 = { RCC_APB1LENR_TIM3EN | RCC_APB1LENR_I2C1EN, &s_nx_extra_apb1lenr_added },
    .ahb1 = { RCC_AHB1ENR_ADC12EN, &s_nx_extra_ahb1enr_added },
    .apb4 = { 0u, NULL },
    .dma_lanes = 0u, .dma_strict = 0u
};
static nx_stm32h743_adc_state_t s_nx_port_sensor;
static const nx_adc_port_t s_nx_face_sensor = {
    &nx_stm32h743_adc_ops, &s_nx_port_sensor
};
const nx_adc_port_t* const nx_binding_sensor = &s_nx_face_sensor;
static const nx_stm32h743_adc_config_t s_nx_config_sensor = {
    .registers = ADC1, .peer = ADC2, .common = ADC12_COMMON, .gpio = GPIOA,
    .reference_mv = 3300u, .supply_mv = 3300u,
    .poll_limit = 1000000u
};
static nx_stm32h743_flash_state_t s_nx_port_storage;
static const nx_flash_port_t s_nx_face_storage = {
    &nx_stm32h743_flash_ops, &s_nx_port_storage
};
const nx_flash_port_t* const nx_binding_storage = &s_nx_face_storage;
__attribute__((section(".bss.nx_h743_flash_workspace")))
_Alignas(1024) nx_stm32h743_flash_ram_workspace_t g_nx_stm32h743_flash_ram_workspace;
static nx_stm32h743_gpio_state_t s_nx_port_led;
static const nx_gpio_port_t s_nx_face_led = {
    &nx_stm32h743_gpio_ops, &s_nx_port_led
};
const nx_gpio_port_t* const nx_binding_led = &s_nx_face_led;
static const nx_stm32h743_gpio_config_t s_nx_config_led = {
    GPIOB, 1u, 0u,
    true
};
static nx_i2c_v2_state_t s_nx_port_bus1;
static const nx_i2c_port_t s_nx_face_bus1 = {
    &nx_i2c_v2_ops, &s_nx_port_bus1
};
const nx_i2c_port_t* const nx_binding_bus1 = &s_nx_face_bus1;
static const nx_i2c_v2_config_t s_nx_config_bus1 = {
    .registers = (nx_i2c_v2_registers_t*)(void*)I2C1,
    .reset = &RCC->APB1LRSTR, .reset_mask = RCC_APB1LRSTR_I2C1RST,
    .timing = 0x70a21f2fu, .poll_limit = 1000000u,
    .ignore_master_berr = true, .receive_reload_one = true
};
static nx_i2c_v2_endpoint_state_t s_nx_endpoint_device1 = { &s_nx_port_bus1, 80u };
static const nx_i2c_endpoint_t s_nx_device_face_device1 = {
    &nx_i2c_v2_endpoint_ops, &s_nx_endpoint_device1
};
const nx_i2c_endpoint_t* const nx_device_device1 = &s_nx_device_face_device1;
static nx_stm32h743_pwm_state_t s_nx_port_wave3;
static const nx_pwm_port_t s_nx_face_wave3 = {
    &nx_stm32h743_pwm_ops, &s_nx_port_wave3
};
const nx_pwm_port_t* const nx_binding_wave3 = &s_nx_face_wave3;
static nx_stm32h743_gpio_state_t s_nx_idle_wave3;
static const nx_stm32h743_pwm_config_t s_nx_config_wave3 = {
    &s_nx_idle_wave3, GPIOA, 0u, 1000u,
    250u, 1000000u, 6u
};
static nx_stm32h743_spi_state_t s_nx_port_bus4;
static const nx_spi_port_t s_nx_face_bus4 = {
    &nx_stm32h743_spi_ops, &s_nx_port_bus4
};
const nx_spi_port_t* const nx_binding_bus4 = &s_nx_face_bus4;
static nx_stm32h743_gpio_state_t s_nx_cs_device4;
static nx_stm32h743_spi_endpoint_state_t s_nx_endpoint_device4 = { .port = &s_nx_port_bus4 };
static const nx_spi_endpoint_t s_nx_device_face_device4 = { &nx_stm32h743_spi_endpoint_ops, &s_nx_endpoint_device4 };
const nx_spi_endpoint_t* const nx_device_device4 = &s_nx_device_face_device4;
static const nx_stm32h743_spi_endpoint_config_t s_nx_endpoints_bus4[] = {
    { &s_nx_endpoint_device4, &s_nx_cs_device4, GPIOE, 2048u, 1500000u, 0u },
};
static const nx_stm32h743_spi_config_t s_nx_config_bus4 = {
    .endpoints = s_nx_endpoints_bus4, .count = 1u,
    .clock_hz = 96000000u
};
static nx_stm32h743_uart_state_t s_nx_port_console;
static const nx_uart_port_t s_nx_face_console = {
    &nx_stm32h743_uart_ops, &s_nx_port_console
};
const nx_uart_port_t* const nx_binding_console = &s_nx_face_console;
static uint8_t s_nx_rx_console[64];
static const nx_stm32h743_uart_config_t s_nx_config_console = {
    .storage = s_nx_rx_console,
    .capacity = 64u, .baud = 115200u,
    .clock_hz = 64000000u,
    .irq_policy = { NX_IRQ_KERNEL_NONE, 150u, 4u, 0u },
    .profile = NX_UART_RX_BYTES
};
void USART3_IRQHandler(void);
/** \brief One selected bounded UART publisher. */
void USART3_IRQHandler(void) { nx_stm32h743_uart_irq(&s_nx_port_console); }
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 7u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 6u);
        nx_result_t status_0 = nx_uart_port_stop(&s_nx_face_console);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 6u;
    }
    if (s_nx_platform_initialized >= 6u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 5u);
        nx_result_t status_0 = nx_stm32h743_spi_release(&s_nx_port_bus4, &s_nx_config_bus4);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 5u;
    }
    if (s_nx_platform_initialized >= 5u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 4u);
        nx_result_t status_0 = nx_stm32h743_pwm_close(&s_nx_port_wave3);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 4u;
    }
    if (s_nx_platform_initialized >= 4u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 3u);
        nx_result_t status_0 = nx_i2c_port_stop(&s_nx_face_bus1);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 3u;
    }
    if (s_nx_platform_initialized >= 3u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 2u);
        nx_result_t status_0 = nx_stm32h743_gpio_stop(&s_nx_port_led, 0u);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 2u;
    }
    if (s_nx_platform_initialized >= 2u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 1u);
        nx_result_t status_0 = nx_stm32h743_flash_ram_stop(&g_nx_stm32h743_flash_ram_workspace);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 1u;
    }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = nx_stm32h743_adc_stop(&s_nx_port_sensor);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_result_t resources = nx_stm32h743_platform_release(&s_nx_platform_config);
    if (resources != NX_SUCCESS) { return resources; }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started) {
        nx_result_t system = nx_stm32h743_system_stop(&g_nx_stm32h743_system, 1000000u);
        if (system != NX_SUCCESS) { return system; }
    }
    nx_result_t clock = nx_stm32h743_pll384_stop(&s_nx_high_clock, 1000000u);
    if (clock != NX_SUCCESS) { return clock; }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_stm32h743_system_preflight(&g_nx_stm32h743_system);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_adc_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_flash_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_i2c_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_pwm_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_spi_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_uart_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_platform_preflight(&s_nx_platform_config);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_validate_identity();
    if (result.primary != NX_SUCCESS) { return result; }
    nx_stm32h743_start_result_t clock = nx_stm32h743_pll384_start(&s_nx_high_clock, 1000000u);
    if (clock.primary != NX_SUCCESS) {
        result.primary = clock.primary;
        result.cleanup = clock.cleanup;
        result.remaining_effects = clock.remaining_effects == 0u ? 0u : 1u;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_stm32h743_start_result_t system = nx_stm32h743_pll384_system_start(&s_nx_high_clock, 0u, 1000000u);
    if (system.primary != NX_SUCCESS) {
        result.primary = system.primary;
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    result.primary = nx_stm32h743_platform_acquire(&s_nx_platform_config);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = nx_stm32h743_adc_prepare(&s_nx_port_sensor, &s_nx_config_sensor);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 1u);
    s_nx_platform_initialized = 2u;
    result.primary = nx_stm32h743_flash_prepare(&s_nx_port_storage, &g_nx_stm32h743_flash_ram_workspace, 3300u);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 2u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 2u);
    s_nx_platform_initialized = 3u;
    result.primary = nx_stm32h743_gpio_prepare(&s_nx_port_led, &s_nx_config_led);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 3u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 3u);
    s_nx_platform_initialized = 4u;
    result.primary = nx_stm32h743_i2c_prepare(&s_nx_port_bus1, &s_nx_config_bus1);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 4u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 4u);
    s_nx_platform_initialized = 5u;
    result.primary = nx_stm32h743_pwm_prepare(&s_nx_port_wave3, &s_nx_config_wave3);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 5u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 5u);
    s_nx_platform_initialized = 6u;
    result.primary = nx_stm32h743_spi_prepare(&s_nx_port_bus4, &s_nx_config_bus4);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 6u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 6u);
    s_nx_platform_initialized = 7u;
    result.primary = nx_stm32h743_uart_prepare(&s_nx_port_console, &s_nx_config_console);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 7u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        case NX_GPIO_ID_LED:
            return nx_binding_led;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return nx_binding_console;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        case NX_SPI_ID_BUS4:
            return nx_binding_bus4;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        case NX_I2C_ID_BUS1:
            return nx_binding_bus1;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        case NX_FLASH_ID_STORAGE:
            return nx_binding_storage;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        case NX_PWM_ID_WAVE3:
            return nx_binding_wave3;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        case NX_ADC_ID_SENSOR:
            return nx_binding_sensor;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        case NX_SPI_DEVICE_ID_DEVICE4:
            return nx_device_device4;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        case NX_I2C_DEVICE_ID_DEVICE1:
            return nx_device_device1;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_gpio_led = {
    0U, 0U, 0U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id) {
    switch (id) {
        case NX_GPIO_ID_LED:
            return &s_nx_capability_gpio_led;
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_uart_console = {
    NX_FACTORY_CAP_IRQ, 0U, 1U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return &s_nx_capability_uart_console;
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_spi_bus4 = {
    NX_FACTORY_CAP_POLLING, 256U, 1U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id) {
    switch (id) {
        case NX_SPI_ID_BUS4:
            return &s_nx_capability_spi_bus4;
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_i2c_bus1 = {
    NX_FACTORY_CAP_POLLING, NX_I2C_MAX_MESSAGE_BYTES, 1U, 1U, NX_I2C_MAX_MESSAGES
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id) {
    switch (id) {
        case NX_I2C_ID_BUS1:
            return &s_nx_capability_i2c_bus1;
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_flash_storage = {
    NX_FACTORY_CAP_POLLING, 0U, 32U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id) {
    switch (id) {
        case NX_FLASH_ID_STORAGE:
            return &s_nx_capability_flash_storage;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_pwm_wave3 = {
    0U, 0U, 0U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id) {
    switch (id) {
        case NX_PWM_ID_WAVE3:
            return &s_nx_capability_pwm_wave3;
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_adc_sensor = {
    NX_FACTORY_CAP_POLLING, 1U, 2U, 2U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id) {
    switch (id) {
        case NX_ADC_ID_SENSOR:
            return &s_nx_capability_adc_sensor;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_spi_device_device4 = {
    NX_FACTORY_CAP_POLLING, 256U, 1U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id) {
    switch (id) {
        case NX_SPI_DEVICE_ID_DEVICE4:
            return &s_nx_capability_spi_device_device4;
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_i2c_device_device1 = {
    NX_FACTORY_CAP_POLLING, NX_I2C_MAX_MESSAGE_BYTES, 1U, 1U, NX_I2C_MAX_MESSAGES
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id) {
    switch (id) {
        case NX_I2C_DEVICE_ID_DEVICE1:
            return &s_nx_capability_i2c_device_device1;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_adc_traits_t s_nx_traits_adc_sensor = {
    16U,
    0U,
    1U,
    NX_IO_ABORT_NOT_APPLICABLE,
    NX_IO_CONTINUITY_NOT_APPLICABLE,
    NX_IO_TIMESTAMP_UNKNOWN,
    NX_IO_DMA_POLICY_NONE,
    0U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_adc_traits_t* nx_factory_adc_traits(
    nx_adc_id_t id) {
    switch (id) {
        case NX_ADC_ID_SENSOR:
            return &s_nx_traits_adc_sensor;
        default:
            return NULL;
    }
}
static const nx_factory_i2c_traits_t s_nx_traits_i2c_bus1 = {
    7U,
    100000U,
    NX_IO_ABORT_NOT_APPLICABLE,
    NX_IO_CONTINUITY_NOT_APPLICABLE,
    NX_IO_TIMESTAMP_UNKNOWN,
    NX_IO_DMA_POLICY_NONE,
    0U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_i2c_traits_t* nx_factory_i2c_traits(
    nx_i2c_id_t id) {
    switch (id) {
        case NX_I2C_ID_BUS1:
            return &s_nx_traits_i2c_bus1;
        default:
            return NULL;
    }
}
static const nx_factory_spi_traits_t s_nx_traits_spi_bus4 = {
    8U,
    1500000U,
    NX_IO_ABORT_NOT_APPLICABLE,
    NX_IO_CONTINUITY_NOT_APPLICABLE,
    NX_IO_TIMESTAMP_UNKNOWN,
    NX_IO_DMA_POLICY_NONE,
    0U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_spi_traits_t* nx_factory_spi_traits(
    nx_spi_id_t id) {
    switch (id) {
        case NX_SPI_ID_BUS4:
            return &s_nx_traits_spi_bus4;
        default:
            return NULL;
    }
}
static const nx_factory_uart_traits_t s_nx_traits_uart_console = {
    8U,
    0U,
    2U,
    115200U,
    NX_IO_ABORT_REQUEST,
    NX_IO_CONTINUITY_IRQ_BUFFERED,
    NX_IO_TIMESTAMP_UNKNOWN,
    NX_IO_DMA_POLICY_NONE,
    0U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_uart_traits_t* nx_factory_uart_traits(
    nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return &s_nx_traits_uart_console;
        default:
            return NULL;
    }
}
/** \brief Pure lookup; no start or hardware access. */
const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
