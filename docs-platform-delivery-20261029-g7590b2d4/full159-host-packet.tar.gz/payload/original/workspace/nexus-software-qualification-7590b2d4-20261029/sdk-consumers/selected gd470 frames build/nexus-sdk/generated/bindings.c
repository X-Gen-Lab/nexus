/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#include "gd32f470_provider.h"
#include "gd32f4xx.h"
#include "system.h"
#include "gd32f470_platform_cold.h"
#include "gd32f4xx_gpio.h"
#include "gd32f4xx_rcu.h"
#include "gd32f470_eth_frames_cold.h"
#include "gd32f4xx_syscfg.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static nx_gd32_eth_resource_receipt_t s_nx_eth_resources;
static nx_eth_frames_mac_t s_nx_port_mac;
static const nx_eth_frames_port_t s_nx_face_mac = {
    &nx_eth_frames_mac_ops, &s_nx_port_mac
};
const nx_eth_frames_port_t* const nx_binding_mac = &s_nx_face_mac;
static uint16_t s_nx_eth_pin_snapshots_mac[9];
static const nx_gd32_platform_pin_config_t s_nx_eth_pins_mac[] = {
    { GPIOA, &s_nx_eth_pin_snapshots_mac[0], 0u, 1u },
    { GPIOA, &s_nx_eth_pin_snapshots_mac[1], 0u, 2u },
    { GPIOA, &s_nx_eth_pin_snapshots_mac[2], 0u, 7u },
    { GPIOC, &s_nx_eth_pin_snapshots_mac[3], 2u, 1u },
    { GPIOC, &s_nx_eth_pin_snapshots_mac[4], 2u, 4u },
    { GPIOC, &s_nx_eth_pin_snapshots_mac[5], 2u, 5u },
    { GPIOG, &s_nx_eth_pin_snapshots_mac[6], 6u, 11u },
    { GPIOG, &s_nx_eth_pin_snapshots_mac[7], 6u, 13u },
    { GPIOG, &s_nx_eth_pin_snapshots_mac[8], 6u, 14u },
};
static nx_eth_frames_descriptor_t s_nx_eth_frames_tx_mac[8];
static nx_eth_frames_descriptor_t s_nx_eth_frames_rx_mac[8];
static nx_eth_frames_tx_slot_t s_nx_eth_frames_tx_slots_mac[8];
static nx_eth_frames_rx_slot_t s_nx_eth_frames_rx_slots_mac[8];
_Alignas(4) static uint8_t s_nx_eth_frames_storage_mac[8][256];
static nx_gd32_eth_pin_receipt_t s_nx_eth_receipt_mac;
static const nx_dma_memory_region_t s_nx_eth_regions_mac[] = {
    { 0x20000000u, 196608u, NX_DMA_MEMORY_READ | NX_DMA_MEMORY_WRITE }
};
static const nx_gd32_eth_frames_cold_config_t s_nx_eth_frames_config_mac = {
    .pins = s_nx_eth_pins_mac, .regions = s_nx_eth_regions_mac,
    .tx_descriptors = s_nx_eth_frames_tx_mac, .rx_descriptors = s_nx_eth_frames_rx_mac,
    .tx_slots = s_nx_eth_frames_tx_slots_mac, .rx_slots = s_nx_eth_frames_rx_slots_mac,
    .storage = &s_nx_eth_frames_storage_mac[0][0], .rx_storage_bytes = 256u,
    .tx_count = 8u, .rx_count = 8u,
    .init_timeout_us = 5000u, .drain_timeout_us = 1000u,
    .irq_policy = { NX_IRQ_KERNEL_NONE, 91u, 4u, 0u }, .priority = 5u,
    .address = { 2u, 0u, 0u, 0u, 0u, 1u },
    .clock_domain = 1u,
};
static const nx_mdio_port_t s_nx_face_mdio_mac = {
    &nx_eth_frames_mdio_ops, &s_nx_port_mac
};
const nx_mdio_port_t* const nx_binding_mac_mdio = &s_nx_face_mdio_mac;
void ENET_IRQHandler(void);
/** \brief Bounded selected RMII publisher. */
void ENET_IRQHandler(void) { nx_eth_frames_mac_irq(&s_nx_port_mac); }
static nx_gd32_platform_pin_receipt_t s_nx_platform_pins;
static const nx_gd32_platform_pin_config_t s_nx_platform_pins_config[] = {
    { GPIOA, &s_nx_eth_pin_snapshots_mac[0], 0u, 1u },
    { GPIOA, &s_nx_eth_pin_snapshots_mac[1], 0u, 2u },
    { GPIOA, &s_nx_eth_pin_snapshots_mac[2], 0u, 7u },
    { GPIOC, &s_nx_eth_pin_snapshots_mac[3], 2u, 1u },
    { GPIOC, &s_nx_eth_pin_snapshots_mac[4], 2u, 4u },
    { GPIOC, &s_nx_eth_pin_snapshots_mac[5], 2u, 5u },
    { GPIOG, &s_nx_eth_pin_snapshots_mac[6], 6u, 11u },
    { GPIOG, &s_nx_eth_pin_snapshots_mac[7], 6u, 13u },
    { GPIOG, &s_nx_eth_pin_snapshots_mac[8], 6u, 14u },
};
static const nx_gd32_platform_config_t s_nx_platform_config = {
    .pins = s_nx_platform_pins_config, .pin_count = 9u,
    .dma_lanes = NULL,
    .dma_lane_count = 0u,
    .apb1_clocks = 0u,
    .apb2_clocks = 0u,
    .ahb1_clocks = RCU_AHB1EN_ENETEN | RCU_AHB1EN_ENETTXEN | RCU_AHB1EN_ENETRXEN | RCU_AHB1EN_ENETPTPEN,
    .ahb2_clocks = 0u,
    .irq_masks = {
        NX_GD32_PLATFORM_IRQ_MASK(ENET_IRQn, 0u),
        NX_GD32_PLATFORM_IRQ_MASK(ENET_IRQn, 1u),
        NX_GD32_PLATFORM_IRQ_MASK(ENET_IRQn, 2u),
    },
    .exti_lines = 0u
};
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = nx_gd32_eth_frames_cold_close(&s_nx_port_mac, &s_nx_eth_frames_config_mac, &s_nx_eth_receipt_mac);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_result_t eth_resources = nx_gd32_eth_resources_close(&s_nx_eth_resources);
    if (eth_resources != NX_SUCCESS) { return eth_resources; }
    nx_result_t pins = nx_gd32_platform_pins_release(&s_nx_platform_config, &s_nx_platform_pins);
    if (pins != NX_SUCCESS) { return pins; }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started && nx_gd32_soc_stop() != 0) { return NX_ERROR_IO; }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_gd32_soc_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_gd32_platform_selected_preflight(&s_nx_platform_config);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_gd32_platform_pins_acquire(&s_nx_platform_config, &s_nx_platform_pins);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_gd32_platform_gpio_clocks_release(&s_nx_platform_pins);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    if (nx_gd32_soc_start() != 0) {
        result.primary = NX_ERROR_IO;
        result.cleanup = nx_gd32_soc_stop() == 0 ? NX_SUCCESS : NX_ERROR_IO;
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        nx_result_t pins = nx_gd32_platform_pins_abort(&s_nx_platform_pins);
        if (pins != NX_SUCCESS) { result.cleanup = pins; result.remaining_effects = 1u; }
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_gd32_eth_resources_capture(&s_nx_eth_resources, true);
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = nx_gd32_eth_frames_cold_prepare(&s_nx_port_mac, &s_nx_eth_frames_config_mac, &s_nx_eth_receipt_mac);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        case NX_ETH_FRAMES_ID_MAC:
            return nx_binding_mac;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        case NX_MDIO_ID_MAC:
            return nx_binding_mac_mdio;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_eth_frames_mac = {
    NX_FACTORY_CAP_IRQ | NX_FACTORY_CAP_BUS_MASTER_DMA, NX_ETH_FRAME_MAX + 4U, 1U, 4U, 1U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id) {
    switch (id) {
        case NX_ETH_FRAMES_ID_MAC:
            return &s_nx_capability_eth_frames_mac;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_mdio_mac = {
    NX_FACTORY_CAP_POLLING, 1U, 2U, 1U, 1U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id) {
    switch (id) {
        case NX_MDIO_ID_MAC:
            return &s_nx_capability_mdio_mac;
        default:
            return NULL;
    }
}
static const nx_factory_eth_frames_traits_t s_nx_traits_eth_frames_mac = {
    1U,
    1U,
    1U,
    NX_IO_ABORT_CONTROLLER_PENDING,
    NX_IO_CONTINUITY_NOT_APPLICABLE,
    NX_IO_TIMESTAMP_HARDWARE_EVENT,
    NX_IO_DMA_POLICY_PROVIDER_DOMAIN,
    0U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_eth_frames_traits_t* nx_factory_eth_frames_traits(
    nx_eth_frames_id_t id) {
    switch (id) {
        case NX_ETH_FRAMES_ID_MAC:
            return &s_nx_traits_eth_frames_mac;
        default:
            return NULL;
    }
}
/** \brief Pure lookup; no start or hardware access. */
const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
