/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#include "stm32h743_cold.h"
#include "stm32h743_platform_cold.h"
#include "stm32h743_dma.h"
#include "stm32h743_spi_dma.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static uint32_t s_nx_gpio_clocks_added;
static uint32_t s_nx_uart_clocks_added;
static uint32_t s_nx_dma_clocks_added;
static uint32_t s_nx_extra_apb2enr_added;
static nx_stm32h743_gpio_lease_t s_nx_gpiod_lease;
static nx_stm32h743_gpio_lease_t s_nx_gpioe_lease;
static const nx_stm32h743_gpio_lease_config_t s_nx_gpio_leases[] = {
    { GPIOD, &s_nx_gpiod_lease, 768u, 3u },
    { GPIOE, &s_nx_gpioe_lease, 30720u, 4u },
};
static const nx_stm32h743_platform_config_t s_nx_platform_config = {
    .ports = s_nx_gpio_leases, .port_count = 2u,
    .gpio_added = &s_nx_gpio_clocks_added,
    .uart_added = &s_nx_uart_clocks_added,
    .dma_added = &s_nx_dma_clocks_added,
    .apb2 = { RCC_APB2ENR_SPI4EN, &s_nx_extra_apb2enr_added },
    .apb1 = { 0u, NULL },
    .ahb1 = { 0u, NULL },
    .apb4 = { 0u, NULL },
    .dma_lanes = 13u, .dma_strict = 12u
};
static nx_stm32h743_spi_dma_state_t s_nx_port_bus4;
static const nx_spi_port_t s_nx_face_bus4 = {
    &nx_stm32h743_spi_dma_ops, &s_nx_port_bus4
};
const nx_spi_port_t* const nx_binding_bus4 = &s_nx_face_bus4;
static const nx_dma_memory_region_t s_nx_dma_regions_bus4[] = {
    { (uintptr_t)0x24000000u, 524288u, NX_DMA_MEMORY_READ | NX_DMA_MEMORY_WRITE },
};
static nx_stm32h743_gpio_state_t s_nx_cs_device4;
static const nx_gpio_port_t s_nx_cs_face_device4 = { &nx_stm32h743_gpio_ops, &s_nx_cs_device4 };
static nx_stm32h743_spi_dma_endpoint_t s_nx_endpoint_device4;
static const nx_spi_endpoint_t s_nx_device_face_device4 = { &nx_stm32h743_spi_dma_endpoint_ops, &s_nx_endpoint_device4 };
const nx_spi_endpoint_t* const nx_device_device4 = &s_nx_device_face_device4;
static const nx_stm32h743_spi_dma_config_t s_nx_config_bus4 = {
    .cs = &s_nx_cs_device4, .endpoint = &s_nx_endpoint_device4, .face = &s_nx_face_bus4,
    .endpoint_face = &s_nx_device_face_device4, .cs_face = &s_nx_cs_face_device4,
    .regions = s_nx_dma_regions_bus4, .region_count = 1u,
    .frequency_hz = 1000000u
};
void DMA1_Stream2_IRQHandler(void);
/** \brief Bounded observer; task owns withdrawal. */
void DMA1_Stream2_IRQHandler(void) { nx_stm32h743_spi_dma_irq(&s_nx_port_bus4, true); }
void DMA1_Stream3_IRQHandler(void);
/** \brief Bounded observer; task owns withdrawal. */
void DMA1_Stream3_IRQHandler(void) { nx_stm32h743_spi_dma_irq(&s_nx_port_bus4, false); }
void SPI4_IRQHandler(void);
/** \brief Bounded observer; task owns withdrawal. */
void SPI4_IRQHandler(void) { nx_stm32h743_spi_dma_wire_irq(&s_nx_port_bus4); }
static nx_stm32h743_uart_dma_state_t s_nx_port_console;
static const nx_uart_port_t s_nx_face_console = {
    &nx_stm32h743_uart_dma_ops, &s_nx_port_console
};
const nx_uart_port_t* const nx_binding_console = &s_nx_face_console;
static const nx_dma_memory_region_t s_nx_dma_regions_console[] = {
    { (uintptr_t)0x24000000u, 524288u, NX_DMA_MEMORY_READ | NX_DMA_MEMORY_WRITE },
};
static uint8_t s_nx_rx_console[64];
static const nx_stm32h743_uart_config_t s_nx_config_console = {
    .storage = s_nx_rx_console,
    .capacity = 64u, .baud = 115200u,
    .clock_hz = 64000000u,
    .irq_policy = { NX_IRQ_KERNEL_NONE, 150u, 4u, 0u },
    .profile = NX_UART_RX_BYTES
};
void USART3_IRQHandler(void);
/** \brief One selected bounded UART publisher. */
void USART3_IRQHandler(void) { nx_stm32h743_uart_dma_uart_irq(&s_nx_port_console); }
void DMA1_Stream0_IRQHandler(void);
/** \brief Selected DMA terminal observer. */
void DMA1_Stream0_IRQHandler(void) { nx_stm32h743_uart_dma_irq(&s_nx_port_console); }
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 2u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 1u);
        nx_result_t status_0 = nx_uart_port_stop(&s_nx_face_console);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 1u;
    }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = nx_stm32h743_spi_dma_release(&s_nx_port_bus4, &s_nx_config_bus4);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_result_t resources = nx_stm32h743_platform_release(&s_nx_platform_config);
    if (resources != NX_SUCCESS) { return resources; }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started) {
        nx_result_t system = nx_stm32h743_system_stop(&g_nx_stm32h743_system, 1000000u);
        if (system != NX_SUCCESS) { return system; }
    }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_stm32h743_system_preflight(&g_nx_stm32h743_system);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_dma_preflight(13u, 12u);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_spi_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_spi_dma_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_uart_preflight();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_platform_preflight(&s_nx_platform_config);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32h743_validate_identity();
    if (result.primary != NX_SUCCESS) { return result; }
    nx_stm32h743_start_result_t system = nx_stm32h743_system_start(&g_nx_stm32h743_system, 64000000u, 0u, 1000000u);
    if (system.primary != NX_SUCCESS) {
        result.primary = system.primary;
        result.cleanup = system.cleanup;
        result.remaining_effects = system.remaining_effects;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    result.primary = nx_stm32h743_platform_acquire(&s_nx_platform_config);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = nx_stm32h743_spi_dma_prepare(&s_nx_port_bus4, &s_nx_config_bus4);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 1u);
    s_nx_platform_initialized = 2u;
    result.primary = nx_stm32h743_uart_dma_prepare(&s_nx_port_console, &s_nx_config_console, s_nx_dma_regions_console, 1u);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 2u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return nx_binding_console;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        case NX_SPI_ID_BUS4:
            return nx_binding_bus4;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        case NX_SPI_DEVICE_ID_DEVICE4:
            return nx_device_device4;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_uart_console = {
    NX_FACTORY_CAP_IRQ | NX_FACTORY_CAP_TX_DMA, UINT16_MAX, 1U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return &s_nx_capability_uart_console;
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_spi_bus4 = {
    NX_FACTORY_CAP_IRQ | NX_FACTORY_CAP_TX_DMA | NX_FACTORY_CAP_RX_DMA, UINT16_MAX, 1U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id) {
    switch (id) {
        case NX_SPI_ID_BUS4:
            return &s_nx_capability_spi_bus4;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_spi_device_device4 = {
    NX_FACTORY_CAP_IRQ | NX_FACTORY_CAP_TX_DMA | NX_FACTORY_CAP_RX_DMA, UINT16_MAX, 1U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id) {
    switch (id) {
        case NX_SPI_DEVICE_ID_DEVICE4:
            return &s_nx_capability_spi_device_device4;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_spi_traits_t s_nx_traits_spi_bus4 = {
    8U,
    1000000U,
    NX_IO_ABORT_REQUEST,
    NX_IO_CONTINUITY_NOT_APPLICABLE,
    NX_IO_TIMESTAMP_UNKNOWN,
    NX_IO_DMA_POLICY_PROVIDER_DOMAIN,
    0U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_spi_traits_t* nx_factory_spi_traits(
    nx_spi_id_t id) {
    switch (id) {
        case NX_SPI_ID_BUS4:
            return &s_nx_traits_spi_bus4;
        default:
            return NULL;
    }
}
static const nx_factory_uart_traits_t s_nx_traits_uart_console = {
    8U,
    0U,
    2U,
    115200U,
    NX_IO_ABORT_REQUEST,
    NX_IO_CONTINUITY_IRQ_BUFFERED,
    NX_IO_TIMESTAMP_UNKNOWN,
    NX_IO_DMA_POLICY_DOMAIN_CACHE_LINE,
    32U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_uart_traits_t* nx_factory_uart_traits(
    nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return &s_nx_traits_uart_console;
        default:
            return NULL;
    }
}
/** \brief Pure lookup; no start or hardware access. */
const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
