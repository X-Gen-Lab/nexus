#include "/workspace/nexus/tests/google/i2c_pair_factory_model.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
