#include "/workspace/nexus/tests/google/physical_platform_factory_model.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
