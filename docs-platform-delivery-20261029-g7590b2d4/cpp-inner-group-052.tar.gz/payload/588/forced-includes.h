#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/usb_device_soc_model.h"
#include "/workspace/nexus/tests/google/usb_factory_model.h"
