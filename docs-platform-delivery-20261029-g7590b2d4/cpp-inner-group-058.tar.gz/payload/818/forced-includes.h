#include "/workspace/nexus/tests/google/legacy_watchdog_gd32_model.h"
