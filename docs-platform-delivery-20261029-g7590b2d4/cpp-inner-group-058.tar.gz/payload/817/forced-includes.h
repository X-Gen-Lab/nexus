#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/legacy_watchdog_stm32_model.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
