#include "/workspace/nexus/tests/google/gd32_uart_receive_model.h"
