#include "/workspace/nexus/tests/google/gd32_adc_stream_model.h"
