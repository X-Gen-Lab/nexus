#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/stm32_uart_receive_model.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
