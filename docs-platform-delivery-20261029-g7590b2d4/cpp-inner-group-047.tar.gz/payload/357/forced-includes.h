#include "/workspace/nexus/tests/cmsis_host/compiler.h"
#include "/workspace/nexus/tests/google/spi_dma_sequence_model.h"
#include "/workspace/nexus/tests/google/stm32_official_model.h"
