"""Read-only independent audit of the actual frozen-v1 remote retrieval."""
import hashlib
import json
from pathlib import Path
import tarfile

BASE = Path('/tmp/nexus-docs-later-evidence/evidence-restore/20261014T104602Z-fc90467c16ec4a3294097894789cf29b')
OUT = Path('/tmp/nexus-docs-later-evidence/final-index-review')
COMMIT = 'ed6835c5caf698f2daa356f72d38c1f0199303eb'
ARCHIVE_SHA = '1774f52c323a9544348026195db19773b483da9d053d3f55a91eb49f44b3f098'
INVENTORY_SHA = '88b4f5ee0659b56a44a57a32bcfbcb9de528b7e7dfbc63bbc890cfa350af50b4'
RECEIPT_SHA = '68c36a43bd3a7fe5d01827cb3c4ac0fb2d86bc518ca7660c7229dcd470b98504'
PREFIX = 'docs-evidence-20261014-source3-v1/'


def require(value, message):
    if not value:
        raise ValueError(message)


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as file:
        while block := file.read(1024 * 1024):
            digest.update(block)
    return {'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def load(path):
    def pairs(rows):
        result = {}
        for key, value in rows:
            require(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def main():
    receipt_file = BASE / 'execution.json'
    require(identity(receipt_file)['sha256'] == RECEIPT_SHA, 'Actual receipt changed')
    receipt = load(receipt_file)
    require(receipt['status'] == 'passed' and receipt['returncode'] == 0,
            'Remote verification did not execute successfully')
    require(receipt['asset_commit'] == COMMIT and
            receipt['source_before'] == receipt['source_after'], 'Remote identity or observer changed')
    require(receipt['physical_status'] == 'not_executed' and
            receipt['source_before']['commit'] == '63d64c1b33248f15dd517953a63be5598942b225' and
            receipt['source_before']['dirty'], 'Observer provenance differs from actual original scope')
    commit = load(BASE / 'remote-commit.json')
    tree = load(BASE / 'remote-tree.json')
    tag = load(BASE / 'remote-tag.json')
    require(commit['sha'] == COMMIT and commit['tree']['sha'] == tree['sha'] and
            not tree.get('truncated') and tag['object'] == {'sha': COMMIT,
                'type': 'commit', 'url': 'https://api.github.com/repos/X-Gen-Lab/nexus/git/commits/' + COMMIT},
            'Actual remote Git commit/tree/tag binding differs')
    blobs = {row['path']: row for row in tree['tree'] if row['type'] == 'blob'}
    for command in receipt['commands']:
        require(command['returncode'] == 0 and
                identity(Path(command['stdout']))['sha256'] == command['stdout_sha256'],
                'Actual Git API observation bytes differ')
    require(len(receipt['requests']) == 12 and receipt['actual_remote_files'] == 11,
            'Asset index versus retained file counts conflated')
    seen = set()
    for request in receipt['requests']:
        url = request['url']
        stem = 'https://raw.githubusercontent.com/X-Gen-Lab/nexus/' + COMMIT + '/'
        require(url.startswith(stem) and request['final_url'] == url and request['status'] == 200,
                'Remote request target/status differs')
        name = url.removeprefix(stem)
        require(name not in seen and name in blobs, 'Remote file duplicate or absent from actual Git tree')
        seen.add(name)
        file = Path(request['path'])
        require(file.is_relative_to(BASE / 'downloaded') and file.is_file() and not file.is_symlink(),
                'Downloaded file is not a regular attempt file')
        require(identity(file) == {key: request[key] for key in ('bytes', 'sha256')},
                'Actual downloaded bytes differ')
        blob = hashlib.sha1(('blob ' + str(file.stat().st_size) + '\0').encode())
        with file.open('rb') as stream:
            while block := stream.read(1024 * 1024):
                blob.update(block)
        require(blob.hexdigest() == request['git_blob_sha1'] == blobs[name]['sha'] and
                file.stat().st_size == blobs[name]['size'], 'Downloaded Git object bytes differ')
    require(seen == {'assets.json'} | {name for name in blobs if name.startswith(PREFIX)},
            'Remote namespace closure differs')
    data = BASE / 'downloaded' / PREFIX
    inventory_path = data / 'EVIDENCE-INVENTORY.json'
    require(identity(inventory_path)['sha256'] == INVENTORY_SHA, 'Remote inventory external digest differs')
    inventory = load(inventory_path)
    expected = {row['path']: {key: row[key] for key in ('bytes', 'sha256')} for row in inventory['members']}
    require(len(expected) == len(inventory['members']) == 17117, 'Inventory count/duplicates differ')
    expected['EVIDENCE-INVENTORY.json'] = identity(inventory_path)
    parts = load(data / 'evidence-parts.json')
    joined = hashlib.sha256()
    joined_bytes = 0
    for part in parts['parts']:
        file = data / part['path']
        require(identity(file) == {key: part[key] for key in ('bytes', 'sha256')} and
                part['bytes'] <= 32 * 1024 * 1024, 'Remote part bytes differ')
        with file.open('rb') as stream:
            while block := stream.read(1024 * 1024):
                joined.update(block)
                joined_bytes += len(block)
    require(joined_bytes == 107591060 and joined.hexdigest() == ARCHIVE_SHA and
            identity(BASE / 'joined-evidence.tar.gz') == {'bytes': joined_bytes, 'sha256': ARCHIVE_SHA},
            'Actual remote ordered join differs')
    actual_members = {}
    with tarfile.open(BASE / 'joined-evidence.tar.gz', 'r|gz') as archive:
        for entry in archive:
            require(entry.isfile() and not entry.issym() and not entry.islnk() and
                    entry.name not in actual_members and entry.name in expected and
                    not entry.name.startswith('/') and '\\' not in entry.name and
                    not any(part in ('', '.', '..') for part in entry.name.split('/')),
                    'Unsafe/duplicate/unregistered actual remote archive member')
            digest = hashlib.sha256()
            with archive.extractfile(entry) as stream:
                while block := stream.read(1024 * 1024):
                    digest.update(block)
            actual_members[entry.name] = {'bytes': entry.size, 'sha256': digest.hexdigest()}
            require(actual_members[entry.name] == expected[entry.name],
                    'Actual remote archive member differs: ' + entry.name)
    require(actual_members == expected and len(actual_members) == 17118,
            'Actual remote full archive closure differs')
    observations = load(BASE / 'archive-member-observations.json')
    require(observations['status'] == 'passed' and
            {row['path']: {key: row[key] for key in ('bytes', 'sha256')}
             for row in observations['members']} == actual_members,
            'Streamed observation member identities differ')
    for item in ('member_observations', 'selected_reader'):
        require(identity(Path(receipt[item]['path'])) ==
                {key: receipt[item][key] for key in ('bytes', 'sha256')},
                'Actual remote observation locator differs')
    selected = load(BASE / 'selected-reader-members.json')
    require(selected['status'] == 'passed' and len(selected['members']) == 41 and
            selected['proof_members'] == 36 and selected['control_members'] == 5,
            'Selected restore count differs')
    reader = BASE / 'independent-reader'
    for member in selected['members']:
        require(identity(reader / member['path']) == actual_members[member['path']] ==
                {key: member[key] for key in ('bytes', 'sha256')},
                'Actual independently restored proof bytes differ')
    tasks = load(reader / 'payload/final-closure/accepted-task-records.json')
    require(tasks['status'] == 'passed' and tasks['task_count'] == len(tasks['records']) == 58,
            'Restored task acceptance record count differs')
    proof_names = set()
    for row in tasks['records']:
        require(row['status'] == 'passed' and row['validation_scope'] == 'accepted_docs_exit',
                'Task acceptance scope differs')
        for member in row['evidence']:
            proof_names.add(member['member_path'])
            require(identity(reader / member['member_path']) == actual_members[member['member_path']] ==
                    {key: member[key] for key in ('bytes', 'sha256')},
                    'Task proof was not actually restored byte-identically')
    result = {'schema_version': 1, 'kind': 'independent_remote_v1_index_supplement_audit',
        'status': 'passed', 'scope': 'actual_remote_git_object_download_full_archive_and_selected_task_proof_restore',
        'archive_bytes': joined_bytes, 'archive_sha256': ARCHIVE_SHA,
        'inventory_sha256': INVENTORY_SHA, 'remote_receipt': {'original_path': str(receipt_file),
            **identity(receipt_file)}, 'storage_commit': COMMIT,
        'remote_https_requests': 12, 'remote_retained_files': 11,
        'all_archive_members_independently_rehashed': len(actual_members),
        'payload_members': sum(name.startswith('payload/') for name in actual_members),
        'selected_restored_reader_files': 41, 'selected_proof_files': 36,
        'accepted_documentation_tasks': 58, 'distinct_per_task_evidence_members': len(proof_names),
        'observer_source_commit': receipt['source_before']['commit'],
        'observer_source_dirty': True, 'observer_source_unchanged': True,
        'qualified_documentation_source': '3835e13cd7da34bd75307746859d4514745ae2ff',
        'firmware_qualification': 'unchanged original source-bound receipts',
        'physical_hil': 'not_executed', 'limitations': ['Actual retrieval used a fresh independent filesystem root in the current host; no second physical host is claimed.',
            'SHA checks detect changed bytes and are not signatures.',
            'This audit supplements the frozen v1 archive and does not mutate it or its primary final review.',
            'A final index-only source revision remains distinct from primary Source3 documentation execution.'],
        'local_inventory_review': {'original_path': str(OUT / 'inventory-review.json'),
            **identity(OUT / 'inventory-review.json')}}
    (OUT / 'remote-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'all_archive_members_independently_rehashed',
        'selected_restored_reader_files', 'accepted_documentation_tasks')}))


if __name__ == '__main__':
    main()
