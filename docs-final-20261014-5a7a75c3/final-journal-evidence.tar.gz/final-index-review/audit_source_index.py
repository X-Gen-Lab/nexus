"""Read-only audit of final acceptance journal source and immutable evidence index."""
import csv
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
from urllib.request import urlopen

ROOT = Path('/tmp/nexus-docs-implementation-source-20261014')
OUT = Path('/tmp/nexus-docs-later-evidence/final-index-review')
EVIDENCE = Path('/tmp/nexus-docs-artifacts/evidence')
ORIGINAL = '0111c8d3b9c7b37d258b9c401070305b13b6f3a1'
SOURCE3 = '3835e13cd7da34bd75307746859d4514745ae2ff'
FILES = ['docs/design/documentation-improvements.md', 'docs/design/documentation-system-execution.csv',
    'docs/reference/documentation-delivery.md', 'docs/status/documentation-acceptance.md',
    'docs/status/documentation-results.json', 'docs/status/ledgers/documentation-system.md']


def require(value, message):
    if not value:
        raise ValueError(message)


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load(path):
    def pairs(rows):
        result = {}
        for key, value in rows:
            require(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)


def git(*args):
    return subprocess.run(['git', '-C', str(ROOT), *args], check=True, capture_output=True).stdout


def main():
    before = {name: identity(ROOT / name) for name in FILES}
    status_before = git('status', '--porcelain=v1', '--untracked-files=all')
    changes = [line[3:] for line in status_before.decode().splitlines()]
    require(set(changes) == set(FILES), 'Unexpected dirty source outside six acceptance documents')
    ledger = FILES[1]
    original = list(csv.DictReader(io.StringIO(git('show', ORIGINAL + ':' + ledger).decode())))
    current = list(csv.DictReader((ROOT / ledger).open()))
    require(len(original) == len(current) == 58, 'Original task count differs')
    fields = ('task_id', 'priority', 'phase', 'task', 'dependencies', 'exit_condition')
    for old, new in zip(original, current):
        require({key: old[key] for key in fields} == {key: new[key] for key in fields},
                'Original ID/task/dependency/priority/phase/exit text changed: ' + old['task_id'])
        require(new['owner'] == 'codex' and new['implementation_status'] == 'implemented' and
                new['validation_status'] == 'passed' and new['validation_scope'] == 'accepted_docs_exit',
                'Actual documentation acceptance scope differs')
        require(new['evidence_paths'] == 'docs/status/documentation-results.json;payload/final-closure/accepted-task-records.json#' + new['task_id'],
                'Task archive record selector is incorrect')
    index = load(ROOT / FILES[4])
    require(index['status'] == 'passed' and index['validation_scope'] == 'accepted_docs_exit' and
            index['task_count'] == len(index['tasks']) == 58 and
            index['task_authority_sha256'] == before[ledger]['sha256'], 'Final index task authority differs')
    require(index['source']['documentation_commit'] == SOURCE3 and
            index['source']['documentation_tree'] == git('rev-parse', SOURCE3 + '^{tree}').decode().strip(),
            'Primary qualified documentation source differs')
    require(index['qualified_code_reference']['commit'] == 'cc6a065c002041234a212a964be863a69198f9b4' and
            index['qualified_code_reference']['index_sha256'] == identity(ROOT / index['qualified_code_reference']['index'])['sha256'],
            'Original code qualification reference differs')
    require(index['physical_hil'] == {'status': 'not_executed', 'changed_by_documentation': False},
            'Physical qualification boundary differs')
    inventory = load(EVIDENCE / 'EVIDENCE-INVENTORY.json')
    members = {row['path']: {key: row[key] for key in ('bytes', 'sha256')} for row in inventory['members']}
    accepted = load(Path('/tmp/nexus-docs-final-evidence/final-closure/accepted-task-records.json'))
    require([row['task_id'] for row in index['tasks']] == [row['task_id'] for row in current] ==
            [row['task_id'] for row in accepted['records']], 'Final index task ordering differs')
    for expected, row in zip(accepted['records'], index['tasks']):
        require(row['status'] == expected['status'] == 'passed' and
                row['validation_scope'] == expected['validation_scope'] == 'accepted_docs_exit' and
                row['evidence_keys'] == [ref['key'] for ref in expected['evidence']],
                'Index task proof association differs')
        for ref in expected['evidence']:
            key = ref['key']
            require(index['evidence'][key] == {field: value for field, value in ref.items() if field != 'key'},
                    'Index shared evidence scope differs: ' + key)
    proofs = [*index['evidence'].values(), *index['actual_scope_receipts'].values(),
              index['source']['clean_execution_receipt'], index['offline_tool_cache']['actual_installation']]
    for proof in proofs:
        require(proof['member_path'].startswith('payload/') and
                members[proof['member_path']] == {key: proof[key] for key in ('bytes', 'sha256')},
                'Final index proof bytes/path differs')
    delivery = index['evidence_delivery']
    require(delivery['channel'] == 'immutable Git commit storage' and
            delivery['storage_commit'] == 'ed6835c5caf698f2daa356f72d38c1f0199303eb' and
            delivery['archive_bytes'] == 107591060 and
            delivery['archive_sha256'] == '1774f52c323a9544348026195db19773b483da9d053d3f55a91eb49f44b3f098' and
            delivery['inventory_sha256'] == identity(EVIDENCE / 'EVIDENCE-INVENTORY.json')['sha256'] and
            delivery['members'] == len(members) == 17117,
            'Final evidence archive identity/channel/count differs')
    require(delivery['parts'] == load(EVIDENCE / 'evidence-parts.json')['parts'] and
            delivery['parts_sha256'] == identity(EVIDENCE / 'evidence-parts.json')['sha256'],
            'Final ordered part identities differ')
    remote_url = delivery['external_receipt_url']
    require(remote_url == 'https://raw.githubusercontent.com/X-Gen-Lab/nexus/0de273ddf7aa191e5d9e19d6d9ec695af574395b/docs-evidence-20261014-source3-v1-restore/restore.json',
            'Actual external D3 locator differs')
    with urlopen(remote_url, timeout=30) as response:
        require(response.status == 200 and response.geturl() == remote_url, 'Actual D3 HTTP target/status differs')
        remote_raw = response.read()
    require(len(remote_raw) == delivery['external_receipt_bytes'] == 15315 and
            hashlib.sha256(remote_raw).hexdigest() == delivery['external_receipt_sha256'] ==
            '68c36a43bd3a7fe5d01827cb3c4ac0fb2d86bc518ca7660c7229dcd470b98504',
            'Actual D3 returned bytes differ')
    (OUT / 'd3-restore-receipt.json').write_bytes(remote_raw)
    remote = json.loads(remote_raw)
    require(remote['status'] == 'passed' and remote['returncode'] == 0 and
            remote['source_before'] == remote['source_after'] and
            remote['asset_commit'] == delivery['storage_commit'] and
            remote['observed_members'] == 17118 and remote['restored_reader_members'] == 41,
            'Actual D3 receipt scope differs')
    package = index['documentation_package']
    require(package['release_id'] == 'docs-20261014-3835e13cd7da' and package['payload_files'] == 1600 and
            package['archive_bytes'] == 7078685 and package['archive_sha256'] ==
            '566acb2d7f4a8ec80022364ca6002ec07b93319c1eb150f5df78e5b996b879df' and
            package['manifest_sha256'] == '21912550daba4d9c7f9c7292c43d44e1b26923dc0b4331544196971c3c9a7aaa',
            'Primary package identity differs')
    sys.path.insert(0, str(ROOT))
    from tools.documentation import status, check
    generated = status.generate(ROOT, check=True)
    mapping = status.check_mapping(ROOT)
    scan = check.scan(ROOT)
    critical = check.validate_translations(ROOT)
    require(generated['status'] == mapping['status'] == scan['status'] == critical['status'] == 'passed',
            'Current read-only source/derived view/navigation/translation checks failed')
    require(mapping['sources'] == 230 and mapping['old_urls'] == 287, 'Authority/alias source counts changed')
    for name in check.CRITICAL_PAGES:
        path = 'docs/' + name + '.md'
        require((ROOT / path).read_bytes() == git('show', SOURCE3 + ':' + path),
                'Critical source changed outside original review: ' + name)
    for file in (ROOT / 'docs/locale').rglob('*.po'):
        path = file.relative_to(ROOT).as_posix()
        require(file.read_bytes() == git('show', SOURCE3 + ':' + path),
                'PO catalog changed outside original review: ' + path)
    after = {name: identity(ROOT / name) for name in FILES}
    require(before == after and status_before == git('status', '--porcelain=v1', '--untracked-files=all'),
            'Final source changed during read-only review')
    summary = {'schema_version': 1, 'kind': 'independent_final_documentation_index_source_audit',
        'status': 'passed', 'scope': 'six_acceptance_only_documents_and_actual_immutable_evidence_index',
        'observer_source_commit': git('rev-parse', 'HEAD').decode().strip(),
        'observer_source_dirty': True, 'source_unchanged_during_review': True,
        'qualified_documentation_source': SOURCE3, 'original_exit_baseline': ORIGINAL,
        'source_files': [{'path': name, **before[name]} for name in FILES],
        'tasks': 58, 'original_exit_ids_text_order_dependencies_preserved': True,
        'accepted_task_archive_sha256': '81ad61da91d0b1336365635f17c6452b7b13f130ce265be19b5cb1b0730fba8a',
        'current_index_proof_references_verified': len(proofs),
        'critical_pages': len(check.CRITICAL_PAGES), 'critical_source_and_all_po_bytes_unchanged_from_source3': True,
        'read_only_checks': {'generated_views': generated, 'authority_and_aliases': mapping,
            'current_source': scan, 'critical_translations': critical},
        'actual_D3_download': {'url': remote_url, 'status': 200,
            'bytes': len(remote_raw), 'sha256': hashlib.sha256(remote_raw).hexdigest()},
        'physical_hil': 'not_executed', 'firmware_qualification': 'unchanged original scopes',
        'limitations': ['This is a read-only review of the current six dirty acceptance source documents; final normal commit hooks/builds have their own actual receipts.',
            'Primary strict build/package and browser execution remain Source3; Source2 reader execution is preserved with actual input-equivalence proof.',
            'Current source index cannot include this supplement hash without a self-reference cycle; this review is published separately after its input source is frozen.']}
    (OUT / 'source-index-review.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': summary['status'], 'tasks': 58, 'index_proof_references': len(proofs),
        'authority_sources': mapping['sources'], 'aliases': mapping['old_urls'], 'critical_records': len(critical['records'])}))


if __name__ == '__main__':
    main()
