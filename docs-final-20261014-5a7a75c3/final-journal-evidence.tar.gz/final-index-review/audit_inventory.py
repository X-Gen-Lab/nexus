"""Audit the frozen v1 inventory and accepted task proof bytes without modifying it."""
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path('/tmp/nexus-docs-artifacts/evidence')
OUT = Path('/tmp/nexus-docs-later-evidence/final-index-review')
ARCHIVE_SHA = '1774f52c323a9544348026195db19773b483da9d053d3f55a91eb49f44b3f098'
INVENTORY_SHA = '88b4f5ee0659b56a44a57a32bcfbcb9de528b7e7dfbc63bbc890cfa350af50b4'
FINAL_REVIEW_SHA = 'f1f3bd38e8f26d28e5d65de3d0069f9d61958fe689ecd28e15e8cfa1b80d40f1'
ACCEPTED_SHA = '81ad61da91d0b1336365635f17c6452b7b13f130ce265be19b5cb1b0730fba8a'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def main():
    archive = ROOT / 'nexus-docs-evidence-20261014-source3-3835e13-v1.tar.gz'
    inventory_path = ROOT / 'EVIDENCE-INVENTORY.json'
    require(archive.stat().st_size == 107591060 and sha(archive) == ARCHIVE_SHA,
            'Frozen archive identity differs')
    require(sha(inventory_path) == INVENTORY_SHA, 'Frozen inventory differs')
    inventory = json.loads(inventory_path.read_text())
    members = {row['path']: row for row in inventory['members']}
    require(len(members) == 17117 == len(inventory['members']), 'Inventory duplicate/count')
    require('EVIDENCE-INVENTORY.json' not in members, 'Inventory hashes itself')
    expected = dict(members)
    expected['EVIDENCE-INVENTORY.json'] = {'path': 'EVIDENCE-INVENTORY.json',
        'bytes': inventory_path.stat().st_size, 'sha256': INVENTORY_SHA}
    selected = {}
    seen = set()
    with tarfile.open(archive, 'r:gz') as stream:
        for entry in stream:
            name = entry.name
            require(entry.isfile() and not entry.issym() and not entry.islnk(),
                    'Nonregular evidence member')
            require(not name.startswith('/') and '\\' not in name and
                    not any(part in ('', '.', '..') for part in name.split('/')),
                    'Unsafe evidence path')
            require(name not in seen and name in expected, 'Duplicate or extra archive path')
            seen.add(name)
            digest = hashlib.sha256()
            capture = name in {'payload/final-closure/final-review.json',
                               'payload/final-closure/accepted-task-records.json'}
            chunks = []
            with stream.extractfile(entry) as file:
                while chunk := file.read(1024 * 1024):
                    digest.update(chunk)
                    if capture:
                        chunks.append(chunk)
            require(entry.size == expected[name]['bytes'] and
                    digest.hexdigest() == expected[name]['sha256'],
                    'Actual archive member differs: ' + name)
            if capture:
                selected[name] = json.loads(b''.join(chunks))
    require(seen == set(expected), 'Missing frozen archive member')
    final_path = 'payload/final-closure/final-review.json'
    task_path = 'payload/final-closure/accepted-task-records.json'
    require(expected[final_path]['sha256'] == FINAL_REVIEW_SHA and
            expected[task_path]['sha256'] == ACCEPTED_SHA, 'Frozen final audit/task record changed')
    final = selected[final_path]
    accepted = selected[task_path]
    require(final['status'] == 'passed' and accepted['status'] == 'passed' and
            accepted['validation_scope'] == 'accepted_docs_exit', 'Wrong acceptance scope')
    require(accepted['task_count'] == len(accepted['records']) == 58,
            'Accepted task count differs')
    ids = ['DOC-' + str(number).zfill(2) for number in range(1, 59)]
    require([row['task_id'] for row in accepted['records']] == ids,
            'Accepted IDs changed or duplicated')
    task_proofs = []
    for row in accepted['records']:
        require(row['status'] == 'passed' and
                row['validation_scope'] == 'accepted_docs_exit' and row['evidence'],
                'Task lacks accepted documented exit proof')
        refs = []
        for ref in row['evidence']:
            member = ref['member_path']
            require(member.startswith('payload/') and member in members,
                    'Task proof member not actually in archive: ' + member)
            require(members[member]['sha256'] == ref['sha256'] and
                    members[member]['bytes'] == ref['bytes'], 'Task proof bytes differ')
            refs.append({'member_path': member, 'bytes': ref['bytes'],
                         'sha256': ref['sha256'], 'original_scope': ref['original_scope']})
        task_proofs.append({'task_id': row['task_id'], 'verified_proof_members': refs})
    parts = json.loads((ROOT / 'evidence-parts.json').read_text())
    whole = hashlib.sha256()
    whole_bytes = 0
    for part in parts['parts']:
        file = ROOT / part['path']
        require(part['bytes'] <= 32 * 1024 * 1024 and file.stat().st_size == part['bytes']
                and sha(file) == part['sha256'], 'Part identity differs')
        with file.open('rb') as stream:
            while chunk := stream.read(1024 * 1024):
                whole.update(chunk)
                whole_bytes += len(chunk)
    require(whole_bytes == 107591060 and whole.hexdigest() == ARCHIVE_SHA,
            'Actual ordered part join differs')
    result = {'schema_version': 1, 'kind': 'independent_frozen_v1_evidence_inventory_audit',
        'status': 'passed', 'scope': 'actual_frozen_archive_and_per_task_member_bytes',
        'archive_bytes': 107591060, 'archive_sha256': ARCHIVE_SHA,
        'inventory_sha256': INVENTORY_SHA, 'archive_members': len(seen),
        'payload_members': sum(name.startswith('payload/') for name in seen),
        'control_members': len(seen) - sum(name.startswith('payload/') for name in seen),
        'accepted_task_record_sha256': ACCEPTED_SHA, 'primary_final_review_sha256': FINAL_REVIEW_SHA,
        'actual_parts': len(parts['parts']), 'actual_ordered_join_sha256': whole.hexdigest(),
        'task_count': 58, 'records': task_proofs,
        'primary_review_or_archive_modified': False,
        'supplement_separate_from_frozen_archive': True,
        'remote_retrieval_scope': 'Separate actual remote HTTPS verification/restore receipt required; this local audit does not claim it.',
        'physical_status': 'not_executed', 'firmware_qualification': 'unchanged original scopes'}
    (OUT / 'inventory-review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('status', 'archive_members', 'payload_members', 'control_members', 'task_count')}))


if __name__ == '__main__':
    main()
