"""Bind the independently reviewed source bytes to its actual clean final commit."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/tmp/nexus-docs-implementation-source-20261014')
OUT = Path('/tmp/nexus-docs-later-evidence/final-index-review')
SOURCE = '5a7a75c321ea173df8692714f95a8df13715293d'


def require(value, message):
    if not value:
        raise ValueError(message)


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def git(*args):
    return subprocess.run(['git', '-C', str(ROOT), *args], check=True, capture_output=True).stdout


def copy_proof(source, name):
    destination = OUT / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    require(identity(source) == identity(destination), 'Copied actual evidence differs')
    return {'member_path': name, 'original_path': str(source), **identity(destination)}


def main():
    require(git('rev-parse', 'HEAD').decode().strip() == SOURCE and
            not git('status', '--porcelain=v1', '--untracked-files=all'), 'Actual final source not clean')
    prior = json.loads((OUT / 'source-index-review.json').read_text())
    for row in prior['source_files']:
        require(identity(ROOT / row['path']) == {key: row[key] for key in ('bytes', 'sha256')} and
                (ROOT / row['path']).read_bytes() == git('show', SOURCE + ':' + row['path']),
                'Actual committed source differs from independently reviewed bytes')
    require(set(git('diff-tree', '--no-commit-id', '--name-only', '-r', SOURCE).decode().splitlines()) ==
            {row['path'] for row in prior['source_files']}, 'Final commit changes beyond reviewed six docs')
    metadata = Path('/tmp/nexus-docs-final-journal-build/documentation-build.json')
    data = json.loads(metadata.read_text())
    require(data['status'] == 'passed' and data['source']['commit'] == SOURCE and
            data['source']['tree'] == git('rev-parse', 'HEAD^{tree}').decode().strip() and
            data['source']['dirty'] is False and data['languages'] == ['en', 'zh_CN'] and
            data['source_check']['status'] == 'passed' and data['qualification'] is False,
            'Actual final strict build metadata scope differs')
    proofs = [copy_proof(metadata, 'final-journal/documentation-build.json')]
    for receipt_path in data['command_receipts']:
        source = Path(receipt_path)
        receipt = json.loads(source.read_text())
        require(receipt['exit_code'] == receipt['child_returncode'] == 0 and
                receipt['stage'].startswith('documentation-'), 'Actual final build command failed')
        proofs.append(copy_proof(source, 'final-journal/' + receipt['stage'] + '-receipt.json'))
    require(len(proofs) == 5, 'Actual four stage build closure differs')
    commit_log = Path('/tmp/nexus-docs-later-evidence/final-journal-commit.log')
    require(commit_log.read_text().count('Passed') == 4 and '[codex/documentation-system-implementation-20261014 5a7a75c3]' in commit_log.read_text(),
            'Actual final normal commit hook log differs')
    proofs.extend([copy_proof(commit_log, 'final-journal/commit.log'),
        copy_proof(Path('/tmp/nexus-docs-later-evidence/final-journal-clean-build.log'), 'final-journal/clean-build.log')])
    result = {'schema_version': 1, 'kind': 'independent_final_source_commit_binding',
        'status': 'passed', 'scope': 'Actual final source commit contains the six previously independently reviewed bytes and has its own clean strict document build.',
        'source_commit': SOURCE, 'source_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'source_dirty': False, 'reviewed_source_files': prior['source_files'],
        'pre_commit_review': {'member_path': 'source-index-review.json', **identity(OUT / 'source-index-review.json')},
        'actual_normal_commit_hooks': {'format_comment_text': 'passed', 'offline_doc_source_config': 'passed',
            'google_contract_execution': 'passed', 'conventional_commit_message': 'passed'},
        'actual_clean_strict_build': 'passed', 'actual_document_build_stages': 4,
        'actual_proof_files': proofs,
        'primary_qualification_commit': '3835e13cd7da34bd75307746859d4514745ae2ff',
        'boundary': 'This final clean source/build binding supplements primary Source3 evidence. Original firmware/reader/browser receipts retain their exact identities. No new full browser run or physical MCU run is inferred.',
        'physical_hil': 'not_executed'}
    (OUT / 'final-source-binding.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': 'passed', 'actual_clean_source': SOURCE, 'reviewed_files': 6,
                     'actual_document_build_stages': 4}))


if __name__ == '__main__':
    main()
