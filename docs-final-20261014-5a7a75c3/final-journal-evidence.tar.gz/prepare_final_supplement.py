"""Seal the actual final-source reviews and published-journal QA separately."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

source = Path('/tmp/nexus-docs-later-evidence')
output = Path('/tmp/nexus-docs-final-supplement')
if output.exists():
    raise ValueError('Final supplement must use a fresh output')
output.mkdir()
chosen = {}
for path in sorted(source.glob('*.py')):
    chosen[path.relative_to(source).as_posix()] = path
chosen['browser/validate_journal.py'] = source / 'browser/validate_journal.py'
for prefix in ('final-index-review', 'browser/final-journal', 'postdeploy-final-journal'):
    for path in sorted((source / prefix).rglob('*')):
        if path.is_file():
            chosen[path.relative_to(source).as_posix()] = path
for path in sorted((source / 'final-journal-download').rglob('*')):
    relative = path.relative_to(source)
    if path.is_file() and not any(part in {'downloaded', 'independent-restoration'} for part in relative.parts):
        chosen[relative.as_posix()] = path
for name in ('final-journal-commit.log', 'final-journal-push.log',
             'final-journal-package.log', 'final-journal-publisher-assembly.log',
             'final-journal-publisher-commit.log', 'final-journal-publisher-push.log',
             'original-source-sync.json', 'verify_final_journal_download.py'):
    path = source / name
    if path.is_file():
        chosen[name] = path


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


members = []
for name, path in sorted(chosen.items()):
    if path.is_symlink():
        raise ValueError('Final proof must be a regular file')
    members.append({'path': name, 'bytes': path.stat().st_size,
                    'sha256': digest(path), 'original_path': str(path)})
archive = output / 'final-journal-evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for row in members:
                path = chosen[row['path']]
                if digest(path) != row['sha256']:
                    raise ValueError('Final proof changed while sealing')
                info = tarfile.TarInfo(row['path'])
                info.size, info.mode, info.mtime = row['bytes'], 0o644, 0
                with path.open('rb') as stream:
                    tar.addfile(info, stream)
with tarfile.open(archive, 'r:gz') as tar:
    actual = tar.getmembers()
    if len(actual) != len(members):
        raise ValueError('Final proof member count differs')
    for item, row in zip(actual, members):
        if not item.isfile() or item.name != row['path'] or item.size != row['bytes']:
            raise ValueError('Final proof member schema differs')
        with tar.extractfile(item) as stream:
            if hashlib.file_digest(stream, 'sha256').hexdigest() != row['sha256']:
                raise ValueError('Final proof member bytes differ')
for row in members:
    if digest(chosen[row['path']]) != row['sha256']:
        raise ValueError('Final proof input changed after sealing')
result = {'schema_version': 1, 'kind': 'nexus_final_documentation_journal_evidence',
          'status': 'passed', 'documentation_commit': '5a7a75c321ea173df8692714f95a8df13715293d',
          'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                      'sha256': digest(archive)}, 'members': members,
          'physical_hil': 'not_executed',
          'boundary': 'Final journal strict build/browser/public/download proofs. Source3 primary qualification, original reader scopes and v1 evidence retain their original identities.'}
(output / 'final-journal-evidence.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
package = json.loads(Path('/tmp/nexus-docs-final-journal-artifacts/package-result.json').read_text())
shutil.copyfile(package['archive'], output / Path(package['archive']).name)
if digest(output / Path(package['archive']).name) != package['archive_sha256']:
    raise ValueError('Final journal offline archive differs')
(output / 'documentation-package.json').write_text(json.dumps(package, indent=2) + '\n')
(output / 'README.txt').write_text('Nexus final documentation journal\n\nThe offline documentation archive binds clean source5a7a75c3. Its complete manifest and SHA256SUMS are inside.\nfinal-journal-evidence.json lists every member of final-journal-evidence.tar.gz with byte size and SHA-256.\nVerify the outer archive digest before reading, and verify every member without following symbolic links.\nOnly actual final-source build/browser/HTTP/download scopes are claimed; no MCU HIL is granted.\nPrimary qualification and all original failed attempts remain in the separately retained Source3 v1 evidence.\n')
print(json.dumps({'status': 'passed', 'members': len(members),
                  'archive': result['archive'], 'output': str(output)}))
