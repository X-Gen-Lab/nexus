"""Download final journal docs from actual Pages and restore them independently."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from urllib.request import urlopen
import uuid


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--documentation-commit', required=True)
    parser.add_argument('--archive-url', required=True)
    parser.add_argument('--archive-sha256', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--evidence-root', type=Path, required=True)
    args = parser.parse_args()
    root = args.source_root.resolve()
    evidence = args.evidence_root.resolve()
    if evidence.is_relative_to(root) or root.is_relative_to(evidence):
        raise ValueError('Independent output overlaps source')
    sys.path.insert(0, str(root))
    from tools.documentation import delivery
    from tools.evidence.identity import observe_git_source
    attempt = evidence / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex)
    attempt.mkdir(parents=True)
    module = root / 'tools/documentation/delivery.py'
    module_sha = hashlib.sha256(module.read_bytes()).hexdigest()
    receipt = {'schema_version':1,'kind':'independent_final_journal_pages_archive_restore',
        'status':'running','started_at':datetime.now(timezone.utc).isoformat(),
        'command':[sys.executable,*sys.argv],
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_before':observe_git_source(root),'production_module_sha256':module_sha,
        'expected_documentation_commit':args.documentation_commit,
        'expected_archive_sha256':args.archive_sha256,
        'expected_manifest_sha256':args.manifest_sha256,
        'physical_status':'not_executed','browser_execution':'not_executed_by_this_restore'}
    record = attempt / 'execution.json'
    record.write_text(json.dumps(receipt,indent=2)+'\n')
    started = time.monotonic()
    try:
        if receipt['source_before']['dirty'] or receipt['source_before']['commit'] != args.documentation_commit:
            raise ValueError('Expected clean final documentation verification source')
        command=['gh','api','repos/X-Gen-Lab/nexus/git/commits/'+args.documentation_commit]
        remote=subprocess.run(command,capture_output=True,timeout=60)
        (attempt/'remote-source-commit.json').write_bytes(remote.stdout)
        (attempt/'remote-source-commit.stderr').write_bytes(remote.stderr)
        receipt['remote_source_request']={'argv':command,'returncode':remote.returncode,
            'stdout_sha256':hashlib.sha256(remote.stdout).hexdigest()}
        if remote.returncode or json.loads(remote.stdout)['sha'] != args.documentation_commit:
            raise ValueError('Actual GitHub Source5 commit binding differs')
        archive=attempt/'downloaded-final-journal.tar.gz'; digest=hashlib.sha256(); count=0
        with urlopen(args.archive_url,timeout=60) as response, archive.open('xb') as output:
            if response.status != 200 or response.geturl() != args.archive_url:
                raise ValueError('Unexpected actual archive HTTP status or final URL')
            headers=dict(response.headers)
            while block:=response.read(1024*1024):
                count+=len(block);digest.update(block);output.write(block)
                if count > 128*1024*1024 or time.monotonic()-started > 300:
                    raise ValueError('Archive download exceeds finite size/time bound')
        if digest.hexdigest()!=args.archive_sha256:
            raise ValueError('Actual Pages archive bytes differ from expected SHA')
        if headers.get('Content-Length') is not None and int(headers['Content-Length'])!=count:
            raise ValueError('Archive actual HTTP byte count differs')
        receipt['actual_http']={'url':args.archive_url,'final_url':args.archive_url,'status':200,
            'bytes':count,'sha256':digest.hexdigest(),'headers':headers,'archive_path':str(archive)}
        verified=delivery.verify(archive,expected_manifest_sha256=args.manifest_sha256)
        destination=attempt/'independent-restoration'
        restored=delivery.restore(archive,destination,expected_manifest_sha256=args.manifest_sha256)
        if restored != verified or delivery.verify(destination,expected_manifest_sha256=args.manifest_sha256)!=restored:
            raise ValueError('Downloaded archive and independent restored closure differ')
        if (len(restored['files'])!=1600 or restored['documentation_source']['commit']!=args.documentation_commit or
                restored['physical_status']!='not_executed'):
            raise ValueError('Final documentation source/count/physical boundary differs')
        if hashlib.sha256(module.read_bytes()).hexdigest()!=module_sha:
            raise ValueError('Production restore verifier changed')
        receipt.update(status='passed',returncode=0,restored_files=1600,
            restored_directory=str(destination),documentation_source=restored['documentation_source'],
            code_source=restored['code_source'],qualified_code=restored['qualified_code'],
            archive_sha256=digest.hexdigest(),archive_bytes=count,manifest_sha256=args.manifest_sha256,
            limitations=['No Source5 tag or Release asset assertion. Actual Source5 commit was checked through GitHub API.',
                'This fresh execution verifies full download and restore bytes; browser reuse is evaluated separately and is not claimed as a new browser execution at this root.'])
        code=0
    except Exception as error:
        receipt.update(status='failed',returncode=1,error=str(error));code=1
    finally:
        receipt.update(elapsed_seconds=round(time.monotonic()-started,3),finished_at=datetime.now(timezone.utc).isoformat(),source_after=observe_git_source(root))
        if receipt['source_before']!=receipt['source_after'] or receipt['source_after']['dirty']:
            receipt.update(status='failed',returncode=1,error='Verification source changed or was dirty');code=1
        record.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':receipt['status'],'receipt':str(record),'elapsed_seconds':receipt['elapsed_seconds'],'restored_directory':receipt.get('restored_directory')}),flush=True)
    return code

if __name__=='__main__':
    raise SystemExit(main())
