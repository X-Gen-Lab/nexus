"""Write the final results index using actually retained and verified identities."""
import argparse
import hashlib
import json
from pathlib import Path
import re

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--export', type=Path, required=True)
parser.add_argument('--storage-commit', required=True)
parser.add_argument('--restore-commit', required=True)
parser.add_argument('--restore-receipt', type=Path, required=True)
args = parser.parse_args()
for value in (args.storage_commit, args.restore_commit):
    if not re.fullmatch(r'[0-9a-f]{40}', value):
        raise ValueError('Require actual full Git commit identities')
evidence = Path('/tmp/nexus-docs-final-evidence')
accepted = json.loads((evidence / 'final-closure/accepted-task-records.json').read_text())
export = json.loads((args.export / 'export-receipt.json').read_text())
inventory = json.loads((args.export / 'EVIDENCE-INVENTORY.json').read_text())
parts = json.loads((args.export / 'evidence-parts.json').read_text())
restore = json.loads(args.restore_receipt.read_text())
if any(record.get('status') != 'passed' for record in (accepted, export, restore)):
    raise ValueError('Actual accepted exits, export and remote evidence restoration must pass')
members = {row['path']: row for row in inventory['members']}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def proof(relative, scope):
    name = 'payload/' + relative
    row = members[name]
    actual = evidence / relative
    if row['sha256'] != sha(actual) or row['bytes'] != actual.stat().st_size:
        raise ValueError('Evidence inventory differs from observed original')
    return {'member_path': name, 'bytes': row['bytes'], 'sha256': row['sha256'],
            'scope': scope}


shared, tasks = {}, []
for task in accepted['records']:
    keys = []
    for item in task['evidence']:
        member = members[item['member_path']]
        if member['bytes'] != item['bytes'] or member['sha256'] != item['sha256']:
            raise ValueError('Accepted per-task evidence member differs from archive')
        key = item['key']
        item = {key: value for key, value in item.items() if key != 'key'}
        if key in shared and shared[key] != item:
            raise ValueError('Shared evidence key has contradictory scope')
        shared[key] = item
        keys.append(key)
    tasks.append({'task_id': task['task_id'], 'status': task['status'],
                  'validation_scope': task['validation_scope'], 'evidence_keys': keys})
asset_root = 'docs-evidence-20261014-source3-v1'
raw = 'https://raw.githubusercontent.com/X-Gen-Lab/nexus/'
storage = raw + args.storage_commit + '/' + asset_root + '/'
restore_url = raw + args.restore_commit + '/docs-evidence-20261014-source3-v1-restore/restore.json'
package = json.loads((evidence / 'formal-package-source3/package-result.json').read_text())
manifest = json.loads((evidence / 'formal-package-source3/documentation-manifest.json').read_text())
tool_manifest = Path('/tmp/nexus-documentation-assets-20261014/docs-20261014-3835e13cd7da/documentation-tools-parts.json')
tool = json.loads(tool_manifest.read_text())
doc_base = raw + 'd8913934e6b296e4a17e6dd50e4ae389da60309f/docs-20261014-3835e13cd7da/'
result = {
    'schema_version': 1, 'kind': 'nexus_documentation_delivery_results_index',
    'status': 'passed', 'validation_scope': 'accepted_docs_exit',
    'task_authority': 'docs/design/documentation-system-execution.csv',
    'task_authority_sha256': sha(args.source / 'docs/design/documentation-system-execution.csv'),
    'task_count': len(tasks), 'formal_evidence_required_for': [],
    'source': {'documentation_commit': manifest['documentation_source']['commit'],
               'documentation_tree': manifest['documentation_source']['tree'],
               'clean_execution_receipt': proof('formal-package-source3/documentation-build.json',
                    'Actual clean Source3 strict Doxygen/gettext/en/zh_CN build; later journal HEAD is separate.'),
               'boundary': 'This index reports the actual Source3 qualification. Later acceptance-only documents have their own build manifest and do not rewrite prior execution identities.'},
    'qualified_code_reference': manifest['qualified_code'],
    'documentation_package': {'release_id': package['release_id'],
        'manifest_sha256': package['manifest_sha256'], 'archive_sha256': package['archive_sha256'],
        'archive_bytes': 7078685, 'payload_files': 1600,
        'download_url': doc_base + package['release_id'] + '.tar.gz',
        'pages_download_url': 'https://x-gen-lab.github.io/nexus/downloads/' + package['release_id'] + '.tar.gz'},
    'evidence_delivery': {'status': 'passed', 'channel': 'immutable Git commit storage',
        'release_url': 'https://github.com/X-Gen-Lab/nexus/releases/tag/docs-20261014-3835e13cd7da',
        'storage_commit': args.storage_commit, 'retention_tag': 'docs-evidence-20261014-source3-v1',
        'archive_name': export['archive'], 'archive_sha256': export['archive_sha256'],
        'archive_bytes': export['archive_bytes'], 'parts_url': storage + 'evidence-parts.json',
        'parts_sha256': sha(args.export / 'evidence-parts.json'),
        'parts': parts['parts'], 'inventory_url': storage + 'EVIDENCE-INVENTORY.json',
        'inventory_sha256': export['inventory_sha256'], 'members': len(inventory['members']),
        'verifier_url': storage + 'VERIFY-EVIDENCE.py',
        'verifier_sha256': sha(args.export / 'VERIFY-EVIDENCE.py'),
        'export_receipt_url': storage + 'export-receipt.json',
        'export_receipt_sha256': sha(args.export / 'export-receipt.json'),
        'external_receipt_url': restore_url, 'external_receipt_sha256': sha(args.restore_receipt),
        'external_receipt_bytes': args.restore_receipt.stat().st_size,
        'excluded_duplicate_bodies': {'files': export['excluded_files'],
             'bytes': export['excluded_bytes'], 'index_url': storage + 'EVIDENCE-EXCLUSIONS.json',
             'index_sha256': export['exclusions_sha256'],
             'boundary': 'Only byte-identical remotely retained asset bodies are excluded; every receipt, failed attempt and selected original member remains intact.'},
        'boundary': 'Release attachment upload returned HTTP 401; these are actually retrieved Git objects, not Release attachments. Inventory excludes itself; archive and outer receipt are outside payload.'},
    'offline_tool_cache': {'storage_commit': 'd8913934e6b296e4a17e6dd50e4ae389da60309f',
        'parts_url': doc_base + 'documentation-tools-parts.json', 'parts_sha256': sha(tool_manifest),
        'archive_sha256': tool['sha256'], 'archive_bytes': tool['bytes'], 'parts': tool['parts'],
        'archive_members': 75, 'locked_configuration_members': 2,
        'qualified_tuple': 'Linux x86_64 / CPython 3.12',
        'actual_installation': proof('tool-install/installation.json', 'Actual locked native ELF, font, Python and license closure installation; the remote cache was independently retrieved and validated.')},
    'actual_scope_receipts': {
        'clean_source_build': proof('formal-package-source3/documentation-build.json', 'Clean Source3 strict bilingual build.'),
        'normal_commit_gates': proof('pages-hidden-fix/normal-gates/receipt.json', 'Actual normal pre-commit staged two-file correction at parent3835; 3252 Google cases and 1555 tool cases; not a fresh clean63d64 firmware qualification.'),
        'browser_desktop_narrow_zoom_print': proof('browser/final-source3/acceptance-summary.json', 'Source3 actual162 checks, 22 PDFs, 32 blocks/800 lines, original18 visual pages.'),
        'published_site_and_download': proof('postdeploy-source3/20261014T101418Z-72db5d74ff344aef97934b8e76c5c144/production-post-deploy.json', 'Actual1895 public HTTP observations,1600payload and290root gateways plus stable/downloads.'),
        'independent_download_restore': proof('git-assets-restore/20261014T101842Z-00ee87ce697a4d38870a7d4f9b3a5e4a/execution.json', 'Real fixed-commit HTTPS retrieval,1600files restored,75tool archives and2configs verified.'),
        'restored_browser': proof('browser/remote-restored-source3/acceptance-summary.json', 'Another actual162 browser records and22newPDF completeness checks in remote-restored independent root; original18visual pages reused only through exact render-input SHA equivalence.'),
        'final_independent_review': proof('final-closure/final-review.json', 'All58 original documentation exits accepted with original execution scopes preserved.'),
        'accepted_task_records': proof('final-closure/accepted-task-records.json', 'Full per-task original exit and actual proof member identities; each listed member verified after real archive retrieval.')},
    'evidence': shared, 'tasks': tasks,
    'retention': {'status': 'remote_retrieved_and_verified', 'channel': 'immutable Git commit objects',
        'policy': 'Preserve release and evidence tags, prior version paths and original Git assets. Add new identities; do not force-replace retained objects. Keep a verified independent copy using the download instructions.',
        'restoration_scope': 'Actual public remote retrieval into a new independent filesystem root; no claim of a second physical-machine exercise or provider permanence.'},
    'limitations': {'browser_tuple': 'Chromium151 on Linux',
        'file_uri': 'not_executed: existing enterprise Chromium policy blocksfile://; policy unchanged; actual localHTTP and server-stopped browser-offline byte reads passed',
        'translation': 'Critical pages/navigation reviewed; other pages retain accurate original/missing/stale states.',
        'environment_branch_policy_api': '403; existing github-pages policy unchanged. Publisher is guarded by exact repository/ref, a reviewed prepared payload and separate minimal permissions.'},
    'physical_hil': {'status': 'not_executed', 'changed_by_documentation': False},
    'qualification_boundary': 'Accepted documentation exits and their original actual scopes only. Original firmware/SoC qualification stays bound to its exact sources; no physical MCU HIL is granted.'}
if len(tasks) != 58 or any(task['status'] != 'passed' for task in tasks):
    raise ValueError('Expected all58 actually accepted documentation exits')
destination = args.source / 'docs/status/documentation-results.json'
destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': 'written', 'tasks': len(tasks), 'shared_evidence': len(shared),
                  'index_sha256': sha(destination)}))
