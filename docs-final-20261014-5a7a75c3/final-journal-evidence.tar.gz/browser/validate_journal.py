"""Read-only actual browser acceptance of three changed final journal pages."""
from __future__ import annotations
import argparse,csv,hashlib,importlib.util,json,mimetypes,re,subprocess,threading
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote,urlsplit
from playwright.sync_api import sync_playwright

PAGES=('status/documentation-acceptance','design/documentation-improvements',
       'status/ledgers/documentation-system')
QUALIFIED='3835e13cd7da34bd75307746859d4514745ae2ff'
IDS={f'DOC-{number:02d}' for number in range(1,59)}

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args):pass

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(site):
    values={str(p.relative_to(site)):sha(p) for p in sorted(site.rglob('*')) if p.is_file()}
    return values,hashlib.sha256(json.dumps(values,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--site',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--expected-source',required=True)
    args=parser.parse_args();site=args.site.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    identity=json.loads((site/'documentation-build.json').read_text())
    if identity['status']!='passed' or identity['source']['commit']!=args.expected_source or identity['source']['dirty'] is not False:
        raise ValueError('matching clean final-journal build identity required')
    helper_path=Path('/tmp/nexus-docs-final-evidence/browser/validate_site.py')
    spec=importlib.util.spec_from_file_location('qualified_browser_helpers',helper_path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    before,before_hash=inventory(site)
    report={'schema_version':1,'status':'pending','source':args.expected_source,'site':str(site),
        'scope':'Meaningful actual browser and print checks of three changed final-journal pages',
        'script_sha256':sha(Path(__file__)),'helper_sha256':sha(helper_path),'records':[],'errors':[],
        'external_requests':[],'page_errors':[],'downloads':[],'print_headers_footers':False,
        'file_uri_status':'not executed due existing managed Chromium policy; localhost and stopped-server hard-offline byte reader actually executed'}
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(site)))
    threading.Thread(target=server.serve_forever,daemon=True).start();base=f'http://127.0.0.1:{server.server_port}'
    def route_local(route):
        if route.request.url.startswith(base+'/'):route.continue_()
        else:report['external_requests'].append(route.request.url);route.abort()
    def meaningful(page,name):
        text=page.locator('.nexus-canonical-content').inner_text()
        if name==PAGES[0]:
            if '58 项任务已按原退出条件完成独立验收' not in text or QUALIFIED not in text:
                report['errors'].append(name+': missing accepted58 or preserved Source3 identity')
            if 'not_executed' not in text or 'HIL' not in text or '后续台账和交付索引提交' not in text:
                report['errors'].append(name+': missing no-new-HIL/later-journal boundary')
        elif name==PAGES[1]:
            tables=page.locator('.nexus-canonical-content table').evaluate_all(
                '(tables)=>tables.map(t=>[...t.querySelectorAll("tr")].map(r=>[...r.querySelectorAll("th,td")].map(c=>c.innerText.trim())))')
            if not any(['implemented','passed','58'] in rows for rows in tables):
                report['errors'].append(name+': accepted58 summary absent')
            found=set(re.findall(r'DOC-\d{2}',text))
            if found!=IDS:report['errors'].append(name+': task IDs incomplete')
        else:
            records=page.locator('.nexus-canonical-content table').evaluate_all('''tables=>tables.map(t=>Object.fromEntries(
                [...t.querySelectorAll('tr')].filter(r=>r.querySelectorAll('td').length===2).map(r=>
                [...r.querySelectorAll('td')].map(c=>c.innerText.trim())))).filter(r=>r.task_id)''')
            if len(records)!=58 or {r['task_id'] for r in records}!=IDS or any(
                r.get('validation_status')!='passed' or r.get('implementation_status')!='implemented' for r in records):
                report['errors'].append(name+': actual58 implemented/passed rows differ')
        return {'characters':len(text),'task_ids':sorted(set(re.findall(r'DOC-\d{2}',text))),
                'preserved_source3':QUALIFIED in text}
    try:
      with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,
            args=['--no-sandbox','--disable-dev-shm-usage','--disable-background-networking'])
        report['browser']=browser.version
        for mode,size,dpr in [('desktop',{'width':1440,'height':1000},1),('narrow',{'width':390,'height':844},1),
                             ('zoom200',{'width':1440,'height':1000},1),('reflow200',{'width':720,'height':500},2)]:
            context=browser.new_context(viewport=size,device_scale_factor=dpr);context.route('**/*',route_local)
            page=context.new_page();page.on('pageerror',lambda e:report['page_errors'].append(str(e)))
            session=context.new_cdp_session(page)
            for lang in ('en','zh_CN'):
                for name in PAGES:
                    response=page.goto(base+'/'+lang+'/'+name+'.html',wait_until='networkidle')
                    if mode=='zoom200':session.send('Emulation.setPageScaleFactor',{'pageScaleFactor':2})
                    g=helper.geometry(page)
                    if response.status!=200 or (mode!='zoom200' and g['scroll_width']>g['width']+1):
                        report['errors'].append(f'{mode}/{lang}/{name}: status or whole-page overflow')
                    if g['actual_lang'] not in {'zh_CN','zh-CN'} or g['translation']!=('original' if lang=='zh_CN' else 'missing'):
                        report['errors'].append(f'{mode}/{lang}/{name}: actual-language fallback mislabeled')
                    if mode=='zoom200' and g['visual_scale']!=2:report['errors'].append('200% zoom not observed')
                    record={'mode':mode,'language':lang,'page':name,**g,**meaningful(page,name)}
                    if lang=='zh_CN' and name==PAGES[0]:
                        file=out/(mode+'-acceptance.png');page.screenshot(path=str(file));record['screenshot']=file.name
                    report['records'].append(record)
            context.close()
        context=browser.new_context(viewport={'width':1440,'height':1000});context.route('**/*',route_local)
        page=context.new_page();page.on('pageerror',lambda e:report['page_errors'].append(str(e)))
        for lang in ('en','zh_CN'):
            for name in PAGES:
                page.goto(base+'/'+lang+'/'+name+'.html',wait_until='networkidle')
                file=out/('print-'+lang+'-'+name.replace('/','-')+'.pdf')
                page.pdf(path=str(file),format='A4',display_header_footer=False,print_background=True,
                    margin={'top':'12mm','bottom':'12mm','left':'12mm','right':'12mm'})
                codes=helper.print_code_completeness(site/lang/(name+'.html'),file)
                extracted=subprocess.run(['pdftotext','-layout',str(file),'-'],check=True,capture_output=True,text=True).stdout
                if name==PAGES[0] and QUALIFIED not in extracted:report['errors'].append('printed acceptance loses qualification SHA')
                if name==PAGES[2] and set(re.findall(r'DOC-\d{2}',extracted))!=IDS:report['errors'].append('printed ledger loses task IDs')
                if '\ufffd' in extracted:report['errors'].append('printed replacement character')
                report['records'].append({'mode':'print','language':lang,'page':name,'pdf':file.name,
                    'sha256':sha(file),'bytes':file.stat().st_size,'code_completeness':codes})
        page.goto(base+'/zh_CN/'+PAGES[0]+'.html',wait_until='networkidle')
        for fragment in ['documentation-results.json','documentation-system-execution.csv']:
            anchor=page.locator('a.reference.download.internal[href*="'+fragment+'"]').first
            href=anchor.get_attribute('href')
            with page.expect_download() as info:anchor.click()
            download=info.value;raw=Path(download.path()).read_bytes()
            url=urlsplit(base+'/zh_CN/'+PAGES[0]+'.html')
            from urllib.parse import urljoin
            relative=unquote(urlsplit(urljoin(page.url,href)).path).lstrip('/')
            if raw!=(site/relative).read_bytes():report['errors'].append('actual download bytes differ '+fragment)
            if fragment.endswith('.json'):
                value=json.loads(raw)
                if value['task_count']!=58 or value['source']['documentation_commit']!=QUALIFIED or value['physical_hil']['status']!='not_executed' or len(value['tasks'])!=58 or any(t['status']!='passed' for t in value['tasks']):
                    report['errors'].append('downloaded index scope/status/identity differs')
            else:
                values=list(csv.DictReader(raw.decode().splitlines()))
                if len(values)!=58 or {v['task_id'] for v in values}!=IDS or any(v['validation_status']!='passed' for v in values):report['errors'].append('downloaded CSV58 differs')
            report['downloads'].append({'name':fragment,'actual_url':urljoin(page.url,href),'payload_member':relative,
                'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'actual_click_download':True})
        for path in ['index.html','api/hal.html','api/osal.html']:
            page.goto(base+'/'+path,wait_until='networkidle');text=page.locator('body').inner_text()
            if path=='index.html':
                if args.expected_source not in text or 'Physical HIL: not executed' not in text:report['errors'].append('root identity/HIL boundary missing')
            elif 'historical API contract' not in text:report['errors'].append(path+': historic contract recall missing')
            report.setdefault('root_and_historical_routes',[]).append({'path':path,'actual_text':text})
        context.close()
        offline=browser.new_context(viewport={'width':390,'height':844},offline=True);reads=[]
        def local_bytes(route):
            u=route.request.url
            if not u.startswith(base+'/'):report['errors'].append('offline external '+u);route.abort();return
            relative=unquote(urlsplit(u).path).lstrip('/');path=(site/relative).resolve()
            if not path.is_relative_to(site) or not path.is_file():report['errors'].append('offline unsafe/missing '+relative);route.abort();return
            raw=path.read_bytes();reads.append({'member':relative,'sha256':hashlib.sha256(raw).hexdigest()})
            route.fulfill(body=raw,content_type=mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
        offline.route('**/*',local_bytes);page=offline.new_page();server.shutdown();server.server_close()
        for lang in ('en','zh_CN'):
            for name in PAGES:
                page.goto(base+'/'+lang+'/'+name+'.html',wait_until='networkidle');g=helper.geometry(page)
                if g['scroll_width']>g['width']+1:report['errors'].append('offline whole-page overflow')
                report['records'].append({'mode':'hard-offline-byte-reader','language':lang,'page':name,**g,**meaningful(page,name)})
        report['offline_reads']=reads;offline.close();browser.close()
    finally:
        server.shutdown();server.server_close()
    after,after_hash=inventory(site)
    if before!=after:report['errors'].append('package mutated during supplemental audit')
    if report['external_requests'] or report['page_errors']:report['errors'].append('external request/pageerror')
    report.update(payload_read_only=before==after,payload_files=len(after),payload_inventory_sha256=after_hash,
        status='failed' if report['errors'] else 'passed')
    path=out/'journal-browser-report.json';path.write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'records':len(report['records']),'errors':report['errors'],
        'report_sha256':sha(path)},ensure_ascii=False));return bool(report['errors'])

if __name__=='__main__':raise SystemExit(main())
