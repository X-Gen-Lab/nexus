"""Reviewed English labels for canonical Chinese diagrams; unchanged topology."""
import json
import re
from pathlib import Path
from tools.documentation.diagrams import LABEL

ROOT = Path('/workspace/nexus-build-system-20261012/docs/assets/diagrams')
GROUPS = {
'build-targets.dot': [
'FIG-02 H743 / baremetal / IRQ UART: selected target dependencies\nArrow: dependent -> dependency, not a runtime call',
'External firmware\nnexus_add_firmware()',
'firmware_nexus_startup\nOBJECT: official startup + owned system',
'Nexus::Platform\ngenerated bindings.c',
'nexus_soc_stm32h743\nselected GPIO / UART drivers',
'Nexus::IO','Nexus::Arch','Nexus::Core','Nexus::OSBaremetal','Nexus::OSWait',
'nexus_abi_options\nselected by the frozen CPU profile',
'Nexus::Config\ngenerated includes / ABI / build policy',
'Vendor CMSIS headers\nSYSTEM PRIVATE include',
'PRIVATE link','PRIVATE: selected backend','OBJECT injection','PUBLIC link',
'PRIVATE include','INTERFACE link'],
'continuous-stream.dot': [
'FIG-15 STM32F407 USART1 continuous RX: caller-owned block loans\nDMA2 stream2 channel4; two targets + at least one replacement block',
'Block states and token (slot + monotonic epoch)',
'FREE: available for the next producer target',
'FILLING: two hardware targets + pending replacement loan\nHardware may still write; do not lend to consumers',
'READY: old address detached from every hardware target\nImmutable payload with boundary / loss flags',
'BORROWED: consumer acquire\nRelease the matching token after final use',
'Preposted reserve / explicit DMA-domain validation',
'FIFO publish: old block proven detached','Consumer acquire',
'Matching release; stale/double release cannot alter the loan',
'DMA TC IRQ: reserve a third FREE block\nReplace the completed inactive target',
'Prove both target addresses / CT / EN\nNo new TC or error; old address fully removed',
'No FREE block / abnormal CT / new error\nWithdraw RX source immediately; actually disable/drain',
'Disable not proven: retain all producer loans\nBounded task-service retries; do not reclaim consumer loans',
'After drain, publish a reliable positive-length prefix / LIFO-abort future loans\nRecord observable loss / stop gaps; do not guess lost bytes',
'Budget: IRQ + target replacement < one block fill time\nConsumer frontier-release delay determines block count\nTC cannot recover arbitrarily coalesced wraps',
'rx_stop closes admission; no rearm\nDrain source + engine, release consumer loans, outstanding=0\nObservers and callers must also exit before reuse',
'TC is a boundary hint','Replacement block exists','Every proof holds',
'Cannot replace','Any proof fails','Write source not drained',
'Actual write source drained','Reliable prefix and flags',
'Measure worst latency on hardware','Check success after loans return',
'Explicit stop path'],
'cortex-m-capabilities.dot': [
'FIG-13 Cortex-M software capabilities and actual platform integration\nCore name grants no FPU / cache / MPU / security-domain / HIL qualification',
'Explicit CPU facts\nM0 / M0+ / M3 / M4 / M7 / M23 / M33 / M55 / M85\nABI / DSP / FPU / MVE / cache / MPU / DWT / security / IRQ',
'Strict CpuProfileIR\nLegal capability combinations, ABI and exact kernel port',
'Arch / Core primitives\nMasks, atomics, barriers, explicit cache / MPU / SAU\nCold cache control is maintained for M7 only',
'Nexus::Runtime\nCore + Arch + typed I/O faces + baremetal / FreeRTOS\nNo SoC / Board / startup / linker / factory',
'Nexus::Platform: actual SoC + Board assembly\nF407/F470 initial platforms; limited G474/H743/U575 reference slices\nDevice ops / IRQ / clock / DMA and resources require separate integration',
'External product / boot owner\nTasks, mappings, secure boot, private layout and recovery',
'Independent software scope\nHost/model execution and actual ARM/runtime variant compilation',
'Actual CPU / SoC / PCB station\nContext retention, cache/DMA, MPU/SAU, latency\nWithout hardware: not_executed',
'Check actual silicon facts','Select compile-time mechanisms',
'Select production targets / port','Public mechanisms',
'Full platform additionally requires SoC/Board facts',
'Explicit calls and responsibilities','External assembly / policy',
'Actual gate','Selected whole-image gate','Independent physical acceptance',
'Exact real-silicon acceptance'],
'dma-completion.dot': [
'FIG-07 STM32F407 finite DMA completion order\nTop-to-bottom order; task service and IRQ separate; cancellation retains borrow',
'USART1 TX: DMA2 stream7 channel4',
'Task: validate submit / admit\nACCEPTED borrows request + payload',
'Task: configure TX DMA / UART DMAT\nDMA writes UART DR; UART shifts bits onto the wire',
'DMA IRQ: observe TC / NDTR / errors\nWithdraw DMAT and DMA source; observe actual EN',
'UART IRQ: independently observe real TC\nLatch wire completion and deadline facts',
'Task service: drain EN / IRQ source / TC\nFinal error observation; detach active references',
'Final release-publication of SETTLED\nTask acquire-observes and reads final result/count',
'UART cancel / deadline / DMA error\nWithdraw DMAT / DMA source; retain request and payload',
'UART drain not proven: QUARANTINED\nRetain DMA / IRQ / execution and recovery responsibility',
'Termination event','Only after actual UART drain is established',
'Budget exhausted without proven drain','Valid admission',
'DMA phase complete, not wire TC','TC only after the final serial bit leaves',
'Executor explicitly advances','All necessary references detached',
'SPI1: RX stream0 / TX stream3, DMA2 channel3',
'Task: admit + select endpoint\nExclusive TX/RX buffers and controller',
'Task: enable RX before TX\nBidirectional DMA progress; retain CS',
'Two DMA IRQs: observe each TC separately\nDisable each engine / IRQ source separately',
'Task service: actual BSY=0 and TXE=1\nBoth engines drained; check late errors',
'Task: withdraw SPI DMA/SPE, clear state\nIssue CS release; detach active/endpoint references',
'SPI cancel / deadline / DMA error\nWithdraw both DMA and SPI write sources; retain request / buffers',
'SPI drain not proven: QUARANTINED\nRetain engines / IRQ / CS and recovery responsibility',
'Check actual SPI / both-engine drain','RX/TX complete separately',
'TC does not replace peripheral idle','Drain conditions established',
'Final provider access'],
'documentation-target.dot': [
'FIG-12 supplement: original documentation-system target design',
'One Markdown / RST prose source','Current public C headers',
'Existing facts / ledgers / software and HIL records',
'gettext / PO: actual translation state','Reviewable DOT source',
'Content, link and example checks with independent review',
'Public-only Doxygen XML','Read-only derived support / qualification views',
'Local SVG: rendering and resource checks','Strict MyST / Sphinx / Breathe build',
'HTML / search / diagrams / language entry','Identity and documentation-package verification',
'Immutable version / stable documentation entry',
'Relative-link offline package / verification / licenses',
'Actual post-deployment check / independent restoration',
'Review current prose','Generate API','Preserve separate qualification identities',
'Render with locked tools','Admitted prose','XML from this build',
'Admitted status views','Language and review state','Diagrams and provenance',
'Successful output from this build','Bind code / docs / qualified source',
'Actual deployment','Seal documentation package','Check online identity',
'Retrieve, browse and verify'],
'h743-memory-cache.dot': [
'FIG-09 STM32H743ZIT6: finite UART TX DMA and cache\nOnly AXI SRAM selected for initial linker / TX domain; no RX DMA claim',
'SoC physical-domain facts do not authorize placement',
'Cortex-M7 CPU\nSelected D-cache off / on',
'AXI SRAM: 0x24000000 / 512 KiB\nOnly initial linker and TX payload domain',
'USART3 TX\nDMA1 stream0 / DMAMUX request46',
'ITCM 64 KiB / DTCM 128 KiB\nUnreachable by DMA1/2; physically reachable by MDMA\nNot selected by the initial linker',
'D2 SRAM1/2/3, D3 SRAM4, backup\nReachability recorded separately per dma_engines\nNot selected by the initial linker',
'Load / store, possibly through cache','DMA reads actual SRAM bytes',
'Physical CPU path','Physical domain, unauthorized for this TX',
'Cache-on: exclusive borrow of every complete 32-byte line',
'Validate AXI domain / overflow / exclusive complete lines\n32-byte address alignment; length a multiple of 32, <=65504',
'Admit -> provider PREPARING marker\nBorrow already established; cancel cannot reclaim',
'Clean + barriers under the normal incoming mask\nNo outward rounding or bounce buffer',
'Recheck cancel / deadline / policy\nConfigure and start DMA only if not terminated',
'Prove DMA / UART wire / IRQ references drained\nOnly then make final observation and publish SETTLED',
'Clean / detach failed or incomplete\nRetain borrow; advance the actual termination path',
'Admission passed','Long maintenance outside a long IRQ mask',
'Maintenance complete','Actual completion / drain','Rejection / failure',
'Drain cannot be proven','Selected DMA TX domain'],
'platform-lifecycle.dot': [
'FIG-05 Generated Platform explicit cold lifecycle\nOne external privileged task owner advances serially',
'Cold object: no successful running permission',
'Check context / started\nReject ISR and masks; physical implementation checks privilege',
'SoC start_system / start_resources\nExact cold clock, timebase, pin-lease prerequisites',
'Initialize instances in declaration order\nCount potentially effectful attempts before calling for cleanup',
'start primary=SUCCESS\nExternal application may operate; no scheduler start',
'Externally close producers / direct writers first\nExecutor continues draining; join callers and observers',
'nx_platform_stop: stop initialized instances in reverse order\nDecrease initialized count only after each successful step',
'Provider stop_system\nRestore owned pin / gate / timebase / cache effects',
'stop=SUCCESS: remaining effects released\nDoes not promise continued active product-safe output drive',
'Initialization error: retain primary\nCall nx_platform_stop to collect cleanup outcome',
'BUSY / IO: retain uncleaned leases and storage\nMay be partially stopped; continue required service, then retry',
'Explicit start','Rejected: preserve existing lifecycle and effects\nNo newly authorized operational calls',
'Context / STATE error','Prerequisites passed','Stage succeeded',
'Failure after effects acquired','All succeeded','Any failure',
'Reverse cleanup including the effectful failed instance',
'Product decides to stop','Stop-call prerequisites satisfied',
'All instances released','First uncleaned effect encountered',
'Observe successful cleanup','System cleanup failed',
'Retry the actual retained stage\nNo forced timeout reclamation',
'New epoch / new lifecycle'],
'platform-runtime.dot': [
'FIG-01 supplement: current runtime access','External product project',
'Application: resources, scheduling, execution progress','Nexus reusable platform',
'Typed factory: lookup of existing instances','Public face: readonly ops + context',
'Optional owner / execution adapter','Optional OS / wait-wake',
'SoC provider: private instance state','Core: request, deadline, epoch',
'Arch: compile-time CPU primitives','Selected controller / IRQ / DMA',
'Obtain interface','Return existing reference','Direct I/O after successful start',
'Optional shared path','Executor port uses interface',
'Explicit task and wait selection','Selected wait / wake adaptation',
'Lifecycle and stable slots','Request and time contracts',
'Direct CPU primitive call','ops(context, ...)','Drive selected hardware mode'],
'qualification-evidence.dot': [
'FIG-11 Separate software, fixture and physical qualification\nEvery conclusion binds source / config / artifact / execution scope',
'Clean source / dependency / toolchain / config\nIdentical ELF / BIN / map bytes',
'Host / model\nActual GoogleTest/GoogleMock + tool tests\nSoftware evidence for algorithms and failure paths',
'ARM compile / link / resources\nActual instructions, ABI, layout and budgets',
'Independent Source SDK consumer\nRelocated prefix, actual build/run or link',
'Two independent network-disabled clean builds\nSame ELF/BIN bytes, original commands and tool identities',
'HIL fixture / station / protocol tooling\nSoftware checks for boundaries and negative paths',
'Scope proof + candidate seal\nUnsigned software candidate retaining original evidence',
'Actual station: PCB / silicon / probes / wires\nFlash the same image, then measure and inject faults',
'Record physical results only for actually executed cases\nWithout equipment: not_executed',
'Product admission under actual software + physical scope\nRelease / safety certification decided by external policy',
'Actual execution','Verify evidence','Fixture scope, not physical measurement',
'Same image supplied to actual equipment','Only actual station results',
'Software scope','Independent review of physical scope'],
'u575-security-domains.dot': [
'FIG-14 U575 TZEN=1: no-OS synchronous GPIO dual-domain reference\nIndependent Secure / NS images, not default TZEN0 Platform',
'External boot / provisioning owner\n2 MiB, bank1 Secure, bank2 NS pages\nSupplies layout/vectors/options; mechanism never writes option bytes',
'Secure cold owner: no active worlds / IRQ / DMA\nSRAM1 Secure; zero future NS SRAM3 before declassification\nGTZC/MPCBB + SAU 3 spans + NS MPU\nRead/clear actual 8 or 16 regions, lock and read back',
'Any error after admission: FAILED + effects\nIrreversible attribution retained until reset; no rollback',
'READY -> RUNNING -> actual CMSE entry\nNS unprivileged Thread; unexpected return fail-stops',
'NonSecure: static mappings, no RTOS / handlers / autonomous masters',
'NS caller + explicit NS RAM request/output\nFixed world principal; do not trust message task IDs',
'NS receives synchronous return\nFinal access to input/output storage has exited',
'Secure privileged Thread: exclusive synchronous gateway',
'Actual SG: validate NS caller / Thread / RUNNING\nSave and mask NS interrupts',
'Constrain explicit NS RAM span + CMSE unprivileged check\nSynchronous pin under static attribution and no concurrency',
'Bounded input copy to Secure snapshot\nFixed PC7 grant, output spans prevalidated',
'UserIoBroker: scalar GPIO read / set-reset\nNo arbitrary MMIO / callbacks / asynchronous DMA grant',
'Final output copy -> unpin -> restore NS mask\nCleanup never replays GPIO; impossible release failure terminates',
'Actual prerequisites and parameters before entry',
'Read back all permissions / locks / vectors','Failure after acquiring effects',
'Enter NS unprivileged Thread','Synchronous SG call',
'Actual principal and serialization prerequisites',
'Pin succeeded; a check alone does not pin','Authorized and output prevalidation passed',
'Single result, no automatic replay','Synchronous return'],
}

ZH = {
'PRIVATE link':'PRIVATE 链接','PUBLIC link':'PUBLIC 链接',
'INTERFACE link':'INTERFACE 链接','PRIVATE include':'PRIVATE 包含',
'consumer acquire':'消费者 acquire',
'const UART face A\nops* + context*':'只读 UART face A\nops* + context*',
'const UART face B\nops* + context*':'只读 UART face B\nops* + context*',
'fresh initialize':'首次初始化',
'release publication → acquire observation':'release 发布 → acquire 观察',
}

def main():
    en, zh = {}, {}
    for path in sorted(ROOT.glob('*.dot')):
        labels = list(dict.fromkeys(LABEL.findall(path.read_text())))
        if path.name in GROUPS:
            assert len(labels) == len(GROUPS[path.name]), (path, len(labels), len(GROUPS[path.name]))
            en.update(zip(labels, GROUPS[path.name]))
        else:
            for raw in labels:
                lines = raw.replace('\\n', '\n').splitlines()
                target = '\n'.join(line for line in lines if not re.search(r'[\u3400-\u9fff]', line))
                if re.search(r'[\u3400-\u9fff]', raw):
                    assert target, (path, raw)
                else:
                    target = raw.replace('\\n', '\n')
                en[raw] = target
        for raw in labels:
            decoded = raw.replace('\\n', '\n')
            lines = decoded.splitlines()
            cjk = [i for i, line in enumerate(lines) if re.search(r'[\u3400-\u9fff]', line)]
            if cjk and path.name not in GROUPS:
                translated = '\n'.join(lines[:cjk[-1] + 1])
            else:
                translated = ZH.get(decoded, decoded)
            zh[raw] = translated
    mapping = {'schema_version': 1, 'en': en, 'zh_CN': zh}
    assert set(en) == set(zh)
    assert not any(re.search(r'[\u3400-\u9fff]', value) for value in en.values())
    (ROOT / 'labels.json').write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + '\n')
    print(len(en), 'labels in both languages')

if __name__ == '__main__':
    main()
