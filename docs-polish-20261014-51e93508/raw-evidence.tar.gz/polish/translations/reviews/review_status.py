"""Record independent semantic/structure review of authored status catalogs."""

from collections import Counter
from pathlib import Path
import hashlib
import json
import re
import polib


SOURCE = Path('/workspace/nexus-build-system-20261012')
POTS = Path('/tmp/nexus-docs-polish-20261014/gettext/status')
REVIEW = Path(__file__).parent
MAPPING = Path('/tmp/nexus-docs-polish-20261014/translations/status/mapping.json')
authored = json.loads(MAPPING.read_text(encoding='utf-8'))
errors = []
records = []


def codes(text):
    return Counter(token for token in re.findall(r'(?<!`)`([^`]+)`(?!`)', text)
                   if '<' not in token)


for pot_path in sorted(POTS.rglob('*.pot')):
    name = 'status/' + str(pot_path.relative_to(POTS).with_suffix(''))
    source = SOURCE / 'docs' / (name + '.md')
    source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    pot = polib.pofile(str(pot_path))
    for language in ('en', 'zh_CN'):
        path = SOURCE / 'docs/locale' / language / 'LC_MESSAGES' / (name + '.po')
        po = polib.pofile(str(path))
        if len(po) != len(pot) or set(e.msgid for e in po) != set(e.msgid for e in pot):
            errors.append({'catalog': str(path), 'issue': 'POT message set'})
        if len({e.msgid for e in po}) != len(po):
            errors.append({'catalog': str(path), 'issue': 'duplicate msgid'})
        if po.metadata.get('X-Nexus-Source-SHA256') != source_hash:
            errors.append({'catalog': str(path), 'issue': 'source digest'})
        if po.metadata.get('Language') != language:
            errors.append({'catalog': str(path), 'issue': 'language'})
        changes = 0
        for entry in po:
            if not entry.msgstr or 'fuzzy' in entry.flags or entry.obsolete:
                errors.append({'catalog': str(path), 'message': entry.msgid, 'issue': 'incomplete'})
            expected = authored[language].get(entry.msgid, entry.msgid)
            if entry.msgstr != expected:
                errors.append({'catalog': str(path), 'message': entry.msgid, 'issue': 'authored mapping mismatch'})
            for label, pattern in (
                ('link target', r'\]\(([^)]+)\)'),
                ('hash identity', r'\b[0-9a-f]{32,64}\b'),
                ('raw status', r'(?<![A-Za-z0-9_])(?:not_executed|not_implemented|development_passed|qualification_record_authority|prepared_unbound|ACCEPTED|REJECTED|SETTLED|QUARANTINED)(?![A-Za-z0-9_])'),
            ):
                if Counter(re.findall(pattern, entry.msgid)) != Counter(re.findall(pattern, entry.msgstr)):
                    errors.append({'catalog': str(path), 'message': entry.msgid, 'issue': label})
            if codes(entry.msgid) != codes(entry.msgstr):
                errors.append({'catalog': str(path), 'message': entry.msgid, 'issue': 'inline code identity'})
            changes += entry.msgstr != entry.msgid
        records.append({'docname': name, 'locale': language, 'messages': len(po),
                        'changed_messages': changes, 'source_sha256': source_hash,
                        'catalog': str(path.relative_to(SOURCE))})

receipt = {
    'reviewer': '/root/docs_translate_delivery',
    'author': '/root/docs_translate_status',
    'scope': 'Independent semantic review of all authored status translations and structural verification of every extracted message in both locales.',
    'semantic_review': {
        'unique_authored_messages_read_in_full': {lang: len(values) for lang, values in authored.items()},
        'method': 'Read each canonical msgid beside the authored msgstr; check obligations, rejection, retained borrow, exact identity, historical execution, software/HIL scope, source authority and original exit-field meaning. Follow up six precise wording corrections with the author and reread their final PO entries.',
        'corrections': [
            'Unreviewed barrier removal is the prohibited action, not removal of barriers that happen to be unreviewed.',
            'Product secure updates are distinct from safety-level upgrades.',
            'SETTLED marks final provider access rather than being an access action.',
            'MPU and split-security modes remain independent entries.',
            'Each of the two complete ThreadX TSan executions has 62 cases.',
            'Old-timeout reproduction qualifies the eight fail-stop cases, not the preceding 224 fixture-lifetime executions.',
        ],
        'preserved_boundaries': ['Raw CSV fields and statuses', 'Original source/configuration/tool/artifact identities', 'Failed attempts', 'Original task IDs and exit conditions', 'Software qualification versus physical HIL', 'No current documentation HEAD inheritance'],
    },
    'structural_review': {'catalogs': len(records), 'messages': sum(x['messages'] for x in records), 'errors': errors},
    'catalogs': records,
    'result': 'passed' if not errors else 'failed',
    'new_firmware_or_hardware_qualification': False,
}
if not errors:
    for record in records:
        path = SOURCE / record['catalog']
        po = polib.pofile(str(path))
        po.metadata['X-Nexus-Reviewed'] = 'true'
        po.header = 'Authored translation; independently semantically reviewed.'
        po.save(str(path))
        record['reviewed'] = True
        record['catalog_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
REVIEW.mkdir(parents=True, exist_ok=True)
(REVIEW / 'status.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'result': receipt['result'], 'catalogs': len(records),
                  'messages': sum(x['messages'] for x in records), 'errors': errors}, ensure_ascii=False, indent=2))
raise SystemExit(bool(errors))
