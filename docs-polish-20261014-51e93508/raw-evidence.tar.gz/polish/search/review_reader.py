"""Independent reader-catalog corrections with protected code/link identities."""
from pathlib import Path
import hashlib
import json
import re
import sys
sys.path.insert(0,'/workspace/nexus-build-system-20261012')
from tools.documentation.sphinx_ext import read_catalog,source_language
ROOT=Path('/workspace/nexus-build-system-20261012')
BASE=Path('/tmp/nexus-docs-polish-20261014/translations/reader')
POTS=Path('/tmp/nexus-docs-polish-20261014/gettext')
import polib
WORDS={
'result/count':'result/count','COUNT':'COUNT','ARM':'ARM','Source SDK':'Source SDK','helper':'辅助函数','sequence':'序列','hint':'提示','priority':'优先级','sink':'接收端','client':'客户端','control':'控制','geometry':'几何','port':'端口','block loan':'块借用','cache line':'缓存行','absolute monotonic deadline':'绝对单调截止时间','nominal strong ID':'名义强类型 ID','typed factory':'类型化工厂','typed getter':'类型化获取函数','typed IR':'类型化 IR','qualified code':'已验证代码','raw receipt':'原始回执','raw measurement':'原始测量','source identity':'源码身份','authoritative predicate':'权威谓词','replacement target':'替换目标','shared readonly ops':'共享只读 ops','field model/schema':'字段模型／schema','build root':'构建根目录','kernel syscall ceiling':'内核系统调用优先级阈值','masking policy':'屏蔽策略','scheduler context':'调度器上下文','wake latency':'唤醒延迟','Flash footprint':'Flash 占用范围','source distribution':'源发行包','hash requirements':'摘要约束','targeted development scope':'定向开发范围','strong ID':'强类型 ID','IRQ ceiling':'IRQ 优先级阈值','IRQ width':'IRQ 优先级位宽','split-security':'分裂安全状态','cache off/on':'缓存关闭／启用','core contract':'Core 合同',
'provider':'提供者','providers':'提供者','face':'接口面','faces':'接口面','context':'上下文','contexts':'上下文','binding':'绑定','bindings':'绑定','controller':'控制器','controllers':'控制器','endpoint':'端点','endpoints':'端点','child':'子端点','bus':'总线','getter':'获取函数','getters':'获取函数','header':'头文件','headers':'头文件','buffer':'缓冲区','buffers':'缓冲区','request':'请求','requests':'请求','observer':'观察者','observers':'观察者','publisher':'发布者','publishers':'发布者','producer':'生产者','producers':'生产者','consumer':'消费工程','consumers':'消费工程','executor':'执行者','worker':'执行任务','workers':'执行任务','slot':'槽','slots':'槽','task':'任务','tasks':'任务','stack':'栈','queue':'队列','notification':'通知','scheduler':'调度器','kernel':'内核','predicate':'谓词','deadline':'截止时间','admission':'准入','accepted':'已接受的','transfer':'传输','block':'块','loan':'借用','replacement':'替换','storage':'存储','capacity':'容量','publication':'发布','idle':'空闲','interval':'区间','count':'计数','counter':'计数器','timestamp':'时间戳','latency':'延迟','guard':'临界区保护','lifetime':'生命周期','ownership':'所有权','teardown':'拆除','author':'编写','authored':'人工编写的','resolver':'解析器','emitter':'生成器','fixture':'夹具','binary':'可执行文件','route':'路由','pin':'引脚','reservation':'预留','role':'角色','recovery':'恢复','revision':'版本','provenance':'来源依据','package':'包','hook':'钩子','hooks':'钩子','preset':'预设','target':'目标','fallback':'回退','clock':'时钟','mode':'模式','profile':'配置','record':'记录','scope':'范围','artifact':'产物','hash':'摘要','digest':'摘要','source':'源码','configuration':'配置','byte':'字节','byte-count':'字节计数','heap':'堆','identity':'身份','field':'字段','debug':'调试','owned':'自有','linker memory':'链接器内存','vector':'向量表','handler':'处理函数','strong handler':'强符号处理函数','measurement':'测量','station':'工位','admitted':'已准入的','probe':'探针','wiring':'接线','image':'镜像','connector':'连接器','transceiver':'收发器','pad':'焊盘','plan':'计划','smoke':'基本功能检查','trace':'跟踪记录','include':'包含路径','gate':'门禁','tuple':'组合','loss':'丢失','service-latency':'服务延迟','selected':'选定','transport':'传输端口','gateway':'网关','readonly':'只读','fresh':'新生成的','offline':'离线','host':'主机','arm':'建立通知序列快照','wake':'唤醒','wakes':'唤醒','timeout':'超时','stop':'停止','start':'启动','restart':'重启','clone':'克隆','receipt':'回执','catalog':'消息目录','builder':'构建器','directive':'指令','wrapper':'包装对象','member':'成员','payload':'内容文件','job':'任务','wheel':'wheel 包','console':'控制台','selector':'选择项','direct':'直接','scan':'扫描','rearm':'重新使能','Cache':'缓存','32-bit':'32 位','32-byte':'32 字节','Baremetal':'裸机',
}
# Complete English technical labels can be identifiers; preserve those. Mixed
# Chinese prose translates ordinary terms outside code spans and link targets.
PROTECTED=re.compile(r'(`+.*?`+|\]\([^)]*\)|https?://[^\s)]+)',re.DOTALL)
pattern=re.compile(r'(?<![A-Za-z0-9_])('+ '|'.join(re.escape(word) for word in sorted(WORDS,key=len,reverse=True)) +r')(?![A-Za-z0-9_])',re.I)
normalized={key.lower():value for key,value in WORDS.items()}
def readable(text):
    if not re.search('[\u3400-\u9fff]',text):
        return text
    parts=PROTECTED.split(text)
    result=''.join(part if i%2 else pattern.sub(lambda m:m[0] if m[0].isupper() else normalized[m[0].lower()],part) for i,part in enumerate(parts))
    result=re.sub(r'(?<=[\u3400-\u9fff]) +(?=[\u3400-\u9fff])','',result)
    result=re.sub(r'(?<=[\u3400-\u9fff]) +(?=[，。；：、])','',result)
    return result

if __name__=='__main__':
    receipt=Path('/tmp/nexus-docs-polish-20261014/search/reader-corrections.json')
    changed=json.loads(receipt.read_text()) if receipt.exists() else []
    for data in sorted(BASE.glob('*.json')):
        name=data.stem.replace('__','/')
        if name in ('explanation/source-map','sphinx/development/coding_standards'):continue
        source=ROOT/'docs'/(name+'.md')
        target='zh_CN' if source_language(source.read_text())=='en' else 'en'
        path=ROOT/'docs/locale'/target/'LC_MESSAGES'/(name+'.po')
        po=polib.pofile(str(path))
        if target=='zh_CN':
            for entry in po:
                before=entry.msgstr
                after=readable(before)
                if entry.msgid=='Stop':after='停止'
                if entry.msgid.startswith('Fresh reports require nonzero actual executions'):
                    after='新报告要求实际执行数量大于零，并保留原始日志。工具缺失、空 XML、只有跳过的运行、陈旧输出或输入变化都不能通过门禁。完整验收执行不得过滤或分片。开发子集保留有限范围，不能关闭完整候选退出条件。'
                if entry.msgid.startswith('Continuous receive and ADC use explicit caller-owned block loans.'):
                    after='连续接收与 ADC 使用调用者显式拥有的块借用。消费者必须保持块不可变，直到匹配释放成功。生产者发布旧硬件 bank 前，必须取得替换目标；无法替换时显式停止或施加背压，绝不能覆盖消费者。停止需等待正在填充、就绪及已借用的块，而不只是活动 DMA。[流合同](../design/io-observation-recovery.md)说明丢失计数与软件时间戳能够证明及不能证明的范围。'
                if entry.msgid.startswith('The resolver combines authored TOML with reviewed SoC/Board facts'):
                    after='解析器将人工编写的 TOML 与已审查 SoC／Board 事实组合为不可变类型化 IR 及原子生成包。它验证模式、资源、时钟、IRQ、ABI、DMA 可达性与预算。CMake 拥有源码依赖图；解析器不根据设备名称发现软件，也不生成产品执行任务。'
                if entry.msgid.startswith('Resource checks cover actual pin/AF'):
                    after='资源检查覆盖实际引脚／AF、控制器、IRQ 系统调用优先级阈值、共享定时器／时间基准、物理 DMA 控制器／流、时钟、准确内存域、模式及端点身份。即使选择项语法合法，仍可能因提供者未实现该路由而被拒绝。解析器绝不静默改变引脚、模式或时钟。'
                if entry.msgid.startswith("Use the request's latched predicate as truth."):
                    after='以请求的锁存谓词为权威。先检查完成谓词，调用 `arm` 快照通知序列，再次检查，以同一绝对单调截止时间等待，然后再次检查。唤醒只是提示，可能合并或与当前请求无关。超时后执行合同要求的最后一次谓词观察。不得在每次提示后重新开始相对时间预算，也不得阻塞唯一负责推进的执行者。'
                if entry.msgid.startswith('Both binaries must execute nonempty passing cases.'):
                    after='两个可执行文件都必须实际执行非空且全部通过的用例。此定向开发范围不替代完整 TDD 门禁。[nexus-examples](https://github.com/X-Gen-Lab/nexus-examples) 的外部 UART owner 应用提供产品执行任务；声明消费工程执行前必须记录其固定源码版本。'
                if name=='tutorials/async-io':
                    after=after.replace('内容文件','载荷')
                if 'Source SDK' in entry.msgid:
                    after=after.replace('源码 SDK','Source SDK')
                if after!=before:
                    entry.msgstr=after
                    changed.append({'document':name,'language':target,'msgid':entry.msgid,'before':before,'after':after})
        else:
            for entry in po:
                if entry.msgid.startswith('{download}`URL 迁移表'):
                    before=entry.msgstr
                    after=before.replace('at `versions/<release_id>/api/index.html` under the immutable version root','within an immutable version at the site-relative path `versions/<release_id>/api/index.html`')
                    if after!=before:
                        entry.msgstr=after
                        changed.append({'document':name,'language':target,'msgid':entry.msgid,'before':before,'after':after})
        po.metadata['X-Nexus-Reviewed']='false'
        po.save(str(path))
    out=Path('/tmp/nexus-docs-polish-20261014/search/reader-corrections.json')
    out.write_text(json.dumps(changed,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'corrected_messages':len(changed),'receipt':str(out)},ensure_ascii=False))
