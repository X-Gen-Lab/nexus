"""Execute real locked Sphinx/Chromium exclusion regression outside default CI.

No installation, outbound request, source mutation or optional-suite skips.
The init script retains the unmodified native function before the adapter's
DOMContentLoaded callback, solely to compare positive rows and scores.
"""
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import unittest
from urllib.parse import urlencode

from playwright.sync_api import sync_playwright

PROJECT = Path('/workspace/nexus-build-system-20261012')
OUT = Path('/tmp/nexus-docs-polish-20261014/search')
PYTHON = Path('/workspace/nexus-docs-implementation-20261014/tool-lock/prefix-qualified/venv/bin/python')
RUN = sys.argv.pop(1) if len(sys.argv) > 1 else 'green'
ROOT = OUT / ('exclusion-' + RUN + '-fixture')
REPORT = {'scope': 'actual_sphinx_7_4_7_native_terms_exclusion_compatibility',
          'records': [], 'assertions': [], 'run': RUN, 'passed': False,
          'sources': {name: hashlib.sha256((PROJECT / name).read_bytes()).hexdigest()
                      for name in ('docs/assets/styles/nexus-search.js',
                                   'tools/documentation/search_language.py',
                                   'tools/documentation/sphinx_ext.py')}}


class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *arguments):
        pass


class ExclusionBrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if ROOT.exists():
            shutil.rmtree(ROOT)
        ROOT.mkdir()
        pages = {
            'a_zero': ('Zero target', 'borrow alpha beta 借用 zeroexcluded arrayexcluded'),
            'b_before': ('Before target', 'borrow alpha beta 借用'),
            'c_array': ('Array target', 'borrow alpha beta 借用 arrayexcluded'),
            'd_scalar': ('Scalar target', 'borrow alpha beta 借用 singletonexcluded'),
            'e_after': ('After target', 'borrow alpha beta 借用'),
            'f_title': ('Titleexcluded target', 'borrow alpha beta 借用'),
            'g_titlearray': ('Arraytitle first', 'borrow alpha beta 借用'),
            'h_titlearray': ('Arraytitle second', 'borrow alpha beta 借用'),
            'i_other': ('Other target', 'alpha unrelated'),
            'j_score': ('Borrow 借用 target', 'alpha beta'),
        }
        environment = os.environ.copy()
        for name in list(environment):
            if name.startswith('NEXUS_DOCS_') or name == 'PYTHONPATH':
                environment.pop(name)
        for locale in ('en', 'zh_CN'):
            docs = ROOT / ('sources-' + locale)
            docs.mkdir()
            (docs / 'conf.py').write_text(
                'import sys\n' + f'sys.path.insert(0, {str(PROJECT)!r})\n'
                + "extensions=['myst_parser','tools.documentation.sphinx_ext']\n"
                + "source_suffix={'.md':'markdown'}\nroot_doc='index'\n"
                + "project='Exclusion fixture'\nhtml_theme='alabaster'\n"
                + f'language={locale!r}\n'
                + "version=release='exclusion-fixture'\n"
                + f'html_static_path=[{str(PROJECT / "docs/assets/styles")!r}]\n'
                + "html_css_files=['nexus.css']\n", encoding='utf-8')
            prefix = f'---\nsource_language: {locale}\ntype: reference\n---\n\n'
            (docs / 'index.md').write_text(prefix + '# Exclusion fixture\n\n'
                + '```{toctree}\n' + '\n'.join(pages) + '\n```\n', encoding='utf-8')
            for name, (title, text) in pages.items():
                (docs / (name + '.md')).write_text(
                    prefix + '# ' + title + '\n\n' + text + '\n', encoding='utf-8')
        for arguments in (['init', '-q'], ['add', 'sources-en', 'sources-zh_CN'],
                          ['-c', 'user.name=Fixture', '-c',
                           'user.email=fixture@example.invalid', 'commit', '-q',
                           '-m', 'test: native exclusion compatibility']):
            subprocess.run(['git', '-C', str(ROOT)] + arguments,
                           check=True, capture_output=True)
        for locale in ('en', 'zh_CN'):
            result = subprocess.run(
                [str(PYTHON), '-m', 'sphinx', '-E', '-n', '-W', '-b', 'html',
                 str(ROOT / ('sources-' + locale)), str(ROOT / locale)],
                env=environment, capture_output=True, text=True, timeout=60)
            (OUT / ('exclusion-' + RUN + '-build-' + locale + '.log')).write_text(
                result.stdout + result.stderr, encoding='utf-8')
            if result.returncode:
                raise RuntimeError(result.stdout + result.stderr)
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0),
            partial(Quiet, directory=str(ROOT)))
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.base = 'http://127.0.0.1:' + str(cls.server.server_address[1])
        cls.playwright = sync_playwright().start()
        cls.browser = cls.playwright.chromium.launch(
            executable_path='/usr/bin/chromium', headless=True,
            args=['--no-sandbox'])
        REPORT['chromium'] = cls.browser.version

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()
        cls.server.shutdown()
        cls.server.server_close()

    def open(self, locale, query='borrow'):
        page = self.browser.new_page()
        errors, requests = [], []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.on('request', lambda request: requests.append(request.url))
        page.route('**/*', lambda route: route.continue_()
            if route.request.url.startswith(self.base + '/') else route.abort())
        page.add_init_script('''document.addEventListener('DOMContentLoaded',
            () => { window.__nativeTermsSearch = Search.performTermsSearch; },
            {once: true});''')
        response = page.goto(self.base + '/' + locale + '/search.html?'
                             + urlencode({'q': query}))
        self.assertEqual(response.status, 200)
        page.wait_for_function('typeof Search !== "undefined" && Search.hasIndex()')
        self.addCleanup(page.close)
        return page, errors, requests

    def test_scalar_zero_nonzero_array_and_title_postings_keep_candidates(self):
        cases = {
            'zeroexcluded': ['a_zero'], 'singletonexcluded': ['d_scalar'],
            'arrayexcluded': ['a_zero', 'c_array'],
            'titleexcluded': ['f_title', 'index'],
            'arraytitle': ['g_titlearray', 'h_titlearray', 'index'],
            'absentexcluded': [],
        }
        for locale in ('en', 'zh_CN'):
            page, errors, requests = self.open(locale)
            for term, excluded_docs in cases.items():
                with self.subTest(locale=locale, term=term):
                    result = page.evaluate('''({term, excludedDocs}) => {
                        term = new Stemmer().stemWord(term.toLowerCase());
                        const indexBefore = JSON.stringify(Search._index);
                        const required = new Set(['borrow']);
                        const native = __nativeTermsSearch(required, new Set());
                        const expected = native.filter(row => !excludedDocs.includes(row[0]));
                        let actual = [], error = null;
                        try {actual = Search.performTermsSearch(required, new Set([term]));}
                        catch (failure) {error = failure.toString();}
                        return {expected, actual, error, native,
                            postings: {body:Search._index.terms[term],
                                       title:Search._index.titleterms[term]},
                            index_unchanged: indexBefore === JSON.stringify(Search._index)};
                    }''', {'term': term, 'excludedDocs': excluded_docs})
                    REPORT['records'].append({'locale': locale, 'term': term, **result})
                    self.assertIsNone(result['error'])
                    self.assertEqual(result['actual'], result['expected'])
                    self.assertTrue(result['index_unchanged'])
            self.assertFalse(errors)
            self.assertTrue(all(url.startswith(self.base + '/') for url in requests))

    def test_positive_and_scores_rows_paths_and_repeat_install_stay_native(self):
        source = (PROJECT / 'docs/assets/styles/nexus-search.js').read_text()
        for locale in ('en', 'zh_CN'):
            page, errors, requests = self.open(locale)
            page.wait_for_function('Search._pulse_status === -1')
            for required in (['borrow'], ['borrow', 'alpha'],
                             ['borrow', 'unmatchedquery'], ['nx_uart_read']):
                with self.subTest(locale=locale, required=required):
                    observed = page.evaluate('''required => ({
                        native: __nativeTermsSearch(new Set(required), new Set()),
                        adapted: Search.performTermsSearch(new Set(required), new Set())
                    })''', required)
                    self.assertEqual(observed['adapted'], observed['native'])
            before = page.evaluate('''() => ({index:JSON.stringify(Search._index),
                html:document.getElementById('search-results').innerHTML})''')
            page.evaluate('''() => {
                window.__firstCompatibleMethod=Search.performTermsSearch;
                return true;
            }''')
            page.evaluate(source)
            page.evaluate(source)
            self.assertTrue(page.evaluate('Search.performTermsSearch === __firstCompatibleMethod'))
            after = page.evaluate('''() => ({index:JSON.stringify(Search._index),
                html:document.getElementById('search-results').innerHTML})''')
            self.assertEqual(after['index'], before['index'])
            self.assertEqual(after['html'], before['html'])
            rows = page.evaluate('''() => [...document.querySelectorAll('#search-results li')]
                .map(item => ({href:item.querySelector('a').getAttribute('href'),
                    identity:item.querySelectorAll('.nexus-search-identity').length,
                    excerpt:item.querySelectorAll('.nexus-search-excerpt').length,
                    requested:item.dataset.nexusRequestedLanguage,
                    actual:item.dataset.nexusActualLanguage,
                    version:item.dataset.nexusVersion,
                    type:item.dataset.nexusType}))''')
            self.assertTrue(rows)
            self.assertTrue(all(row['identity'] == 1 and row['excerpt'] <= 1
                                and row['requested'] == locale and row['actual'] == locale
                                and row['type'] == 'reference'
                                and row['version'] == 'exclusion-fixture'
                                and not row['href'].startswith(('http:', 'https:', '../'))
                                for row in rows))
            self.assertFalse(errors)
            self.assertTrue(all(url.startswith(self.base + '/') for url in requests))
            REPORT['records'].append({'locale': locale, 'positive_dom': rows})

    def test_chinese_first_navigation_completes_exclusions_before_native_init(self):
        for term, excluded_docs in (
                ('zeroexcluded', ['a_zero']),
                ('singletonexcluded', ['d_scalar']),
                ('arrayexcluded', ['a_zero', 'c_array']),
                ('Titleexcluded', ['f_title', 'index']),
                ('Arraytitle', ['g_titlearray', 'h_titlearray', 'index'])):
            with self.subTest(term=term):
                page, errors, requests = self.open('zh_CN', '借用 -' + term)
                page.wait_for_timeout(300)
                observed = page.evaluate('''() => {
                    const [, required, excluded] = Search._parseQuery(
                        new URLSearchParams(location.search).get('q'));
                    const native = __nativeTermsSearch(required, new Set());
                    return {expected:native.map(row=>row[0]),
                        excluded:[...excluded],complete:Search._pulse_status === -1,
                        visible:[...document.querySelectorAll('#search-results li a')]
                            .map(link=>link.getAttribute('href').split('.html')[0]),
                        identities:document.querySelectorAll('.nexus-search-identity').length};
                }''')
                REPORT['records'].append({'first_navigation': term, **observed,
                                          'errors': errors})
                self.assertFalse(errors)
                self.assertTrue(observed['complete'])
                self.assertEqual(set(observed['visible']),
                                 set(observed['expected']) - set(excluded_docs))
                self.assertEqual(observed['identities'], len(observed['visible']))
                self.assertTrue(all(url.startswith(self.base + '/') for url in requests))

    def test_missing_native_method_or_metadata_is_a_stable_noop(self):
        page = self.browser.new_page()
        self.addCleanup(page.close)
        source = (PROJECT / 'docs/assets/styles/nexus-search.js').read_text()
        page.set_content('<!doctype html><div id="search-results"></div>')
        page.evaluate(source)
        page.evaluate('window.Search = {unrelated:"preserved"}')
        page.evaluate(source)
        page.evaluate(source)
        self.assertEqual(page.evaluate('JSON.stringify(Search)'),
                         '{"unrelated":"preserved"}')


if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(ExclusionBrowserTests))
    REPORT.update(passed=result.wasSuccessful(), tests_run=result.testsRun,
                  failures=len(result.failures), errors=len(result.errors),
                  skipped=len(result.skipped))
    (OUT / ('exclusion-' + RUN + '.json')).write_text(
        json.dumps(REPORT, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    sys.exit(0 if result.wasSuccessful() else 1)
