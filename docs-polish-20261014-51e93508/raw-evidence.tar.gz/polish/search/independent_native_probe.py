"""Read-only independent review: build local Sphinx input and query native JS."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import hashlib, json, os, shutil, subprocess, threading
from urllib.parse import urlencode
from playwright.sync_api import sync_playwright

PROJECT=Path('/workspace/nexus-build-system-20261012')
EVIDENCE=Path('/tmp/nexus-docs-polish-20261014/search')
ROOT=EVIDENCE/'independent-native-fixture'
PYTHON=Path('/workspace/nexus-docs-implementation-20261014/tool-lock/prefix-qualified/venv/bin/python')
if ROOT.exists(): shutil.rmtree(ROOT)
DOCS=ROOT/'docs'; DOCS.mkdir(parents=True)
(DOCS/'conf.py').write_text('import sys\n'+f'sys.path.insert(0, {str(PROJECT)!r})\n'+"extensions=['myst_parser','tools.documentation.sphinx_ext']\nsource_suffix={'.md':'markdown'}\nroot_doc='index'\nproject='Independent native Chinese review'\nhtml_theme='alabaster'\nlanguage='zh_CN'\nhtml_static_path=['/workspace/nexus-build-system-20261012/docs/assets/styles']\nhtml_css_files=['nexus.css']\n")
pages={
 'a_keep': ('更新流程','借用允许更新，排版独立。'),
 'b_both': ('双步骤','借用和排空完成。'),
 'c_drain': ('单步骤','排空操作。'),
 'd_hal': ('外设调用','HAL nx_uart_read running。\n\n```{c:function} int nx_uart_read(void)\n\nStatic API fixture.\n```'),
 'e_borrow': ('存储状态','借用保存存储。'),
 'f_separated': ('字符检查','借，用。排，空。'),
 'g_title': ('借用','只含标题中的关键词。'),
 'h_unicode': ('扩展字','𠮷野。\U00031350野。\U0002ebf0野。'),
}
(DOCS/'index.md').write_text('---\nsource_language: zh_CN\n---\n\n# 搜索验证\n\n```{toctree}\n'+ '\n'.join(pages)+'\n```\n',encoding='utf-8')
for name,(title,text) in pages.items():
 (DOCS/(name+'.md')).write_text('---\nsource_language: zh_CN\n---\n\n# '+title+'\n\n'+text+'\n',encoding='utf-8')
for args in (['init','-q'],['add','docs'],['-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-q','-m','test: independent native search fixture']):
 subprocess.run(['git','-C',str(ROOT)]+args,check=True,capture_output=True)
env=os.environ.copy()
for key in tuple(env):
 if key.startswith('NEXUS_DOCS_'):env.pop(key)
r=subprocess.run([str(PYTHON),'-m','sphinx','-E','-n','-W','-b','html',str(DOCS),str(ROOT/'html')],env=env,capture_output=True,text=True)
(EVIDENCE/'independent-native-build.log').write_text(r.stdout+r.stderr)
assert r.returncode==0,r.stdout+r.stderr
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(ROOT/'html')))
threading.Thread(target=server.serve_forever,daemon=True).start()
base=f'http://127.0.0.1:{server.server_address[1]}'
report={'scope':'independent_production_sphinx_extension_and_native_sphinx_7_4_7_js','records':[],'code':{name:hashlib.sha256((PROJECT/name).read_bytes()).hexdigest() for name in ('tools/documentation/search_language.py','tools/documentation/sphinx_ext.py','docs/assets/styles/nexus-search.js')}}
try:
 with sync_playwright() as tool:
  browser=tool.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  report['chromium']=browser.version
  page=browser.new_page();errors=[];requests=[]
  page.add_init_script("document.addEventListener('DOMContentLoaded',()=>{window.__independentNative=Search.performTermsSearch;},{once:true});")
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:requests.append(r.url))
  for query in ('借用','排空','借用 排空','借用 HAL','不存在 HAL','借用 -排空','借用 -排版','借用 -HAL','借用 -存储','借用 -MISSINGPREFIXxyz','借用 -借用','借','nx_uart_read','RUNNING','𠮷野','\U00031350野','\U0002ebf0野','借用 借用','<img src=x onerror=alert(1)> 借用'):
   response=page.goto(base+'/search.html?'+urlencode({'q':query}))
   page.wait_for_function('typeof Search !== "undefined" && Search.hasIndex()')
   # Native query parsing/terms search is deterministic and avoids render timing.
   parsed=page.evaluate('''query=>{ const [q,required,excluded,highlights,objects]=Search._parseQuery(query); let terms=[],error=null; const indexBefore=JSON.stringify(Search._index); const nativePositive=window.__independentNative.call(Search,required,new Set()); const compatiblePositive=Search.performTermsSearch(required,new Set()); try {terms=Search.performTermsSearch(required,excluded);} catch(e) {error=e.toString();} return {raw:splitQuery(query),required:[...required],excluded:[...excluded],highlights:[...highlights],objects:[...objects],object_results:[...objects].flatMap(t=>Search.performObjectSearch(t,objects)).map(r=>({doc:r[0],anchor:r[2],score:r[4]})),error,native_positive_rows:nativePositive,positive_rows_equal:JSON.stringify(nativePositive)===JSON.stringify(compatiblePositive),filtered_rows_retained:terms.every(row=>nativePositive.some(original=>JSON.stringify(row)===JSON.stringify(original))),index_unchanged:JSON.stringify(Search._index)===indexBefore,excluded_index:[...excluded].map(t=>({term:t,body:Search._index.terms[t],title:Search._index.titleterms[t]})),terms:terms.map(row=>({doc:row[0],score:row[4]})),index:{terms:Object.keys(Search._index.terms).filter(t=>t.startsWith('nxcjk_')).length,titleterms:Object.keys(Search._index.titleterms).filter(t=>t.startsWith('nxcjk_')).length}};}''',query)
   page.wait_for_timeout(150)
   parsed.update(query=query,http_status=response.status,visible=page.locator('#search-results').inner_text(),prefix_visible='nxcjk_' in page.locator('body').inner_text(),alerts=page.locator('#search-results img').count())
   report['records'].append(parsed)
  report['javascript_errors']=errors
  report['external_requests']=[r for r in requests if not r.startswith(base+'/')]
  browser.close()
finally:
 server.shutdown();server.server_close()
report['code_after']={name:hashlib.sha256((PROJECT/name).read_bytes()).hexdigest() for name in report['code']}
report['stable_inputs']=report['code']==report['code_after']
(EVIDENCE/'independent-native-probe.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'queries':len(report['records']),'negative_han':next(x for x in report['records'] if x['query']=='借用 -排空'),'unicode':next(x for x in report['records'] if x['query']=='\U00031350野'),'js_errors':report['javascript_errors'],'external_requests':report['external_requests']},ensure_ascii=False,indent=2))
