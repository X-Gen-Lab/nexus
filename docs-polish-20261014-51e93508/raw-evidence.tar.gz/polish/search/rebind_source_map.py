"""Rebind only mechanically normalized include targets, preserving reviewed prose."""
from pathlib import Path
import hashlib
import json
import re
import sys
sys.path.insert(0,'/workspace/nexus-build-system-20261012')
from tools.documentation.sphinx_ext import read_catalog
import polib
ROOT=Path('/workspace/nexus-build-system-20261012')
POT=Path('/tmp/nexus-docs-polish-20261014/gettext/explanation/source-map.pot')
OUT=Path('/tmp/nexus-docs-polish-20261014/search')
MD=re.compile(r'\[([^]]+)\]\(([^)]+)\)')
DOWNLOAD=re.compile(r'\{download\}`([^`<>]+) <([^>]+)>`')
def visible(message):
    return DOWNLOAD.sub(lambda m:'['+m[1]+']',MD.sub(lambda m:'['+m[1]+']',message))

def targets(message):
    result={label:('markdown',target) for label,target in MD.findall(message)}
    result.update({label:('download',target) for label,target in DOWNLOAD.findall(message)})
    return result

required=list(read_catalog(POT)[1])
report={'scope':'derived include-read href IDs only; canonical source and peer-reviewed prose preserved','page':'explanation/source-map','records':[]}
for language in ('en','zh_CN'):
    path=ROOT/'docs/locale'/language/'LC_MESSAGES/explanation/source-map.po'
    before=path.read_bytes()
    (OUT/('source-map-before-links-'+language+'.po')).write_bytes(before)
    po=polib.pofile(str(path))
    assert len(po)==len(required)==49
    changes=[]
    for entry,new in zip(po,required):
        old=entry.msgid
        if old==new:continue
        assert visible(old)==visible(new),(old,new)
        old_targets=targets(old);new_targets=targets(new)
        assert set(old_targets)==set(new_targets)
        replacements={old_targets[label][1]:new_targets[label] for label in old_targets if old_targets[label]!=new_targets[label]}
        before_prose=entry.msgstr
        def replace(match):
            label,target=match.groups()
            if target not in replacements:return match[0]
            kind,value=replacements[target]
            return ('{download}`'+label+' <'+value+'>`' if kind=='download' else '['+label+']('+value+')')
        after_prose=MD.sub(replace,before_prose)
        assert visible(before_prose)==visible(after_prose),(before_prose,after_prose)
        assert len(targets(after_prose))==len(targets(before_prose))
        entry.msgid=new;entry.msgstr=after_prose
        changes.append({'old_msgid':old,'new_msgid':new,'old_msgstr':before_prose,'new_msgstr':after_prose,'targets':replacements})
    po.metadata['X-Nexus-Reviewed']='false'
    source=ROOT/'docs/explanation/source-map.md'
    po.metadata['X-Nexus-Source-SHA256']=hashlib.sha256(source.read_bytes()).hexdigest()
    po.save(str(path));path.write_text(path.read_text().rstrip()+'\n')
    meta,messages,fuzzy=read_catalog(path)
    assert set(messages)==set(required) and all(messages.values()) and not fuzzy
    assert meta['Language']==language
    assert meta['X-Nexus-Source-SHA256']==hashlib.sha256(source.read_bytes()).hexdigest()
    report['records'].append({'language':language,'messages':len(messages),'changed_messages':len(changes),'old_catalog_sha256':hashlib.sha256(before).hexdigest(),'new_catalog_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_sha256':meta['X-Nexus-Source-SHA256'],'changes':changes})
(OUT/'source-map-link-delta.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'catalogs':len(report['records']),'messages_per_catalog':49,'changed_per_catalog':[row['changed_messages'] for row in report['records']]},ensure_ascii=False))
