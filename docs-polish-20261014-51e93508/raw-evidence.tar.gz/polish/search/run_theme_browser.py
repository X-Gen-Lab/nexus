"""Inspect actual bilingual production-template UI on two local pages."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import subprocess
import threading
from playwright.sync_api import sync_playwright

PROJECT=Path('/workspace/nexus-build-system-20261012')
OUT=Path('/tmp/nexus-docs-polish-20261014/search')
ROOT=OUT/'theme-browser-fixture'
PYTHON=Path('/workspace/nexus-docs-implementation-20261014/tool-lock/prefix-qualified/venv/bin/python')
if ROOT.exists():shutil.rmtree(ROOT)
for language in ('en','zh_CN'):
    repository=ROOT/('source-'+language)
    docs=repository/'docs';docs.mkdir(parents=True)
    config=PROJECT/'docs/sphinx/conf.py'
    (docs/'conf.py').write_text(f'__file__={str(config)!r}\nexec(compile(open({str(config)!r}).read(),__file__,"exec"))\n'+"html_sidebars={'**':['about.html','navigation.html','relations.html','searchbox.html']}\n")
    title='平台使用说明' if language=='zh_CN' else 'Platform guide'
    next_title='下一项任务' if language=='zh_CN' else 'Next task'
    (docs/'index.md').write_text('---\nsource_language: '+language+'\n---\n\n# '+title+'\n\n```{toctree}\nnext\n```\n')
    (docs/'next.md').write_text('---\nsource_language: '+language+'\n---\n\n# '+next_title+'\n\n'+title+'.\n')
    for arguments in (['init','-q'],['add','docs'],['-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-q','-m','test: theme browser fixture']):
        subprocess.run(['git','-C',str(repository)]+arguments,check=True,capture_output=True)
    environment=os.environ.copy()
    for name in ('NEXUS_DOCS_REVISION','NEXUS_DOCS_CODE_REVISION','NEXUS_DOCS_TRANSLATION_ROOT','NEXUS_DOCS_GETTEXT_ROOT','NEXUS_DOCS_LANGUAGES','NEXUS_DOCS_DOXYGEN_XML'):
        environment.pop(name,None)
    environment.update(NEXUS_DOCS_LANGUAGE=language,NEXUS_DOCS_VERSION='docs-theme-fixture')
    result=subprocess.run([str(PYTHON),'-m','sphinx','-E','-n','-W','--keep-going','-b','html',str(docs),str(ROOT/language)],env=environment,capture_output=True,text=True)
    (OUT/('theme-build-'+language+'.log')).write_text(result.stdout+result.stderr)
    assert result.returncode==0,result.stdout+result.stderr
class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*arguments):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
base=f'http://127.0.0.1:{server.server_address[1]}'
report={'scope':'two_local_actual_browser_pages_using_production_conf_and_templates','records':[]}
try:
    with sync_playwright() as tool:
        browser=tool.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        report['chromium']=browser.version
        page=browser.new_page(viewport={'width':1280,'height':800})
        errors=[];requests=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.on('request',lambda request:requests.append(request.url))
        for language in ('en','zh_CN'):
            response=page.goto(base+'/'+language+'/next.html')
            observed=page.evaluate('''() => ({sidebar:document.querySelector('.sphinxsidebar').innerText, footer:document.querySelector('.footer').innerText, title:document.querySelector('.nexus-canonical-content h1').innerText, relations:document.querySelector('.relations').innerText, description:document.querySelector('.blurb').innerText, search_scripts:[...document.scripts].filter(script=>script.src.includes('nexus-search')).map(script=>script.src), credit_links:[...document.querySelectorAll('.footer a')].map(link=>({text:link.innerText,href:link.href})), overflow:document.documentElement.scrollWidth>window.innerWidth})''')
            assert response.status==200
            assert not observed['search_scripts'] and not observed['overflow']
            assert '2026, Nexus Team' in observed['footer']
            assert 'Sphinx 7.4.7' in observed['footer'] and 'Alabaster 0.7.16' in observed['footer']
            if language=='zh_CN':
                assert '相关主题' in observed['relations'] and '文档总览' in observed['relations'] and '上一页' in observed['relations']
                assert '技术支持' in observed['footer'] and 'Powered by' not in observed['footer']
                assert observed['description']=='可复用的静态嵌入式平台机制'
            else:
                assert 'Related Topics' in observed['relations'] and 'Documentation overview' in observed['relations'] and 'Previous:' in observed['relations']
                assert 'Powered by' in observed['footer']
                assert observed['description']=='Static embedded platform mechanisms'
            screenshot=OUT/('theme-'+language+'.png')
            page.screenshot(path=str(screenshot))
            report['records'].append({'language':language,'url':page.url,'http_status':response.status,'screenshot':str(screenshot),**observed})
        report['javascript_errors']=errors
        report['external_requests']=[url for url in requests if not url.startswith(base+'/')]
        assert not errors and not report['external_requests']
        browser.close()
finally:
    server.shutdown();server.server_close()
report['passed']=True
(OUT/'theme-browser.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':True,'pages':len(report['records']),'javascript_errors':report['javascript_errors'],'external_requests':report['external_requests']},ensure_ascii=False))
