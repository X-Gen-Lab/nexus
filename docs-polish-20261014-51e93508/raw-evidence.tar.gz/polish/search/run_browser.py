"""Build and inspect actual isolated bilingual Sphinx search pages."""
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import shutil
import threading
from playwright.sync_api import sync_playwright

PROJECT = Path('/workspace/nexus-build-system-20261012')
OUT = Path('/tmp/nexus-docs-polish-20261014/search')
PYTHON = Path('/workspace/nexus-docs-implementation-20261014/tool-lock/prefix-qualified/venv/bin/python')
ROOT = OUT / 'browser-fixture'
if ROOT.exists():
    shutil.rmtree(ROOT)
DOCS = ROOT / 'docs'
DOCS.mkdir(parents=True, exist_ok=True)
(DOCS / 'conf.py').write_text('import sys, os\n' + f'sys.path.insert(0, {str(PROJECT)!r})\n' + "extensions=['myst_parser','tools.documentation.sphinx_ext']\nsource_suffix={'.md':'markdown'}\nroot_doc='index'\nproject='Search browser fixture'\nhtml_theme='alabaster'\nlanguage=os.environ['NEXUS_DOCS_LANGUAGE']\nversion=release='docs-browser-fixture'\nhtml_static_path=['/workspace/nexus-build-system-20261012/docs/assets/styles']\nhtml_css_files=['nexus.css']\ngettext_compact=False\nexclude_patterns=['locale/**']\n")
sources = {
    'index': '---\nsource_language: en\ntype: reference\n---\n\n# Search fixture\n\n```{toctree}\nsdk\nstale\n```\n',
    'sdk': '---\nsource_language: en\ntype: tutorial\n---\n\n# SDK tutorial\n\nSDK returns an existing static interface.\n',
    'stale': '---\nsource_language: en\ntype: explanation\n---\n\n# SDK stale contract\n\nSDK cancellation retains borrowed storage.\n'
}
for name, source in sources.items():
    (DOCS / (name + '.md')).write_text(source)
for args in (['init','-q'],['add','docs'],['-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-q','-m','test: browser fixture']):
    subprocess.run(['git','-C',str(ROOT)]+args, check=True, capture_output=True)
env = os.environ.copy()
for name in ('NEXUS_DOCS_REVISION','NEXUS_DOCS_CODE_REVISION','NEXUS_DOCS_TRANSLATION_ROOT','NEXUS_DOCS_GETTEXT_ROOT','NEXUS_DOCS_LANGUAGES'):
    env.pop(name, None)
env['NEXUS_DOCS_LANGUAGES']='en,zh_CN'
def build(builder, locale, output):
    local = env | {'NEXUS_DOCS_LANGUAGE':locale}
    if builder != 'gettext':
        local['NEXUS_DOCS_GETTEXT_ROOT']=str(ROOT/'gettext')
    result=subprocess.run([str(PYTHON),'-m','sphinx','-E','-W','--keep-going','-b',builder,str(DOCS),str(output)],env=local,capture_output=True,text=True)
    (OUT / ('build-'+builder+'-'+locale+'.log')).write_text(result.stdout+result.stderr)
    assert result.returncode == 0, result.stdout+result.stderr
build('gettext','en',ROOT/'gettext')
import sys
sys.path.insert(0,str(PROJECT))
from tools.documentation.sphinx_ext import read_catalog
mapping={'SDK tutorial':'SDK 教程','SDK returns an existing static interface.':'SDK 返回已有静态接口。','SDK stale contract':'SDK 过期合同','SDK cancellation retains borrowed storage.':'SDK 取消保留借用存储。','Search fixture':'搜索夹具'}
for name, source in sources.items():
    messages=read_catalog(ROOT/'gettext'/(name+'.pot'))[1]
    digest=hashlib.sha256(source.encode()).hexdigest() if name != 'stale' else '0'*64
    header='Language: zh_CN\nContent-Type: text/plain; charset=UTF-8\nX-Nexus-Source-SHA256: '+digest+'\nX-Nexus-Reviewed: true\n'
    entries='msgid ""\nmsgstr '+json.dumps(header,ensure_ascii=False)+'\n\n'
    for message in messages:
        entries+='msgid '+json.dumps(message,ensure_ascii=False)+'\nmsgstr '+json.dumps(mapping[message],ensure_ascii=False)+'\n\n'
    catalog=DOCS/'locale/zh_CN/LC_MESSAGES'/(name+'.po')
    catalog.parent.mkdir(parents=True,exist_ok=True)
    catalog.write_text(entries)
for locale in ('en','zh_CN'):
    build('html',locale,ROOT/locale)
class Quiet(SimpleHTTPRequestHandler):
    def log_message(self,*args):
        pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
base=f'http://127.0.0.1:{server.server_address[1]}'
report={'scope':'isolated_bilingual_actual_sphinx_search','records':[],'assertions':[]}
try:
    with sync_playwright() as tool:
        browser=tool.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        report['chromium']=browser.version
        page=browser.new_page(viewport={'width':1280,'height':900})
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        requests=[]
        page.on('request',lambda request:requests.append(request.url))
        for locale in ('en','zh_CN'):
            response=page.goto(base+'/'+locale+'/search.html?q=SDK')
            page.wait_for_selector('#search-results .nexus-search-identity',timeout=15000)
            page.wait_for_function('() => Search._pulse_status === -1')
            page.wait_for_timeout(300)
            rows=page.evaluate('''() => [...document.querySelectorAll('#search-results li')].map(item => ({href:item.querySelector('a')?.getAttribute('href'),dataset:{...item.dataset},text:item.innerText,excerpt:item.querySelector('.nexus-search-excerpt')?.textContent,identity_count:item.querySelectorAll('.nexus-search-identity').length,context_count:item.querySelectorAll('p.context').length}))''')
            report['records'].append({'locale':locale,'http_status':response.status,'rows':rows})
            assert rows and all(row['dataset']['nexusVersion']=='docs-browser-fixture' for row in rows)
            assert all(row['identity_count']==1 for row in rows)
            assert all(row['context_count']==1 for row in rows if row['excerpt'])
            assert all('qualification' not in (row['excerpt'] or '') for row in rows)
            sdk=next(row for row in rows if row['href'].split('#')[0]=='sdk.html')
            assert sdk['dataset']['nexusType']=='tutorial'
            assert sdk['dataset']['nexusTranslation']==('original' if locale=='en' else 'reviewed')
            assert sdk['dataset']['nexusActualLanguage']==locale
            stale=next(row for row in rows if row['href'].split('#')[0]=='stale.html')
            assert stale['dataset']['nexusActualLanguage']=='en'
            assert stale['dataset']['nexusTranslation']==('original' if locale=='en' else 'stale')
            page.screenshot(path=str(OUT/('search-'+locale+'.png')))
        injection=page.evaluate('''() => {
            window.__nexusInjection = false;
            const entry = NEXUS_SEARCH_DATA.records['sdk.html'];
            entry.title = '<img src=x onerror="window.__nexusInjection=true">';
            entry.excerpt = '<script>window.__nexusInjection=true</script> SDK literal';
            const parent = document.querySelector('#search-results ul');
            for (const href of ['sdk.html#SDK','https://evil.invalid/zh_CN/sdk.html','../en/sdk.html','%2e%2e/en/sdk.html']) {
                const item = document.createElement('li');
                item.id = 'injection-' + parent.children.length;
                const link = document.createElement('a');
                link.href = href; link.textContent = 'injected';
                item.appendChild(link); parent.appendChild(item);
            }
            return true;
        }''')
        page.wait_for_timeout(300)
        observed=page.evaluate('''() => ({executed:window.__nexusInjection,items:[...document.querySelectorAll('#search-results li[id^=injection-]')].map(item => ({href:item.querySelector('a').getAttribute('href'),decorated:!!item.querySelector('.nexus-search-identity'),excerpt:item.querySelector('.nexus-search-excerpt')?.textContent,script_count:item.querySelectorAll('script,img').length}))})''')
        assert not observed['executed']
        assert observed['items'][0]['decorated']
        assert observed['items'][0]['excerpt'].startswith('<script>')
        assert all(item['script_count']==0 for item in observed['items'])
        assert all(not item['decorated'] for item in observed['items'][1:])
        report['injection']=observed
        file_records=[]
        for locale in ('en','zh_CN'):
            try:
                page.goto((ROOT/locale/'search.html').as_uri()+'?q=SDK')
            except Exception as error:
                file_records.append({'locale':locale,'state':'not_executed',
                                     'reason':str(error)})
                break
            page.wait_for_selector('#search-results .nexus-search-identity',timeout=15000)
            page.wait_for_function('() => Search._pulse_status === -1')
            observed_file=page.evaluate("() => ({count:document.querySelectorAll('.nexus-search-identity').length})")
            file_records.append({'locale':locale,'state':'executed',**observed_file})
        report['direct_file_browsing']=file_records
        report['javascript_errors']=errors
        report['external_requests']=[url for url in requests if not url.startswith(base+'/') and not url.startswith(ROOT.as_uri()+'/')]
        assert not errors and not report['external_requests']
        report['assertions']=['bilingual_actual_search','version_type_badges','original_reviewed_stale_truth','safe_plaintext_injection','reject_foreign_and_parent_result_urls','one_identity_and_excerpt_per_result','no_external_requests']
        browser.close()
finally:
    server.shutdown()
    server.server_close()
report['passed']=True
(OUT/'browser.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':True,'locales':len(report['records']),'assertions':report['assertions']},ensure_ascii=False))
