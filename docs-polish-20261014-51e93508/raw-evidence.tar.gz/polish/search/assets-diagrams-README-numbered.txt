0	Nexus 平台图册
1	本图册交付15类必需视图及两张补充图。主图登记见 {download}`图清单 <diagram-index.csv>`，维护规则见 [图示标准](../../design/documentation-standards.md)。图有精确current/reference身份， 不可从图源存在、渲染成功或软件流程推断硬件和外部发布已执行。
2	代码依据固定为`0111c8d3b9c7b37d258b9c401070305b13b6f3a1`，该提交后的本轮 文档工具实现另以最终执行记录为准；固件源码关系没有随图生成改变。图源为可编辑 DOT，输出为本地SVG。深色标签、线型和文字共同表达关系，不依赖颜色单独传达。
3	FIG-01/03/04/06/08/10/12的节点和关系附简短英文，供关键双语页面共享同一图源。 SVG采用Graphviz Cairo字形路径输出，使离线读者无需安装中文字体；每图附title、 desc和正文alt/caption。生成主机需要锁定Graphviz、Cairo及Noto Sans CJK SC， 最终工具身份与自动检查结果由文档交付记录绑定。源码语义、实际浏览器桌面/窄屏/ 放大/打印与离线包验收分开记录。15主图和2补充图已独立逐边与PNG审查；current为source_reviewed，reference为 reference_reviewed，补充target为design_reviewed。浏览器与正式包验收另按实际 执行记录判断，这些状态不建立HIL或公开部署资格。
4	FIG-01 全平台分层与外部边界
5	**身份：current。范围：产品外置；可选组件与OS；运行访问和构建事实逐边区分。**
6	![FIG-01：产品外置；可选组件与OS；运行访问和构建事实逐边区分](platform-architecture.svg)
7	FIG-01：产品外置；可选组件与OS；运行访问和构建事实逐边区分
8	应用拥有任务、调度、恢复和停机协调。Board参与构建期授权；factory取得身份后日常I/O通过face进入provider。Arch按编译目标选择，没有CPU factory或强制OS转发。虚线为显式可选关系或构建期事实，实线标签说明调用/合同。
9	依据：[当前架构合同](../../delivery/architecture.md)、[根CMake](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/CMakeLists.txt)、[静态装配生成](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/bindings.py)、[平台运行补充图](platform-runtime.svg)。 {download}`可编辑DOT <platform-architecture.dot>`；实施关联：DOC-43。
10	FIG-02 选定编译目标依赖
11	**身份：reference。范围：H743 baremetal IRQ UART；准确PUBLIC/PRIVATE/INTERFACE/OBJECT关系。**
12	![FIG-02：H743 baremetal IRQ UART；准确PUBLIC/PRIVATE/INTERFACE/OBJECT关系](build-targets.svg)
13	FIG-02：H743 baremetal IRQ UART；准确PUBLIC/PRIVATE/INTERFACE/OBJECT关系
14	参考tools/configure/assemblies/nucleo-h743-baremetal-uart.toml的选定目标。箭头从依赖者指向被依赖目标；虚线明确PRIVATE include或OBJECT注入。统一warnings、配置选项边和GC策略省略；它们仍由真实CMake管理。厂商headers只进入实现/启动私有范围，配置生成的bindings也按私有include规则消费SDK；可选组件不在本装配中。
15	依据：[根目标图](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/CMakeLists.txt)、[firmware helper](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/cmake/platform/Firmware.cmake)、[IO targets](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/io/CMakeLists.txt)、[Arch targets](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/arch/CMakeLists.txt)、[OS targets](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/os/CMakeLists.txt)、[H743 target](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32h743/CMakeLists.txt)、[ABI/Config目标](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/cmake/platform/Options.cmake)。 {download}`可编辑DOT <build-targets.dot>`；实施关联：DOC-44。
16	FIG-03 配置与原子生成
17	**身份：current。范围：构建输入/产物链，生成失败使owned bundle失效。**
18	![FIG-03：构建输入/产物链，生成失败使owned bundle失效](configuration-generation.svg)
19	FIG-03：构建输入/产物链，生成失败使owned bundle失效
20	边表示构建时输入和产物传递，不表示运行时调用。严格解析不能修复非法字段、冲突或陈旧输入；失败只撤回拥有的输出，不清理未拥有目录，也不暴露半成品。ELF/资源报告不构成实板资格。
21	依据：[配置器](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/configure.py)、[不可变IR](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/ir.py)、[bundle事务](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/bundle.py)、[构建合同](../../design/build-system.md)。 {download}`可编辑DOT <configuration-generation.dot>`；实施关联：DOC-45。
22	FIG-04 factory与静态实例
23	**身份：reference。范围：按需选入的两同类实例示意；同模式ops共享，controller/endpoint独立。**
24	![FIG-04：按需选入的两同类实例示意；同模式ops共享，controller/endpoint独立](factory-instances.svg)
25	FIG-04：按需选入的两同类实例示意；同模式ops共享，controller/endpoint独立
26	结构图展示由生成器支持的按配置实例布局，不声称每块PCB均授权这些组合。同provider同模式实例共享readonly ops，各自context/state/storage独立。不同provider或模式可使用不同ops；调用方法接收本次context。controller和endpoint有独立factory命名空间，endpoint不冒充控制器。ID只在当前assembly有效，默认uint16_t typedef不提供语言级跨类防混用。
27	依据：[typed factory生成](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/factory.py)、[face/state装配](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/bindings.py)、[SPI公开接口](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/io/include/nexus/io/spi.h)、[Native provider](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/providers/native/bindings.py)。 {download}`可编辑DOT <factory-instances.dot>`；实施关联：DOC-46。
28	FIG-05 显式启动停机与失败撤回
29	**身份：current。范围：生成生命周期骨架；每个SoC私有启动/清理保持具体合同。**
30	![FIG-05：生成生命周期骨架；每个SoC私有启动/清理保持具体合同](platform-lifecycle.svg)
31	FIG-05：生成生命周期骨架；每个SoC私有启动/清理保持具体合同
32	外部唯一执行者串行调用start/stop。start不启动调度器；失败的primary、cleanup、remaining_effects分别保留。已取得效果者参与逆序cleanup，停止可能先成功释放部分实例再返回BUSY/IO。不能把BUSY视为仍然完整运行，也不能因timeout回收存储。具体start_system失败可能在其私有路径中完成清理或保留失败阶段，重试必须满足该provider合同，不能把图视为统一恢复API。
33	依据：[生成的start/stop](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/bindings.py)、[GPIO冷租约](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/gpio_phase.py)、[H743冷生命周期](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32h743/README.md)、[当前平台合同](../../delivery/architecture.md)。 {download}`可编辑DOT <platform-lifecycle.dot>`；实施关联：DOC-47。
34	FIG-06 Core请求状态与借用
35	**身份：current。范围：Core helper允许的迁移与调用前提；不承诺各provider恢复API。**
36	![FIG-06：Core helper允许的迁移与调用前提；不承诺各provider恢复API](request-lifecycle.svg)
37	FIG-06：Core helper允许的迁移与调用前提；不承诺各provider恢复API
38	REJECTED/ACCEPTED是admission结果而非request状态。ACCEPTED后保持request/buffer借用，cancel/deadline只启动终止进度。SETTLED前必须完成provider最终访问、排空全部必要引用并release发布；调用方acquire观察。相关adapter/observer另需退出。QUARANTINED到SETTLED仅在实际恢复和排空证明成立时合法，不能通过initialize强行重置借用对象。
39	依据：[request公开合同](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/core/include/nexus/core/request.h)、[实际Core迁移](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/core/src/request.c)、[owner最终发布](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/components/bus_owner/src/bus_owner.c)。 {download}`可编辑DOT <request-lifecycle.dot>`；实施关联：DOC-48。
40	FIG-07 UART与SPI有限DMA时序
41	**身份：reference。范围：F407 USART1/SPI1精确有限DMA；Task/IRQ/DMA完成与失败路径。**
42	![FIG-07：F407 USART1/SPI1精确有限DMA；Task/IRQ/DMA完成与失败路径](dma-completion.svg)
43	FIG-07：F407 USART1/SPI1精确有限DMA；Task/IRQ/DMA完成与失败路径
44	上到下为先后，并区分Task、DMA IRQ和UART IRQ。UART DMA TC不替代最后串行位的TC；SPI两个DMA完成不替代BSY=0/TXE=1。最终排空与错误观察、引用撤回都先于SETTLED。CS节点描述软件命令，未证明电气电平或物理时序。取消/错误分支仍需同样的实际排空条件；失败保持QUARANTINED借用。不把NDTR推导为可靠wire字节数，也不推广为GD32 reset语义。
45	依据：[F407 UART DMA](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32f407/drivers/uart_dma.c)、[F407 SPI DMA](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32f407/drivers/spi_dma.c)、[DMA排空合同](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/io/include/nexus/io/dma.h)、[多控制器合同](../../design/multiple-dma-controllers.md)。 {download}`可编辑DOT <dma-completion.dot>`；实施关联：DOC-49。
46	FIG-08 wait wake与外部退出
47	**身份：current。范围：ready-arm-ready-wait-ready与实际执行/join责任。**
48	![FIG-08：ready-arm-ready-wait-ready与实际执行/join责任](wait-wake-shutdown.svg)
49	FIG-08：ready-arm-ready-wait-ready与实际执行/join责任
50	nx_wait_until只检查谓词并等待提示，不service硬件或创建worker。arm后再次检查避免lost wake；TIMEOUT后最终谓词为true仍返回SUCCESS。通知端口要求单一waiter。外部shutdown先关闭admission并请求cancel，保持owner/IRQ推进drain。producer借用结清后join；确认owner idle包含publication退出，再结束并join执行者。随后停止硬件RX/IRQ publishers、detach wake并join其他发布者，最后销毁OS同步存储。相关observers最终访问另需退出；仍运行的内核不得提前撤回clock/Tick，失败存储继续保留。
51	依据：[wait合同](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/os/include/nexus/os/wait.h)、[生产wait算法](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/os/wait.c)、[owner接口](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/components/bus_owner/include/nexus/components/bus_owner.h)、[OS生命周期](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/os/README.md)。 {download}`可编辑DOT <wait-wake-shutdown.dot>`；实施关联：DOC-50。
52	FIG-09 H743内存DMA与Cache
53	**身份：reference。范围：H743ZIT6有限USART3 TX；AXI SRAM完整32-byte lines。**
54	![FIG-09：H743ZIT6有限USART3 TX；AXI SRAM完整32-byte lines](h743-memory-cache.svg)
55	FIG-09：H743ZIT6有限USART3 TX；AXI SRAM完整32-byte lines
56	选定TX DMA仅授权AXI SRAM 512 KiB；其他物理域和dma_engines可达事实不自动授权placement或供电。Cache-on要求完整32-byte lines独占，最大65504 bytes；Cache-off接受1..65535 bytes。PREPARING借用先成立，clean在调用方正常mask下进行，完成前不能取消回收。图不实现或声明H743 RX DMA；未来RX需要独立前置及排空后维护合同。可信复位或此前成功自有clean/disable才建立冷cache前提，CCR关闭位不能认领外国dirty状态。
57	依据：[精确物理域](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32h743/soc.json)、[H743 provider范围](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32h743/README.md)、[TX DMA实现](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32h743/drivers/uart_dma.c)、[cache范围合同](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/arch/include/nexus/arch/cache.h)、[冷cache合同](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/arch/include/nexus/arch/cache_control.h)。 {download}`可编辑DOT <h743-memory-cache.dot>`；实施关联：DOC-51。
58	FIG-10 Source SDK独立消费
59	**身份：current。范围：实际公开入口和consumer；搬移完整prefix，Native run/ARM link分开。**
60	![FIG-10：实际公开入口和consumer；搬移完整prefix，Native run/ARM link分开](source-sdk-consumer.svg)
61	FIG-10：实际公开入口和consumer；搬移完整prefix，Native run/ARM link分开
62	打包、搬移、verify与consumer执行是独立步骤。安装prefix必须整体移动，SDK子树不能单独替代包闭包。find_package与resolver边界读取实际字节身份，fixture opt-in不绕过checksum。Native consumer实际运行；MCU consumer建立编译/链接/资源证据，不声明上板执行。parent target不得受到平台宏或厂商include污染。
63	依据：[Source SDK打包与verify](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/cmake/package/package_source_sdk.py)、[真实独立consumers](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/cmake/package/verify_consumers.py)、[resolver SDK验证边界](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/sdk.py)、[CMake SDK入口](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/cmake/platform/SDK.cmake)。 {download}`可编辑DOT <source-sdk-consumer.dot>`；实施关联：DOC-52。
64	FIG-11 软件与HIL证据关系
65	**身份：current。范围：实际scope evidence独立取得；HIL tooling不是物理测量。**
66	![FIG-11：实际scope evidence独立取得；HIL tooling不是物理测量](qualification-evidence.svg)
67	FIG-11：实际scope evidence独立取得；HIL tooling不是物理测量
68	Host/model、ARM/link/resources、SDK消费、两次断网复现和HIL工装各自必须有实际执行记录，并绑定同source/config/artifact。候选封存重新验证scope proof和原始字节。实际station测量另外绑定PCB、silicon、fixture及同镜像；无设备为not_executed。软件候选不自动提升为产品release、安全认证或LTS。
69	依据：[资格合同](../../delivery/qualification.md)、[candidate scope校验](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/evidence/candidate.py)、[真实proof验证](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/evidence/proof.py)、[断网复现](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/evidence/reproduce.py)、[HIL工装](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/hil/README.md)。 {download}`可编辑DOT <qualification-evidence.dot>`；实施关联：DOC-53。
70	FIG-12 文档SDK与证据发布恢复
71	**身份：reference。范围：交付流程参考；公开发布/下载需真实receipt，不从流程图推断发生。**
72	![FIG-12：交付流程参考；公开发布/下载需真实receipt，不从流程图推断发生](release-recovery.svg)
73	FIG-12：交付流程参考；公开发布/下载需真实receipt，不从流程图推断发生
74	文档、SDK、软件候选保持独立payload与资格。manifest的outputs只列payload，不含自身/checksums/archive；archive hash由外层receipt记录。不可变release-id不覆盖旧目录，stable不表达全部HIL通过。SDK/candidate/evidence使用现有字节验证与恢复机制，文档发布工具按实际CLI结果验收。独立恢复检查路径、size、hash与适用consumer，不把归档成功视为重新执行全部历史tests。公开发布、下载、长期存储由真实外部receipt证明，流程存在不能替代。
75	依据：[文档实际封存与恢复](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/documentation/delivery.py)、[文档交付合同](../../design/documentation-system.md)、[Source SDK闭包](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/cmake/package/package_source_sdk.py)、[候选封存](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/evidence/candidate.py)、[scope proof](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/evidence/proof.py)、[归档与独立恢复](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/evidence/store.py)。 {download}`可编辑DOT <release-recovery.dot>`；实施关联：DOC-54。
76	FIG-13 Cortex-M能力分层
77	**身份：current。范围：九核CPU软件层、Runtime、真实SoC与实板范围分开。**
78	![FIG-13：九核CPU软件层、Runtime、真实SoC与实板范围分开](cortex-m-capabilities.svg)
79	FIG-13：九核CPU软件层、Runtime、真实SoC与实板范围分开
80	CpuProfileIR显式选择合法ABI和optional feature，不从内核名推导能力。Runtime没有SoC/Board/startup/linker/factory；整平台另需精确provider和资源。当前M7冷cache控制不推广至其他带cache内核。图中的软件gates表示必须实际取得范围内证据，不继承历史counts；真实context保存、coherence、特权和波形仍需物理验收。
81	依据：[九核软件合同](../../delivery/cortex-m.md)、[CPU解析器](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/tools/configure/cpu.py)、[Runtime CMake入口](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/cmake/platform/Runtime.cmake)、[Arch源码目标](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/arch/CMakeLists.txt)、[整平台支持范围](../../delivery/support.md)。 {download}`可编辑DOT <cortex-m-capabilities.dot>`；实施关联：DOC-55。
82	FIG-14 U575同步双域参考
83	**身份：reference。范围：独立TZEN1无OS同步GPIO；不改变TZEN0默认provider。**
84	![FIG-14：独立TZEN1无OS同步GPIO；不改变TZEN0默认provider](u575-security-domains.svg)
85	FIG-14：独立TZEN1无OS同步GPIO；不改变TZEN0默认provider
86	boot owner供给并在执行前建立实际option-byte/镜像布局前提，机制不写option bytes。GTZC/SAU/NS MPU是不同边界，NSC fetch检查Secure MPU，不能用CMSE观察替代bus firewall或pin。参考要求无NS handlers、RTOS和自主masters，固定world principal只允许同步scalar GPIO。取得不可逆效果后的失败只能保留到reset；SG的同步pin来自静态映射和无并发条件。实际8/16 MPU region观测仅属于此参考，不修改TZEN0 provider的exact-eight tuple。全部物理隔离尚未执行。
87	依据：[双域权威合同](../../design/u575-trustzone-contract.md)、[生产冷owner](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32u575/security.c)、[真实配对镜像fixture](https://github.com/X-Gen-Lab/nexus/tree/NEXUS-DOCUMENTATION-SOURCE/tests/contracts/u575_trustzone)、[UserIoBroker](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/components/user_io_broker/README.md)、[CMSE公开观察合同](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/arch/include/nexus/arch/nonsecure.h)。 {download}`可编辑DOT <u575-security-domains.dot>`；实施关联：DOC-56。
88	FIG-15 连续RX与可见丢块
89	**身份：reference。范围：F407 USART1连续RX；预置FIFO贷款、loss和停止责任。**
90	![FIG-15：F407 USART1连续RX；预置FIFO贷款、loss和停止责任](continuous-stream.svg)
91	FIG-15：F407 USART1连续RX；预置FIFO贷款、loss和停止责任
92	preposted producer和普通producer不得混用。旧块在两个hardware targets中完全消失并证明CT/EN/新flags后才能FIFO发布；失败撤源并LIFO撤未来贷款，BORROWED consumer块不被覆盖。缺spare、IDLE和恢复可有间隙，lost_blocks是已观察边界而非精确遗漏wire字节。TC标志不能数任意多次合并回绕，实际IRQ/换址延迟必须小于一块fill时间。stop关闭admission、保持drain，outstanding=0后仍需调用者/observer退出。ADC首发trigger blocks由service显式rearm且有块间间隙，本图不声称连续ADC。
93	依据：[UART DMA/连续贷款合同](../../design/uart-dma-rs485.md)、[stream状态合同](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/io/include/nexus/io/stream.h)、[容量与观察合同](../../design/io-observation-recovery.md)、[F407 RX DMA实现](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32f407/drivers/uart_receive.c)、[ADC显式rearm](https://github.com/X-Gen-Lab/nexus/blob/NEXUS-DOCUMENTATION-SOURCE/soc/stm32f407/drivers/adc_stream.c)。 {download}`可编辑DOT <continuous-stream.dot>`；实施关联：DOC-57。
94	补充视图
95	[运行时访问补充图](platform-runtime.svg)和{download}`DOT图源 <platform-runtime.dot>`分开 表达factory lookup与直接I/O，不替代FIG-01完整分层。
96	[原文档系统目标图](documentation-target.svg)和{download}`DOT图源 <documentation-target.dot>` 保留原规划的构建输入关系；其target身份只表示方案来源，不建立当前工具、公开 部署、SDK或实板资格。现行交付与恢复按FIG-12及实际执行记录判定。
