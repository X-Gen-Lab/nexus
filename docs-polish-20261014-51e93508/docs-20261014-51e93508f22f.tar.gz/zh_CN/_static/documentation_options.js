const DOCUMENTATION_OPTIONS = {
    VERSION: '1.0.0',
    LANGUAGE: 'zh-CN',
    COLLAPSE_INDEX: false,
    BUILDER: 'html',
    FILE_SUFFIX: '.html',
    LINK_SUFFIX: '.html',
    HAS_SOURCE: false,
    SOURCELINK_SUFFIX: '.txt',
    NAVIGATION_WITH_KEYS: false,
    SHOW_SEARCH_SUMMARY: false,
    ENABLE_SEARCH_SHORTCUTS: true,
};