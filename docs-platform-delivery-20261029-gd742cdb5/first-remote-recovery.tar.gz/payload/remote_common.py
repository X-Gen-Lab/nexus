"""Bounded exact-Git-commit transport observation using existing verifiers."""
import os,sys,json,hashlib,shutil,tarfile,time
from pathlib import Path,PurePosixPath
from urllib.request import Request,urlopen
from urllib.parse import quote
ROOT=Path('/workspace/nexus');sys.path.insert(0,str(ROOT))
from tools.dev.process import run
C=ROOT/'build/c-cold-20261028/p5-external-retention';META=C/'remote';META.mkdir(exist_ok=True)
STORAGE=json.loads((C/'push-readback.json').read_text())['commit'];NS='docs-platform-delivery-20261029-gd742cdb5';LOCAL=Path('/dev/shm/nexus-assets-final')/NS
OUT=Path('/dev/shm/nexus-assets-p5-remote-'+STORAGE[:8]);DATA=OUT/NS;TOOLS=OUT/'verification-tools';MIN=250*1024**2

def checksum(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def guard(path,needed=0,reserve=0):
 if shutil.disk_usage(path).free-needed-reserve<MIN:raise RuntimeError('Capacity guard: '+str(path))

def fetch_small(relative,path,identity):
 url='https://raw.githubusercontent.com/X-Gen-Lab/nexus/'+STORAGE+'/'+quote(relative,safe='/')
 with urlopen(Request(url,headers={'User-Agent':'Nexus-P5-exact-retention'}),timeout=60) as response:
  assert response.status==200;data=response.read(identity['bytes']+1)
 assert len(data)==identity['bytes'] and hashlib.sha256(data).hexdigest()==identity['sha256'];guard(path.parent,len(data));path.write_bytes(data)
 return {**identity,'path':relative,'url':url,'http_status':200,'status':'downloaded_exact_bytes_verified'}

def stream_archive(package,observations):
 target=DATA/package['archive']['path'];assert not target.exists();guard('/dev/shm',package['archive']['bytes'],16*1024**2)
 whole=hashlib.sha256();size=0
 try:
  with target.open('xb') as output:
   for part in package['parts']:
    url='https://raw.githubusercontent.com/X-Gen-Lab/nexus/'+STORAGE+'/'+quote(NS+'/'+part['path'],safe='/');h=hashlib.sha256();n=0
    with urlopen(Request(url,headers={'User-Agent':'Nexus-P5-exact-retention'}),timeout=90) as response:
     assert response.status==200
     while block:=response.read(1024**2):
      guard('/dev/shm',len(block),8*1024**2);n+=len(block)
      if n>part['bytes']:raise ValueError('Remote part exceeded original bytes')
      h.update(block);whole.update(block);output.write(block)
    assert n==part['bytes'] and h.hexdigest()==part['sha256'];size+=n
    observations.append({**part,'path':NS+'/'+part['path'],'url':url,'http_status':200,'status':'downloaded_exact_bytes_verified'})
    (META/'downloads.json').write_text(json.dumps({'storage_commit':STORAGE,'members':observations},indent=2)+'\n')
  assert size==package['archive']['bytes'] and whole.hexdigest()==package['archive']['sha256']
 except Exception:
  target.unlink(missing_ok=True);raise
 return target

def command(name,argv,timeout=900):
 guard('/workspace');guard('/dev/shm')
 r=run(argv,cwd=OUT,env=os.environ.copy(),log=META/(name+'.log'),timeout=timeout,stage=name);assert r.returncode==0,name

def verify_archive(package):
 command(package['archive']['path']+'-verify',[sys.executable,'-B',str(TOOLS/'tools/evidence/store.py'),'verify','--package',str(DATA/package['original_package']),'--archive',str(DATA/package['archive']['path']),'--report',str(META/(package['archive']['path']+'-verify.json'))])

def restore_one(package):
 expanded=package.get('expanded_bytes') or 100*1024**2
 guard('/workspace',expanded,64*1024**2)
 role=package['role'];name=package['archive']['path'];archive=DATA/name;dest=C/('independent-restore-'+name.replace('.tar.gz',''))
 assert not dest.exists()
 if role=='strict_bilingual_documentation':
  leaf=json.loads((DATA/'delivery-index.json').read_text());code='import sys,json;from pathlib import Path;sys.path.insert(0,'+repr(str(TOOLS))+');from tools.documentation import delivery;h='+repr(leaf['docs']['manifest_sha256'])+';a=Path('+repr(str(archive))+');d=Path('+repr(str(dest))+');delivery.verify(a,expected_manifest_sha256=h);r=delivery.restore(a,d,expected_manifest_sha256=h);delivery.verify(d,expected_manifest_sha256=h);print(json.dumps({"status":"passed","release_id":r["release_id"],"manifest_sha256":h}))'
  command(name+'-restore',[sys.executable,'-B','-c',code])
 else:
  command(name+'-restore',[sys.executable,'-B',str(TOOLS/'tools/evidence/store.py'),'restore','--package',str(DATA/package['original_package']),'--archive',str(archive),'--destination',str(dest),'--report',str(META/(name+'-restore.json'))])
  if role=='observed_generic_OCI_layout_bytes_only':
   code='import sys,json;from pathlib import Path;sys.path.insert(0,'+repr(str(TOOLS))+');from tools.evidence.container import verify;r=verify(Path('+repr(str(dest/'environment.json'))+'),runtime=False);print(json.dumps({"status":"verified_observed_layout_bytes","image_config_id":r["image_config_id"],"fresh_daemon_load":"not_executed","recipe_reconstruction":False}))'
   command(name+'-OCI-layout-verify',[sys.executable,'-B','-c',code])
  elif role=='fresh_P5_example_produced_verified_SourceSDK_not_formal50_claim':
   command(name+'-restored-sdk-verify',[sys.executable,'-B',str(dest/'share/nexus/src/cmake/package/package_source_sdk.py'),'--verify',str(dest/'share/nexus/src')])
 # Existing unchanged maintenance verifiers have checked the full original member
 # closure. Only this newly restored duplicate is retired; all source/lease bytes stay.
 shutil.rmtree(dest);archive.unlink()
 return {'role':role,'archive_sha256':package['archive']['sha256'],'actual_restore_exit_code':0,'original_envelope_unchanged':True,'restored_duplicate_retired_only_after_full_verification':True,'remote_download_duplicate_retired_after_verified_restore':True}

def setup_verifiers(leaf):
 assert not TOOLS.exists();TOOLS.mkdir()
 expected={x['path']:x for x in leaf['verifiers']['source_files']};seen=set()
 with tarfile.open(DATA/leaf['verifiers']['archive']['path'],'r:gz') as archive:
  for member in archive:
   p=PurePosixPath(member.name);assert not p.is_absolute() and '..' not in p.parts
   target=TOOLS/str(p)
   if member.isdir():target.mkdir(parents=True,exist_ok=True);continue
   assert member.isfile() and member.name in expected and member.name not in seen;seen.add(member.name)
   data=archive.extractfile(member).read();spec=expected[member.name];assert len(data)==spec['bytes'] and hashlib.sha256(data).hexdigest()==spec['sha256']
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);target.chmod(member.mode&0o777)
 assert seen==set(expected)
