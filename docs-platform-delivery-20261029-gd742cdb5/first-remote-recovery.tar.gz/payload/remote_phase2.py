import os,sys,json,shutil,time
from pathlib import Path
os.nice(15);sys.path.insert(0,str(Path(__file__).parent))
from remote_common import *
p=json.loads((META/'phase1-handoff.json').read_text());assert p['all34new_members_downloaded_and_SHA_verified']
assert shutil.disk_usage('/workspace').free>=1500000000
record={'kind':'P5_coordinated_independent_heavy_restore','authorization':'final_qualification NativeDebug actualpass + pure.o fully verified backup/evict; overlay>=1.5GB window explicitly granted','started_disk':{x:shutil.disk_usage(x)._asdict() for x in ['/workspace','/dev/shm']},'restores':[]}
(META/'phase2-progress.json').write_text(json.dumps(record,indent=2)+'\n')
for package in sorted(p['pending_coordinated_restores'],key=lambda x:x['expanded_bytes'],reverse=True):
 result=restore_one(package);record['restores'].append(result);record['current_disk']={x:shutil.disk_usage(x)._asdict() for x in ['/workspace','/dev/shm']}
 (META/'phase2-progress.json').write_text(json.dumps(record,indent=2)+'\n')
all_restores=[*p['small_independent_restores'],*record['restores']];assert len(all_restores)==7
record.update(status='all7actual_independent_restores_passed_and_duplicates_retired',all_restores=all_restores,all_large_downloads_and_expansions_retired=True,source_prefix_and_existing_archives_untouched=True,qualified_firmware=False,physical_status='not_executed',OCI_recipe_reconstruction=False,fresh_daemon_load='not_executed',full159_and8candidates='pending',finished_disk={x:shutil.disk_usage(x)._asdict() for x in ['/workspace','/dev/shm']})
(META/'phase2-handoff.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'actual_independent_restores':7,'all_large_duplicates_cleaned':True,'disk':record['finished_disk']}))
