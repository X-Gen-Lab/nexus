import os,sys,json,shutil
from pathlib import Path
os.nice(15)
sys.path.insert(0,str(Path(__file__).parent))
from remote_common import *
assert not OUT.exists();OUT.mkdir();DATA.mkdir()
s=json.loads((C/'stage.json').read_text());leaf_expected=json.loads((LOCAL/'delivery-index.json').read_text());parts={x['path'] for a in leaf_expected['archives'] for x in a['parts']}
observations=[]
# First authenticate the cumulative registry bytes against the actual pushed tree.
registry_path=Path('/dev/shm/nexus-assets-final/assets.json');expected={'bytes':registry_path.stat().st_size,'sha256':checksum(registry_path)}
fetch_small('assets.json',OUT/'assets.json',expected)
registry=json.loads((OUT/'assets.json').read_text());old=json.loads((C/'old-assets.json').read_text());assert registry['members'][:136]==old['members'];assert {k:v for k,v in registry.items() if k!='members'}=={k:v for k,v in old.items() if k!='members'}
new=[x for x in registry['members'] if x['path'].startswith(NS+'/')];assert len(new)==s['member_count']==34
for item in new:
 if Path(item['path']).name not in parts:
  observations.append(fetch_small(item['path'],DATA/Path(item['path']).name,item))
(META/'downloads.json').write_text(json.dumps({'storage_commit':STORAGE,'members':observations},indent=2)+'\n')
leaf=json.loads((DATA/'delivery-index.json').read_text());assert leaf==leaf_expected;setup_verifiers(leaf)
restored=[];pending=[]
for package in leaf['archives']:
 stream_archive(package,observations);verify_archive(package)
 if package['role'] in ['observed_generic_OCI_layout_bytes_only','complete_examples_scope_all_starters_and_onboarding']:
  pending.append(package)
 else:
  # Small restores are rolling and bounded; a capacity refusal defers them to
  # the same explicitly coordinated window rather than weakening the guard.
  try:restored.append(restore_one(package))
  except RuntimeError as failure:
   if not str(failure).startswith('Capacity guard:'):raise
   pending.append(package)
   (META/'deferred-capacity.json').write_text(json.dumps({'role':package['role'],'reason':str(failure)})+'\n')
 (META/'phase1-progress.json').write_text(json.dumps({'storage_commit':STORAGE,'verified_remote_members':len(observations),'restored':restored,'pending':pending,'disk':{p:shutil.disk_usage(p)._asdict() for p in ['/workspace','/dev/shm']}},indent=2)+'\n')
assert len(observations)==34 and {x['path'] for x in observations}=={x['path'] for x in new}
record={'kind':'P5_completed_assets_exact_commit_download_and_stream_verification','storage_commit':STORAGE,'all34new_members_downloaded_and_SHA_verified':True,'new_member_bytes':s['new_bytes'],'all7original_archives_existing_store_verified':True,'small_independent_restores':restored,'pending_coordinated_restores':pending,'old136members_and_header_unchanged':True,'heavy_restore_started':False,'qualification':False,'full159_and8candidates':'pending','physical_status':'not_executed','OCI_recipe_reconstruction':False,'fresh_daemon_load':'not_executed','disk':{p:shutil.disk_usage(p)._asdict() for p in ['/workspace','/dev/shm']}}
(META/'phase1-handoff.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'storage_commit':STORAGE,'new_members':34,'all7streamverified':True,'rolling_restores':len(restored),'pending_heavy':len(pending),'tmpfs_free':shutil.disk_usage('/dev/shm').free,'overlay_free':shutil.disk_usage('/workspace').free}))
