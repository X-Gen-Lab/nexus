"""One-shot append-only P5 completed-artifact transport, never qualification."""
import os,sys,json,hashlib,shutil,subprocess,tarfile
from pathlib import Path
os.nice(15)
ROOT=Path('/workspace/nexus');sys.path.insert(0,str(ROOT))
from tools.dev.process import run
from tools.evidence.common import file_identity
B=ROOT/'build/c-cold-20261028';CONTROL=B/'p5-external-retention';LOG=CONTROL/'execution';LOG.mkdir(exist_ok=True)
A=Path('/dev/shm/nexus-assets-final');NS='docs-platform-delivery-20261029-gd742cdb5';D=A/NS
P='d742cdb5a0606bd4be22e14eff0738df3ba07549';E='6f09ae5539d58161acdab944767e8067895ad9bb';BASE='5fd10744da5416169c879147f47c7902916ef8ca';MIN=250*1024**2
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==P
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True)==''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=A,text=True).strip()==BASE
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=A,text=True)==''
assert not D.exists();D.mkdir()
old=json.loads((A/'assets.json').read_text());assert len(old['members'])==136
(CONTROL/'old-assets.json').write_bytes((A/'assets.json').read_bytes())

def capacity(path,needed=0):
 free=shutil.disk_usage(path).free
 if free-needed<MIN:raise RuntimeError('Capacity guard refuses write: '+str(path)+' free='+str(free)+' needed='+str(needed))
 return free

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def copy(src,name):
 src=Path(src);target=D/name;assert src.is_file() and not src.is_symlink() and not target.exists();capacity('/dev/shm',src.stat().st_size)
 shutil.copyfile(src,target);assert sha(src)==sha(target);return target

def execute(name,argv,timeout=900):
 capacity('/workspace');capacity('/dev/shm')
 r=run(argv,cwd=ROOT,env=os.environ.copy(),log=LOG/(name+'.log'),timeout=timeout,stage=name)
 assert r.returncode==0,name

def package(src,envelope,name,role):
 src=Path(src);envelope=Path(envelope);value=json.loads(envelope.read_text())
 assert src.stat().st_size==value['archive']['size'] and sha(src)==value['archive']['sha256']
 env_name=name+'.package.json';copy(envelope,env_name)
 parts=[]
 with src.open('rb') as stream:
  index=0
  while block:=stream.read(32*1024**2):
   target_name=name if src.stat().st_size<=32*1024**2 else name+'.part'+str(index).zfill(4)
   capacity('/dev/shm',len(block));target=D/target_name;assert not target.exists();target.write_bytes(block)
   parts.append({'path':target_name,'bytes':len(block),'sha256':hashlib.sha256(block).hexdigest()});index+=1
 assert sum(x['bytes'] for x in parts)==value['archive']['size']
 return {'role':role,'original_package':env_name,'archive':{'path':name,'bytes':value['archive']['size'],'sha256':value['archive']['sha256']},'parts':parts,'original_envelope_unchanged':True,'expanded_bytes':value.get('bytes'),'files':value.get('files')}

docs=B/'docs/final-d742cdb5';ex=Path('/dev/shm/nexus-examples-p5-evidence-6f09ae55');oci=B/'integration/observed-oci-retention'
dh=json.loads((docs/'handoff.json').read_text());eh=json.loads((ex/'final-package-index.json').read_text());oh=json.loads((oci/'handoff.json').read_text())
assert dh['source']['commit']==P and eh['platform_commit']==P and eh['examples_commit']==E
for source,name in [(docs/'handoff.json','docs-handoff.json'),(ex/'final-package-index.json','examples-index.json'),(ex/'final-handoff.json','examples-handoff.json'),(ex/'final-delivery-summary.json','examples-summary.json'),(B/'integration/commit-association-05.json','ordinary-commit-association.json'),(B/'workflow/f04-review/f04-original-exit-p5-review.json','f04-original-exit-p5-review.json'),(oci/'handoff.json','observed-oci-handoff.json'),(oci/'retention-receipt.json','observed-oci-retention-receipt.json'),(oci/'layer-path-audit.json','observed-oci-layer-path-audit.json')]:copy(source,name)
archives=[]
archives.append(package(Path(dh['documentation_package']['friendly_archive']),docs/'package-preservation.json','documentation.tar.gz','strict_bilingual_documentation'))
archives.append(package(Path(dh['raw_build_and_execution_records']['archive']['path']),docs/'raw-build-package.json','documentation-raw.tar.gz','actual_strict_docs_build_and_execution'))
for key,name,role in [('examples-build','examples.tar.gz','complete_examples_scope_all_starters_and_onboarding'),('user-product','created-product.tar.gz','actual_external_created_product')]:
 env=Path(eh['packages'][key]['package']);v=json.loads(env.read_text());archives.append(package(Path(v['archive']['path']),env,name,role))
env=B/'final-software-execution/ordinary-p5-package.json';v=json.loads(env.read_text());archives.append(package(Path(v['archive']['path']),env,'ordinary-p5.tar.gz','actual_ordinary_hook_gate_and_same_tree_canonical_association'))
env=oci/oh['archive']['package'];v=json.loads(env.read_text());archives.append(package(Path(v['archive']['path']),env,'observed-oci.tar.gz','observed_generic_OCI_layout_bytes_only'))
# SourceSDK is freshly produced by the P5 examples all-scope entry, not inherited
# from P4 or relabelled as the still-pending formal50-consumer execution.
prefix=Path(eh['immutable_sdk_prefix']);sdk_manifest=prefix/'share/nexus/src/.nexus-source-sdk.json';sdk_before=file_identity(sdk_manifest);sdk=json.loads(sdk_manifest.read_text());assert sdk['source_revision']==P and sdk['snapshot_sha256']==eh['sdk_snapshot_sha256']
sdkout=CONTROL/'source-sdk';sdkout.mkdir()
capacity('/workspace',16*1024**2)
execute('source-sdk-export',[sys.executable,'-B',str(ROOT/'tools/evidence/store.py'),'export','--source',str(prefix),'--store',str(sdkout/'store'),'--report',str(sdkout/'package.json')])
execute('source-sdk-store-verify',[sys.executable,'-B',str(ROOT/'tools/evidence/store.py'),'verify','--package',str(sdkout/'package.json'),'--report',str(sdkout/'verify.json')])
v=json.loads((sdkout/'package.json').read_text());archives.append(package(Path(v['archive']['path']),sdkout/'package.json','source-sdk.tar.gz','fresh_P5_example_produced_verified_SourceSDK_not_formal50_claim'))
assert file_identity(sdk_manifest)==sdk_before
with tarfile.open(Path(dh['documentation_package']['friendly_archive']),'r:gz') as t:
 m=t.getmember('documentation-manifest.json');assert m.isfile();(D/'documentation-manifest.json').write_bytes(t.extractfile(m).read())
assert sha(D/'documentation-manifest.json')==dh['documentation_package']['original_documentation_manifest_sha256']
changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',P],cwd=ROOT,text=True).splitlines();assert len(changed)==7
source_archive=D/'p5-seven-source-paths.tar.gz';subprocess.run(['git','archive','--format=tar.gz','--output',str(source_archive),P,*changed,'LICENSE'],cwd=ROOT,check=True)
source_records=[{'path':name,'sha256':hashlib.sha256(subprocess.check_output(['git','show',P+':'+name],cwd=ROOT)).hexdigest()} for name in changed]
verifier_files=['LICENSE','tools/evidence/store.py','tools/evidence/common.py','tools/evidence/identity.py','tools/evidence/container.py','tools/configure/metadata.py','tools/documentation/delivery.py']
verifier_archive=D/'verification-tools-gd742cdb5.tar.gz';subprocess.run(['git','archive','--format=tar.gz','--output',str(verifier_archive),P,*verifier_files],cwd=ROOT,check=True)
verifiers=[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name in verifier_files for data in [subprocess.check_output(['git','show',P+':'+name],cwd=ROOT)]]
index={'schema_version':1,'kind':'existing_delivery_artifact_navigation','batch':'completed_P5_docs_examples_ordinary_SourceSDK_and_observed_OCI_only','platform':{'commit':P,'tree':'570f807e722649e976670f747950fe1acb61fcc7'},'examples':{'commit':E,'tree':'1616b4faa55c2f63cc4eaac62b1b6dc23c790b84','platform_gitlink':P},'storage_parent':BASE,'archives':archives,'source_change_paths':source_records,'source_change_archive':{'path':source_archive.name,'sha256':sha(source_archive),'bytes':source_archive.stat().st_size},'verifiers':{'archive':{'path':verifier_archive.name,'bytes':verifier_archive.stat().st_size,'sha256':sha(verifier_archive)},'source_commit':P,'source_files':verifiers},'docs':{'languages':['en','zh_CN'],'pages':132,'language_page_records':264,'tool_tests':355,'manifest_sha256':sha(D/'documentation-manifest.json'),'qualification_references':[]},'examples_actual':{'commands':104,'presets':17,'standalones':9,'ARM_images':41,'starters':4,'external_actual_create_build_run':'passed'},'ordinary_gate':{'python':3479,'google_programs':386,'google_cases':6817,'IO_properties':203,'association':'ordinary-commit-association.json'},'F04_original_exit':{'review':'f04-original-exit-p5-review.json','status':'passed_at_declared_mapping_and_immutable_setup_scope','automapped_C_independence_unknown':4438,'all_cases_manually_proven_independent':False},'source_sdk':{'producer':'fresh_P5_examples_scope_all','snapshot_sha256':sdk['snapshot_sha256'],'source_revision':P,'formal_all50_consumers':'pending_fresh_P5_formal_stage88'},'full_159_stage_execution':'pending_separate_final_result','eight_final_candidates':'pending_separate_seals','qualification':False,'physical_status':'not_executed','observed_OCI':{'archive_role':'observed_generic_OCI_layout_bytes_only','image_config_id':'sha256:a1ba03c16d424aef88dad6e5b2ead2892734a0bf909dedc23d8855fa4861fbe0','recipe_independently_reconstructed':False,'fresh_daemon_load':'not_executed','runtime_verification_during_retention':False},'official_release':'not_published','rendered_site_deployment':'not_established_by_Git_asset_retention','scope':'Original archive/envelope bytes and source identities preserved. This is artifact navigation, not a replacement task or qualification authority. Existing P4 members keep their original identity; none is relabelled as P5. Later final results append separate final-index files.'}
(D/'delivery-index.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n')
(D/'README.txt').write_text('''Nexus P5 completed software/documentation artifacts\n\nExact platform d742cdb5a0606bd4be22e14eff0738df3ba07549\nExact examples 6f09ae5539d58161acdab944767e8067895ad9bb\n\nUse one exact immutable storage-commit URL for every member. Cumulative assets.json\nbinds member bytes; delivery-index.json binds original full archives and ordered\n<=32MiB transport parts. Join parts in that order and check original size/SHA.\nKeep all original package JSON path fields unchanged: existing store.py verify/\nrestore accepts explicit --archive navigation after transport. The small verifier\narchive contains unchanged exact-P5 stdlib tools and LICENSE. Documentation\nverify/restore must force the original manifest hash in delivery-index.json.\nSourceSDK can be restored and checked by its own package_source_sdk.py --verify.\nObserved OCI may be restored and checked with container.verify(runtime=False);\nthis preserves observed layout bytes, not a recipe rebuild or fresh-daemon load.\n\n本批交付已完成的中英文文档、示例、普通提交门禁、P5源码SDK和观察到的OCI字节。\n完整159阶段及8候选待单独实际执行、验证后以新final-index追加，未赋予本批固件资格。\n实板HIL未执行；没有创建正式Release、Pages部署或服务端规则。\nP4所有历史成员原样保留，禁止把旧包重标为P5。\n\nF04 closes only its declared contract/oracle mapping and immutable shared setup\nexit;4438 automatic C mappings retain unknown individual semantic independence.\nA successful portable byte restore is not a new firmware test execution.\n''')
entries=[]
for p in sorted(D.iterdir()):
 assert p.is_file() and not p.is_symlink() and p.stat().st_size<=32*1024**2
 entries.append({'path':p.relative_to(A).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
updated={**old,'members':old['members']+entries};assert len({x['path'] for x in updated['members']})==len(updated['members'])
(A/'assets.json').write_text(json.dumps(updated,indent=2,ensure_ascii=False)+'\n')
execute('asset-full-verify',['python3','-B',str(A/'verify_assets.py')])
record={'kind':'P5_first_completed_asset_stage','base':BASE,'namespace':NS,'new_members':entries,'member_count':len(entries),'new_bytes':sum(x['bytes'] for x in entries),'original136_members_and_header_unchanged':updated['members'][:136]==old['members'] and {k:v for k,v in updated.items() if k!='members'}=={k:v for k,v in old.items() if k!='members'},'source_prefix_untouched':sdk_before,'heavy_restore':'not_started_requires_finalqual_NativeDebug_pass_window','disk':{s:shutil.disk_usage(s)._asdict() for s in ['/workspace','/dev/shm']}}
(CONTROL/'stage.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'members':record['member_count'],'bytes':record['new_bytes'],'capacity':record['disk']}))
