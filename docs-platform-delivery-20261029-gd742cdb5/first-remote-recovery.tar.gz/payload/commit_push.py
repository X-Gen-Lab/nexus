import os,sys,json,subprocess,shutil
from pathlib import Path
os.nice(15)
R=Path('/workspace/nexus');sys.path.insert(0,str(R))
from tools.dev.process import run
C=R/'build/c-cold-20261028/p5-external-retention';A=Path('/dev/shm/nexus-assets-final');L=C/'git-execution';L.mkdir()
s=json.loads((C/'stage.json').read_text());minimum=250*1024**2
assert shutil.disk_usage('/dev/shm').free-s['new_bytes']-128*1024**2>=minimum
for number,path in enumerate(['assets.json',*[x['path'] for x in s['new_members']]]):
 needed=(A/path).stat().st_size
 if shutil.disk_usage('/dev/shm').free-needed-64*1024**2<minimum:raise RuntimeError('Gitadd capacity guard stopped before '+path)
 argv=['git','-c','gc.auto=0','-c','core.compression=1','add','--',path]
 r=run(argv,cwd=A,env=os.environ.copy(),log=L/('add-'+str(number).zfill(3)+'.log'),timeout=300,stage='P5_asset_add');assert r.returncode==0
r=run(['git','-c','gc.auto=0','-c','core.compression=1','commit','-m','docs(assets): retain completed P5 software and observed OCI bytes'],cwd=A,env=os.environ.copy(),log=L/'ordinary-commit.log',timeout=600,stage='P5_asset_ordinary_commit');assert r.returncode==0
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=A,text=True).strip();base=subprocess.check_output(['git','rev-parse','HEAD^'],cwd=A,text=True).strip();assert base==s['base']
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=A,text=True)==''
observed=subprocess.run(['gh','api','repos/X-Gen-Lab/nexus/branches/documentation-assets','--jq','.commit.sha'],capture_output=True,text=True,check=True).stdout.strip();assert observed==base
(C/'commit-preflight.json').write_text(json.dumps({'commit':head,'parent':base,'expected_old':base,'observed_old':observed,'force':False,'normal_hook':'passed','memory_free_before_push':shutil.disk_usage('/dev/shm').free},indent=2)+'\n')
if shutil.disk_usage('/dev/shm').free-128*1024**2<minimum:raise RuntimeError('Gitpush capacity guard')
env=os.environ.copy();env['GIT_TERMINAL_PROMPT']='0'
argv=['git','-c','gc.auto=0','-c','pack.threads=1','-c','pack.window=0','-c','pack.windowMemory=32m','-c','pack.deltaCacheSize=16m','-c','credential.helper=','-c','credential.helper=!gh auth git-credential','push','origin','HEAD:refs/heads/documentation-assets']
r=run(argv,cwd=A,env=env,log=L/'nonforce-push.log',timeout=1800,stage='P5_asset_push');assert r.returncode==0
observed=subprocess.run(['gh','api','repos/X-Gen-Lab/nexus/branches/documentation-assets','--jq','.commit.sha'],capture_output=True,text=True,check=True).stdout.strip();assert observed==head
(C/'push-readback.json').write_text(json.dumps({'commit':head,'parent':base,'observed_remote':observed,'actual_push_exit_code':0,'force':False,'new_member_count':s['member_count'],'new_member_bytes':s['new_bytes'],'tmpfs_free':shutil.disk_usage('/dev/shm').free,'overlay_free':shutil.disk_usage('/workspace').free},indent=2)+'\n')
print(json.dumps({'commit':head,'parent':base,'push_and_readback':'passed','tmpfs_free':shutil.disk_usage('/dev/shm').free}))
