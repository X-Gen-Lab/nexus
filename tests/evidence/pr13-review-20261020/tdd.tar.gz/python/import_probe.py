"""Exercise both supported import forms in separate uncached interpreters."""
import hashlib
import importlib
import json
from pathlib import Path
import sys

root = Path('/tmp/nexus-review-20261020')
mode, first = sys.argv[1:]
sys.path.insert(0, str(root if mode == 'package' else root / 'tools/configure'))
prefix = 'tools.configure.' if mode == 'package' else ''
importlib.import_module(prefix + first)
configure = importlib.import_module(prefix + 'configure')
factory = importlib.import_module(prefix + 'factory')
results = []
for assembly in ('tools/configure/assemblies/native.toml',
                 'tests/contracts/mainstream_assembly/f103-devices.toml'):
    resolved = configure.resolve_ir(root / assembly, root)
    header, source = factory.emit(resolved)
    assert 'nx_factory_gpio(' in header
    assert '#define NEXUS_FACTORY_H' in header
    results.append({'assembly': assembly,
        'factory_sha256': hashlib.sha256((header + source).encode()).hexdigest(),
        'soc_family': resolved.soc_family})
print(json.dumps({'mode': mode, 'first': first, 'status': 'passed',
                  'results': results}, sort_keys=True))
