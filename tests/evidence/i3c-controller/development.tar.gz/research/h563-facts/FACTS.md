# STM32H563 I3C software-reference facts

This is source research, not hardware selection or qualification. No source,
index, vendor tree or compiler was modified. STM32H563ZIT6 is a possible exact
software reference; PCB identity, electrical routing and fitted devices remain
unknown. The STM32H743 is single-core and does not gain I3C from this research.

## Source identities

- STM32H562/H563 datasheet **DS14258 Rev 6, May 2025**, downloaded from
  <https://www.st.com/resource/en/datasheet/stm32h563zi.pdf>.
- Device errata **ES0565 Rev 8, January 2026**, downloaded from
  <https://www.st.com/resource/en/errata_sheet/es0565-stm32h562xx563xx-and-stm32h573xx-device-errata-stmicroelectronics.pdf>.
- Application note **AN5879 Rev 6, June 2026**, downloaded from
  <https://www.st.com/resource/en/application_note/an5879-introduction-to-i3c-for-stm32-mcus-stmicroelectronics.pdf>.
- Official CMSIS device H5 commit
  `884b8dc78e41cbfca008363342b17f4a9e8641f7`.
- Official STM32H5 HAL/LL commit
  `16fea2d290119d6349b8f9a3b8538781ba1e1bdc`.
- Official STM32CubeH5 commit
  `bac48badf93cb496f6445afba956082490d3f543`.
- Official STM32 open pin data commit
  `7d1f1514ed5583ec5007ad91236b4e1d377295b1`.

Exact URLs, downloaded byte lengths and SHA-256 identities are in
`source-manifest.json`. The full RM0481 was not downloaded: its official response
advertised 72,018,543 bytes. Its exact register descriptions and a hardware wire
quiescence sequence therefore remain explicit validation work.

## Exact peripheral, package and electrical boundary

DS14258 section 3.36/table 8 establishes one I3C peripheral and SDR controller
and target capability. The H563 CMSIS header exposes only `I3C1`, with event IRQ
123 and error IRQ 124. `RCC_APB1LENR.I3C1EN` and
`RCC_APB1LRSTR.I3C1RST` are bit 23. `RCC_CCIPR4.I3C1SEL` is bits 25:24.

The pin-data `mcu/STM32H563ZITx.xml` specifies **LQFP144** and these package pins:

| I3C1 SCL | I3C1 SDA | AF | Physical package positions |
| --- | --- | --- | --- |
| PB8 | PB9 | AF3 | 139 / 140 |
| PB6 | PB7 | AF3 | 136 / 137 |
| PD12 | PD13 | AF5 | 81 / 82 |
| PF5 | PF15 | AF5 | 15 / 55 |
| PG7 | PG6 | AF3 | 92 / 91 |

The separate GPIO modes XML supplies the AF values. The Cube H563 hot-join
example uses PB8/PB9 AF3, AF push-pull, PCLK1 kernel clock. This establishes an
official example route, not an observed PCB route. DS14258 identifies PB8/PB9 as
part of the independently supplied **VDDIO2** domain (pages 29 and 35). An exact
integration must establish that supply and applicable voltage/compensation policy
before using those pins.

DS14258 electrical characteristics pages 224–225 state SDR SCL up to **12.5 MHz**,
under the stated setup: GPIO `OSPEEDR=10`, I/O compensation active, HSLV active
when VDD is at most 2.7 V, VOS0. Measured timing departures are explicitly listed
and may require longer SCL-low intervals or supported stalls. A low-level API or
register divider alone does not establish an electrically valid bus.

## Clocks, FIFOs and bounds

For H563, the official HAL RCC header's `RCC_CR_PLL3ON` branch selects **PCLK1,
PLL3R or HSI**. The PLL2R branch is for other H5 variants and must not be copied
into H563 facts. Clock frequency is an explicit configured fact, never inferred
from the existence of a selector. The example's PLL and HSE bypass setup does
not establish an external product's oscillator frequency.

AN5879 section 2.4, page 5 establishes:

- C-FIFO and S-FIFO: **two words each**.
- TX-FIFO and RX-FIFO: **eight bytes each**.
- TX/RX threshold: **one byte or four bytes**.

Threshold values are not FIFO depth. The HAL target-characteristics table has
four entries (`DEVRX[4]` in CMSIS); its IBI acknowledge/data settings refer to
targets 1–4. This does not establish that an arbitrary discovery loop is bounded.
The Cube hot-join example callback increments an application array index without
an independent capacity check; that pattern is unsuitable for platform admission.

Timing examples in AN5879 pages 26–27 contain inconsistent explanatory constants
(for example an SCL-low field described as 0x08 while its formula uses 0x09).
Use the actual selected register fields, kernel frequency and checked integer
timing equations; do not copy explanatory numbers as an authoritative tuple.

## Protocol limits and ownership implications

DS14258 table 8 supports SDR messages, DAA, CCCs, IBI with MDB, hot join,
secondary-controller behavior and target reset. It does **not** support HDR
DDR/TSL/TSP/BT, multilane data, or monitoring device early termination. Target
mode is not intended as a statically addressed I2C target. Legacy I2C controller
compatibility is limited to Fm/Fm+ targets that do not stretch the clock.

AN5879 sections 8.4–8.7 document 7-bit dynamic-address restrictions, ENTDAA 0x07,
RSTDAA 0x06, and direct versus broadcast CCC framing. Do not accept every value
from 0x03 through 0x7d: reserved and conditional addresses exist. A narrow pure-I3C
reference can admit an explicit collision-free conservative address set.

AN5879 section 8.10 states that a target advertising IBI data supplies at least
the MDB and **at most four bytes total** after the accepted IBI. An IBI event
must copy only that bounded payload into explicit caller storage. Discovery,
hot join and event delivery must not create devices in the static factory or
silently schedule application work.

## Errata that change the reference contract

ES0565 table 3 marks all four I3C limitations present on revisions A/Z/X/W;
table 2 maps them to REV_ID 0x1000/0x1001/0x1007/0x100f.

1. **2.15.1, pages 29–30:** legacy I2C read plus STALLT can continue clocking dummy
   bytes until RX overrun. Workarounds require error handling, timeout detection,
   stopping FIFO reads when necessary, and RX flush after the specific CE1/DOVR
   condition. The initial software reference should exclude legacy I2C entirely.
2. **2.15.2, pages 30–31:** address ACK/NACK stall may be missing after frame start.
   Set `NOARBH=0`; if necessary increase open-drain SCL-low time. A register stall
   setting is not proof of its intended bus behavior.
3. **2.15.3, page 31:** enabling a controller may generate an unexpected 0x7f read
   frame. Temporarily enable the SDA GPIO pull-up, wait **1 ms**, disable the
   pull-up, set CRINIT with EN still clear, then set EN. The Cube example uses
   that preparation on PB8/PB9. A common mechanism cannot invent that GPIO/time
   owner or treat merely reading EN back as proof that initialization was clean.
4. **2.15.4, pages 31–32:** no actual IBI-ACK timestamp exists for Async mode 0.
   The workaround is an application-owned timer approximation, not a hardware
   timestamp. Initial scope should exclude time-correlated IBI claims.

The downloaded errata supply no general cancellation/reset sequence proving that
the wire, peripheral, DMA and IRQ references are all detached. LL FIFO flush
functions merely request CFGR flush bits. A finite software deadline, FCF flag
or successful flush API call alone must not revoke a retained request/buffer.
The real port must supply verified quiescence; failure retains quarantine.

## Compile-only dependency and notice boundary

The I3C LL header includes `stm32h5xx.h`; selecting `STM32H563xx` includes the
H563 device header, then `core_cm33.h` and `system_stm32h5xx.h`. The maintained
CMSIS Core closure includes `cmsis_version.h`, `cmsis_compiler.h`, compiler-specific
`cmsis_gcc.h` for GCC and `mpu_armv8.h`. Enabling `USE_HAL_DRIVER` or full LL
implementation changes that closure and must be deliberate.

The unmodified ST headers retain their original copyright/license notices.
The downloaded HAL license is BSD-style three-clause; the CMSIS device component
is Apache-2.0; open pin data is BSD-3-Clause. Their exact license files are saved
alongside the sources. PDF documents are research references, not production
vendor code. No new H563 SoC, factory, startup or Board support follows from
compiling these headers in a Cortex-M33 Runtime consumer.
