from pathlib import Path
import sys,json,hashlib
import configure,bindings,factory,ir
from providers import maintained
output=Path(sys.argv[1]);output.mkdir(exist_ok=True)
result=configure.resolve_ir(configure.ROOT/'tools/configure/assemblies/u575-lptim-run.toml')
item,=result.controllers
construction=maintained(result.soc_family).constructor(item,result,result['board_bindings'],result['routes'],result.devices)
files=dict(zip(('nexus_bindings.h','nexus_bindings.c'),bindings.emit(result)))
files.update(zip(('nexus_factory.h','nexus_factory.c'),factory.emit(result)))
files['construction.json']=json.dumps(ir.thaw(construction),indent=2)+'\n'
records={}
for name,value in files.items():
    data=value.encode();(output/name).write_bytes(data);records[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
print(json.dumps(records,indent=2))
