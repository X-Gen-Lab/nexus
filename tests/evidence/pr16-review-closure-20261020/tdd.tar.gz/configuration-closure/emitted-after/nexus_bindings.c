/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#ifndef NX_PLATFORM_REGISTER_WRITE
#define NX_PLATFORM_REGISTER_WRITE(reg, value) ((reg) = (uint32_t)(value))
#endif
#ifndef NX_PLATFORM_PRIORITY_WRITE
#define NX_PLATFORM_PRIORITY_WRITE(reg, value) ((reg) = (uint8_t)(value))
#endif
#include "stm32u575_provider.h"
#include "stm32u575_lptim.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static nx_stm32u575_lptim_state_t s_nx_port_counter;
static const nx_lptim_port_t s_nx_face_counter = {
    &nx_stm32u575_lptim_ops, &s_nx_port_counter
};
const nx_lptim_port_t* const nx_binding_counter = &s_nx_face_counter;
static nx_result_t prepare_counter(void) {
    if (s_nx_port_counter.registers == NULL) { s_nx_port_counter.registers = LPTIM2; }
    return nx_stm32u575_lptim_initialize(&s_nx_port_counter);
}
void LPTIM2_IRQHandler(void);
/** \brief Exact UE observation; settlement remains task-owned. */
void LPTIM2_IRQHandler(void) { nx_stm32u575_lptim_irq(&s_nx_port_counter); }
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = nx_lptim_port_stop(&s_nx_face_counter);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    if (s_nx_platform_started) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
        nx_result_t system = nx_stm32u575_system_stop(&g_nx_stm32u575_system, 1000000u);
        if (system != NX_SUCCESS) { return system; }
    }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_stm32u575_system_preflight(&g_nx_stm32u575_system);
    if (result.primary != NX_SUCCESS) { return result; }
    if ((NX_U575_READ(&RCC->APB1RSTR2) & RCC_APB1RSTR2_LPTIM2RST) != 0u || (NX_U575_READ(&RCC->CCIPR1) & RCC_CCIPR1_LPTIM2SEL) != 0u || !NX_U575_IRQ_AVAILABLE(LPTIM2_IRQn)) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if ((NX_U575_READ(&RCC->APB1ENR2) & RCC_APB1ENR2_LPTIM2EN) != 0u) {
        if (NX_U575_READ(&LPTIM2->CR) != 0u || NX_U575_READ(&LPTIM2->CFGR) != 0u || NX_U575_READ(&LPTIM2->CFGR2) != 0u || NX_U575_READ(&LPTIM2->DIER) != 0u || NX_U575_READ(&LPTIM2->ISR) != 0u || NX_U575_READ(&LPTIM2->CCMR1) != 0u || NX_U575_READ(&LPTIM2->RCR) != 0u || NX_U575_READ(&LPTIM2->CNT) != 0u || NX_U575_READ(&LPTIM2->CCR1) != 0u || NX_U575_READ(&LPTIM2->CCR2) != 0u || NX_U575_READ(&LPTIM2->ARR) != 1u) {
            result.primary = NX_ERROR_BUSY; return result;
        }
    }
    nx_stm32u575_start_result_t system = nx_stm32u575_system_start(&g_nx_stm32u575_system, 1000000u);
    if (system.primary != NX_SUCCESS) {
        result.primary = system.primary;
        result.cleanup = system.cleanup;
        result.remaining_effects = system.remaining_effects;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = prepare_counter();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}
