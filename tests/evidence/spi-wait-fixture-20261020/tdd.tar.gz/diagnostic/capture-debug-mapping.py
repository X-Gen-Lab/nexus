import json
import os
from pathlib import Path
import sys
sys.path.insert(0,'/tmp/nexus-quality-20261019')
from tools.dev import process
root=Path('/tmp/nexus-quality-20261019')
out=Path('/tmp/nexus-spi-wait-fixture-20261020')
binary=str(root/'build/native-debug/bin/nexus_spi_dma_owner_wait_test')
env=os.environ.copy();env['CMAKE_BUILD_PARALLEL_LEVEL']='1'
for name,command in [
    ('old-close-assembly',['objdump','-d','-C','--no-show-raw-insn','--start-address=0xcb04','--stop-address=0xcc70',binary]),
    ('abort-diagnostic-assembly',['objdump','-d','--no-show-raw-insn',str(out/'diagnostic.so')]),
    ('old-close-source-lines',['addr2line','-f','-C','-e',binary,'0xcbcb','0x10837']),
    ('old-debug-dwarf',['readelf','--debug-dump=info',binary])]:
    result=process.run(command,cwd=root,env=env,log=out/(name+'.log'),timeout=120,stage=name)
    print(name,result.returncode,flush=True)
