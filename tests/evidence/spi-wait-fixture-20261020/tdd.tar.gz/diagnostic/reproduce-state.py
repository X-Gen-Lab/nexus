import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
sys.path.insert(0, '/tmp/nexus-quality-20261019')
from tools.dev import process
out = Path('/tmp/nexus-spi-wait-fixture-20261020')
primary = Path('/tmp/nexus-quality-20261019')
binary = primary/'build/native-debug/bin/nexus_spi_dma_owner_wait_test'
env = os.environ.copy()
env['CMAKE_BUILD_PARALLEL_LEVEL'] = '1'
commands = []
def run(name, command, environment=env):
    result = process.run(command, cwd=primary, env=environment,
                         log=out/(name+'.log'), timeout=120, stage=name)
    commands.append({'name': name, 'returncode': result.returncode,
                     'receipt': str(result.receipt_path)})
    print(name, result.returncode, flush=True)
    return result
run('compile-diagnostic-state', ['gcc','-shared','-fPIC','-g','-O0',str(out/'diagnostic.c'),'-ldl','-pthread','-o',str(out/'diagnostic.so')])
symbols = run('baseline-symbols-state',['nm','-an',str(binary)])
entries = [line.split() for line in symbols.stdout.splitlines()]
index = next(i for i,row in enumerate(entries) if len(row)==3 and row[2]=='notify_wake')
start = entries[index][0]
end = next(row[0] for row in entries[index+1:] if len(row)==3 and row[0]!=start)
held = env.copy()
held.update(LD_PRELOAD=str(out/'diagnostic.so'), NEXUS_NOTIFY_WAKE_START=start, NEXUS_NOTIFY_WAKE_END=end)
red = run('old-close-controlled-publication-state', [str(binary),'--gtest_filter=SPIDMAOwnerWait.ConcurrentCancelRetainsLoansUntilPublisherDrain', '--gtest_output=xml:'+str(out/'old-close-controlled-publication-state.xml')], held)
(out/'red-state.json').write_text(json.dumps({'old_binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(), 'old_source_sha256':hashlib.sha256((primary/'tests/google/spi_dma_owner_wait_test.cpp').read_bytes()).hexdigest(), 'notify_wake_start':start,'notify_wake_end':end,'commands':commands, 'controlled_scheduling_only':True, 'does_not_establish_remote_stack':True},indent=2)+'\n')
print(red.stdout, red.stderr)
