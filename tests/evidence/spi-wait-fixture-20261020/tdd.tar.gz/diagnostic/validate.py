import hashlib
import json
import os
from pathlib import Path
import sys
sys.path.insert(0, '/tmp/nexus-quality-20261019')
from tools.dev import process
out = Path('/tmp/nexus-spi-wait-fixture-20261020')
worker = Path('/dev/shm/nexus-validation-throughput-20261020')
cmake = '/tmp/nexus-quality-20261019/.venv/bin/cmake'
env = os.environ.copy()
env['PATH'] = '/tmp/nexus-quality-20261019/.venv/bin:' + env['PATH']
env['CMAKE_BUILD_PARALLEL_LEVEL'] = '1'
env['NEXUS_BUILD_JOBS'] = '1'
commands = []
def run(name, command, environment=env, timeout=600):
    result = process.run(command, cwd=worker, env=environment,
                         log=out/(name+'.log'), timeout=timeout, stage=name)
    commands.append({'name': name, 'returncode': result.returncode,
                     'receipt': str(result.receipt_path)})
    (out/'green-progress.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(name, result.returncode, flush=True)
    if result.returncode != 0:
        print(result.stdout[-5000:], result.stderr[-5000:], flush=True)
        raise SystemExit(result.returncode)
    return result
for mode in ('debug','asan'):
    build=out/('build-'+mode)
    command = [cmake,'-S',str(worker),'-B',str(build),'-G','Ninja',
               '-DCMAKE_BUILD_TYPE=Debug','-DNEXUS_BUILD_TESTS=ON',
               '-DNEXUS_ASSEMBLY_FILE='+str(worker/'tools/configure/assemblies/native.toml')]
    if mode == 'asan':
        command += ['-DNEXUS_ENABLE_SANITIZERS=ON']
    run(mode+'-configure', command)
    run(mode+'-build',[cmake,'--build',str(build),'--parallel','1','--target',
                       'nexus_spi_dma_owner_wait_test','nexus_native_spi_dma_owner_test'])
    binary=build/'bin/nexus_spi_dma_owner_wait_test'
    run(mode+'-owner-wait-all',[str(binary),'--gtest_output=xml:'+str(out/(mode+'-owner-wait-all.xml'))])
    run(mode+'-native-owner-all',[str(build/'bin/nexus_native_spi_dma_owner_test'),
                                  '--gtest_output=xml:'+str(out/(mode+'-native-owner-all.xml'))])
    if mode == 'debug':
        symbols = run('green-debug-symbols',['nm','-an',str(binary)])
        entries = [line.split() for line in symbols.stdout.splitlines()]
        index = next(i for i,row in enumerate(entries) if len(row)==3 and row[2]=='notify_wake')
        start = entries[index][0]
        end = next(row[0] for row in entries[index+1:] if len(row)==3 and row[0]!=start)
        held=env.copy()
        held.update(LD_PRELOAD=str(out/'diagnostic.so'),NEXUS_NOTIFY_WAKE_START=start,NEXUS_NOTIFY_WAKE_END=end)
        run('green-controlled-publication-all',[str(binary),'--gtest_output=xml:'+str(out/'green-controlled-publication-all.xml')],held)
        run('green-normal-bounded-repeat',[str(binary),'--gtest_repeat=20',
                                           '--gtest_output=xml:'+str(out/'green-normal-bounded-repeat.xml')])
run('final-diff-check',['git','diff','--check','--','tests/google/spi_dma_owner_wait_test.cpp'])
source=worker/'tests/google/spi_dma_owner_wait_test.cpp'
(out/'after.cpp').write_bytes(source.read_bytes())
(out/'result.json').write_text(json.dumps({'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(), 'before_sha256':hashlib.sha256((out/'before.cpp').read_bytes()).hexdigest(), 'commands':commands, 'focused_development_only':True,'all_native_modes_qualification':False,'bounded_repeat_is_stress_not_retry_admission':True},indent=2)+'\n')
