#define _GNU_SOURCE
#include <dlfcn.h>
#include <execinfo.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
static int (*real_unlock)(pthread_mutex_t*);
static void (*real_abort)(void);
__attribute__((constructor)) static void prepare(void) {
    real_unlock = dlsym(RTLD_NEXT, "pthread_mutex_unlock");
    real_abort = dlsym(RTLD_NEXT, "abort");
}
int pthread_mutex_unlock(pthread_mutex_t* mutex) {
    int result = real_unlock(mutex);
    Dl_info info;
    void* caller = __builtin_return_address(0);
    const char* start_text = getenv("NEXUS_NOTIFY_WAKE_START");
    const char* end_text = getenv("NEXUS_NOTIFY_WAKE_END");
    if (start_text != NULL && end_text != NULL &&
        syscall(SYS_gettid) != getpid() && dladdr(caller, &info) != 0) {
        uintptr_t offset = (uintptr_t)caller - (uintptr_t)info.dli_fbase;
        uintptr_t start = strtoull(start_text, NULL, 16);
        uintptr_t end = strtoull(end_text, NULL, 16);
        if (offset >= start && offset < end) {
            char message[160];
            int n = snprintf(message, sizeof(message),
                "DIAGNOSTIC real notify_wake unlock complete: tid=%ld offset=%lx; callback return held 50 ms\n",
                syscall(SYS_gettid), (unsigned long)offset);
            (void)write(STDERR_FILENO, message, (size_t)n);
            const struct timespec interval = {0, 50000000};
            (void)nanosleep(&interval, NULL);
        }
    }
    return result;
}
__attribute__((noreturn)) void abort(void) {
    uintptr_t caller_rax;
    uintptr_t caller_rbx;
    __asm__ volatile("mov %%rax, %0; mov %%rbx, %1"
                     : "=m"(caller_rax), "=m"(caller_rbx));
    char state[200];
    int state_bytes = snprintf(state, sizeof(state),
        "DIAGNOSTIC Close abort: saved_rax=%lu fixture=%lx wake_publishers=%u opened=%u wire_idle=%u\n",
        (unsigned long)caller_rax, (unsigned long)caller_rbx,
        *(uint32_t*)(caller_rbx + 400 + 44),
        *(unsigned char*)(caller_rbx + 400 + 50),
        *(unsigned char*)(caller_rbx + 400 + 54));
    (void)write(STDERR_FILENO, state, (size_t)state_bytes);
    void* frames[32];
    int count = backtrace(frames, 32);
    const char message[] = "DIAGNOSTIC actual abort backtrace follows\n";
    (void)write(STDERR_FILENO, message, sizeof(message) - 1);
    backtrace_symbols_fd(frames, count, STDERR_FILENO);
    real_abort();
    __builtin_unreachable();
}
