SPI wait fixture maintenance fix, 2026-10-20

Only the test fixture Close order changes: drain the owner; stop and join the
model publisher; then stop the provider. All three original tests and their
assertions remain. No production BUSY or borrow contract changes.

The unchanged old primary binary aborts under a controlled real notify_wake
publication window. A diagnosis-only LD_PRELOAD shim delays callback return
after the real mutex unlock; it never changes provider return values. The raw
abort trace, x86-64 saved return register, actual DWARF member offsets and
assembly establish local stop BUSY=2 with wake_publishers=1. The original
remote failure has no stack: this archive does not claim that a remote stack
or its precise branch was directly captured.

The twelve GREEN command receipts include two actual CMake builds, original
3-case wait and 14-case publisher suites in Debug and ASan/UBSan, a controlled
publication-window 3-case run and twenty bounded stress iterations. Stress
XML contains only the last three cases and is never counted as sixty fresh
qualification cases. Focused runs do not replace the ordinary complete-index
gate, four Native CI modes, SDK qualification or physical HIL.

Original full DWARF is retained externally with its exact receipt, path, hash
and a derived relevant excerpt here. This avoids packing unrelated framework
DWARF. No ELF, build tree, vendor tree or duplicate source before-image is
included. An initial missing-dependency configure attempt remains externally
preserved; the twelve GREEN records describe the subsequent maintained builds
after offline locked dependency initialization. No original raw evidence was
deleted or overwritten by packaging.

manifest.json inventories all payload regular files by SHA256/mode and all
implicit directories by type/mode. The outer preservation receipt hashes the
manifest itself. Every member was read back and verified; all selected original
inputs were hashed again after archive verification and remained unchanged.
