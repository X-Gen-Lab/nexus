import sys,json,hashlib,ast
from pathlib import Path
root=Path(sys.argv[1]);sys.path.insert(0,str(root/'scripts/ci'))
import style_gate
paths=sys.argv[2:];rows=[]
for rel in paths:
 p=root/rel;issues=style_gate.check_text(p,rel);rows.append({'path':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'errors':issues})
print(json.dumps({'kind':'maintained_fullfile_text_check','scope':'four author files, not staged hook','files':rows},indent=2));sys.exit(int(any(r['errors'] for r in rows)))
