from pathlib import Path
import hashlib,json,time
F=Path('/dev/shm/nexus-u575-pair-capture-CI-20261018-r1')
def row(path):
 raw=path.read_bytes();s=path.stat()
 return {'path':str(path),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':s.st_mode&0o777,'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns}
def emit(path,value):
 assert not path.exists();raw=(json.dumps(value,indent=2)+'\n').encode()
 allocated=sum(p.stat().st_blocks*512 for p in F.rglob('*') if p.is_file())
 assert allocated+((len(raw)+4095)//4096)*4096<=3670016
 path.write_bytes(raw)
freeze=json.loads((F/'final-source-freeze-r1.json').read_text())
commands=[]
for path in sorted(F.glob('*.command.json')):
 value=json.loads(path.read_text());commands.append({'identity':row(path),'stage':value['stage'],'exit_code':value['exit_code'],'outcome':value['outcome'],'withdrawal_complete':value['withdrawal_complete'],'stdout':value['stdout'],'stderr':value['stderr']})
summary={'kind':'u575_pair_CI_capture_development_validation','source_freeze':row(F/'final-source-freeze-r1.json'),'final_actual':{'pair_pure':70,'capture_pure':21,'workflow':57,'skips':0,'complete_text_files':8,'old_workflow_bodies_preserved':54,'all_current_workflow_DSL':'exit0'},'final_stems':['whole-pair-70-final','whole-capture-21-final','whole-workflow-57-final','source-eight-text-and-preserved54','all-current-workflow-dsl'],'commands':commands,'classification':{'initial_workflow_environment':'57 methods; missing owner PYTHONPATH/cmake produced old failures plus new assertions; original fullraw retained','initial_capture_fixture':'18 setup PermissionError at /unrelated; write denied, path absent; corrected fixture retained','new_API_firstcoverage':['capture missing begin/finish/run flag; 18 errors','File API function/optional stage field absent; 65 methods10errors'],'actual_same_checker_RED_GREEN':['workflow57 missing capture/verify/upload assertions:4 failures to0','capture19 reader could rebind report:1 failure to0','capture21 unexpected local LOAD and stable after-A/final-B library:2 failures to0','pair70 unknown external LOAD and rehashed before-A/library-B:2 failures to0'],'first_implementation':'capture18 mismatch bytes/size and foreign fixture output produced2fail2error, corrected before firstGREEN; retained','old_r1_temporal_boundary':'R1 whole-pure-final-r2 was50; later include-conflict51 true RED/GREEN had distinct sourceguard. No old guard relabelled.'},'not_executed':['fresh clean-source ARM pair producer','actual19 gate tests on new captured pair','real File API ARM closure','real78MB seal/verify/fullrestore','hardware/TrustZone option bytes/Stop/VBAT/HIL'],'qualification':{'signature':'unsigned','software':'not_qualified','physical':'not_executed','candidate':False},'source_only_review':row(Path('/dev/shm/nexus-u575-pair-capture-source-independent-review-20261018-r1.json')),'persistence':'all new source/evidence volatile until Root normal commit and push'}
emit(F/'validation-summary-r1.json',summary)
original=json.loads((F/'archive-inputs-r1.json').read_text());old_names={r['path'] for r in original['rows']}
controls=[row(p) for p in sorted(F.rglob('*')) if p.is_file() and p.relative_to(F).as_posix() not in old_names]
historical=[]
for name in ['nexus-u575-pair-feature-20261018-r1','nexus-u575-pair-copy-map-r2-20261018']:
 root=Path('/dev/shm')/name
 historical.append({'root':str(root),'unchanged_original_references_only':True,'leaves':[row(p) for p in sorted(root.rglob('*')) if p.is_file()]})
leafmap={'kind':'u575_pair_eight_source_and_complete_evidence_handoff','source_count':8,'files':freeze['source_rows'],'frozen_source_identity':freeze['source_identity'],'index_sha256':freeze['index_sha256'],'new_feature':{'root':str(F),'archive':row(F/'execution-evidence-r1.tar.gz'),'archive_verification':row(F/'archive-verification-r1.json'),'frozen_original_leaf_count':157,'original_members':original['rows'],'all_later_control_leaves':controls,'no_recursive_self_archive':True},'historical_packets':historical,'independent_source_review':row(Path('/dev/shm/nexus-u575-pair-capture-source-independent-review-20261018-r1.json')),'historical_independent_pure_R2_review':row(Path('/dev/shm/nexus-u575-pair-independent-review-20261018-r2/report.json')),'budget_bytes':3670016,'source_persistence':'volatile_until_Root_normal_commit_push','classification_summary':row(F/'validation-summary-r1.json')}
emit(F/'final-eight-source-and-evidence-leafmap-r1.json',leafmap)
handoff={'source_count':8,'freeze':row(F/'final-source-freeze-r1.json'),'leafmap':row(F/'final-eight-source-and-evidence-leafmap-r1.json'),'summary':row(F/'validation-summary-r1.json'),'archive':row(F/'execution-evidence-r1.tar.gz'),'boundary':'157 frozen original leaves inside archive; subsequent controls separately leafmapped; leafmap/handoff roots externally SHA-pinned, no self-hash cycles','all_original_failures_and_receipts_preserved':True,'actual_new_ARM_real_pair_restore':'not_executed','Root_only':'integration/fullhooks/commit/push/actualcleanpair','created_ns':time.time_ns()}
emit(F/'completed-handoff-r1.json',handoff)
print(json.dumps({'handoff':row(F/'completed-handoff-r1.json'),'leafmap':row(F/'final-eight-source-and-evidence-leafmap-r1.json'),'feature_allocated':sum(p.stat().st_blocks*512 for p in F.rglob('*') if p.is_file()),'feature_logical':sum(p.stat().st_size for p in F.rglob('*') if p.is_file())}))
