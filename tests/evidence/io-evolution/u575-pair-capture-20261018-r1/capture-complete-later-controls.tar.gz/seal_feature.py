from pathlib import Path
import gzip,hashlib,json,tarfile
F=Path('/dev/shm/nexus-u575-pair-capture-CI-20261018-r1')
plan=json.loads((F/'archive-inputs-r1.json').read_text())
rows=plan['rows'];out=F/'execution-evidence-r1.tar.gz'
assert not out.exists()
def check(row):
 p=F/row['path'];assert not any(x.is_symlink() for x in [p,*p.parents]);s=p.stat()
 assert p.is_file() and s.st_size==row['bytes']
 assert (s.st_mode&0o777,s.st_uid,s.st_gid,s.st_mtime_ns)==(row['mode'],row['uid'],row['gid'],row['mtime_ns'])
 assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
for row in rows:check(row)
with tarfile.open(out,'w:gz',format=tarfile.PAX_FORMAT) as content:
 for row in rows:
  p=F/row['path'];info=content.gettarinfo(str(p),arcname=row['path'])
  sec,ns=divmod(row['mtime_ns'],10**9);info.pax_headers['mtime']='%d.%09d'%(sec,ns)
  with p.open('rb') as stream:content.addfile(info,stream)
expected={r['path']:r for r in rows};seen=set()
with tarfile.open(out,'r|gz') as content:
 for member in content:
  assert member.isfile() and member.name in expected and member.name not in seen
  row=expected[member.name];seen.add(member.name)
  assert (member.size,member.mode,member.uid,member.gid)==(row['bytes'],row['mode'],row['uid'],row['gid'])
  sec,ns=divmod(row['mtime_ns'],10**9)
  assert member.pax_headers['mtime']=='%d.%09d'%(sec,ns)
  value=hashlib.sha256()
  with content.extractfile(member) as stream:
   while block:=stream.read(65536):value.update(block)
  assert value.hexdigest()==row['sha256']
  content.members.clear()
assert seen==set(expected)
with gzip.open(out,'rb') as stream:
 while stream.read(65536):pass
for row in rows:check(row)
summary={'frozen_original_leaves':len(rows),'all_member_bytes_modes_uid_gid_nsmtime_verified':True,'full_gzip_crc_eof':True,'originals_before_after_unchanged':True,'archive':{'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},'plan_sha256':hashlib.sha256((F/'archive-inputs-r1.json').read_bytes()).hexdigest(),'later_control_files_outside_archive':True}
(F/'archive-verification-r1.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
