def cmake_link_graph(index, directory, stage, image, read):
    """Read one fresh File API target closure without opening old labels."""
    directory, index = _label(directory), _label(index)
    reply = posixpath.join(directory, ".cmake/api/v1/reply")
    if (posixpath.dirname(index) != reply or
            not posixpath.basename(index).startswith("index-") or
            not index.endswith(".json")):
        raise EvidenceError("exact stage File API index required")
    inputs = []
    def load(label):
        if label in inputs or len(inputs) >= MAX_ENTRIES:
            raise EvidenceError("duplicate or excessive File API reply")
        inputs.append(label)
        return _read_json(read(label))
    def reply_path(name):
        if (not isinstance(name, str) or not name.endswith(".json") or
                name in (".", "..") or "/" in name or "\\" in name):
            raise EvidenceError("File API reply path escapes its stage")
        return posixpath.join(reply, name)
    entry = load(index)["reply"]["codemodel-v2"]
    if entry.get("kind") != "codemodel" or entry.get("version", {}).get(
            "major") != 2:
        raise EvidenceError("codemodel-v2 reply required")
    model = load(reply_path(entry["jsonFile"]))
    configurations = model["configurations"]
    if (_label(model["paths"]["build"]) != directory or
            not isinstance(configurations, list) or len(configurations) != 1):
        raise EvidenceError("one exact stage codemodel configuration required")
    rows = configurations[0]["targets"]
    if not isinstance(rows, list) or not 1 <= len(rows) <= MAX_ENTRIES:
        raise EvidenceError("bounded File API target table required")
    targets, filenames = {}, set()
    for row in rows:
        identifier, path = row["id"], reply_path(row["jsonFile"])
        if (not isinstance(identifier, str) or not identifier or
                identifier in targets or path in filenames):
            raise EvidenceError("duplicate File API target identity or reply")
        filenames.add(path)
        targets[identifier] = row
    roots = [row for row in rows if row["name"] == "u575_" + stage]
    if len(roots) != 1:
        raise EvidenceError("one actual stage executable target required")
    completed, visiting, libraries = set(), set(), []
    def visit(identifier):
        if identifier in completed:
            return
        if identifier in visiting or len(visiting) >= 64:
            raise EvidenceError("cyclic or excessive File API dependency depth")
        if identifier not in targets:
            raise EvidenceError("unknown File API target dependency")
        visiting.add(identifier)
        row = targets[identifier]
        value = load(reply_path(row["jsonFile"]))
        if value.get("id") != identifier or value.get("name") != row["name"]:
            raise EvidenceError("File API target identity mismatch")
        artifacts = value.get("artifacts", [])
        if not isinstance(artifacts, list):
            raise EvidenceError("invalid File API artifact list")
        paths = [_label(item["path"], directory) for item in artifacts]
        if (len(paths) != len(set(paths)) or any(
                posixpath.commonpath((directory, path)) != directory
                for path in paths)):
            raise EvidenceError("File API artifact leaves its stage")
        if identifier == roots[0]["id"]:
            if value.get("type") != "EXECUTABLE" or paths != [_label(image)]:
                raise EvidenceError("actual File API executable differs")
        elif value.get("type") == "STATIC_LIBRARY":
            if len(paths) != 1 or paths[0] in libraries:
                raise EvidenceError("one unique static library artifact required")
            libraries.extend(paths)
        dependencies = value.get("dependencies", [])
        if not isinstance(dependencies, list) or len(dependencies) > MAX_ENTRIES:
            raise EvidenceError("invalid File API target dependencies")
        identifiers = [item["id"] for item in dependencies]
        if len(identifiers) != len(set(identifiers)):
            raise EvidenceError("duplicate File API target dependency")
        for dependency in identifiers:
            visit(dependency)
        visiting.remove(identifier)
        completed.add(identifier)
    visit(roots[0]["id"])
    return {"inputs": inputs, "libraries": sorted(libraries)}


