class PortableCmakeLinkGraph(unittest.TestCase):
    def setUp(self):
        self.directory = "/old/secure"
        self.reply = self.directory + "/.cmake/api/v1/reply/"
        self.index = self.reply + "index-fixture.json"
        self.values = {
            self.index: {"reply": {"codemodel-v2": {
                "kind": "codemodel", "version": {"major": 2},
                "jsonFile": "codemodel.json"}}},
            self.reply + "codemodel.json": {
                "paths": {"build": self.directory},
                "configurations": [{"name": "", "targets": [
                    {"id": "app-id", "name": "u575_secure",
                     "jsonFile": "app.json"},
                    {"id": "interface-id", "name": "interface",
                     "jsonFile": "interface.json"},
                    {"id": "lib-id", "name": "actual_library",
                     "jsonFile": "lib.json"},
                    {"id": "unrelated-id", "name": "unrelated",
                     "jsonFile": "unrelated.json"}]}]},
            self.reply + "app.json": {"id": "app-id", "name": "u575_secure",
                "type": "EXECUTABLE", "artifacts": [{"path": "image.elf"}],
                "dependencies": [{"id": "interface-id"}]},
            self.reply + "interface.json": {"id": "interface-id",
                "name": "interface", "type": "UTILITY",
                "dependencies": [{"id": "lib-id"}]},
            self.reply + "lib.json": {"id": "lib-id",
                "name": "actual_library", "type": "STATIC_LIBRARY",
                "artifacts": [{"path": "nexus-runtime/libactual.a"}]},
            self.reply + "unrelated.json": {"id": "unrelated-id",
                "name": "unrelated", "type": "STATIC_LIBRARY",
                "artifacts": [{"path": "unrelated.a"}]}}
        self.reads = []

    def graph(self):
        def read(label):
            self.reads.append(label)
            return json.dumps(self.values[label]).encode()
        return u575_pair.cmake_link_graph(self.index, self.directory,
            "secure", "/old/secure/image.elf", read)

    def test_only_actual_executable_dependency_closure_is_selected(self):
        value = self.graph()
        self.assertEqual(value["libraries"],
                         ["/old/secure/nexus-runtime/libactual.a"])
        self.assertNotIn(self.reply + "unrelated.json", value["inputs"])
        self.assertEqual(set(value["inputs"]), set(self.reads))

    def test_duplicate_target_ids_or_reply_paths_are_rejected(self):
        for key in ("id", "jsonFile"):
            self.setUp()
            rows = self.values[self.reply + "codemodel.json"][
                "configurations"][0]["targets"]
            rows[1][key] = rows[0][key]
            with self.subTest(key=key), self.assertRaises(EvidenceError):
                self.graph()

    def test_missing_or_cyclic_dependency_is_rejected(self):
        for dependencies in ([{"id": "absent"}], [{"id": "app-id"}]):
            self.values[self.reply + "lib.json"]["dependencies"] = dependencies
            with self.subTest(dependencies=dependencies):
                with self.assertRaises(EvidenceError):
                    self.graph()

    def test_reply_escape_and_artifact_escape_are_rejected(self):
        self.values[self.index]["reply"]["codemodel-v2"][
            "jsonFile"] = "../other.json"
        with self.assertRaises(EvidenceError):
            self.graph()
        self.setUp()
        self.values[self.reply + "lib.json"]["artifacts"] = [
            {"path": "../../outside.a"}]
        with self.assertRaises(EvidenceError):
            self.graph()

    def test_stage_root_image_and_target_identity_must_match(self):
        for field in ("build", "image", "target"):
            self.setUp()
            if field == "build":
                self.values[self.reply + "codemodel.json"]["paths"][
                    "build"] = "/other"
            elif field == "image":
                self.values[self.reply + "app.json"]["artifacts"] = [
                    {"path": "other.elf"}]
            else:
                self.values[self.reply + "lib.json"]["id"] = "different"
            with self.subTest(field=field), self.assertRaises(EvidenceError):
                self.graph()

    def test_optional_typed_api_refs_are_collected_without_changing_legacy(self):
        value = report()
        expected = u575_pair.collect_report(value)
        item = identity(self.index, b"api")
        value["build_inputs"][0]["cmake_file_api"] = [item]
        actual = u575_pair.collect_report(value)
        self.assertEqual(set(actual), set(expected) | {self.index})
        self.assertEqual(actual[self.index]["sha256"], item["sha256"])

    def test_optional_api_type_duplicate_and_cross_stage_refs_rejected(self):
        for entries in (False, [], [identity(self.index)] * 2,
                        [identity("/elsewhere/index.json")]):
            value = report()
            value["build_inputs"][0]["cmake_file_api"] = entries
            with self.subTest(entries=entries), self.assertRaises(EvidenceError):
                u575_pair.collect_report(value)


