class CapturedFileApiClosure(unittest.TestCase):
    def setUp(self):
        self.pure = ExactTypedClosure()
        self.pure.setUp()
        for stage in self.pure.value["build_inputs"]:
            name = stage["stage"]
            graph = PortableCmakeLinkGraph()
            graph.setUp()
            rows = []
            for path, value in graph.values.items():
                if path.endswith("unrelated.json"):
                    continue
                label = path.replace("/secure", "/" + name)
                raw = json.dumps(value).replace("/secure", "/" + name).replace(
                    "u575_secure", "u575_" + name).encode()
                self.pure.blobs[label] = raw
                rows.append(identity(label, raw))
            stage["cmake_file_api"] = rows
            library = "/old/" + name + "/nexus-runtime/libactual.a"
            self.pure.blobs[library] = b"actual graph archive fixture"
            path = stage["stage"] + "_map"
            label = self.pure.value["artifacts"][path]["path"]
            self.pure.blobs[label] += ("LOAD " + library + "\n").encode()
        self.before = {}
        for name in ("libgcc.a", "libc_nano.a", "libnosys.a"):
            label = "/tools/" + name
            self.pure.blobs.setdefault(label, b"before library fixture")
            row = {**identity(label, self.pure.blobs[label]), "mode": 384}
            self.before[name] = {**row, "copy": identity(
                "/control/" + name, self.pure.blobs[label])}
        self.refresh()

    def refresh(self):
        value, blobs = self.pure.value, self.pure.blobs
        for stage in value["build_inputs"]:
            for row in stage["cmake_file_api"]:
                row.update(identity(row["path"], blobs[row["path"]]))
        for row in value["artifacts"].values():
            row.update(identity(row["path"], blobs[row["path"]]))
        blobs["/old/report.json"] = json.dumps(value).encode()
        history = {"files": [{**identity(path, raw), "mode": 384}
            for path, raw in blobs.items() if path != "/history.json"],
            "libraries_before": self.before,
            "libraries_after": {name: {key: field for key, field in row.items()
                if key != "copy"} for name, row in self.before.items()}}
        blobs["/history.json"] = json.dumps(history).encode()
        self.pure.context["report"] = identity("/old/report.json",
            blobs["/old/report.json"])
        self.pure.context["history"] = [identity("/history.json",
            blobs["/history.json"])]

    def test_graph_replies_and_only_reachable_static_artifacts_are_retained(self):
        pair = self.pure.pair()
        names = {row["path"] for row in pair["members"]}
        self.assertIn("/old/secure/nexus-runtime/libactual.a", names)
        self.assertIn("/old/nonsecure/.cmake/api/v1/reply/lib.json", names)
        self.assertFalse(any(path.endswith("unrelated.json") for path in names))

    def test_rehashed_unrelated_local_load_is_rejected_offline(self):
        label = "/old/secure/unrelated.a"
        self.pure.blobs[label] = b"not in actual executable target closure"
        self.pure.blobs["/old/secure/image.map"] += (
            "LOAD " + label + "\n").encode()
        self.refresh()
        with self.assertRaisesRegex(EvidenceError, "local.*LOAD"):
            self.pure.pair()

    def test_unrelated_typed_reply_cannot_expand_the_selected_graph(self):
        label = "/old/secure/.cmake/api/v1/reply/unrelated.json"
        self.pure.blobs[label] = b"{}"
        self.pure.value["build_inputs"][0]["cmake_file_api"].append(
            identity(label, b"{}"))
        self.refresh()
        with self.assertRaisesRegex(EvidenceError, "unrelated typed replies"):
            self.pure.pair()

    def test_unknown_external_load_cannot_be_after_authorized(self):
        label = "/tools/unknown.a"
        self.pure.blobs[label] = b"not selected before configure"
        self.pure.blobs["/old/secure/image.map"] += (
            "LOAD " + label + "\n").encode()
        self.refresh()
        with self.assertRaisesRegex(EvidenceError, "external.*LOAD"):
            self.pure.pair()

    def test_rehashed_library_bytes_must_equal_before_and_after(self):
        self.pure.blobs["/tools/libgcc.a"] = b"different library"
        self.refresh()
        with self.assertRaisesRegex(EvidenceError, "library.*changed"):
            self.pure.pair()


