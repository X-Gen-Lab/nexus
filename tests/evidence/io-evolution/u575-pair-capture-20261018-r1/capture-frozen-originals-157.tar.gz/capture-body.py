def _capture_file(path):
    """Hash bounded regular bytes while retaining their observation metadata."""
    from tools.evidence import u575_pair
    path = regular_file(path, nonempty=False)
    before = path.stat()
    if before.st_size > u575_pair.MAX_BYTES:
        raise EvidenceError("pair capture input exceeds bound")
    checksum = hashlib.sha256()
    remaining = before.st_size
    with path.open("rb") as stream:
        while remaining:
            block = stream.read(min(u575_pair.CHUNK, remaining))
            if not block:
                raise EvidenceError("pair capture input changed")
            checksum.update(block)
            remaining -= len(block)
        if stream.read(1):
            raise EvidenceError("pair capture input changed")
    after = path.stat()
    keys = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_size",
            "st_mtime_ns", "st_ctime_ns")
    if any(getattr(before, key) != getattr(after, key) for key in keys):
        raise EvidenceError("pair capture input changed")
    return {"path": str(path), "bytes": before.st_size,
            "sha256": checksum.hexdigest(), "mode": before.st_mode & 0o777,
            "device": before.st_dev, "inode": before.st_ino,
            "uid": before.st_uid, "gid": before.st_gid,
            "mtime_ns": before.st_mtime_ns, "ctime_ns": before.st_ctime_ns}


def begin_pair_context(output, tools, recorder, source):
    """Retain actual GCC-selected libraries before any configure/build call."""
    from tools.evidence import u575_pair
    u575_pair._source(source)
    control = Path(output) / "pair-context"
    if (control.exists() or any(p.is_symlink() for p in
                               (control, *control.parents))):
        raise EvidenceError("pair context control must be fresh and unaliased")
    compiler = _capture_file(tools["gcc"])
    libraries, aliases = {}, set()
    # A query uses the same ABI as both actual stages, never host defaults.
    for name in ("libgcc.a", "libc_nano.a", "libnosys.a"):
        raw = recorder.execute([tools["gcc"], "-mcpu=cortex-m33", "-mthumb",
            "-mfloat-abi=soft", "--print-file-name=" + name],
            "pair-before-" + name)
        lines = raw.splitlines()
        if len(lines) != 1 or not Path(lines[0]).is_absolute():
            raise EvidenceError("actual absolute GCC library selection required")
        # Reject symlink components before collapsing legitimate bin/../lib.
        regular_file(lines[0])
        path = Path(os.path.normpath(lines[0]))
        row = _capture_file(path)
        alias = (row["device"], row["inode"])
        if alias in aliases:
            raise EvidenceError("pair library choices must not alias")
        aliases.add(alias)
        libraries[name] = row
    control.mkdir()
    copies = control / "before-libraries"
    copies.mkdir()
    for name, row in libraries.items():
        destination = copies / name
        u575_pair._copy_retained(Path(row["path"]), destination,
            {"size": row["bytes"], "sha256": row["sha256"],
             "mode": row["mode"]})
        if _capture_file(row["path"]) != row:
            raise EvidenceError("original pair library changed before build")
        row["copy"] = _capture_file(destination)
    value = {"source": json.loads(json.dumps(source)), "compiler": compiler,
             "libraries": libraries, "observed_ns": time.time_ns()}
    atomic_json(control / "libraries-before.json", value)
    return value


def finish_pair_context(output, report, before):
    """Publish only the exact typed closure after the unchanged build gate."""
    from tools.evidence import u575_pair
    control = Path(output) / "pair-context"
    targets = [control / leaf for leaf in
               ("libraries-after.json", "history.json", "context.json")]
    if any(p.exists() or p.is_symlink() for p in targets):
        raise EvidenceError("pair context outputs must be absent")
    selected = u575_pair.collect_report(report)
    if (report["source"] != before["source"] or
            _capture_file(before["compiler"]["path"]) != before["compiler"]):
        raise EvidenceError("original pair compiler/source changed")
    for key in ("path", "bytes", "sha256"):
        report_key = "size" if key == "bytes" else key
        if report["tools"]["gcc"].get(report_key) != before["compiler"][key]:
            raise EvidenceError("original pair compiler report changed")
    after = {}
    for name, row in before["libraries"].items():
        original = {key: value for key, value in row.items() if key != "copy"}
        if (_capture_file(row["path"]) != original or
                _capture_file(row["copy"]["path"]) != row["copy"]):
            raise EvidenceError("original or retained pair library changed")
        after[name] = original
    known_libraries = {row["path"] for row in after.values()}
    emitted, not_emitted = {}, {}
    for stage in report["build_inputs"]:
        name = stage["stage"]
        database = regular_file(stage["compile_commands"]["path"])
        directory = database.parent
        for leaf in u575_pair.BUNDLE:
            path = directory / "nexus-runtime/generated" / leaf
            selected[str(path)] = {"path": str(path)}
        if database.stat().st_size > u575_pair.MAX_METADATA:
            raise EvidenceError("actual compile database exceeds bound")
        declared = u575_pair.compile_outputs(json.loads(database.read_text()),
            name, report["tools"]["gcc"]["path"])
        emitted[name], not_emitted[name] = [], []
        for label in declared:
            path = Path(label)
            if path.is_symlink():
                raise EvidenceError("compiler output cannot be a symlink")
            if path.exists():
                selected[label] = {"path": label}
                emitted[name].append(label)
            else:
                not_emitted[name].append(label)
        map_path = regular_file(report["artifacts"][name + "_map"]["path"])
        if map_path.stat().st_size > u575_pair.MAX_METADATA:
            raise EvidenceError("actual map exceeds bound")
        for label in u575_pair.map_inputs(map_path.read_bytes(), str(directory)):
            path = Path(label)
            if (not path.is_relative_to(Path(output) / "secure") and
                    not path.is_relative_to(Path(output) / "nonsecure") and
                    label not in known_libraries):
                raise EvidenceError("unknown external pair map LOAD")
            selected.setdefault(label, {"path": label})
    if len(selected) > u575_pair.MAX_ENTRIES:
        raise EvidenceError("pair capture input count exceeds bound")
    files = [_capture_file(path) for path in sorted(selected)]
    if sum(row["bytes"] for row in files) > u575_pair.MAX_BYTES:
        raise EvidenceError("pair capture closure exceeds bound")
    # The original report is still authoritative; history cannot replace it.
    for row in files:
        prior = selected[row["path"]]
        if "sha256" in prior and (prior["sha256"] != row["sha256"] or
                prior.get("size", prior.get("bytes")) != row["bytes"]):
            raise EvidenceError("original pair report input changed")
    atomic_json(targets[0], {"libraries": after,
                            "observed_ns": time.time_ns()})
    history = {"files": files, "libraries_before": before["libraries"],
               "libraries_after": after, "emitted": emitted,
               "not_emitted": not_emitted}
    atomic_json(targets[1], history)
    context = {"schema_version": 1, "kind": "u575_pair_build_context",
               "source": report["source"], "tools": report["tools"],
               "report": file_identity(Path(output) / "report.json"),
               "history": [file_identity(targets[1])]}
    def read_metadata(label):
        path = regular_file(label, nonempty=False)
        if path.stat().st_size > u575_pair.MAX_METADATA:
            raise EvidenceError("pair metadata exceeds bound")
        return path.read_bytes()
    u575_pair.build_pair(context, read_metadata)
    atomic_json(targets[2], context)
    return targets[2]


