import hashlib,json,os,resource,shutil,sys,time
from pathlib import Path
ROOT=Path('/dev/shm/nexus-qualification-transport-20261018-r1')
F=Path('/dev/shm/nexus-u575-pair-capture-CI-20261018-r1')
sys.path.insert(0,str(ROOT))
from tools.dev import process
from tools.evidence.identity import observe_git_source
name=sys.argv[1]
cmd=sys.argv[2:]
paths=json.loads((F/'before-eight.json').read_text())
def state():
    source=observe_git_source(ROOT)
    return {'time_ns':time.time_ns(),'source':source,'index_sha256':hashlib.sha256((ROOT/'.git/index').read_bytes()).hexdigest(),'memory_current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'memory_events':Path('/sys/fs/cgroup/memory.events').read_text()}
before=state()
assert int(Path('/sys/fs/cgroup/memory.max').read_text())-before['memory_current']>=900*1024**2
assert shutil.disk_usage('/workspace').free>=64*1024**2
assert shutil.disk_usage('/tmp').free>=200*1024**2
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(ROOT),TMPDIR='/dev/shm/nexus-u575-pair-tests-20261018-r1',PATH='/workspace/nexus-build-system-20261012/.venv/bin:'+os.environ.get('PATH','/usr/bin:/bin'))
result=process.run(cmd,cwd=ROOT,env=env,log=F/(name+'.log'),timeout=180,stage=name)
after=state()
receipt={'before':before,'after':after,'returncode':result.returncode,'maxrss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}
(F/(name+'.guard.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'returncode':result.returncode,'maxrss_kib':receipt['maxrss_kib'],'source_unchanged':before['source']==after['source'],'index_unchanged':before['index_sha256']==after['index_sha256']}))
