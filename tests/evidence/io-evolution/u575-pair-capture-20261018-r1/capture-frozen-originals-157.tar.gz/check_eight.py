import ast,hashlib,json,sys
from pathlib import Path
root=Path('/dev/shm/nexus-qualification-transport-20261018-r1')
f=Path('/dev/shm/nexus-u575-pair-capture-CI-20261018-r1')
sys.path.insert(0,str(root))
from scripts.ci import style_gate
values=json.loads((f/'before-eight.json').read_text())
rows=[];errors=[]
for row in values['source_rows']:
 path=root/row['path'];raw=path.read_bytes()
 errors.extend(style_gate.check_text(path,row['path']))
 rows.append({'path':row['path'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
name='.github/workflows/test_platform_ci.py'
old=(f/'before'/name).read_text();new=(root/name).read_text()
def methods(source):
 return {(c.name,n.name):ast.get_source_segment(source,n) for c in ast.parse(source).body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
a,b=methods(old),methods(new)
assert len(a)==54 and all(b.get(k)==v for k,v in a.items())
assert not errors,errors
print(json.dumps({'whole_text_files':8,'old_workflow_methods_preserved':54,'final_workflow_methods':len(b),'errors':errors,'sources':rows},indent=2))
