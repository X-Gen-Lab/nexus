import pathlib,json,hashlib,os
ROOT=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018')
FEATURE=pathlib.Path('/dev/shm/nexus-h743-uart-runtime-feature-20261018-r1')
ALLOWED={x['path'] for x in json.loads((FEATURE/'bootstrap.json').read_text())['before10']}
def write(rel,text):
 assert rel in ALLOWED
 data=text.encode() if isinstance(text,str) else text
 assert data.endswith(b'\n')
 assert not any(x<32 and x not in (9,10) for x in data)
 dest=FEATURE/'files'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 assert sum(x.stat().st_blocks*512 for x in [FEATURE,*FEATURE.rglob('*')])<=4194304
 (ROOT/rel).write_bytes(data)
def read(rel):return (ROOT/rel).read_text()
