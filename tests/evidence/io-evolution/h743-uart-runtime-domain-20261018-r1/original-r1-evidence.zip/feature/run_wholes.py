import pathlib,sys,json,subprocess,hashlib,xml.etree.ElementTree as ET
F=pathlib.Path('/dev/shm/nexus-h743-uart-runtime-feature-20261018-r1');B=pathlib.Path('/dev/shm/nexus-h743-uart-runtime-builds-20261018-r1');R=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018')
phase,profile=sys.argv[1:3];names=sys.argv[3:];out=F/(phase+'-result.json');assert not out.exists();rows=[]
def source():return {x['path']:hashlib.sha256((R/x['path']).read_bytes()).hexdigest() for x in json.loads((F/'bootstrap.json').read_text())['before10']}
before=source()
for name in names:
 elf=B/profile/'bin'/name;xml=B/'junit'/(name+'-'+phase+'.xml');assert not xml.exists()
 q=subprocess.run(['/tmp/nexus-io-validation-20261018/.venv/bin/python','-B',str(F/'run_stage.py'),name+'-'+phase,str(elf),'--gtest_output=xml:'+str(xml)],capture_output=True,text=True)
 row={'target':name,'actual_exit':q.returncode,'ELF_path':str(elf),'ELF_sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'XML_path':str(xml),'XML_exists':xml.exists()}
 if xml.exists():
  j=ET.parse(xml).getroot();row['XML']=dict(j.attrib);row['XML_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest();row['failed_cases']=[s.attrib.get('name')+'.'+t.attrib['name'] for s in j for t in s if t.find('failure') is not None]
 rows.append(row);print(json.dumps(row,indent=2),flush=True)
after=source();assert before==after
out.write_text(json.dumps({'phase':phase,'profile':profile,'source_before':before,'source_after':after,'whole_no_filters':True,'all_children_joined':True,'programs':rows,'all_programs_actual0':all(x['actual_exit']==0 for x in rows)},indent=2)+'\n')
