import pathlib,json,hashlib,gzip,subprocess,os,time,zipfile
F=pathlib.Path('/dev/shm/nexus-h743-uart-runtime-feature-20261018-r1');B=pathlib.Path('/dev/shm/nexus-h743-uart-runtime-builds-20261018-r1');R=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018');CG=pathlib.Path('/sys/fs/cgroup')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while chunk:=f.read(262144):h.update(chunk)
 return h.hexdigest()
def allocated(root):
 rows={}
 for p in [root,*root.rglob('*')]:
  q=p.stat();rows[(q.st_dev,q.st_ino)]=q.st_blocks*512
 return sum(rows.values())
def store(name,value):
 p=F/name;assert not p.exists(),p;p.write_text(json.dumps(value,indent=2)+'\n');return p
assert allocated(F)<4194304 and allocated(B)<234881024
assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize>=67108864
bootstrap=json.loads((F/'bootstrap.json').read_text());freeze=json.loads((F/'source-freeze-r2.json').read_text())
assert sha(R/'.git/index')==bootstrap['index_sha256']==freeze['index_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==bootstrap['HEAD']
for row in freeze['source10']:
 assert sha(R/row['path'])==sha(F/'files'/row['path'])==row['sha256']
for row in bootstrap['before10']:
 p=F/'before'/(row['path'].replace('/','__')+'.gz');data=gzip.decompress(p.read_bytes());assert hashlib.sha256(data).hexdigest()==row['sha256'];assert sha(p)==row['gzip_sha256']
assert hashlib.sha256(gzip.decompress((F/'index-before.gz').read_bytes())).hexdigest()==bootstrap['index_sha256']
programs=[]
for phase in ['final-debug-r2','final-asan-tx','final-asan-rx']:
 r=json.loads((F/(phase+'-result.json')).read_text());assert r['all_programs_actual0'] and r['whole_no_filters'] and r['all_children_joined']
 for row in freeze['source10']:assert r['source_before'][row['path']]==r['source_after'][row['path']]==row['sha256']
 for entry in r['programs']:
  assert sha(pathlib.Path(entry['ELF_path']))==entry['ELF_sha256'];assert entry['XML']['failures']=='0' and entry['XML']['errors']=='0' and entry['XML']['disabled']=='0'
  programs.append({'profile':r['profile'],**entry,'result_path':str(F/(phase+'-result.json'))})
assert len(programs)==9 and sum(int(x['XML']['tests']) for x in programs)==408
retained=[]
for p in sorted(B.glob('retained-*/*.gz')):
 h=hashlib.sha256();length=0
 with gzip.open(p,'rb') as f:
  while chunk:=f.read(262144):h.update(chunk);length+=len(chunk)
 retained.append({'gzip_path':str(p),'gzip_sha256':sha(p),'gzip_bytes':p.stat().st_size,'original_sha256':h.hexdigest(),'original_bytes':length,'full_decompression_CRC_and_SHA_checked':True})
# Keep exact current compile rows for the nine selected targets, not the entire
# repository database. This is an observed final input map, not an ARM proof.
dbrows=[]
for profile in ['debug','asan']:
 db=B/profile/'compile_commands.json';rows=json.loads(db.read_text());names=[x['target'] for x in programs if x['profile']==profile];selected=[]
 for row in rows:
  if any('CMakeFiles/'+name+'.dir/' in row.get('output','') for name in names):
   src=pathlib.Path(row['file']);selected.append({**row,'observed_source_sha256':sha(src),'observed_source_bytes':src.stat().st_size})
 dbrows.append({'profile':profile,'whole_database_sha256':sha(db),'selected_rows':selected})
compilemap=store('final-selected-compile-inputs.json',{'rows':dbrows,'qualification':'Final observed selected native compile inputs; canonical build receipts and source10 guards recorded separately. No MCU/installed-SDK/process-family claim.'})
receipts=[]
for p in sorted((B/'commands').glob('*/receipt.json')):
 r=json.loads(p.read_text());d=p.parent;assert r['child_joined'];assert sha(d/'stdout.raw')==r['stdout_sha256'];assert sha(d/'stderr.raw')==r['stderr_sha256'];receipts.append({'name':r['name'],'actual_exit':r['actual_exit'],'child_RSS_max_KiB':r['child_RSS_max_KiB'],'receipt_path':str(p),'receipt_sha256':sha(p)})
summary=store('final-delivery-r1.json',{
 'baseline_HEAD':bootstrap['HEAD'],'branch':freeze['branch'],'root':str(R),'index_sha256':sha(R/'.git/index'),'source_freeze_path':str(F/'source-freeze-r2.json'),'source_freeze_sha256':sha(F/'source-freeze-r2.json'),'patch_path':str(F/'source10-r2.patch'),'patch_sha256':sha(F/'source10-r2.patch'),'source10':freeze['source10'],
 'first_setup_failure':'debug-first-red-build actual1: newly authored enum ACQUIRED invalid; corrected to BORROWED. Bad source/raw preserved, not behaviorRED.',
 'TDD_history':[
  {'phase':'first-red','actual':'TX66fail30/RX67fail36; all old35/31 and model selfcheck pass','classification':'real runtimeRED; selected-domain gate/reset guards missing'},
  {'phase':'first-green','actual':'TX66/RX67 all0','classification':'same-test minimal implementationGREEN'},
  {'phase':'stop-mask-red','actual':'TX67/RX68 fail1 each','classification':'real runtimeRED in new healthy-stop saved-mask observation'},
  {'phase':'stop-mask-green','actual':'TX67/RX68 all0','classification':'same-test cleanup criticalsectionGREEN'},
  {'phase':'final-debug','actual':'7programs267cases all0','classification':'historical d638 candidate only; not substituted for finalnewsource'},
  {'phase':'stop-delegation-red','actual':'wholeRX71fail3','classification':'reviewer-found real runtimeRED, ordinary stop settled shared TX before mode domain fence'},
  {'phase':'stop-delegation-green','actual':'same-testwholeRX71 all0','classification':'minimal mode cancel+service join before ordinary stop'},
  {'phase':'final-debug-r2','actual':'7programs270cases all0','classification':'finalmatching source; nonreturn returned-marker strengthening honestly firstGREEN coverage'},
  {'phase':'final-asan-tx + final-asan-rx','actual':'2programs138cases all0','classification':'actualfresh canonical native-asan compile/run, flags unchanged'}],
 'final_programs':programs,'final_totals':{'programs':9,'Debug':270,'ASAN':138,'case_executions':408,'failures':0,'errors':0,'disabled':0,'whole_no_filters_or_shards':True},
 'retained_historical_ELFs':retained,'all_command_receipts':receipts,'max_measured_child_RSS_KiB':max(x['child_RSS_max_KiB'] for x in receipts),'actual_style10':{'report':str(B/'final-style.json'),'report_sha256':sha(B/'final-style.json'),'receipt':str(B/'commands/final-style/receipt.json'),'actual_exit':0},
 'discovery_proof':{'path':str(F/'final-discovery-proof.json'),'sha256':sha(F/'final-discovery-proof.json'),'cases_exact_match_XML':408},'ordinary_state_hotpath_proof':{'path':str(F/'post-review-token-and-boundary-proof.json'),'sha256':sha(F/'post-review-token-and-boundary-proof.json')},'selected_compile_inputs':{'path':str(compilemap),'sha256':sha(compilemap)},
 'scope_limits':['Only actual observed DMA1 gate/DMA1RST/DMA2RST violations become sticky; no claim to detect pulses wholly between observations.','Domain irrecoverability retains real request/slot/stream loans and isolates both owned vectors. Failed isolation parks masked; no normal ISR WCET claim for that fault boundary.','Fork kill/reap is parent process disposition, not provider cleanup. Nonreturn oracle observes a bounded window plus source-level infinite park.','Ordinary UART state definition and transmit IRQ text unchanged; target Flash/instruction cost not yet measured.','This packet has no ARM build/runtime, installedSDK, OCI/process-family, HIL, or physical electrical qualification.','Artifacts are volatile exec-shm development evidence. Root alone owns integration/full gates/commit/push.'],
 'budget':{'feature_cap':4194304,'build_cap':234881024,'feature_allocated_before_packet':allocated(F),'build_allocated':allocated(B),'allocated_method':'Unique (st_dev,st_ino) st_blocks*512, recursively only these two owned roots.','memory_events':(CG/'memory.events').read_text(),'all_command_children_joined':True,'all_old_evidence_retained':True}})
# Freeze small evidence leaves. Historical/final ELF bytes stay at the named
# immutable retained/current paths under the separately authorized build cap.
leaves=[]
for root,prefix in [(F,'feature'),(B/'commands','commands'),(B/'junit','junit')]:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  if root==F and p.name in {'final-leaf-inventory-r1.json','delivery-evidence-r1.zip','completed-handoff-r1.json'}:continue
  leaves.append({'name':prefix+'/'+p.relative_to(root).as_posix(),'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in [B/'final-style.json']:
 leaves.append({'name':'checks/'+p.name,'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
assert len({x['name'] for x in leaves})==len(leaves)
manifest=store('final-leaf-inventory-r1.json',{'leaves':leaves,'all_raw_before_after_and_failed_attempts_preserved':True,'excluded_large_ELFs':'Exact paths/fullSHA/gzipCRC are recorded in final-delivery-r1.json; no deletion or rewriting.'})
archive=F/'delivery-evidence-r1.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in leaves:z.write(row['path'],row['name'])
 z.write(manifest,'final-leaf-inventory-r1.json')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in leaves:assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
 assert hashlib.sha256(z.read('final-leaf-inventory-r1.json')).hexdigest()==sha(manifest)
assert allocated(F)<4194304 and allocated(B)<234881024
for row in freeze['source10']:assert sha(R/row['path'])==row['sha256']
assert sha(R/'.git/index')==bootstrap['index_sha256']
final=store('completed-handoff-r1.json',{'summary':{'path':str(summary),'sha256':sha(summary)},'inventory':{'path':str(manifest),'sha256':sha(manifest),'leaves':len(leaves)},'archive':{'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(leaves)+1,'full_member_SHA_CRC_readback':True},'source_freeze_sha256':sha(F/'source-freeze-r2.json'),'index_before_after_sha256':sha(R/'.git/index'),'final_programs':9,'final_case_executions':408,'feature_allocated_before_final_handoff':allocated(F),'build_allocated':allocated(B),'all_children_joined':True,'no_extra_qualification':True})
print(json.dumps({'handoff':str(final),'handoff_sha256':sha(final),'summary_sha256':sha(summary),'inventory_sha256':sha(manifest),'archive_sha256':sha(archive),'leaves':len(leaves),'feature_allocated':allocated(F),'build_allocated':allocated(B)},indent=2))
