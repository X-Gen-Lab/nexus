import pathlib,os,sys,time,subprocess,json,hashlib,resource
FEATURE=pathlib.Path('/dev/shm/nexus-h743-uart-runtime-feature-20261018-r1');BUILD=pathlib.Path('/dev/shm/nexus-h743-uart-runtime-builds-20261018-r1');ROOT=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018');CG=pathlib.Path('/sys/fs/cgroup')
def allocated(root):
 seen={}
 for p in (root,*root.rglob('*')):
  q=p.stat();seen[(q.st_dev,q.st_ino)]=q.st_blocks*512
 return sum(seen.values())
def guard():
 assert allocated(FEATURE)<4194304
 assert allocated(BUILD)<234881024
 assert int((CG/'memory.max').read_text())-int((CG/'memory.current').read_text())>=943718400
 s=os.statvfs('/workspace');assert s.f_bavail*s.f_frsize>=67108864
 s=os.statvfs('/tmp');assert s.f_bavail*s.f_frsize>=209715200
 assert 'oom 0' in (CG/'memory.events').read_text() and 'oom_kill 0' in (CG/'memory.events').read_text()
name=sys.argv[1];cmd=sys.argv[2:];out=BUILD/'commands'/name;assert not out.exists();guard();out.mkdir(parents=True)
env=os.environ.copy();env['TMPDIR']=str(BUILD/'tmp');env['PYTHONDONTWRITEBYTECODE']='1';env['CMAKE_BUILD_PARALLEL_LEVEL']='1';env['PATH']='/tmp/nexus-io-validation-20261018/.venv/bin:'+env['PATH']
for k in list(env):
 if k.startswith('GTEST_'):env.pop(k)
before=(CG/'memory.events').read_text();start=time.time_ns()
with (out/'stdout.raw').open('wb') as stdout,(out/'stderr.raw').open('wb') as stderr:
 child=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr);code=child.wait()
r={'name':name,'command':cmd,'cwd':str(ROOT),'TMPDIR':env['TMPDIR'],'actual_exit':code,'child_joined':True,'started_ns':start,'finished_ns':time.time_ns(),'memory_events_before':before,'memory_events_after':(CG/'memory.events').read_text(),'child_RSS_max_KiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'build_allocated':allocated(BUILD),'feature_allocated':allocated(FEATURE),'stdout_sha256':hashlib.sha256((out/'stdout.raw').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((out/'stderr.raw').read_bytes()).hexdigest()}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print((out/'stderr.raw').read_text()[-12000:]);print((out/'stdout.raw').read_text()[-3000:]);sys.exit(code)
