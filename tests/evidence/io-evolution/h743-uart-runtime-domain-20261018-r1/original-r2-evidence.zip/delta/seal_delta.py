import pathlib,json,hashlib,gzip,zipfile,subprocess,os
F=pathlib.Path('/dev/shm/nexus-h743-uart-runtime-feature-20261018-r1');N=F/'lifecycle-r2';B=pathlib.Path('/dev/shm/nexus-h743-uart-runtime-builds-20261018-r1');R=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018');CG=pathlib.Path('/sys/fs/cgroup')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def alloc(d):
 q={}
 for p in [d,*d.rglob('*')]:
  s=p.stat();q[(s.st_dev,s.st_ino)]=s.st_blocks*512
 return sum(q.values())
def store(name,data):
 p=N/name;assert not p.exists();s=(json.dumps(data,indent=2)+'\n').encode();assert alloc(F)+((len(s)+4095)//4096)*4096<4194304;p.write_bytes(s);return p
freeze=json.loads((N/'source-freeze-final.json').read_text());assert sha(F/'delivery-evidence-r1.zip')=='fd33ed8068070be2183e0bed5158d92658a7f7468e95711ae11fad1c7aba6e6b'
for row in freeze['source10']:assert sha(R/row['path'])==sha(pathlib.Path(row['snapshot']))==row['sha256']
assert sha(R/'.git/index')==freeze['index_sha256']
rows=[]
for rel in ['tests/google/h743_dma_test.cpp','tests/google/h743_receive_test.cpp']:
 old=(F/'files'/rel).read_bytes();now=(R/rel).read_bytes();assert now.startswith(old);rows.append({'path':rel,'entire_old71e25e_test_source_byte_prefix_preserved':True,'old_sha256':hashlib.sha256(old).hexdigest()})
for row in freeze['source10']:
 if row['path'] not in ['tests/google/h743_dma_test.cpp','tests/google/h743_receive_test.cpp','soc/stm32h743/drivers/uart_dma.c','soc/stm32h743/drivers/uart_receive.c']:assert (F/'files'/row['path']).read_bytes()==(R/row['path']).read_bytes()
proof=store('preservation-proof.json',{'old_test_prefixes':rows,'other6_source_bytes_exact':True,'original_source_freeze_sha256':sha(F/'source-freeze-r2.json'),'original_archive_sha256':sha(F/'delivery-evidence-r1.zip'),'index_unchanged':freeze['index_sha256']})
programs=[]
for phase in ['lifecycle-final-debug','lifecycle-final-asan']:
 data=json.loads((F/(phase+'-result.json')).read_text());assert data['all_programs_actual0']
 for row in freeze['source10']:assert data['source_before'][row['path']]==data['source_after'][row['path']]==row['sha256']
 for row in data['programs']:
  assert sha(pathlib.Path(row['ELF_path']))==row['ELF_sha256'];programs.append({'profile':data['profile'],**row})
assert len(programs)==9 and sum(int(x['XML']['tests']) for x in programs)==420
retained=[]
for p in sorted([*(B/'retained-final-r1').glob('*/*.gz'),*(B/'retained-lifecycle-red').glob('*.gz')]):
 original=gzip.decompress(p.read_bytes());retained.append({'path':str(p),'gzip_sha256':sha(p),'original_sha256':hashlib.sha256(original).hexdigest(),'original_bytes':len(original),'full_decompression_CRC_SHA_checked':True})
compile_rows=[]
for profile in ['debug','asan']:
 db=B/profile/'compile_commands.json';targetnames=[x['target'] for x in programs if x['profile']==profile];selected=[x for x in json.loads(db.read_text()) if any('CMakeFiles/'+name+'.dir/' in x.get('output','') for name in targetnames)]
 compile_rows.append({'profile':profile,'database_sha256':sha(db),'selected_rows':[{**x,'observed_source_sha256':sha(pathlib.Path(x['file']))} for x in selected]})
compilemap=store('selected-compile-inputs.json',{'rows':compile_rows,'observed_final_inputs_not_an_ARM_or_full_process_family_proof':True})
receipts=[]
for p in sorted((B/'commands').glob('lifecycle-*/receipt.json')):
 d=json.loads(p.read_text());assert d['child_joined'];assert sha(p.parent/'stdout.raw')==d['stdout_sha256'] and sha(p.parent/'stderr.raw')==d['stderr_sha256'];receipts.append({'name':d['name'],'actual_exit':d['actual_exit'],'receipt':str(p),'sha256':sha(p),'child_RSS_max_KiB':d['child_RSS_max_KiB']})
summary=store('final-delivery-r2.json',{'baseline_HEAD':freeze['baseline_HEAD'],'source_freeze':{'path':str(N/'source-freeze-final.json'),'sha256':sha(N/'source-freeze-final.json')},'base_packet_immutable':{'path':str(F/'completed-handoff-r1.json'),'sha256':sha(F/'completed-handoff-r1.json'),'archive_sha256':sha(F/'delivery-evidence-r1.zip')},'patch':{'path':str(N/'source10.patch'),'sha256':sha(N/'source10.patch')},'actual_TDD':'Same-test wholeTX70fail3/RX74fail3→GREEN70/74; realUSART IRQ after ordinaryretained/initialized/enable before mode irqsave observes loss; externalrestore must not wash sticky. No model or existing testbody changes.','production_fix':'Only a freshunowned cold lifecycle clears domain_lost before first DMAprobe; masked postordinarysuccess mode-retain/domain_live guard preserves observedloss and returnsSTATE without new selectedDMAsetup.','final_programs':programs,'totals':{'programs':9,'Debug':276,'ASAN':144,'case_executions':420,'failures':0,'errors':0,'disabled':0,'whole_no_filters_shards':True},'all_new_receipts':receipts,'retained_prior_final4_and_new_RED2_ELFs':retained,'preservation_proof':{'path':str(proof),'sha256':sha(proof)},'compile_inputs':{'path':str(compilemap),'sha256':sha(compilemap)},'strict_style10':{'report':str(B/'lifecycle-final-style.json'),'sha256':sha(B/'lifecycle-final-style.json'),'actual_exit':0},'actual_discovery':{'path':str(N/'final-discovery-proof.json'),'sha256':sha(N/'final-discovery-proof.json'),'XML_identity_exact_cases':420},'actual_resources':{'feature_allocated_before_delta_archive':alloc(F),'build_allocated':alloc(B),'feature_cap':4194304,'build_cap':234881024,'memory_events':(CG/'memory.events').read_text(),'max_measured_child_RSS_KiB':max(x['child_RSS_max_KiB'] for x in receipts),'all_children_joined':True},'boundaries':['Prior408 packet remains historical, superseded by this exactsource420 runtime tuple.','No ARM/installedSDK/HIL/OCI/process-family qualification; no ordinaryUARTstate or hotIRQ growth.','Only observed domainlosses become sticky; transient unobserved pulses not detected.','Fork kill/reap is parent disposition, not providercleanup.']})
leaves=[]
for p in sorted(N.rglob('*')):
 if p.is_file():leaves.append({'name':'delta/'+p.relative_to(N).as_posix(),'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in sorted(F.glob('lifecycle-*-result.json')):leaves.append({'name':'results/'+p.name,'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in sorted((B/'commands').glob('lifecycle-*/*')):
 if p.is_file():leaves.append({'name':'commands/'+p.relative_to(B/'commands').as_posix(),'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in sorted((B/'junit').glob('*-lifecycle-*.xml')):leaves.append({'name':'junit/'+p.name,'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in [B/'lifecycle-final-style.json']:leaves.append({'name':'checks/'+p.name,'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for row in freeze['source10']:
 p=pathlib.Path(row['snapshot']);leaves.append({'name':'final-source/'+row['path'],'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
assert len({x['name'] for x in leaves})==len(leaves)
manifest=store('leaf-inventory-r2.json',{'leaves':leaves,'base_archive_is_referenced_not_duplicated':sha(F/'delivery-evidence-r1.zip')})
archive=N/'delivery-delta-r2.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in leaves:z.write(row['path'],row['name'])
 z.write(manifest,'leaf-inventory-r2.json')
assert alloc(F)<4194304
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for row in leaves:assert hashlib.sha256(z.read(row['name'])).hexdigest()==row['sha256']
for row in freeze['source10']:assert sha(R/row['path'])==row['sha256']
assert sha(R/'.git/index')==freeze['index_sha256']
last=store('completed-handoff-r2.json',{'summary':{'path':str(summary),'sha256':sha(summary)},'source_freeze_sha256':sha(N/'source-freeze-final.json'),'archive':{'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(leaves)+1,'full_member_SHA_CRC_readback':True},'inventory':{'path':str(manifest),'sha256':sha(manifest),'leaves':len(leaves)},'source10_index_stable':True,'final_programs':9,'case_executions':420,'feature_allocated_before_this_file':alloc(F),'build_allocated':alloc(B),'no_qualification_expansion':True})
print(json.dumps({'handoff':str(last),'handoff_sha256':sha(last),'source_freeze_sha256':sha(N/'source-freeze-final.json'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'leaves':len(leaves),'feature_allocated':alloc(F),'build_allocated':alloc(B)},indent=2))
