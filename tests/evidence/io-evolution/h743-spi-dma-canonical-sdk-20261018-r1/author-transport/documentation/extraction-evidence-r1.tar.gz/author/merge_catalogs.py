import hashlib,json,sys
from pathlib import Path
import polib
R=Path('/tmp/nexus-h743-fixed-hsi-s0-20261018')
O=Path('/dev/shm/nexus-h743-spi-dma-d3-docs-gettext-20261018-r1')
sys.path.insert(0,str(R))
from tools.documentation.sphinx_ext import read_catalog
translated=[
'对经审查的 TOML 列表重复传入 `--fixture`。未指定 `--project` 时，每份 TOML 仍须位于 `tests/contracts`，并具有维护中的同目录 `CMakeLists.txt`。显式 `--project` 将整次调用绑定到当前 checkout 的 `tests/contracts` 下一个既有 CMake 工程；TOML 可以是该仓库的合同夹具，或直接位于 `tools/configure/assemblies` 的规范 schema-2 装配。每个选择都必须解析为 MCU 配置。门禁不根据系列自动发现工程，也不静默切换模式。',
'对于三个公开的 H743 SPI4 DMA 装配，在仓库根目录执行既有 H743 工程，并确保维护中的 ARM 编译器位于 `PATH`：',
'输出路径必须全新；每个选定固件构建、资源报告和保留的 provider 方法均须通过。命令链接 ARM 软件并保存报告及原始输出，不执行 MCU。完整 H743 provider 阶段通过同一工程选择既有 26 份合同装配和这三份规范装配。仅运行三份夹具不等于完成全部 29 份夹具的阶段。',
'可选的系列断言对照实际解析结果。不同后端必须具有分别维护的 TOML；不存在独立 OS 覆盖项。CMake 使用 `NEXUS_SOURCE_ROOT` 和 `NEXUS_ASSEMBLY_FILE` 构建所选工程的默认目标图。Native 选择、仓库外工程、符号链接工程、重复夹具和重复指定工程均被拒绝。选定源码根目录必须拥有实际执行的门禁及其导入工具；其他 checkout 的工具被拒绝。',
'实际编译数据库和 Ninja 依赖日志将编译源码、生成头、选定厂商头及编译器提供的头绑定到文件身份。维护中的图／配置源码及选定的锁定 SDK 输入字节在执行前建立快照，并在执行后复核。显式工程、它的 CMake 输入和所选装配均属于该快照。工程源码或任何声明装配发生变化都会使证据失效。矩阵拒绝源码、Git 版本、工具或产物变化。dirty checkout 可以提供身份明确的开发证据，但仅此门禁不能赋予 clean 发布候选资格。'
]
reports=[]
for doc,language in [('design/provider-assemblies','zh_CN'),('delivery/capabilities','en'),('delivery/capabilities','zh_CN')]:
 pot=O/'gettext'/(doc+'.pot');_,required,_=read_catalog(pot)
 rel=f'docs/locale/{language}/LC_MESSAGES/{doc}.po';old=R/rel
 _,old_msgs,old_fuzzy=read_catalog(old);assert not old_fuzzy
 source=R/'docs'/(doc+'.md');source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
 po=polib.pofile(str(old));po.merge(polib.pofile(str(pot)))
 adds=[];position=0
 for x in po:
  if x.obsolete:continue
  if x.msgid not in old_msgs:
   if doc=='delivery/capabilities':
    assert all(p.startswith('`') and p.endswith('`') and '/' in p for p in x.msgid.split(', '))
    x.msgstr=x.msgid
   else:
    x.msgstr=translated[position];position+=1
   x.flags=[f for f in x.flags if f!='fuzzy']
   adds.append({'msgid':x.msgid,'msgstr':x.msgstr})
 assert position==(5 if doc=='design/provider-assemblies' else 0)
 po.metadata.update({'Language':language,'X-Nexus-Source-SHA256':source_sha,'X-Nexus-Reviewed':'false'})
 target=O/'candidates'/rel;target.parent.mkdir(parents=True,exist_ok=True);po.save(str(target),newline='\n')
 metadata,after,fuzzy=read_catalog(target)
 assert set(after)==set(required) and all(after.values()) and not fuzzy
 assert all(after[k]==v for k,v in old_msgs.items() if k in after)
 assert metadata['X-Nexus-Reviewed']=='false' and metadata['X-Nexus-Source-SHA256']==source_sha
 reports.append({'path':rel,'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'candidate':str(target),'after_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'source_sha256':source_sha,'pot':str(pot),'pot_sha256':hashlib.sha256(pot.read_bytes()).hexdigest(),'required':len(after),'retained_unchanged_pairs':sum(k in required for k in old_msgs),'added_pairs':adds,'obsolete_msgids':[k for k in old_msgs if k not in required],'reviewed':False})
(O/'catalog-merge-review.json').write_text(json.dumps({'catalogs':reports,'canonical_sources_unchanged':True,'qualification':False},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'catalogs':[{k:v for k,v in r.items() if k not in ('added_pairs','obsolete_msgids')} for r in reports]},ensure_ascii=False))
