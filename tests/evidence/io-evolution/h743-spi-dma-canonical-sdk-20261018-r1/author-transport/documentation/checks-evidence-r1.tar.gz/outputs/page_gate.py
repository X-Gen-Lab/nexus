import json,pathlib,sys
root=pathlib.Path('/tmp/nexus-h743-fixed-hsi-s0-20261018');sys.path.insert(0,str(root))
from tools.documentation import check,sphinx_ext
out=pathlib.Path('/dev/shm/nexus-h743-spi-dma-d3-docs-gettext-20261018-r1')
report=check.validate_translations(root,pot_root=out/'gettext',critical_pages=['delivery/capabilities','design/provider-assemblies'],languages=('en','zh_CN'))
(out/'page-translation-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False));raise SystemExit(bool(report['errors']))
