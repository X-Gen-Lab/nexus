/**
 * \file            nexus_bindings.h
 * \brief           Fixed typed aliases selected by one assembly.
 * \author          Nexus Team
 */
#ifndef NEXUS_BINDINGS_H
#define NEXUS_BINDINGS_H
#include "nexus/core/status.h"
#include "nexus/io/spi.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct {
    nx_result_t primary;
    nx_result_t cleanup;
    uint32_t remaining_effects;
} nx_platform_start_result_t;
/** \brief Startup-only; no scheduler or product worker is created.
 * \return Primary/cleanup errors and retained effects. On error
 * all ports remain unusable; preserve contexts until cleanup.
 */
nx_platform_start_result_t nx_platform_start(void);
/** \brief Stop after direct writers/IRQ consumers quiesce.
 * \return SUCCESS after drain and release. BUSY or IO retains
 * incomplete leases; preserve all contexts and retry cleanup.
 * The owner must continue service before retrying BUSY.
 * Complete release restores the selected original pin states;
 * retain ownership if the product requires continued idle drive.
 */
nx_result_t nx_platform_stop(void);
/** \brief Cold lifecycle stage; errors remain in the normal result. */
typedef enum {
    NX_PLATFORM_PHASE_NONE, NX_PLATFORM_PHASE_CONTEXT,
    NX_PLATFORM_PHASE_SYSTEM, NX_PLATFORM_PHASE_RESOURCES,
    NX_PLATFORM_PHASE_CONTROLLER
} nx_platform_phase_t;
/** \brief Caller-owned output, accessed only during this call.
 * Controller indices are zero-based resolved.json controllers
 * positions, not typed factory IDs. SIZE_MAX means no controller.
 * Success clears all fields; failure identifies the failing stage.
 */
typedef struct {
    nx_platform_phase_t phase;
    size_t controller_index;
    nx_platform_phase_t cleanup_phase;
    size_t cleanup_controller_index;
} nx_platform_diagnostic_t;
/** \brief Start with optional call-scoped failure metadata.
 * \param diagnostic Writable output or NULL; never retained.
 * \return The normal primary/cleanup/remaining-effects result.
 * Context, deadline and ownership rules match nx_platform_start.
 */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop with optional call-scoped failure metadata.
 * \param diagnostic Writable output or NULL; never retained.
 * \return The normal stop result; failure never releases a borrow.
 * Context and ownership rules match nx_platform_stop.
 */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic);
/** \brief Fixed static identity; lifecycle stays explicit. */
extern const nx_spi_port_t* const nx_binding_bus4;
extern const nx_spi_endpoint_t* const nx_device_device4;
#ifdef __cplusplus
}
#endif
#endif
