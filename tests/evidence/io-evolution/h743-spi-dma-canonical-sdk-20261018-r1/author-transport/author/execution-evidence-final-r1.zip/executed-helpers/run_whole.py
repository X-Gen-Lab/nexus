import importlib.util,json,pathlib,sys,unittest
root=pathlib.Path(sys.argv[1]);sys.path.insert(0,str(root));path=root/sys.argv[2]
spec=importlib.util.spec_from_file_location('d3_whole_module',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
def names(s):
 for x in s:
  if isinstance(x,unittest.TestSuite):yield from names(x)
  else:yield x.id()
ids=list(names(suite));r=unittest.TextTestRunner(verbosity=2).run(suite)
p=pathlib.Path(sys.argv[3]);p.write_text(json.dumps({'module':sys.argv[2],'discovered':ids,'run':r.testsRun,'failures':[x.id() for x,_ in r.failures],'errors':[x.id() for x,_ in r.errors],'skipped':[(x.id(),v) for x,v in r.skipped],'successful':r.wasSuccessful()},indent=2)+'\n')
sys.exit(0 if r.wasSuccessful() and r.testsRun and not r.skipped else 1)
