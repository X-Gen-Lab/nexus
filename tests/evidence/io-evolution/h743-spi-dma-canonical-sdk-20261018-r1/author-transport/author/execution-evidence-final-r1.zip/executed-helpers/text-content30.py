from pathlib import Path
import sys,json,hashlib
root=Path('/tmp/nexus-h743-fixed-hsi-s0-20261018');sys.path.insert(0,str(root))
from scripts.ci.style_gate import check_text
base=Path('/dev/shm/nexus-h743-spi-dma-d3-20261018-r1')
paths=json.loads((base/'before33.json').read_text())['approved_paths']
rows=[];errors=[]
for name in paths:
 p=root/name
 if not p.exists():continue
 failures=check_text(p,name);errors.extend(failures);rows.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'errors':failures})
result={'status':'passed' if not errors else 'failed','scope':'actual maintained check_text rules on30 current worktree files; not staged/index admission','files':rows,'errors':errors}
(base/'development-text30.json').write_text(json.dumps(result,indent=2)+'\n');print('TEXT30',len(rows),len(errors));raise SystemExit(bool(errors))
