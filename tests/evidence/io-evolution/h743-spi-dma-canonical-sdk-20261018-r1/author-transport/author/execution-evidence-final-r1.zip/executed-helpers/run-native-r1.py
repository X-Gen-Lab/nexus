from pathlib import Path
import hashlib,json,os,resource,signal,stat,subprocess,sys,threading,time
root=Path('/tmp/nexus-h743-fixed-hsi-s0-20261018');sys.path.insert(0,str(root))
from tools.dev.process import run
from scripts.validation.junit import prepare_report,validate_junit
base=Path('/dev/shm/nexus-h743-spi-dma-d3-native-20261018-r1')
feature=Path('/dev/shm/nexus-h743-spi-dma-d3-20261018-r1')
assert not base.exists();base.mkdir();(base/'tmp').mkdir()
cap=201326592;cg=Path('/sys/fs/cgroup');workspace=Path('/workspace')
paths=json.loads((feature/'before33.json').read_text())['approved_paths']
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def allocated():return sum(p.lstat().st_blocks*512 for p in base.rglob('*'))
def metrics():
 s=os.statvfs(workspace)
 return {'headroom':int((cg/'memory.max').read_text())-int((cg/'memory.current').read_text()),'workspace_free':s.f_bavail*s.f_frsize,'allocated':allocated(),'events':dict(line.split() for line in (cg/'memory.events').read_text().splitlines())}
def guard(spawn=False):
 m=metrics();assert m['headroom']>=(900 if spawn else 600)*1024*1024,m;assert m['workspace_free']>=64*1024*1024,m;assert m['allocated']<=cap-4*1024*1024,m;assert m['events']['oom']=='0' and m['events']['oom_kill']=='0',m;return m
def source():
 return {'head':subprocess.check_output(['git','--no-optional-locks','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'index_sha256':sha(root/'.git/index'),'files':[{'path':n,'sha256':sha(root/n),'bytes':(root/n).stat().st_size,'mode':stat.S_IMODE((root/n).stat().st_mode)} if (root/n).exists() else {'path':n,'absent':True} for n in paths]}
env=dict(os.environ,TMPDIR=str(base/'tmp'),PYTHONDONTWRITEBYTECODE='1',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1')
env['PATH']='/workspace/nexus-build-system-20261012/.venv/bin:'+env['PATH']
for name in list(env):
 if name.startswith(('GTEST_','CTEST_')):del env[name]
records=[];summary={'kind':'focused_complete_four_programs_each_profile_development','qualification':False,'cap_bytes':cap,'scope':'No filter/shard; unchanged real CMake Google targets, Debug and ASan/UBSan presets; not complete repository suite/ARM/HIL/SDK.','phases':records,'profiles':[]}
def execute(stage,argv):
 before=guard(True);done=threading.Event();obs={'minimum_headroom':before['headroom'],'maximum_allocated':before['allocated'],'breaches':[]}
 def watch():
  while not done.wait(0.5):
   m=metrics();obs['minimum_headroom']=min(obs['minimum_headroom'],m['headroom']);obs['maximum_allocated']=max(obs['maximum_allocated'],m['allocated'])
   if m['headroom']<600*1024*1024 or m['workspace_free']<64*1024*1024 or m['allocated']>cap-4*1024*1024 or m['events']['oom']!='0' or m['events']['oom_kill']!='0':
    obs['breaches'].append(m);os.kill(os.getpid(),signal.SIGINT);return
 signal.signal(signal.SIGINT,lambda signum,frame:None);t=threading.Thread(target=watch,daemon=True);t.start()
 try:r=run(argv,cwd=root,env=env,log=base/(stage+'.raw'),timeout=7200,stage=stage)
 finally:done.set();t.join()
 record={'stage':stage,'argv':argv,'actual_returncode':r.returncode,'receipt':str(r.receipt_path),'before':before,'after':metrics(),'resource_observation':obs,'max_completed_child_rusage_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss};records.append(record)
 (base/'execution.json').write_text(json.dumps(summary,indent=2)+'\n');print('ACTUAL',stage,r.returncode,flush=True)
 assert r.returncode==0 and not obs['breaches'],record
 guard();return record
cmake='/workspace/nexus-build-system-20261012/.venv/bin/cmake';python='/workspace/nexus-build-system-20261012/.venv/bin/python';ninja='/workspace/nexus-build-system-20261012/.venv/bin/ninja'
targets=['nexus_h743_spi_dma_factory_test','nexus_h743_spi_dma_uart_tx_factory_test','nexus_h743_spi_dma_uart_rx_factory_test','nexus_h743_spi_dma_test']
try:
 for profile in ('native-debug','native-asan'):
  build=base/profile;before=source();entry={'profile':profile,'source_before':before,'programs':[]};summary['profiles'].append(entry)
  execute(profile+'-configure',[cmake,'--preset',profile,'-B',str(build),'-DPython3_EXECUTABLE='+python,'-DCMAKE_MAKE_PROGRAM='+ninja])
  execute(profile+'-build',[cmake,'--build',str(build),'--parallel','1','--verbose','--target',*targets])
  execute(profile+'-actual-dependencies',[ninja,'-C',str(build),'-t','deps'])
  for target in targets:
   elf=build/'bin'/target;assert elf.is_file(),str(elf)
   xml=base/(profile+'-'+target+'.xml');anchor=prepare_report(xml)
   identity={'path':str(elf),'bytes':elf.stat().st_size,'sha256':sha(elf)}
   execute(profile+'-'+target,[str(elf),'--gtest_output=xml:'+str(xml)])
   junit=validate_junit(xml,not_before_ns=anchor);assert junit['skipped']==0
   assert identity['sha256']==sha(elf)
   entry['programs'].append({'target':target,'elf':identity,'junit':junit,'xml':str(xml)})
  entry['source_after']=source();assert before==entry['source_after']
  entry['compile_commands']={'path':str(build/'compile_commands.json'),'bytes':(build/'compile_commands.json').stat().st_size,'sha256':sha(build/'compile_commands.json')}
 summary['status']='passed';summary['final']=guard()
except BaseException as exc:
 summary['status']='failed';summary['error']=repr(exc);summary['final']=metrics();raise
finally:
 (base/'execution.json').write_text(json.dumps(summary,indent=2)+'\n')
 print('NATIVE_SUMMARY',summary['status'],flush=True)
