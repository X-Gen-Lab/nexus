from pathlib import Path
import hashlib,json,os,signal,stat,subprocess,sys,threading,resource
root=Path('/tmp/nexus-h743-fixed-hsi-s0-20261018');sys.path.insert(0,str(root))
from tools.dev.process import run
base=Path('/dev/shm/nexus-h743-spi-dma-d3-arm-20261018-r1');assert not base.exists();base.mkdir();(base/'tmp').mkdir()
feature=Path('/dev/shm/nexus-h743-spi-dma-d3-20261018-r1');paths=json.loads((feature/'before33.json').read_text())['approved_paths'];cg=Path('/sys/fs/cgroup');cap=256*1024*1024
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def source():return {'head':subprocess.check_output(['git','--no-optional-locks','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'index_sha256':sha(root/'.git/index'),'files':[{'path':n,'bytes':(root/n).stat().st_size,'sha256':sha(root/n),'mode':stat.S_IMODE((root/n).stat().st_mode)} if (root/n).exists() else {'path':n,'absent':True} for n in paths]}
def metrics():
 s=os.statvfs('/workspace');return {'headroom':int((cg/'memory.max').read_text())-int((cg/'memory.current').read_text()),'workspace_free':s.f_bavail*s.f_frsize,'allocated':sum(p.lstat().st_blocks*512 for p in base.rglob('*')),'events':dict(line.split() for line in (cg/'memory.events').read_text().splitlines())}
before=metrics();assert before['headroom']>=900*1024*1024 and before['workspace_free']>=64*1024*1024 and before['events']['oom']=='0'
record={'kind':'focused_three_canonical_assemblies_actual_arm_elf_development','qualification':False,'source_before':source(),'before':before,'cap_bytes':cap};done=threading.Event();obs={'minimum_headroom':before['headroom'],'maximum_allocated':0,'breaches':[]}
def watch():
 while not done.wait(0.5):
  m=metrics();obs['minimum_headroom']=min(obs['minimum_headroom'],m['headroom']);obs['maximum_allocated']=max(obs['maximum_allocated'],m['allocated'])
  if m['headroom']<600*1024*1024 or m['workspace_free']<64*1024*1024 or m['allocated']>cap-4*1024*1024 or m['events']['oom']!='0':obs['breaches'].append(m);os.kill(os.getpid(),signal.SIGINT);return
signal.signal(signal.SIGINT,lambda signum,frame:None);thread=threading.Thread(target=watch,daemon=True);thread.start()
python='/workspace/nexus-build-system-20261012/.venv/bin/python';arm='/tmp/nexus-io-tools-recovery-20261018/arm-gnu-toolchain-14.3.rel1-x86_64-arm-none-eabi/bin'
env=dict(os.environ,TMPDIR=str(base/'tmp'),PYTHONDONTWRITEBYTECODE='1',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1');env['PATH']='/workspace/nexus-build-system-20261012/.venv/bin:'+arm+':'+env['PATH']
argv=[python,str(root/'scripts/ci/provider_assemblies.py'),'--root',str(root),'--project','tests/contracts/h743_assembly','--family','stm32h743','--compiler',arm+'/arm-none-eabi-gcc','--output',str(base/'matrix'),'--parallel','1']
for name in ('h743-spi-dma.toml','h743-spi-dma-uart-tx.toml','h743-spi-dma-uart-rx.toml'):argv+=['--fixture','tools/configure/assemblies/'+name]
try:
 result=run(argv,cwd=root,env=env,log=base/'actual-matrix.raw',timeout=7200,stage='d3-focused-three-arm-canonical')
 record.update({'argv':argv,'actual_returncode':result.returncode,'receipt':str(result.receipt_path)});assert result.returncode==0 and not obs['breaches']
 report=json.loads((base/'matrix/report.json').read_text());assert report['status']=='passed' and len(report['fixtures'])==3
 record['report']={'path':str(base/'matrix/report.json'),'sha256':sha(base/'matrix/report.json')};record['source_after']=source();assert record['source_before']==record['source_after'];record['status']='passed'
except BaseException as exc:record['status']='failed';record['error']=repr(exc);raise
finally:
 done.set();thread.join();record.update({'after':metrics(),'resource_observation':obs,'child_maxrss_KiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss});(base/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print('ACTUAL_ARM3',record['status'],record.get('actual_returncode'),flush=True)
