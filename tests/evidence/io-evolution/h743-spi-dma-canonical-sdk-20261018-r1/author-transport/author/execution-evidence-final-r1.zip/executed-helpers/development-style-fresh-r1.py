from pathlib import Path
import sys,json,os
root=Path('/tmp/nexus-h743-fixed-hsi-s0-20261018');sys.path.insert(0,str(root))
from tools.dev.process import run
base=Path('/dev/shm/nexus-h743-spi-dma-d3-20261018-r1');work=Path('/dev/shm/nexus-h743-spi-dma-d3-work-20261018-r1')
paths=json.loads((base/'before33.json').read_text())['approved_paths']
new={'tools/configure/assemblies/h743-spi-dma.toml','tools/configure/assemblies/h743-spi-dma-uart-tx.toml','tools/configure/assemblies/h743-spi-dma-uart-rx.toml','cmake/package/verification/io_evolution/consumers/h743-spi-dma.c'}
tracked=[n for n in paths if (root/n).exists() and n not in new];smoke='cmake/package/verification/io_evolution/consumers/h743-spi-dma.c'
commands=[('tracked26',[sys.executable,str(root/'scripts/ci/style_gate.py'),'--report',str(base/'development-style-tracked26.json'),*tracked]),('new-c-format',[sys.executable,str(root/'scripts/tools/format.py'),'--check','--files',smoke]),('new-c-comments',[sys.executable,str(root/'scripts/ci/comment_style.py'),'--files',smoke,'--json']),('text30',[sys.executable,str(work/'text-content30.py')])]
rows=[]
for stage,argv in commands:
 r=run(argv,cwd=root,env=os.environ,log=base/('development-style-'+stage+'.raw'),timeout=300,stage='d3-development-style-'+stage)
 rows.append({'stage':stage,'argv':argv,'actual_returncode':r.returncode,'receipt':str(r.receipt_path)})
 (base/'development-style-subcommands-r1.json').write_text(json.dumps({'scope':'Pre-staging maintained content checks only; full newly staged repository hook remains Root responsibility. Earlier style30 index-admission failure preserved.','commands':rows},indent=2)+'\n')
 print(stage,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
