from pathlib import Path
import subprocess,sys,json
base=Path('/dev/shm/nexus-h743-spi-dma-d3-20261018-r1')
work=Path('/dev/shm/nexus-h743-spi-dma-d3-work-20261018-r1')
python='/workspace/nexus-build-system-20261012/.venv/bin/python'
root='/tmp/nexus-h743-fixed-hsi-s0-20261018'
modules=[('provider53','scripts/ci/test_provider_assemblies.py'),('spi_config9','tools/configure/providers/stm32h743/test_spi_dma.py'),('selected18','tools/configure/test_selected_contract_authority.py'),('payload15','tests/contracts/test_device_sdk_payload.py'),('sdk28','tools/testing/test_sdk_verification_call.py'),('release44','.github/workflows/test_release.py'),('qualification8','tools/testing/test_qualification_plan.py'),('work_packages24','tools/testing/test_work_packages.py'),('ci54','.github/workflows/test_platform_ci.py')]
results=[]
for name,module in modules:
 stage='final-python-'+name
 argv=[python,str(work/'execute-source-bound-r2.py'),stage,python,str(work/'run_whole.py'),root,module,str(base/(stage+'.json'))]
 ret=subprocess.run(argv).returncode
 results.append({'module':module,'stage':stage,'actual_returncode':ret})
 (base/'final-python-modules-progress-r1.json').write_text(json.dumps(results,indent=2)+'\n')
 if ret:raise SystemExit(ret)
print('ALL_FINAL_PYTHON_MODULES_ACTUAL_ZERO',flush=True)
