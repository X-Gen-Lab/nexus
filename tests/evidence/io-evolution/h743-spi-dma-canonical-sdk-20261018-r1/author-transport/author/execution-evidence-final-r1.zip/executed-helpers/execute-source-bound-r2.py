from pathlib import Path
import os,sys,json,resource,time,hashlib,zipfile,stat,subprocess,threading,signal
root=Path('/tmp/nexus-h743-fixed-hsi-s0-20261018');sys.path.insert(0,str(root));from tools.dev.process import run
base=Path('/dev/shm/nexus-h743-spi-dma-d3-20261018-r1');work=Path('/dev/shm/nexus-h743-spi-dma-d3-work-20261018-r1')
def memory():return int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text())
assert os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize>=64*1024*1024
assert memory()>=900*1024*1024
assert sum(p.stat().st_blocks*512 for p in base.rglob('*') if p.is_file()) < 6*1024*1024-256*1024
stage=sys.argv[1];env=dict(os.environ,TMPDIR=str(work/'tmp'),NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']='/workspace/nexus-build-system-20261012/.venv/bin:/tmp/nexus-io-tools-recovery-20261018/arm-gnu-toolchain-14.3.rel1-x86_64-arm-none-eabi/bin:'+env['PATH']
paths=json.loads((base/'before33.json').read_text())['approved_paths']
def capture(label):
 rows=[]
 with zipfile.ZipFile(base/(stage+'.'+label+'-source.zip'),'x',compression=zipfile.ZIP_DEFLATED) as archive:
  for name in paths:
   path=root/name
   if not path.exists():rows.append({'path':name,'state':'absent'});continue
   data=path.read_bytes();mode=stat.S_IMODE(path.stat().st_mode)
   rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':mode})
   prior = next((row for row in before['sources'] if row['path']==name), None) if label=='after' else None
   if prior != rows[-1]:archive.writestr(name,data)
  head=subprocess.check_output(['git','--no-optional-locks','-C',str(root),'rev-parse','HEAD']).decode().strip()
  record={'head':head,'sources':rows,'index_sha256':hashlib.sha256((root/'.git/index').read_bytes()).hexdigest()}
  archive.writestr('source-manifest.json',json.dumps(record,indent=2)+'\n')
 (base/(stage+'.'+label+'-source.json')).write_text(json.dumps(record,indent=2)+'\n')
 return record
before=capture('before')
stop=threading.Event();resources={'minimum_headroom':memory(),'guard_breaches':[]}
def resource_watch():
 while not stop.wait(0.5):
  headroom=memory();free=os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize
  resources['minimum_headroom']=min(resources['minimum_headroom'],headroom)
  if headroom<600*1024*1024 or free<64*1024*1024:
   resources['guard_breaches'].append({'headroom':headroom,'workspace_free':free})
   os.kill(os.getpid(),signal.SIGINT)
   return
signal.signal(signal.SIGINT,lambda signum,frame:None)
watch=threading.Thread(target=resource_watch,daemon=True);watch.start()
try:
 result=run(sys.argv[2:],cwd=root,env=env,log=base/(stage+'.raw'),timeout=7200,stage=stage)
finally:
 stop.set();watch.join()
(base/(stage+'.result.json')).write_text(json.dumps({'argv':sys.argv[2:],'actual_returncode':result.returncode,'receipt':str(result.receipt_path),'child_maxrss_KiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'headroom_after':memory(),'events':Path('/sys/fs/cgroup/memory.events').read_text(),'resource_observation':resources},indent=2)+'\n')
after=capture('after');stable=before==after;print('ACTUAL',stage,result.returncode,'SOURCE_STABLE',stable,flush=True);sys.exit(result.returncode if stable and not resources['guard_breaches'] else 1)
