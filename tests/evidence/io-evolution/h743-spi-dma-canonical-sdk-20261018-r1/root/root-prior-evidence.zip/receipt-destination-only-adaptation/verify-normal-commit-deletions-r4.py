"""Independently bind an actual normal hook run to its exact committed input."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/tmp/nexus-io-validation-20261018')
BASE = Path('/workspace/nexus-io-recovery-20261018')
parser = argparse.ArgumentParser()
parser.add_argument('--stage', required=True)
parser.add_argument('--manifest', type=Path, required=True)
parser.add_argument('--applied', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--expected-source-count', type=int, required=True)
parser.add_argument('--scope', required=True)
args = parser.parse_args()
sys.path.insert(0, str(ROOT))
from scripts.ci.tdd_gate import discovered_count, validate_google_report

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def identity(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def git(*arguments):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', '-c',
        'maintenance.auto=false', '-C', str(ROOT), *arguments])

def load(path):
    return json.loads(path.read_text())

def check_process(path, lower, upper):
    value = load(path)
    assert lower <= value['started_ns'] <= value['finished_ns'] <= upper, path
    assert value['outcome'] == 'completed' and value['exit_code'] == 0, path
    assert value['withdrawal_complete'] is True, path
    receipt = Path(value['attempt_receipt'])
    observed = load(receipt)
    for key in ('command', 'cwd', 'stage', 'started_ns', 'finished_ns',
                'outcome', 'exit_code', 'withdrawal_complete'):
        assert observed[key] == value[key], (path, key)
    for role in ('stdout', 'stderr'):
        declared = value[role]
        actual = identity(Path(declared['path']))
        assert actual == declared, (path, role)
    return value

def check_controlled_invocation():
    redirected = ('GIT_DIR', 'GIT_COMMON_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE',
                  'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES',
                  'GIT_NAMESPACE')
    assert not any(key in os.environ for key in redirected)
    assert not any(key.startswith('GIT_CONFIG') for key in os.environ)
    assert args.output.is_absolute() and args.output.resolve() == args.output
    gitdir = Path(git('rev-parse', '--absolute-git-dir').decode().strip()).resolve()
    assert not args.output.is_relative_to(ROOT)
    assert not args.output.is_relative_to(gitdir)
    assert not any(part.is_symlink() for part in args.output.parents)


check_controlled_invocation()
manifest = load(args.manifest)
applied = load(args.applied)
assert sha(args.manifest) == applied['complete_manifest_sha256']
head = git('rev-parse', 'HEAD').decode().strip()
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
assert tree == applied['tree']
assert git('rev-parse', 'HEAD^').decode().strip() == applied['head']
assert not git('status', '--porcelain=v1', '--untracked-files=all')
rows = manifest['files']
deletions = manifest.get('deleted_files', [])
assert manifest['file_count'] == len(rows) + len(deletions)
allowed_deletions = {
    'tests/contracts/h743_assembly/spi-dma.toml',
    'tests/contracts/h743_assembly/spi-dma-uart-tx.toml',
    'tests/contracts/h743_assembly/spi-dma-uart-rx.toml',
}
assert len(deletions) == len(allowed_deletions)
assert {row['path'] for row in deletions} == allowed_deletions
written_source_count = sum(not row['path'].startswith('tests/evidence/') for row in rows)
assert manifest['written_source_count'] == written_source_count
assert manifest['deleted_source_count'] == len(deletions)
assert manifest['source_count'] == applied['source_files'] == args.expected_source_count
assert written_source_count + len(deletions) == args.expected_source_count
actual_names = set(git('diff', '--no-renames', '--name-only', '-z', applied['head'], head).decode().split('\0')) - {''}
assert actual_names == {row['path'] for row in rows + deletions}
for row in rows:
    path = ROOT / row['path']
    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], path
    data = git('show', 'HEAD:' + row['path'])
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], path

for row in deletions:
    path = ROOT / row['path']
    assert not path.exists() and not path.is_symlink()
    assert not git('ls-files', '-z', '--', row['path'])
    assert not git('ls-tree', '-z', head, '--', row['path'])
    old = git('show', applied['head'] + ':' + row['path'])
    assert len(old) == row['bytes'] and hashlib.sha256(old).hexdigest() == row['sha256']
removed = set(git('diff', '--no-renames', '--name-only', '--diff-filter=D', '-z', applied['head'], head).decode().split('\0')) - {''}
assert removed == {row['path'] for row in deletions}

outer_path = Path('/dev/shm/nexus-root-maintained-command-evidence-20261018-r1') / args.stage / 'command.command.json'
outer = load(outer_path)
outer = check_process(outer_path, outer['started_ns'], outer['finished_ns'])
assert outer['command'][:1] == ['git'] and 'commit' in outer['command']
assert outer['cwd'] == str(ROOT)
stderr = Path(outer['stderr']['path']).read_text()
assert 'Failed' not in stderr and 'Skipped' not in stderr

tdd = ROOT / 'build/native-debug/tdd'
summary_path = tdd / 'execution.json'
summary = load(summary_path)
assert summary['kind'] == 'development-contract-execution' and summary['preset'] == 'native-debug'
lower, upper = outer['started_ns'], outer['finished_ns']
assert summary_path.stat().st_mtime_ns >= lower
for name in ('configure', 'build'):
    check_process(tdd / (name + '.command.json'), lower, upper)
tools = []
for suite in summary['tool_suites']:
    name = suite['suite']
    check_process(tdd / ('tools-' + name + '.command.json'), lower, upper)
    assert load(tdd / ('tools-' + name + '.json')) == suite
    assert suite['status'] == 'passed' and suite['discovered'] == suite['executed'] > 0
    assert all(suite[key] == 0 for key in ('skipped', 'failures', 'errors',
                                         'expected_failures', 'unexpected_successes'))
    tools.append(suite)
assert {item['suite'] for item in tools} == {'testing', 'configure', 'ci', 'workflows'}
programs = load(ROOT / 'build/native-debug/google-contracts.json')['executables']
assert len(programs) == len(summary['suites']) and len(set(programs)) == len(programs)
observed_binaries = []
for index, (binary_name, recorded) in enumerate(zip(programs, summary['suites'])):
    binary = Path(binary_name)
    listing = check_process(tdd / ('discovery-%d.command.json' % index), lower, upper)
    execution = check_process(tdd / ('execution-%d.command.json' % index), lower, upper)
    assert listing['command'] == [str(binary), '--gtest_filter=*', '--gtest_list_tests']
    report = tdd / ('google-%d.xml' % index)
    assert execution['command'] == [str(binary), '--gtest_filter=*', '--gtest_repeat=1',
        '--gtest_also_run_disabled_tests', '--gtest_output=xml:' + str(report)]
    count = discovered_count(Path(listing['stdout']['path']).read_text())
    evidence = validate_google_report(report, not_before_ns=execution['started_ns'],
                                      expected_cases=count)
    assert recorded == {'binary': binary.name, **evidence}
    observed_binaries.append({'binary': identity(binary), 'cases': count,
                             'report': identity(report)})
assert summary['passed'] == sum(row['cases'] for row in observed_binaries)
matrix = tdd / 'io-property-report.json'
assert matrix.is_file() and matrix.stat().st_mtime_ns >= lower
assert git('rev-parse', 'HEAD').decode().strip() == head
assert not git('status', '--porcelain=v1', '--untracked-files=all')
result = {'kind': 'actual-normal-complete-index-commit-gates', 'head': head,
    'tree': tree, 'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'worktree_clean': True, 'staged_files_verified': len(rows) + len(deletions), 'deleted_files_verified': len(deletions),
    'programs': len(programs), 'google_test_cases': summary['passed'],
    'tool_tests': sum(row['executed'] for row in tools), 'tool_suites': tools,
    'failures': 0, 'errors': 0, 'skipped': 0,
    'normal_hooks': 'actual ordinary git commit exit0; full raw retained; no bypass/filter/shard',
    'execution_report': identity(summary_path), 'outer_receipt': identity(outer_path),
    'io_property_report': identity(matrix), 'executed_programs': observed_binaries,
    'scope': args.scope}
with args.output.open('x') as stream:
    json.dump(result, stream, indent=2); stream.write('\n')
print(json.dumps({key: result[key] for key in ('head', 'tree', 'staged_files_verified',
    'programs', 'google_test_cases', 'tool_tests', 'worktree_clean')}), flush=True)
