"""Execute recovery validation with raw evidence on persistent storage."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/tmp/nexus-io-validation-20261018')
RECOVERY = Path('/workspace/nexus-io-recovery-20261018')
VENV = Path('/workspace/nexus-build-system-20261012/.venv/bin')
ARM = Path('/tmp/nexus-io-tools-recovery-20261018/arm-gnu-toolchain-14.3.rel1-x86_64-arm-none-eabi/bin')
parser = argparse.ArgumentParser()
parser.add_argument('stage')
parser.add_argument('--timeout', type=int, default=1800)
parser.add_argument('--jobs', type=int, default=1)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
if not args.stage.replace('-', '').isalnum():
    raise ValueError('Use a unique simple stage identity')
command = args.command[1:] if args.command[:1] == ['--'] else args.command
if not command:
    raise ValueError('Actual command is required')
if args.jobs not in (1, 2):
    raise ValueError('Recovery validation uses one or two compile workers')
if command[0] == '@python':
    command[0] = str(VENV / 'python')
sys.path.insert(0, str(ROOT))
from tools.dev import process
environment = dict(os.environ)
if environment.get('SKIP') or environment.get('NEXUS_SKIP_TDD'):
    raise ValueError('Hook bypass settings cannot establish evidence')
if any(key.startswith('GTEST_') for key in environment):
    raise ValueError('Inherited test settings must be reviewed explicitly')
environment.update(PATH=str(VENV) + os.pathsep + str(ARM) + os.pathsep +
                   environment.get('PATH', ''), NEXUS_BUILD_JOBS=str(args.jobs),
                   CMAKE_BUILD_PARALLEL_LEVEL=str(args.jobs), CTEST_PARALLEL_LEVEL='1',
                   PRE_COMMIT_HOME='/tmp/nexus-io-precommit-recovery-20261018',
                   PIP_CACHE_DIR='/tmp/nexus-io-pip-cache-recovery-20261018',
                   VIRTUALENV_OVERRIDE_APP_DATA='/tmp/nexus-io-virtualenv-appdata-20261018',
                   PYTHONDONTWRITEBYTECODE='1')
constraints = RECOVERY / 'python-hook-constraints-r1.txt'
if constraints.is_file():
    environment['PIP_CONSTRAINT'] = str(constraints)
destination = Path('/dev/shm/nexus-root-maintained-command-evidence-20261018-r1') / args.stage
destination.mkdir(parents=True, exist_ok=False)
def source_identity():
    relative = ('soc/stm32h743/drivers/flash_ram_owner.c',
                'soc/stm32h743/private/stm32h743_flash_ram.h',
                'tests/google/h743_flash_ram_generated_test.cpp')
    return {name: hashlib.file_digest((ROOT / name).open('rb'), 'sha256').hexdigest()
            for name in relative}
before = source_identity()
(destination / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
result = process.run(command, cwd=ROOT, env=environment,
                     log=destination / 'command.txt', timeout=args.timeout,
                     stage=args.stage)
after = source_identity()
(destination / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
summary = {'schema': 1, 'command': command, 'cwd': str(ROOT),
           'returncode': result.returncode, 'receipt': str(result.receipt_path),
           'source_unchanged': before == after,
           'qualification': 'actual command only; inspect scope and reports'}
(destination / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
print(result.stdout[-4000:], end='')
print(result.stderr[-2000:], end='', file=sys.stderr)
raise SystemExit(result.returncode)
