"""Finite read-only volatile checkpoint; retained raw requires later GitHub publication."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile
import time
import xml.etree.ElementTree as ET

ROOT = Path('/tmp/nexus-io-validation-20261018')
TDD = ROOT / 'build/native-debug/tdd'
OUT = Path(__file__).resolve().parent
STAGING = Path('/dev/shm/nexus-full-hook-qualification-transfer-staging-20261018-r1')
BUDGET = 3 * 1024 * 1024
INTERVAL = 20
DURATION = 3 * 60 * 60
STOP = OUT / 'STOP'
SEEN = {}
STABLE = {}
BATCH = 0


def sha(stream):
    result = hashlib.sha256()
    for block in iter(lambda: stream.read(65536), b''):
        result.update(block)
    return result.hexdigest()


def allowed(path):
    if not path.is_absolute() or not path.is_relative_to(TDD):
        raise ValueError('Checkpoint input escapes fixed TDD tree')
    if any(parent.is_symlink() for parent in (path, *path.parents)):
        raise ValueError('Checkpoint does not follow symlinks')


def metadata(path):
    allowed(path)
    st = path.stat()
    if not stat.S_ISREG(st.st_mode):
        raise ValueError('Regular report/log file required')
    return {'bytes': st.st_size, 'mode': stat.S_IMODE(st.st_mode),
            'mtime_ns': st.st_mtime_ns, 'ctime_ns': st.st_ctime_ns,
            'dev': st.st_dev, 'ino': st.st_ino}


def observe(path):
    first = metadata(path)
    with path.open('rb') as stream:
        digest = sha(stream)
    if metadata(path) != first:
        raise ValueError('Input changed while being observed')
    return {'path': str(path.relative_to(ROOT)), **first, 'sha256': digest}


def used():
    seen = set()
    total = 0
    for path in OUT.iterdir():
        if not path.is_file() or path.is_symlink():
            continue
        st = path.stat()
        key = st.st_dev, st.st_ino
        if key not in seen:
            total += st.st_blocks * 512
            seen.add(key)
    return total


def write_event(value):
    if used() > BUDGET - 8192:
        raise RuntimeError('Checkpoint metadata budget exhausted')
    with (OUT / 'catalog.jsonl').open('a') as stream:
        stream.write(json.dumps(value) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def changed(path):
    return SEEN.get(str(path)) != metadata(path)


def complete_groups(start_ns):
    groups, pending = [], []
    for path in sorted(TDD.glob('*.command.json')):
        try:
            value = json.loads(path.read_text())
            if value.get('started_ns', 0) < start_ns:
                continue
            if (value.get('outcome') == 'running' or
                    type(value.get('exit_code')) is not int or
                    type(value.get('finished_ns')) is not int or
                    value.get('withdrawal_complete') is not True):
                pending.append({'path': str(path), 'outcome': value.get('outcome'),
                                'exit_code': value.get('exit_code')})
                continue
            if not changed(path):
                continue
            members = [path, Path(value['attempt_receipt'])]
            for field in ('stdout', 'stderr'):
                identity = value[field]
                actual = observe(Path(identity['path']))
                if actual['bytes'] != identity['bytes'] or actual['sha256'] != identity['sha256']:
                    raise ValueError('Completed process raw identity differs')
                members.append(Path(identity['path']))
            args = value['command']
            reports = []
            if '--report' in args:
                reports.append(Path(args[args.index('--report') + 1]))
            reports.extend(Path(arg.split('xml:', 1)[1]) for arg in args
                           if arg.startswith('--gtest_output=xml:'))
            for report in reports:
                if not report.exists():
                    continue
                allowed(report)
                if report.suffix == '.xml':
                    ET.parse(report)
                elif report.suffix == '.json':
                    json.loads(report.read_text())
                else:
                    raise ValueError('Only declared XML/JSON reports are captured')
                members.append(report)
            groups.append((members, {'stage': value['stage'],
                 'started_ns': value['started_ns'], 'finished_ns': value['finished_ns'],
                 'outcome': value['outcome'], 'actual_exit_code': value['exit_code']}))
        except (OSError, ValueError, KeyError, ET.ParseError):
            # Partial publication remains in ROOT and is reconsidered later.
            continue
    return groups, pending


def extra_reports(start_ns, final):
    result = []
    for name in ('execution.json', 'io-property-inputs.json', 'io-property-report.json'):
        path = TDD / name
        try:
            if not path.is_file() or path.stat().st_mtime_ns < start_ns or not changed(path):
                continue
            current = metadata(path)
            json.loads(path.read_text())
            if final or STABLE.get(str(path)) == current:
                result.append(([path], {'role': 'gate JSON checkpoint; no independent admission'}))
            STABLE[str(path)] = current
        except (OSError, ValueError):
            continue
    return result


def verify(archive, rows, manifest_bytes):
    expected = {row['path']: row for row in rows}
    found = set()
    with gzip.open(archive, 'rb') as compressed:
        with tarfile.open(fileobj=compressed, mode='r|') as bundle:
            for member in bundle:
                if member.name == 'CHECKPOINT-MANIFEST.json':
                    if bundle.extractfile(member).read() != manifest_bytes:
                        raise ValueError('Checkpoint manifest differs')
                    continue
                row = expected.get(member.name)
                if row is None or member.name in found or not member.isfile():
                    raise ValueError('Checkpoint member list differs')
                stamp = '%d.%09d' % divmod(row['mtime_ns'], 10**9)
                if (member.size, member.mode, member.pax_headers.get('mtime')) != (row['bytes'], row['mode'], stamp):
                    raise ValueError('Checkpoint member metadata differs')
                with bundle.extractfile(member) as stream:
                    if sha(stream) != row['sha256']:
                        raise ValueError('Checkpoint member bytes differ')
                found.add(member.name)
        while compressed.read(65536):
            pass
    if found != set(expected):
        raise ValueError('Incomplete checkpoint archive')


def checkpoint(groups):
    global BATCH
    if not groups:
        return
    files = sorted({path for members, _ in groups for path in members})
    rows = [observe(path) for path in files]
    manifest = {'schema': 1, 'kind': 'completed_hook_file_checkpoint',
         'qualification': False, 'root': str(ROOT), 'round_started_ns': START_NS,
         'commands_or_roles': [role for _, role in groups], 'files': rows}
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    BATCH += 1
    name = 'batch-%04d.tar.gz' % BATCH
    temporary = STAGING / name
    with temporary.open('xb') as target:
        with tarfile.open(fileobj=target, mode='w:gz', format=tarfile.PAX_FORMAT) as bundle:
            info = tarfile.TarInfo('CHECKPOINT-MANIFEST.json')
            info.size = len(data)
            bundle.addfile(info, io.BytesIO(data))
            for row in rows:
                info = tarfile.TarInfo(row['path'])
                info.size, info.mode = row['bytes'], row['mode']
                info.pax_headers['mtime'] = '%d.%09d' % divmod(row['mtime_ns'], 10**9)
                with (ROOT / row['path']).open('rb') as stream:
                    bundle.addfile(info, stream)
    verify(temporary, rows, data)
    for path, row in zip(files, rows):
        if observe(path) != row:
            raise ValueError('Original changed before checkpoint publication')
    allocated = ((temporary.stat().st_size + 4095) // 4096) * 4096
    if used() + allocated + 16384 > BUDGET:
        write_event({'kind': 'budget_pause', 'candidate': str(temporary),
                     'candidate_bytes': temporary.stat().st_size,
                     'checkpoint_allocated': used(), 'limit': BUDGET,
                     'originals_untouched': True})
        print('BUDGET_PAUSE', flush=True)
        raise RuntimeError('3MiB checkpoint checkpoint cap reached; no originals removed')
    pending = OUT / (name + '.partial')
    with temporary.open('rb') as source, pending.open('xb') as target:
        for block in iter(lambda: source.read(65536), b''):
            target.write(block)
        target.flush()
        os.fsync(target.fileno())
    with temporary.open('rb') as stream:
        digest = sha(stream)
    with pending.open('rb') as stream:
        if sha(stream) != digest:
            raise ValueError('Checkpoint archive bytes differ')
    final = OUT / name
    os.link(pending, final)
    pending.unlink()
    descriptor = os.open(OUT, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    for path in files:
        SEEN[str(path)] = metadata(path)
    value = {'kind': 'batch_sealed', 'batch': BATCH, 'path': str(final),
             'bytes': final.stat().st_size, 'sha256': digest,
             'files': len(rows), 'observed_commands': len(groups),
             'actual_exit_codes': [role.get('actual_exit_code') for _, role in groups
                                   if 'actual_exit_code' in role],
             'all_member_sha_gzip_crc_and_original_recheck': True,
             'checkpoint_allocated': used()}
    write_event(value)
    print(json.dumps(value), flush=True)


if __name__ == '__main__':
    STAGING.mkdir(exist_ok=False)
    outer_path = Path('/workspace/nexus-io-recovery-20261018/validation/commands/qualification-transfer-full-commit-r1/command.command.json')
    outer = json.loads(outer_path.read_text())
    anchor_deadline = time.monotonic() + 600
    while True:
        anchor = json.loads((TDD / 'tools-testing.command.json').read_text())
        if anchor['started_ns'] >= outer['started_ns']:
            break
        if time.monotonic() >= anchor_deadline:
            raise RuntimeError('Fresh current full-hook anchor did not appear')
        time.sleep(2)
    START_NS = anchor['started_ns']
    with (OUT / 'start.json').open('x') as stream:
        json.dump({'scope': str(TDD), 'round_started_ns': START_NS,
             'parent_commit_session': None,
             'parent_stage': 'qualification-transfer-full-commit-r1',
             'parent_reported_index_tree': '3925bfc209c728a33d8d19f21c19c0ee266b13e9', 'budget': BUDGET,
             'interval_seconds': INTERVAL, 'maximum_seconds': DURATION,
             'qualification': False, 'modifies_root_or_index': False}, stream, indent=2)
    deadline = time.monotonic() + DURATION
    try:
        while True:
            final = STOP.is_file() or time.monotonic() >= deadline
            groups, pending = complete_groups(START_NS)
            groups += extra_reports(START_NS, final)
            for offset in range(0, len(groups), 24):
                checkpoint(groups[offset:offset + 24])
            if final:
                write_event({'kind': 'monitor_stopped', 'batches': BATCH,
                     'checkpointed_paths': len(SEEN), 'pending_process_receipts': pending,
                     'reason': 'parent_stop' if STOP.is_file() else 'finite_duration',
                     'checkpoint_allocated': used(), 'qualification': False})
                print('MONITOR_STOPPED', flush=True)
                break
            time.sleep(INTERVAL)
    except Exception as error:
        write_event({'kind': 'monitor_error', 'error': str(error),
                     'batches': BATCH, 'qualification': False})
        raise
