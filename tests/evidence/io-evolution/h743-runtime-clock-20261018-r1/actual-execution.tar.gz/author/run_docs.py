from pathlib import Path
import hashlib,json,os,sys
R=Path('/dev/shm/nexus-qualification-transport-20261018-r1');D=Path('/dev/shm/nexus-h743-runtime-power-docs-20261018-r1');P=Path('/tmp/nexus-recovery-docs-tools-20261018-r1')
sys.path.insert(0,str(R))
from tools.documentation import install,sphinx_ext
from tools.dev import process
D.mkdir(mode=0o700)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def allocated():return sum(p.stat().st_blocks*512 for p in D.rglob('*') if p.is_file())
page=R/'docs/design/clock-domain-sleep.md';before=sha(page);index=sha(R/'.git/index')
tools=install.diagnose(P);env=install.environment(P)
for key in tuple(env):
 if key.startswith('NEXUS_DOCS_'):env.pop(key)
policy=json.loads((R/'dependencies/platform-compatibility.json').read_bytes())
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',NEXUS_DOCS_TOOL_PREFIX=str(P),NEXUS_DOCS_REVISION='e385a5d8e4906138fc4560e71cc1440476671e29',NEXUS_DOCS_CODE_REVISION='e385a5d8e4906138fc4560e71cc1440476671e29',NEXUS_DOCS_VERSION=policy['semantic_version'],NEXUS_DOCS_LANGUAGE='en',NEXUS_DOCS_LANGUAGES='en,zh_CN',NEXUS_DOCS_DOXYGEN_XML=str(D/'api/xml'),NEXUS_DOCS_GETTEXT_ROOT=str(D/'gettext'),NEXUS_DOCS_TRANSLATION_ROOT=str(R/'docs/locale'),TMPDIR=str(D/'tmp'))
(D/'tmp').mkdir();(D/'Doxyfile').write_text(f'@INCLUDE = "{R}/Doxyfile"\nOUTPUT_DIRECTORY = "{D}/api"\nPROJECT_NUMBER = "{policy["semantic_version"]}"\nGENERATE_HTML = NO\nDOT_NUM_THREADS = 1\n')
commands=[('doxygen',[str(P/'bin/doxygen'),str(D/'Doxyfile')]),('gettext',[str(P/'venv/bin/python'),'-B','-m','sphinx','-E','-n','-W','--keep-going','-j','1','-b','gettext','-c',str(R/'docs/sphinx'),'-d',str(D/'doctrees'),str(R/'docs'),str(D/'gettext'),str(page)])]
rows=[]
for stage,argv in commands:
 assert allocated()<32*1024**2
 r=process.run(argv,cwd=R,env=env,log=D/(stage+'.raw'),stage='runtime-power-'+stage,timeout=900);rows.append({'stage':stage,'actual_exit':r.returncode,'receipt':str(r.receipt_path)})
 if r.returncode:raise RuntimeError(stage+' actual '+str(r.returncode))
 assert allocated()<32*1024**2
assert sha(page)==before and sha(R/'.git/index')==index
pot=D/'gettext/design/clock-domain-sleep.pot';metadata,messages,fuzzy=sphinx_ext.read_catalog(pot)
result={'status':'passed','page_sha256':before,'POT_sha256':sha(pot),'entries':len(messages),'fuzzy':fuzzy,'allocated':allocated(),'tool_identity':tools,'commands':rows,'page_index_unchanged':True,'scope':'fresh Doxygen XML + actual single-page POT only; no HTML/ARM/SDK/HIL'}
(D/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='tool_identity'}))
