from pathlib import Path
import hashlib,json,sys
R=Path('/dev/shm/nexus-qualification-transport-20261018-r1');A=Path('/dev/shm/nexus-h743-runtime-power-arm-20261018-r1');F=Path('/dev/shm/nexus-h743-runtime-power-feature-20261018-r1')
sys.path.insert(0,str(R))
from tools.measurement.elf import Elf32
from tools.measurement.retention import linked_object
report=json.loads((A/'report.json').read_text())
assert report['status']=='passed' and report['fixture_count']==2 and report['source_inputs_stable']
results=[]
for row in report['fixtures']:
 selected=Path(row['assembly']['path']).stem=='h743-spi-dma-runtime-clock'
 artifact=row['artifacts']['elf'];p=Path(artifact['path']);data=p.read_bytes()
 assert len(data)==artifact['bytes'] and hashlib.sha256(data).hexdigest()==artifact['sha256']
 elf=Elf32(data);names={s['name'] for s in elf.defined_symbols};states=[]
 if selected:
  for n in ('nx_platform_runtime_domain','nx_platform_runtime_pause','nx_platform_runtime_resume','nx_clock_domain_acquire','nx_clock_domain_release','nx_clock_domain_quiescent'):
   assert n in names,n
  for n in ('s_nx_runtime_domain','s_nx_runtime_lease'):
   symbol,section=linked_object(elf,n,'runtime lifecycle state',writable=True)
   states.append({'name':n,'address':symbol['value'],'bytes':symbol['size'],'section':section['name']})
 else:
  assert not any(n.startswith(('nx_platform_runtime_','nx_clock_domain_','s_nx_runtime_')) for n in names)
 results.append({'selected':selected,'elf':artifact,'runtime_state':states,'runtime_state_bytes':sum(s['bytes'] for s in states),'flash_loaded_bytes':row['flash_loaded_bytes'],'ram_reserved_bytes':row['ram_reserved_bytes'],'face_count':row['face_count'],'method_count':row['method_count']})
assert sum(x['selected'] for x in results)==1
out={'status':'passed','scope':'Actual dirty-author-source ARM CMake link and retained symbols; selected and unselected mains differ, so total image delta is not an isolated component-cost claim. No target execution, WCET, clean SDK, OCI, physical or candidate qualification.','fixtures':results}
p=F/'arm-two-image-postcheck.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
