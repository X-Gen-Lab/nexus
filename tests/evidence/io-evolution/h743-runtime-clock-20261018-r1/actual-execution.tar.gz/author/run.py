from pathlib import Path
import hashlib,json,os,resource,shutil,signal,subprocess,sys,threading,time
R=Path('/dev/shm/nexus-qualification-transport-20261018-r1');F=Path('/dev/shm/nexus-h743-runtime-power-feature-20261018-r1');B=Path('/dev/shm/nexus-h743-runtime-power-builds-20261018-r1')
sys.path.insert(0,str(R))
from tools.dev import process
name=sys.argv[1];cmd=sys.argv[2:];cap=128*1024**2
B.mkdir(exist_ok=True)
def alloc(p):return sum(x.stat().st_blocks*512 for x in p.rglob('*') if x.is_file() and not x.is_symlink())
def state():
 names=set()
 for args in (['diff','--name-only','-z','HEAD'],['ls-files','--others','--exclude-standard','-z']):
  r=subprocess.run(['git','--no-optional-locks','-C',str(R),*args],capture_output=True,check=True);names.update(x.decode() for x in r.stdout.split(b'\0') if x)
 return {'index':hashlib.sha256((R/'.git/index').read_bytes()).hexdigest(),'source':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in sorted(names) if (R/n).is_file()}}
def resource_state(spawn=False):
 headroom=int(Path('/sys/fs/cgroup/memory.max').read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text());events={k:int(v) for k,v in (x.split() for x in Path('/sys/fs/cgroup/memory.events').read_text().splitlines())}
 free={p:shutil.disk_usage(p).free for p in ('/workspace','/tmp','/dev/shm')};used=alloc(B)
 reasons=[]
 if headroom<(900 if spawn else 600)*1024**2:reasons.append('memory_floor')
 if any(events.get(k,0) for k in ('oom','oom_kill','oom_group_kill')):reasons.append('OOM')
 if free['/workspace']<64*1024**2 or min(free['/tmp'],free['/dev/shm'])<200*1024**2:reasons.append('disk_floor')
 if used>cap:reasons.append('build_cap')
 if alloc(Path('/dev/shm/nexus-h743-runtime-power-arm-20261018-r1'))>32*1024**2:reasons.append('arm_cap')
 if alloc(Path('/dev/shm/nexus-h743-runtime-power-docs-20261018-r1'))>48*1024**2:reasons.append('docs_cap')
 return {'ns':time.time_ns(),'headroom':headroom,'events':events,'free':free,'build_allocated':used,'reasons':reasons}
before=state();initial=resource_state(True);assert not initial['reasons'],initial
stop=threading.Event();samples=[]
def monitor():
 while not stop.wait(2):
  s=resource_state();samples.append(s)
  if s['reasons']:os.kill(os.getpid(),signal.SIGTERM);return
thread=threading.Thread(target=monitor,daemon=True);thread.start()
env={k:v for k,v in os.environ.items() if not k.startswith('GTEST_') and not k.startswith('GIT_')}
env.update(PATH='/tmp/nexus-io-validation-20261018/.venv/bin:/usr/bin:/bin',TMPDIR=str(F/'tmp'),PYTHONDONTWRITEBYTECODE='1',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
try:r=process.run(cmd,cwd=R,env=env,log=F/(name+'.raw'),timeout=1200,stage=name)
finally:stop.set();thread.join()
after=state();final=resource_state();record={'actual_exit':r.returncode,'before':before,'after':after,'source_index_unchanged':before==after,'initial':initial,'samples':samples,'final':final,'maxrss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}
(F/(name+'-guard.json')).write_text(json.dumps(record,indent=2)+'\n');assert before==after
print(json.dumps({'stage':name,'actual_exit':r.returncode,'source_index_unchanged':before==after,'build_allocated':final['build_allocated'],'tail':(r.stdout+r.stderr)[-2200:]}),flush=True)
raise SystemExit(r.returncode)
