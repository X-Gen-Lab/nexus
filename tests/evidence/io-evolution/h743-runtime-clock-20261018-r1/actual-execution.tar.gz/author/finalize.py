from pathlib import Path
import gzip,hashlib,io,json,os,stat,tarfile,decimal
F=Path('/dev/shm/nexus-h743-runtime-power-feature-20261018-r1');D=Path('/dev/shm/nexus-h743-runtime-power-docs-20261018-r1');A=Path('/dev/shm/nexus-h743-runtime-power-arm-20261018-r1');R=Path('/dev/shm/nexus-qualification-transport-20261018-r1')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  for b in iter(lambda:s.read(1048576),b''):h.update(b)
 return h.hexdigest()
def identity(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def allocated(p):return sum(q.stat().st_blocks*512 for q in p.rglob('*') if q.is_file())
old=json.loads((F/'final-code35-source-map.json').read_text());replacements={x['path']:x for x in json.loads((F/'final-clock-doc-three-source-map.json').read_text())['files']};rows=[]
for row in old['files']:
 row=replacements.get(row['path'],row);p=Path(row['durable_source']);assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'];rows.append(row)
assert len(rows)==35 and sha(R/'.git/index')==old['index_sha256']
source_map=F/'final-source-map.json';assert not source_map.exists();source_map.write_text(json.dumps({'baseline':old['baseline'],'source_count':35,'files':rows,'index_sha256':old['index_sha256'],'scope':'Exact author e385 source. Root preserves G4 through its reviewed three-way merge; joint capabilities page/POs are separately Root-owned. No final product source copied into this evidence archive.'},indent=2)+'\n')
arm=json.loads((F/'arm-two-image-postcheck.json').read_text());summary={'baseline':old['baseline'],'software_status':'not_qualified','hardware_status':'not_executed','working_behavior':'Selected fixed H743 V2003/default HSI trim64/cache-off/baremetal SPI4 DMA lifecycle lease with actual callable pause/resume, preserving System/TIM2. SETTLED retains lease; actual IRQ/DMA/CS/pad/gate withdrawal precedes release. Default assembly retains no runtime API or ClockDomain state/functions.','final_native':{'program_executions':6,'case_executions':100,'failures':0,'skipped':0,'composition':'17 runtime +17 ClockDomain +16 existing SPI factory in Debug and ASAN/UBSAN','tuple':'Exact per-stage source/index guards; before later packaging/CI/doc metadata additions. Matching retained ELF/DB hashes are explicitly post-execution observations.'},'python_whole_passed':{'configure':878,'SDK_producer_and_payload_modules':45,'release':44,'workflow':57,'work_packages':24},'actual_red_classification':{'initial_config8':'3 new-behavior assertion failures plus1 missing-dependency setup ERROR; preserved, not all classified production RED.','explicit_null9':'1 actual assertion RED then minimal presence-sensitive resolver fix GREEN9.','repeated_pause13':'1 actual assertion RED/four extra RCC writes then no-lease early return GREEN13.','runtime12_initial_and_four_later_coverage_cases':'Initial integration GREEN12; four additional boundaries first-GREEN coverage, never manufactured RED.','SDK45':'9 real assertion failures then minimal tuple/mandatory/public smoke implementation; next run old count fixture44pass1fail, count maintenance followed GREEN45.','workflow57':'1 real missing canonical fixture assertion then one additive existing-job fixture entry GREEN57.','work_packages24':'1 obsolete exact fixture-list expectation then append-only expectation correction GREEN24; MCU192/Native19 retained.','documentation':'Partial TOML marker omission observed by real capabilities CLI; first fresh gettext retry monitored docs32MiB cap withdrawal130, approved48MiB retry0 with all17 ordered msgids and translations unchanged. No runtime RED claim.'},'ARM':arm,'remaining':'Joint clean Main ordinary full gates, actual unified installed SDK36roots39images, OCI/offline reproducibility and physical hardware are not established by this author packet. Other families/modes, DVFS, deep STOP, WFI, RTOS policy and product pin policy are outside this fixed-run slice.'}
(F/'final-execution-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
inputs={}
for p in F.rglob('*'):
 if p.is_file() and not p.is_symlink() and 'tmp' not in p.relative_to(F).parts:inputs['author/'+p.relative_to(F).as_posix()]=p
for p in D.rglob('*'):
 rel=p.relative_to(D)
 if (p.is_file() and not p.is_symlink() and not any(x in rel.parts for x in ['api','doctrees','fragment-doctrees','tmp']) and (p.suffix in {'.raw','.json','.py','.pot'} or p.name in {'stdout.txt','stderr.txt','receipt.json'})):inputs['documentation/'+rel.as_posix()]=p
inputs['arm/report.json']=A/'report.json'
for p in (A/'commands').rglob('*'):
 if p.is_file() and not p.is_symlink():inputs['arm/commands/'+p.relative_to(A/'commands').as_posix()]=p
for label,name in [('runtime-source-subset','/dev/shm/nexus-io30-runtime-power-code-independent-review-20261018-r1.json'),('page-translation','/dev/shm/nexus-io30-clock-domain-sleep-translation-independent-review-20261018-r1.json'),('fragment-metadata','/dev/shm/nexus-io30-clock-domain-sleep-fragment-metadata-independent-addendum-20261018-r1.json')]:inputs['peer/'+label+'.json']=Path(name)
C=Path('/dev/shm/nexus-h743-runtime-power-capabilities-gettext-20261018-r1')
for p in C.glob('owner-capabilities-check-red-r1*'):
 if p.is_file():inputs['original-fragment-rejection/'+p.name]=p
 elif p.is_dir():
  for q in p.rglob('*'):
   if q.is_file():inputs['original-fragment-rejection/'+q.relative_to(C).as_posix()]=q
entries=[]
for name,p in sorted(inputs.items()):
 s=p.stat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink();entries.append({'path':name,'origin':str(p),'bytes':s.st_size,'sha256':sha(p),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns})
archive=F/'actual-execution-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz',format=tarfile.PAX_FORMAT,compresslevel=6) as t:
 for row in entries:
  p=inputs[row['path']];s=p.stat();assert s.st_size==row['bytes'] and sha(p)==row['sha256'];info=t.gettarinfo(str(p),arcname=row['path']);info.mtime=row['mtime_ns']//10**9;info.pax_headers['mtime']=str(row['mtime_ns']//10**9)+'.'+str(row['mtime_ns']%10**9).zfill(9)
  with p.open('rb') as stream:t.addfile(info,stream)
 b=(json.dumps({'files':entries},indent=2)+'\n').encode();info=tarfile.TarInfo('_member-manifest.json');info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b))
with gzip.open(archive,'rb') as stream:
 while stream.read(1048576):pass
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(entries)+1;manifest=json.loads(t.extractfile('_member-manifest.json').read());assert manifest['files']==entries
 for row in entries:
  member=t.getmember(row['path']);data=t.extractfile(member).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];assert member.mode==row['mode'] and member.uid==row['uid'] and member.gid==row['gid'];assert int(decimal.Decimal(member.pax_headers['mtime'])*10**9)==row['mtime_ns'];assert sha(inputs[row['path']])==row['sha256']
for row in rows:assert sha(Path(row['durable_source']))==row['sha256']
assert sha(R/'.git/index')==old['index_sha256']
result={'status':'sealed','source_count':35,'source_map':identity(source_map),'summary':identity(F/'final-execution-summary.json'),'archive':identity(archive),'archive_payload_members':len(entries),'archive_crc_eof_every_member_bytes_sha_mode_uid_gid_mtime_verified':True,'product_sources_copied':False,'source_index_unchanged':True,'native_allocated':allocated(Path('/dev/shm/nexus-h743-runtime-power-builds-20261018-r1')),'docs_allocated':allocated(D),'ARM_allocated':allocated(A),'scope':'Local development implementation and real tests/ARM linking only; no clean SDK/OCI/offline/HIL qualification inherited.'}
p=F/'completed-handoff.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');result['feature_allocated']=allocated(F);assert result['feature_allocated']<=2*1024**2,result;assert result['native_allocated']<=128*1024**2 and result['docs_allocated']<=48*1024**2 and result['ARM_allocated']<=32*1024**2;print(json.dumps(dict(result,handoff=identity(p)),indent=2))
