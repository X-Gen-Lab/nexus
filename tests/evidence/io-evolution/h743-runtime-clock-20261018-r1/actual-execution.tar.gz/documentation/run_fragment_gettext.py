from pathlib import Path
import hashlib,json,os,sys
R=Path('/dev/shm/nexus-qualification-transport-20261018-r1');D=Path('/dev/shm/nexus-h743-runtime-power-docs-20261018-r1');P=Path('/tmp/nexus-recovery-docs-tools-20261018-r1')
sys.path.insert(0,str(R))
from tools.documentation import install,sphinx_ext
from tools.dev import process
env=install.environment(P)
for key in tuple(env):
 if key.startswith('NEXUS_DOCS_'):env.pop(key)
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',NEXUS_DOCS_TOOL_PREFIX=str(P),NEXUS_DOCS_REVISION='e385a5d8e4906138fc4560e71cc1440476671e29',NEXUS_DOCS_CODE_REVISION='e385a5d8e4906138fc4560e71cc1440476671e29',NEXUS_DOCS_VERSION=json.loads((R/'dependencies/platform-compatibility.json').read_text())['semantic_version'],NEXUS_DOCS_LANGUAGE='en',NEXUS_DOCS_LANGUAGES='en,zh_CN',NEXUS_DOCS_DOXYGEN_XML=str(D/'api/xml'),NEXUS_DOCS_GETTEXT_ROOT=str(D/'fragment-gettext'),NEXUS_DOCS_TRANSLATION_ROOT=str(R/'docs/locale'),TMPDIR=str(D/'tmp'))
argv=[str(P/'venv/bin/python'),'-B','-m','sphinx','-E','-n','-W','--keep-going','-j','1','-b','gettext','-c',str(R/'docs/sphinx'),'-d',str(D/'fragment-doctrees'),str(R/'docs'),str(D/'fragment-gettext'),str(R/'docs/design/clock-domain-sleep.md')]
r=process.run(argv,cwd=R,env=env,log=D/'fragment-gettext-r2.raw',stage='fragment-marker-gettext-r2',timeout=600)
assert r.returncode==0,r.stderr
old=sphinx_ext.read_catalog(D/'gettext/design/clock-domain-sleep.pot')[1];new=sphinx_ext.read_catalog(D/'fragment-gettext/design/clock-domain-sleep.pot')[1]
assert tuple(old)==tuple(new) and len(new)==17
print(json.dumps({'actual_exit':r.returncode,'entries':17,'ordered_msgids_unchanged':True,'receipt':str(r.receipt_path),'source_sha256':hashlib.sha256((R/'docs/design/clock-domain-sleep.md').read_bytes()).hexdigest()}))
