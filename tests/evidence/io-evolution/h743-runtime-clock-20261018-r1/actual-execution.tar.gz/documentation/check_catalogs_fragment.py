from pathlib import Path
import json,sys
R=Path('/dev/shm/nexus-qualification-transport-20261018-r1');sys.path.insert(0,str(R))
from tools.documentation.sphinx_ext import read_catalog,translation_status
D=Path('/dev/shm/nexus-h743-runtime-power-docs-20261018-r1')
source=(R/'docs/design/clock-domain-sleep.md').read_text();messages=tuple(read_catalog(D/'fragment-gettext/design/clock-domain-sleep.pot')[1])
rows={lang:translation_status(source,'design/clock-domain-sleep',lang,R/'docs/locale',messages) for lang in ('en','zh_CN')}
assert len(messages)==17 and all(x['status']=='reviewed' for x in rows.values()),rows
print(json.dumps({'message_count':len(messages),'locales':rows},ensure_ascii=False))
