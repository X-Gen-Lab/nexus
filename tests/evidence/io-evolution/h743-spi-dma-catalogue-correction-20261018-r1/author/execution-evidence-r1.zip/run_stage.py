import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import threading
import time

ROOT = Path('/tmp/nexus-h743-fixed-hsi-s0-20261018')
BASE = Path('/dev/shm/nexus-h743-d3-catalogue-amendment-20261018-r1')
OUT = Path(__file__).resolve().parent
PYTHON = '/workspace/nexus-build-system-20261012/.venv/bin/python'
sys.path.insert(0, str(ROOT))
from tools.dev import process


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'mode': path.stat().st_mode & 0o777}


def snapshot():
    baseline = json.loads((BASE / 'before.json').read_text())
    sources = {}
    for name, expected in baseline['source33'].items():
        path = ROOT / name
        actual = {'absent': True} if not path.exists() else identity(path)
        assert actual == expected, name
        sources[name] = actual
    index = ROOT / '.git/index'
    assert identity(index) == baseline['index'], 'index changed'
    head = subprocess.check_output(
        ['git', '--no-optional-locks', 'rev-parse', 'HEAD'], cwd=ROOT,
        text=True).strip()
    assert head == baseline['head']
    return {'head': head, 'index': identity(index), 'source33': sources,
            'additional_sources': {name: identity(ROOT / name)
                                   for name in baseline['additional_sources']}}


def allocated(directory):
    return sum(path.stat().st_blocks * 512 for path in directory.rglob('*')
               if path.is_file())


def observation():
    current = int(Path('/sys/fs/cgroup/memory.current').read_text())
    maximum = int(Path('/sys/fs/cgroup/memory.max').read_text())
    return {'memory_current': current, 'memory_max': maximum,
            'memory_headroom': maximum - current,
            'workspace_free': shutil.disk_usage('/workspace').free,
            'execution_allocated': allocated(OUT),
            'oom_events': Path('/sys/fs/cgroup/memory.events').read_text()}


stage = sys.argv[1]
assert stage in {'matrix-red', 'matrix-green', 'configure-green', 'configure-green-r2', 'style'}
report = OUT / (stage + '.json')
assert not report.exists()
before = snapshot()
resources_before = observation()
assert resources_before['memory_headroom'] >= 900 * 1024 * 1024
assert resources_before['workspace_free'] >= 64 * 1024 * 1024
assert resources_before['execution_allocated'] <= 32 * 1024 * 1024
temporary = OUT / 'tmp'
temporary.mkdir(exist_ok=True)
env = dict(os.environ, TMPDIR=str(temporary), PYTHONDONTWRITEBYTECODE='1',
           NEXUS_BUILD_JOBS='1',
           PATH='/workspace/nexus-build-system-20261012/.venv/bin:' +
           os.environ['PATH'])
if stage.startswith('configure-green'):
    command = [PYTHON, '-B', 'tools/testing/run_tool_tests.py', '--suite',
               'configure', '--report', str(OUT / 'configure-complete.json')]
elif stage == 'style':
    command = [PYTHON, '-B', 'scripts/ci/style_gate.py',
               'tools/configure/assemblies/catalogue.json',
               'tools/configure/test_matrix.py', '--report',
               str(OUT / 'style-result.json')]
else:
    command = [PYTHON, '-B', str(OUT / 'run_matrix_module.py'),
               str(OUT / (stage + '-counts.json'))]
stop = threading.Event()
violations = []
minimum_headroom = resources_before['memory_headroom']
peak_allocated = resources_before['execution_allocated']


def monitor():
    global minimum_headroom, peak_allocated
    while not stop.wait(0.5):
        value = observation()
        minimum_headroom = min(minimum_headroom, value['memory_headroom'])
        peak_allocated = max(peak_allocated, value['execution_allocated'])
        if (value['memory_headroom'] < 600 * 1024 * 1024 or
                value['workspace_free'] < 64 * 1024 * 1024 or
                value['execution_allocated'] > 32 * 1024 * 1024):
            violations.append(value)
            os.kill(os.getpid(), signal.SIGINT)
            return


thread = threading.Thread(target=monitor, daemon=True)
thread.start()
try:
    result = process.run(command, cwd=ROOT, env=env,
                         log=OUT / (stage + '.raw'), timeout=900, stage=stage)
finally:
    stop.set()
    thread.join()
after = snapshot()
record = {'schema': 1, 'stage': stage, 'command': command,
          'returncode': result.returncode,
          'receipt': str(result.receipt_path),
          'sources_and_index_stable': before == after,
          'before': before, 'after': after,
          'resources_before': resources_before, 'resources_after': observation(),
          'explicit_child_path_prefix': '/workspace/nexus-build-system-20261012/.venv/bin',
          'cmake_path': shutil.which('cmake', path=env['PATH']),
          'ninja_path': shutil.which('ninja', path=env['PATH']),
          'sampled_minimum_headroom': minimum_headroom,
          'sampled_peak_execution_allocated': peak_allocated,
          'resource_violations': violations,
          'max_completed_child_rss_kib': resource.getrusage(
              resource.RUSAGE_CHILDREN).ru_maxrss}
report.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'stage': stage, 'actual_returncode': result.returncode,
                  'sources_and_index_stable': before == after,
                  'report': str(report), 'violations': len(violations)}))
sys.exit(result.returncode if not violations and before == after else 127)
