import json
from pathlib import Path
import sys
import unittest

ROOT = Path('/tmp/nexus-h743-fixed-hsi-s0-20261018')
sys.path.insert(0, str(ROOT / 'tools/configure'))
tests = unittest.defaultTestLoader.loadTestsFromName('test_matrix')
expected = tests.countTestCases()
result = unittest.TextTestRunner(verbosity=2).run(tests)
record = {'discovered': expected, 'executed': result.testsRun,
          'failures': len(result.failures), 'errors': len(result.errors),
          'skipped': len(result.skipped),
          'expected_failures': len(result.expectedFailures),
          'unexpected_successes': len(result.unexpectedSuccesses),
          'failure_details': [(test.id(), trace) for test, trace in result.failures],
          'error_details': [(test.id(), trace) for test, trace in result.errors]}
Path(sys.argv[1]).write_text(json.dumps(record, indent=2) + '\n')
sys.exit(0 if expected > 0 and result.testsRun == expected and
         result.wasSuccessful() and not result.skipped and
         not result.expectedFailures else 1)
