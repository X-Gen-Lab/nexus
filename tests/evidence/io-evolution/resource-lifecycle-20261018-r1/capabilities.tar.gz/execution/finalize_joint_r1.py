from pathlib import Path
import hashlib,json,os,stat,sys
F=Path('/dev/shm/nexus-h743-runtime-power-capabilities-20261018-r1');O=Path('/dev/shm/nexus-h743-runtime-power-capabilities-gettext-20261018-r1');R=Path('/tmp/nexus-io-validation-20261018')
sys.path.insert(0,str(R))
from tools.documentation import sphinx_ext

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b)
def save(p,v):write(p,(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
meta=json.loads((F/'candidate-two-catalogs-r1.json').read_text());pot=Path(meta['pot']);required=tuple(sphinx_ext.read_catalog(pot)[1]);assert len(required)==487
rows=[];delta=[]
page='docs/delivery/capabilities.md';src=F/'joint-before'/page;dst=F/'files'/page;write(dst,src.read_bytes());rows.append({'path':page,'durable_source':str(dst),'bytes':dst.stat().st_size,'sha256':sha(dst),'mode':stat.S_IMODE((R/page).stat().st_mode),'origin':'Read-only exact mirror of Root-maintained joint Main generated page; no authored rewrite'})
for row in meta['catalogs']:
 p=Path(row['candidate']);assert sha(p)==row['sha256'];old=p.read_bytes();needle=b'"X-Nexus-Reviewed: false\\n"';assert old.count(needle)==1
 new=old.replace(needle,b'"X-Nexus-Reviewed: true\\n"');dst=F/'files'/row['path'];write(dst,new)
 assert dst.read_bytes().replace(b'"X-Nexus-Reviewed: true\\n"',needle)==old
 rows.append({'path':row['path'],'durable_source':str(dst),'bytes':dst.stat().st_size,'sha256':sha(dst),'mode':stat.S_IMODE((R/row['path']).stat().st_mode),'origin':'Full catalog merged from actual single-page POT; independent-approved metadata-only false-to-true after exact false candidate review'})
 delta.append({'path':row['path'],'before_false_sha256':sha(p),'after_true_sha256':sha(dst),'only_change':'X-Nexus-Reviewed: false -> true','source_sha256_unchanged':meta['source_sha256'],'msgpairs_unchanged':True})
source=(F/'files'/page).read_text();gate=[]
for lang in ['en','zh_CN']:
 value=sphinx_ext.translation_status(source,'delivery/capabilities',lang,F/'files/docs/locale',required)
 assert value['status']=='reviewed',value;gate.append(value)
save(F/'reviewed-metadata-only-delta-r1.json',delta)
save(F/'final-three-source-map-r1.json',{'source_count':3,'scope':'Derived Main joint capabilities and complete EN/ZH catalogs; no Main or author-root mutation by docs worker','source_sha256':meta['source_sha256'],'pot_sha256':meta['pot_sha256'],'sources':rows,'maintained_page_translation_status':gate,'independent_review':'d3_translation_review exact false candidates PASS; formal report follows as separate immutable control','qualification':'source projection and reviewed translations only; no ARM/SDK/HIL qualification'})
print(json.dumps({'sources':rows,'maintained_page_translation_status':gate},ensure_ascii=False,indent=2))
