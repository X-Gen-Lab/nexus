from pathlib import Path
from decimal import Decimal
import gzip,hashlib,io,json,os,stat,tarfile,time
F=Path('/dev/shm/nexus-h743-runtime-power-capabilities-20261018-r1');O=Path('/dev/shm/nexus-h743-runtime-power-capabilities-gettext-20261018-r1');C=Path('/dev/shm/nexus-root-maintained-command-evidence-20261018-r1')
review=Path('/dev/shm/nexus-io30-g474-capabilities-two-catalogs-independent-review-20261018-r1.json');freeze=Path('/dev/shm/nexus-resource-lifecycle-joint-integration-20261018-r1/pre-cap-POT-working-freeze.json')

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  for data in iter(lambda:s.read(65536),b''):h.update(data)
 return h.hexdigest()
def meta(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink()
 return {'bytes':s.st_size,'sha256':sha(p),'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns}
def save(p,v):assert not p.exists();p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
selected={}
for p in sorted(O.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(O)
 if any(part in {'doctrees','gettext','tmp'} for part in rel.parts):continue
 selected['execution/'+rel.as_posix()]=p
pot=O/'gettext/delivery/capabilities.pot';selected['gettext/delivery/capabilities.pot']=pot
for p in sorted(F.glob('*.json')):selected['controls/'+p.name]=p
for stage in ['red','write','green']:
 base=C/('joint-capabilities-'+stage+'-r1')
 for p in sorted(base.rglob('*')):
  if p.is_file():selected['root-maintained-capabilities-'+stage+'/'+p.relative_to(base).as_posix()]=p
selected['independent-review/'+review.name]=review;selected['main-freeze/'+freeze.name]=freeze
rows=[{'member':name,'origin':str(p),**meta(p)} for name,p in selected.items()]
assert len(rows)==len(set(r['member'] for r in rows))
manifest={'scope':'Unique full original command/stdout/stderr/receipt + fresh single-page POT + same-input API proof + merge/gate/review controls. No product source copies, source before/index files, doctrees, API XML, HTML, SDK or firmware archives.','members':rows,'member_count':len(rows),'raw_bytes':sum(r['bytes'] for r in rows)}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();save(F/'raw-members-r1.json',manifest)
archive=F/'joint-capabilities-original-raw-r1.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as t:
 for row in rows:
  p=selected[row['member']];assert meta(p)=={k:row[k] for k in ['bytes','sha256','mode','uid','gid','mtime_ns']}
  info=t.gettarinfo(str(p),arcname=row['member']);sec,ns=divmod(row['mtime_ns'],1000000000);info.pax_headers['mtime']='%d.%09d'%(sec,ns)
  with p.open('rb') as s:t.addfile(info,s)
 info=tarfile.TarInfo('members.json');info.size=len(manifest_bytes);info.mode=0o600;info.mtime=int(time.time());t.addfile(info,io.BytesIO(manifest_bytes))
with gzip.open(archive,'rb') as s:
 while s.read(65536):pass
expected={row['member']:row for row in rows};seen=set()
with tarfile.open(archive,'r:gz') as t:
 for info in t:
  assert info.isfile() and info.name not in seen;seen.add(info.name)
  with t.extractfile(info) as s:data=s.read()
  if info.name=='members.json':assert data==manifest_bytes;continue
  row=expected[info.name];assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];assert info.mode==row['mode'] and info.uid==row['uid'] and info.gid==row['gid'];assert int(Decimal(info.pax_headers['mtime'])*1000000000)==row['mtime_ns']
assert seen==set(expected)|{'members.json'}
for row in rows:assert meta(selected[row['member']])=={k:row[k] for k in ['bytes','sha256','mode','uid','gid','mtime_ns']}
result={'status':'sealed_and_full_verified','archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'member_manifest':str(F/'raw-members-r1.json'),'member_manifest_sha256':sha(F/'raw-members-r1.json'),'original_members':len(rows),'archive_members':len(rows)+1,'all_member_sha_size_mode_uid_gid_nsmtime_verified':True,'gzip_crc_eof_verified':True,'all_original_bytes_and_recorded_metadata_unchanged':True,'archive_code_execution':False,'persistence':'execshm volatile; becomes durable only through Root normal commit/push','qualification':'Current dirty source page extraction/translation only, not clean release docs, SDK, ARM or HIL'}
save(F/'raw-seal-r1.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
