from pathlib import Path
from collections import Counter
import hashlib,json,sys
import polib
R=Path('/tmp/nexus-io-validation-20261018');F=Path('/dev/shm/nexus-h743-runtime-power-capabilities-20261018-r1');O=Path('/dev/shm/nexus-h743-runtime-power-capabilities-gettext-20261018-r1')
sys.path.insert(0,str(R))
from tools.documentation import sphinx_ext

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def key(e):return (e.msgctxt,e.msgid,e.msgid_plural,e.msgstr,tuple(sorted(e.msgstr_plural.items())))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
assert polib.__version__=='1.2.0'
source=F/'joint-before/docs/delivery/capabilities.md';source_sha=sha(source)
assert source_sha=='0b67fb758a6d341c3ed78fef68b080ddf6e030dbab0bc6eecb10726750507298' and sha(R/'docs/delivery/capabilities.md')==source_sha
pot_path=O/'gettext/delivery/capabilities.pot';assert sha(pot_path)=='069db568e411a7ed6e76283566a7fd8f9cbec4e8e303d27e672760a871e46036'
pot=polib.pofile(pot_path);required=[e.msgid for e in pot if not e.obsolete];assert len(set(required))==len(required)==487
records=[]
for lang in ['en','zh_CN']:
 rel='docs/locale/'+lang+'/LC_MESSAGES/delivery/capabilities.po';before=F/'joint-before'/rel;old=polib.pofile(before);prior=Counter(key(e) for e in old);oldactive={e.msgid:e.msgstr for e in old if not e.obsolete}
 po=polib.pofile(before);po.merge(pot);new=[]
 for e in po:
  if not e.obsolete and e.msgid not in oldactive:
   assert e.msgid.startswith('`tools/configure/assemblies/h743-spi-dma-runtime-clock.toml`, ')
   assert all((R/value).is_file() for value in e.msgid.split('`')[1::2])
   e.msgstr=e.msgid;e.flags=[v for v in e.flags if v!='fuzzy'];new.append({'msgid':e.msgid,'msgstr':e.msgstr})
 assert len(new)==1
 po.metadata['X-Nexus-Source-SHA256']=source_sha;po.metadata['X-Nexus-Reviewed']='false';po.metadata['Language']=lang
 assert not (prior-Counter(key(e) for e in po))
 active=[e for e in po if not e.obsolete];assert len(active)==487 and {e.msgid for e in active}==set(required);assert all(e.msgstr and 'fuzzy' not in e.flags for e in active)
 for e in active:
  if e.msgid in oldactive:assert e.msgstr==oldactive[e.msgid]
 dst=F/'candidates-false'/rel;dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();po.save(dst)
 meta,msgs,fuzzy=sphinx_ext.read_catalog(dst);assert set(msgs)==set(required) and len(msgs)==487 and all(msgs.values()) and not fuzzy;assert meta['X-Nexus-Reviewed']=='false' and meta['Language']==lang and meta['X-Nexus-Source-SHA256']==source_sha
 records.append({'path':rel,'candidate':str(dst),'bytes':dst.stat().st_size,'sha256':sha(dst),'before':str(before),'before_sha256':sha(before),'active_count':487,'reused_active_pairs':486,'all_old_including_obsolete_pairs_preserved':True,'old_total_pair_count':sum(prior.values()),'new_messages':new,'obsolete_additions':[e.msgid for e in po if e.obsolete and e.msgid in oldactive]})
report={'status':'false_candidates_ready_for_independent_review','canonical_source':str(source),'source_sha256':source_sha,'pot':str(pot_path),'pot_sha256':sha(pot_path),'required_messages':487,'polib_version':polib.__version__,'catalogs':records,'main_source_modified':False,'authority':'Actual maintained joint Main derived page; one new literal fixture-list message per language; all G4 pairs retained'}
save(F/'candidate-two-catalogs-r1.json',report);print(json.dumps(report,ensure_ascii=False,indent=2))
