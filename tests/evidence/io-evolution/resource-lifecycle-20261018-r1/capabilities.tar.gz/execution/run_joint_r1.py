from pathlib import Path
import hashlib,json,os,re,resource,shlex,signal,sys,threading,time
R=Path('/tmp/nexus-io-validation-20261018')
G=Path('/tmp/nexus-h743-spi-safe-stop-20261018')
O=Path('/dev/shm/nexus-h743-runtime-power-capabilities-gettext-20261018-r1')
F=Path('/dev/shm/nexus-h743-runtime-power-capabilities-20261018-r1')
P=Path('/tmp/nexus-recovery-docs-tools-20261018-r1')
XML=Path('/dev/shm/nexus-g474-pin-state-docs-validation-20261018-r1/documentation-attempts/450f1a05cd2e4d409dec7a0fdcabf37f/api/xml')
FREEZE=Path('/dev/shm/nexus-resource-lifecycle-joint-integration-20261018-r1/pre-cap-POT-working-freeze.json')
CAP=32*1024*1024
sys.path.insert(0,str(R))
from tools.dev import process
from tools.evidence.identity import observe_git_source
from tools.documentation import install,sphinx_ext

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  for b in iter(lambda:s.read(65536),b''):h.update(b)
 return h.hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def allocated(p):return sum(x.lstat().st_blocks*512 for x in p.rglob('*'))+p.lstat().st_blocks*512

def metrics():
 c=Path('/sys/fs/cgroup');e=dict(x.split() for x in (c/'memory.events').read_text().splitlines())
 return {'headroom':int((c/'memory.max').read_text())-int((c/'memory.current').read_text()),'workspace_free':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize,'tmp_free':os.statvfs('/tmp').f_bavail*os.statvfs('/tmp').f_frsize,'output_allocated':allocated(O),'events':e}
def guard(spawn=False):
 m=metrics();assert m['headroom']>=(900 if spawn else 600)*1024*1024,m
 assert m['workspace_free']>=64*1024*1024 and m['tmp_free']>=200*1024*1024,m
 assert m['output_allocated']<=CAP,m
 assert int(m['events']['oom'])==0 and int(m['events']['oom_kill'])==0,m
 return m

def inputs(root):
 text=(root/'Doxyfile').read_text();m=re.search(r'^INPUT\s*=\s*(.+)$',text,re.M);assert m
 assert re.search(r'^FILE_PATTERNS\s*=\s*\*\.h\s*$',text,re.M)
 assert re.search(r'^RECURSIVE\s*=\s*YES\s*$',text,re.M)
 rows={}
 for rel in shlex.split(m.group(1)):
  base=root/rel;assert base.is_dir() and not base.is_symlink(),str(base)
  for p in sorted(base.rglob('*.h')):
   path=p.relative_to(root).as_posix()
   if any(part in {'private','vendors','build'} for part in p.relative_to(root).parts):continue
   assert p.is_file() and not p.is_symlink(),path
   rows[path]={'bytes':p.stat().st_size,'sha256':sha(p)}
 return rows
record={'status':'running','scope':'read-only actual joint Main specific-file capabilities gettext; verified same-public-input G4 API XML reuse, not fresh Doxygen; dirty development docs only','resource_cap':CAP,'resources_before':guard(True),'freeze_sha256':sha(FREEZE),'source_before':observe_git_source(R),'index_sha256_before':sha(R/'.git/index')}
save(O/'joint-extraction-result-r1.json',record)
try:
 frozen=json.loads(FREEZE.read_text());assert record['freeze_sha256']=='423af91f10e4ddd2cfe9903dfb5fea8fd522c089c2b90d5481493680a37e4fbd'
 for row in frozen['files']:
  p=R/row['path'];assert p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
 assert sha(R/'Doxyfile')==sha(G/'Doxyfile')
 current,prior=inputs(R),inputs(G);assert current==prior
 assert XML.is_dir() and (XML/'index.xml').is_file() and (XML/'pin__state_8h.xml').is_file()
 api={'source_root':str(R),'prior_public_input_root':str(G),'xml':str(XML),'doxyfile_sha256':sha(R/'Doxyfile'),'input_headers':current,'same_relative_header_set_and_bytes':True,'generation_receipt':str(Path('/dev/shm/nexus-g474-pin-state-docs-validation-20261018-r1/site-r2/documentation-build.json')),'generation_receipt_sha256':sha(Path('/dev/shm/nexus-g474-pin-state-docs-validation-20261018-r1/site-r2/documentation-build.json'))}
 save(O/'api-same-input-reuse-r1.json',api);record['api_reuse_manifest_sha256']=sha(O/'api-same-input-reuse-r1.json')
 before=[]
 for rel in ['docs/delivery/capabilities.md','docs/locale/en/LC_MESSAGES/delivery/capabilities.po','docs/locale/zh_CN/LC_MESSAGES/delivery/capabilities.po']:
  p=R/rel;dst=F/'joint-before'/rel;dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();dst.write_bytes(p.read_bytes());before.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p),'copy':str(dst)})
 save(F/'joint-before3-r1.json',before)
 env=install.environment(P)
 for k in tuple(env):
  if k.startswith('NEXUS_DOCS_'):env.pop(k)
 (O/'tmp').mkdir(exist_ok=True)
 env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',NEXUS_DOCS_TOOL_PREFIX=str(P),NEXUS_DOCS_REVISION=record['source_before']['commit'],NEXUS_DOCS_CODE_REVISION=record['source_before']['commit'],NEXUS_DOCS_VERSION=json.loads((R/'dependencies/platform-compatibility.json').read_text())['semantic_version'],NEXUS_DOCS_LANGUAGE='en',NEXUS_DOCS_LANGUAGES='en,zh_CN',NEXUS_DOCS_DOXYGEN_XML=str(XML),NEXUS_DOCS_GETTEXT_ROOT=str(O/'gettext'),NEXUS_DOCS_TRANSLATION_ROOT=str(R/'docs/locale'),TMPDIR=str(O/'tmp'))
 argv=[str(P/'venv/bin/python'),'-B','-m','sphinx','-E','-n','-W','--keep-going','-j','1','-b','gettext','-c',str(R/'docs/sphinx'),'-d',str(O/'doctrees'),str(R/'docs'),str(O/'gettext'),str(R/'docs/delivery/capabilities.md')]
 record['argv']=argv;record['environment']={k:v for k,v in env.items() if k.startswith('NEXUS_DOCS_')};record['phase_resources_before']=guard(True)
 save(O/'joint-extraction-result-r1.json',record)
 stop=threading.Event();violations=[];minimum=record['phase_resources_before'].copy();maximum={'output_allocated':minimum['output_allocated']}
 def monitor():
  while not stop.wait(.5):
   try:
    m=guard()
    for key in ['headroom','workspace_free','tmp_free']:minimum[key]=min(minimum[key],m[key])
    maximum['output_allocated']=max(maximum['output_allocated'],m['output_allocated'])
   except BaseException as e:violations.append(repr(e));os.kill(os.getpid(),signal.SIGTERM);return
 thread=threading.Thread(target=monitor,daemon=True);thread.start();start=time.monotonic()
 try:result=process.run(argv,cwd=R,env=env,log=O/'joint-gettext-r1.raw',stage='io30-g4-joint-capabilities-specific-gettext-r1',timeout=600)
 finally:stop.set();thread.join()
 record.update(actual_returncode=result.returncode,receipt=str(result.receipt_path),elapsed_seconds=time.monotonic()-start,sampled_minimum={k:minimum[k] for k in ['headroom','workspace_free','tmp_free']},sampled_maximum=maximum,resource_violations=violations,completed_children_maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
 record['source_after']=observe_git_source(R);record['index_sha256_after']=sha(R/'.git/index');assert record['source_before']==record['source_after'];assert record['index_sha256_before']==record['index_sha256_after'];assert result.returncode==0 and not violations
 pot=O/'gettext/delivery/capabilities.pot';meta,msgs,fuzzy=sphinx_ext.read_catalog(pot)
 record.update(status='passed',pot=str(pot),pot_sha256=sha(pot),required_messages=len(msgs),pot_template_fuzzy=fuzzy,source_sha256=sha(R/'docs/delivery/capabilities.md'),resources_after=guard())
 save(O/'joint-extraction-result-r1.json',record);print(json.dumps(record,ensure_ascii=False,indent=2))
except BaseException as e:
 record.update(status='failed',error=repr(e),source_after_observed=observe_git_source(R),index_sha256_after_observed=sha(R/'.git/index'),resources_after=metrics())
 save(O/'joint-extraction-result-r1.json',record);raise
