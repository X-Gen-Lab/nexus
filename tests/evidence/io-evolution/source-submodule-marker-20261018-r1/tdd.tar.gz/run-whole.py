from pathlib import Path
import hashlib,json,os,resource,shutil,sys,time
R=Path('/dev/shm/nexus-qualification-transport-20261018-r1')
F=Path('/dev/shm/nexus-source-submodule-marker-fix-20261018-r1')
sys.path.insert(0,str(R))
from tools.dev import process
name=sys.argv[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def state():
 return {'ns':time.time_ns(),'two_sources':{r:sha(R/r) for r in ('tools/evidence/identity.py','tools/testing/test_source_observation_dirty.py')},'index':sha(R/'.git/index'),'WIP8':{r['path']:sha(Path(r['path'])) for r in json.loads((F/'before.json').read_bytes())['unchanged_WIP8']},'memory_current':int(Path('/sys/fs/cgroup/memory.current').read_text()),'memory_events':Path('/sys/fs/cgroup/memory.events').read_text()}
before=state();assert int(Path('/sys/fs/cgroup/memory.max').read_text())-before['memory_current']>=900*1024**2
assert all(int(line.split()[1])==0 for line in before['memory_events'].splitlines() if line.split()[0] in ('oom','oom_kill','oom_group_kill'))
assert shutil.disk_usage('/workspace').free>=64*1024**2
assert shutil.disk_usage('/tmp').free>=200*1024**2
T=F/'temporary';T.mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(R),TMPDIR=str(T),NEXUS_BUILD_JOBS='1',PATH='/workspace/nexus-build-system-20261012/.venv/bin:/usr/bin:/bin')
cmd=['/workspace/nexus-build-system-20261012/.venv/bin/python','-B','-m','unittest','tools.testing.test_source_observation_dirty','-v']
result=process.run(cmd,cwd=R,env=env,log=F/(name+'.raw'),timeout=180,stage=name)
after=state();record={'before':before,'after':after,'actual_exit':result.returncode,'maxrss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'sources_unchanged':before['two_sources']==after['two_sources'],'index_unchanged':before['index']==after['index'],'WIP8_unchanged':before['WIP8']==after['WIP8']}
(F/(name+'-guard.json')).write_text(json.dumps(record,indent=2)+'\n')
assert record['sources_unchanged'] and record['index_unchanged'] and record['WIP8_unchanged']
print(json.dumps({'actual_exit':result.returncode,'guard':str(F/(name+'-guard.json')),'stderr_tail':result.stderr[-3400:]}))
raise SystemExit(result.returncode)
