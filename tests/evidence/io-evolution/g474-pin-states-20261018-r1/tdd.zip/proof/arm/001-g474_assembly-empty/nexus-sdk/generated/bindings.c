/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#ifndef NX_PLATFORM_REGISTER_WRITE
#define NX_PLATFORM_REGISTER_WRITE(reg, value) ((reg) = (uint32_t)(value))
#endif
#ifndef NX_PLATFORM_PRIORITY_WRITE
#define NX_PLATFORM_PRIORITY_WRITE(reg, value) ((reg) = (uint8_t)(value))
#endif
#include "stm32g474_provider.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started) {
        nx_result_t system = nx_stm32g474_system_stop(&g_nx_stm32g474_system, 1000000u);
        if (system != NX_SUCCESS) { return system; }
    }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_stm32g474_system_preflight(&g_nx_stm32g474_system);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32g474_validate_identity();
    if (result.primary != NX_SUCCESS) { return result; }
    nx_stm32g474_start_result_t system = nx_stm32g474_system_start(&g_nx_stm32g474_system, 1000000u);
    if (system.primary != NX_SUCCESS) {
        result.primary = system.primary;
        result.cleanup = system.cleanup;
        result.remaining_effects = system.remaining_effects;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
