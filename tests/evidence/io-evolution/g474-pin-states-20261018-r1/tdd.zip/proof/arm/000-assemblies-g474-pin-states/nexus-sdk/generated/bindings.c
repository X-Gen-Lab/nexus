/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#ifndef NX_PLATFORM_REGISTER_WRITE
#define NX_PLATFORM_REGISTER_WRITE(reg, value) ((reg) = (uint32_t)(value))
#endif
#ifndef NX_PLATFORM_PRIORITY_WRITE
#define NX_PLATFORM_PRIORITY_WRITE(reg, value) ((reg) = (uint8_t)(value))
#endif
#include "stm32g474_provider.h"
#include "stm32g474_pin_state.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static nx_stm32g474_pin_state_t s_nx_port_status;
static const nx_pin_state_port_t s_nx_face_status = {
    &nx_stm32g474_pin_state_ops, &s_nx_port_status
};
const nx_pin_state_port_t* const nx_binding_status = &s_nx_face_status;
static const nx_pin_state_plan_t s_nx_pin_plan_status = {
    .pins = 32u, .states = {
        { 1024u, 0u, 0u, 0u, 0u },
        { 3072u, 0u, 0u, 0u, 0u },
    } };
static nx_result_t prepare_status(void) {
    if (s_nx_port_status.control.retained || s_nx_port_status.control.initialized) { return NX_ERROR_BUSY; }
    s_nx_port_status.gpio = GPIOA;
    s_nx_port_status.rcc = RCC;
    s_nx_port_status.bank_mask = RCC_AHB2ENR_GPIOAEN;
    s_nx_port_status.plan = &s_nx_pin_plan_status;
    return nx_stm32g474_pin_state_initialize(&s_nx_port_status);
}
static uint16_t s_nx_platform_pin_state[1u];
static bool s_nx_platform_pins_captured;
static uint32_t s_nx_platform_gpio_clocks_added;
static bool nx_platform_pin_bank_ready(GPIO_TypeDef* gpio) {
    if (gpio == GPIOA) {
        return (NX_G474_READ(&RCC->AHB2ENR) & RCC_AHB2ENR_GPIOAEN) != 0u &&
               (NX_G474_READ(&RCC->AHB2RSTR) & RCC_AHB2RSTR_GPIOARST) == 0u;
    }
    return false;
}
/** \brief A failed condition forbids the protected GPIO access. */
static nx_result_t nx_platform_pin_read(GPIO_TypeDef* gpio, volatile uint32_t* reg, uint32_t* value) {
    if (!nx_platform_pin_bank_ready(gpio)) { return NX_ERROR_STATE; }
    *value = NX_G474_READ(reg);
    return nx_platform_pin_bank_ready(gpio) ? NX_SUCCESS : NX_ERROR_STATE;
}
static nx_result_t nx_platform_pin_write(GPIO_TypeDef* gpio, volatile uint32_t* reg, uint32_t value) {
    if (!nx_platform_pin_bank_ready(gpio)) { return NX_ERROR_STATE; }
    NX_G474_WRITE(reg, value);
    nx_arch_dsb();
    return nx_platform_pin_bank_ready(gpio) ? NX_SUCCESS : NX_ERROR_STATE;
}
static nx_result_t nx_platform_pin_modify(GPIO_TypeDef* gpio, volatile uint32_t* reg, uint32_t mask, uint32_t value) {
    uint32_t old;
    nx_result_t status = nx_platform_pin_read(gpio, reg, &old);
    if (status != NX_SUCCESS) { return status; }
    status = nx_platform_pin_write(gpio, reg, (old & ~mask) | (value & mask));
    if (status != NX_SUCCESS) { return status; }
    status = nx_platform_pin_read(gpio, reg, &old);
    if (status != NX_SUCCESS) { return status; }
    return (old & mask) == (value & mask) ? NX_SUCCESS : NX_ERROR_IO;
}
static nx_result_t nx_platform_pin_capture_checked(GPIO_TypeDef* gpio, unsigned pin, uint16_t* saved) {
    uint32_t value, state = 0u;
    nx_result_t status;
    status = nx_platform_pin_read(gpio, &gpio->MODER, &value);
    if (status != NX_SUCCESS) { return status; }
    state |= ((value >> (pin * 2u)) & 3u) << 0u;
    status = nx_platform_pin_read(gpio, &gpio->OTYPER, &value);
    if (status != NX_SUCCESS) { return status; }
    state |= ((value >> (pin)) & 1u) << 2u;
    status = nx_platform_pin_read(gpio, &gpio->OSPEEDR, &value);
    if (status != NX_SUCCESS) { return status; }
    state |= ((value >> (pin * 2u)) & 3u) << 3u;
    status = nx_platform_pin_read(gpio, &gpio->PUPDR, &value);
    if (status != NX_SUCCESS) { return status; }
    state |= ((value >> (pin * 2u)) & 3u) << 5u;
    status = nx_platform_pin_read(gpio, &gpio->AFR[pin / 8u], &value);
    if (status != NX_SUCCESS) { return status; }
    state |= ((value >> ((pin % 8u) * 4u)) & 15u) << 7u;
    status = nx_platform_pin_read(gpio, &gpio->ODR, &value);
    if (status != NX_SUCCESS) { return status; }
    state |= ((value >> (pin)) & 1u) << 11u;
    *saved = (uint16_t)state;
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pin_restore_checked(GPIO_TypeDef* gpio, unsigned pin, uint16_t state) {
    uint32_t bit = 1u << pin, value;
    nx_result_t status = nx_platform_pin_write(gpio, &gpio->BSRR, (state & (1u << 11u)) != 0u ? bit : bit << 16u);
    if (status != NX_SUCCESS) { return status; }
    status = nx_platform_pin_read(gpio, &gpio->ODR, &value);
    if (status != NX_SUCCESS) { return status; }
    if ((value & bit) != (((uint32_t)state >> 11u & 1u) << pin)) { return NX_ERROR_IO; }
    status = nx_platform_pin_modify(gpio, &gpio->AFR[pin / 8u], 15u << ((pin % 8u) * 4u), ((uint32_t)state >> 7u & 15u) << ((pin % 8u) * 4u));
    if (status != NX_SUCCESS) { return status; }
    status = nx_platform_pin_modify(gpio, &gpio->OTYPER, bit, ((uint32_t)state >> 2u & 1u) << pin);
    if (status != NX_SUCCESS) { return status; }
    status = nx_platform_pin_modify(gpio, &gpio->OSPEEDR, 3u << (pin * 2u), ((uint32_t)state >> 3u & 3u) << (pin * 2u));
    if (status != NX_SUCCESS) { return status; }
    status = nx_platform_pin_modify(gpio, &gpio->PUPDR, 3u << (pin * 2u), ((uint32_t)state >> 5u & 3u) << (pin * 2u));
    if (status != NX_SUCCESS) { return status; }
    status = nx_platform_pin_modify(gpio, &gpio->MODER, 3u << (pin * 2u), ((uint32_t)state & 3u) << (pin * 2u));
    if (status != NX_SUCCESS) { return status; }
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pins_admit_inner(bool powered_only) {
    uint32_t value; nx_result_t status;
    if ((NX_G474_READ(&RCC->AHB2RSTR) & RCC_AHB2RSTR_GPIOARST) != 0u) { return NX_ERROR_BUSY; }
    if (!powered_only || (NX_G474_READ(&RCC->AHB2ENR) & RCC_AHB2ENR_GPIOAEN) != 0u) {
        status = nx_platform_pin_read(GPIOA, &GPIOA->MODER, &value);
        if (status != NX_SUCCESS) { return status; }
        if (((value >> 10u) & 3u) != 0u && ((value >> 10u) & 3u) != 3u) { return NX_ERROR_BUSY; }
        status = nx_platform_pin_read(GPIOA, &GPIOA->LCKR, &value);
        if (status != NX_SUCCESS) { return status; }
        if ((value & 32u) != 0u) { return NX_ERROR_BUSY; }
    }
    return NX_SUCCESS;
}
static nx_result_t nx_platform_gpio_clocks_release_inner(void) {
    if (s_nx_platform_gpio_clocks_added != 0u) {
        NX_G474_WRITE(&RCC->AHB2ENR, NX_G474_READ(&RCC->AHB2ENR) & ~s_nx_platform_gpio_clocks_added);
        nx_arch_dsb();
        if ((NX_G474_READ(&RCC->AHB2ENR) & s_nx_platform_gpio_clocks_added) != 0u) { return NX_ERROR_IO; }
        s_nx_platform_gpio_clocks_added = 0u;
    }
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pins_acquire_inner(void) {
    if (s_nx_platform_pins_captured || s_nx_platform_gpio_clocks_added != 0u) { return NX_ERROR_STATE; }
    s_nx_platform_gpio_clocks_added = ~NX_G474_READ(&RCC->AHB2ENR) & (RCC_AHB2ENR_GPIOAEN);
    if (s_nx_platform_gpio_clocks_added != 0u) {
        NX_G474_WRITE(&RCC->AHB2ENR, NX_G474_READ(&RCC->AHB2ENR) | (RCC_AHB2ENR_GPIOAEN));
        nx_arch_dsb();
    }
    if ((NX_G474_READ(&RCC->AHB2ENR) & (RCC_AHB2ENR_GPIOAEN)) != (RCC_AHB2ENR_GPIOAEN)) { return NX_ERROR_IO; }
    nx_result_t status = nx_platform_pins_admit_inner(false);
    if (status != NX_SUCCESS) { return status; }
    status = nx_platform_pin_capture_checked(GPIOA, 5u, &s_nx_platform_pin_state[0u]);
    if (status != NX_SUCCESS) { return status; }
    s_nx_platform_pins_captured = true;
    return NX_SUCCESS;
}
static nx_result_t nx_platform_pins_release_inner(void) {
    if (s_nx_platform_pins_captured) {
        nx_result_t status; uint16_t current;
        status = nx_platform_pin_modify(GPIOA, &GPIOA->MODER, 3072u, 3072u);
        if (status != NX_SUCCESS) { return status; }
        status = nx_platform_pin_capture_checked(GPIOA, 5u, &current);
        if (status != NX_SUCCESS) { return status; }
        if (current != s_nx_platform_pin_state[0u]) {
            status = nx_platform_pin_restore_checked(GPIOA, 5u, s_nx_platform_pin_state[0u]);
            if (status != NX_SUCCESS) { return status; }
            status = nx_platform_pin_capture_checked(GPIOA, 5u, &current);
            if (status != NX_SUCCESS) { return status; }
            if (current != s_nx_platform_pin_state[0u]) { return NX_ERROR_IO; }
        }
        if (!nx_platform_pin_bank_ready(GPIOA)) { return NX_ERROR_STATE; }
        s_nx_platform_pins_captured = false;
    }
    return nx_platform_gpio_clocks_release_inner();
}
static nx_result_t nx_platform_pins_admit(bool powered_only) {
    nx_arch_irq_state_t previous = nx_arch_irq_save();
    nx_result_t status = nx_platform_pins_admit_inner(powered_only);
    nx_arch_irq_restore(previous);
    return status;
}
static nx_result_t nx_platform_gpio_clocks_release(void) {
    nx_arch_irq_state_t previous = nx_arch_irq_save();
    nx_result_t status = nx_platform_gpio_clocks_release_inner();
    nx_arch_irq_restore(previous);
    return status;
}
static nx_result_t nx_platform_pins_acquire(void) {
    nx_arch_irq_state_t previous = nx_arch_irq_save();
    nx_result_t status = nx_platform_pins_acquire_inner();
    nx_arch_irq_restore(previous);
    return status;
}
static nx_result_t nx_platform_pins_release(void) {
    nx_arch_irq_state_t previous = nx_arch_irq_save();
    nx_result_t status = nx_platform_pins_release_inner();
    nx_arch_irq_restore(previous);
    return status;
}
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = nx_stm32g474_pin_state_stop(&s_nx_port_status);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_result_t pins = nx_platform_pins_release();
    if (pins != NX_SUCCESS) { return pins; }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started) {
        nx_result_t system = nx_stm32g474_system_stop(&g_nx_stm32g474_system, 1000000u);
        if (system != NX_SUCCESS) { return system; }
    }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_stm32g474_system_preflight(&g_nx_stm32g474_system);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_platform_pins_admit(true);
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_stm32g474_validate_identity();
    if (result.primary != NX_SUCCESS) { return result; }
    result.primary = nx_platform_pins_acquire();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_gpio_clocks_release();
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    nx_stm32g474_start_result_t system = nx_stm32g474_system_start(&g_nx_stm32g474_system, 1000000u);
    if (system.primary != NX_SUCCESS) {
        result.primary = system.primary;
        result.cleanup = system.cleanup;
        result.remaining_effects = system.remaining_effects;
        s_nx_platform_pins_captured = false;
        nx_result_t pins = nx_platform_gpio_clocks_release();
        if (pins != NX_SUCCESS) { result.cleanup = pins; result.remaining_effects = 1u; }
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = prepare_status();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pin_state_port_t* nx_factory_pin_state(nx_pin_state_id_t id) {
    switch (id) {
        case NX_PIN_STATE_ID_STATUS:
            return nx_binding_status;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
