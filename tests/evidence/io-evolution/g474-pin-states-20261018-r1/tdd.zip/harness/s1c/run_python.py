import sys,pathlib,unittest,json,xml.etree.ElementTree as ET,time,hashlib
R=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018');sys.path[:0]=[str(R),str(R/'tools/configure'),str(R/'.github/workflows'),str(R/'tests/contracts')]
module=sys.argv[1];out=pathlib.Path(sys.argv[2]);assert not out.exists();tests=unittest.defaultTestLoader.loadTestsFromName(module);expected=tests.countTestCases();assert expected>0
class Recorded(unittest.TextTestResult):
 def __init__(self,*a,**k):super().__init__(*a,**k);self.rows=[]
 def startTest(self,t):super().startTest(t);self.started=time.monotonic();self.row=ET.Element('testcase',name=t.id())
 def stopTest(self,t):self.row.set('time',str(time.monotonic()-self.started));self.rows.append(self.row);super().stopTest(t)
 def addFailure(self,t,e):super().addFailure(t,e);ET.SubElement(self.row,'failure').text=self._exc_info_to_string(e,t)
 def addError(self,t,e):super().addError(t,e);ET.SubElement(self.row,'error').text=self._exc_info_to_string(e,t)
 def addSubTest(self,t,sub,e):
  super().addSubTest(t,sub,e)
  if e:ET.SubElement(self.row,'failure',subtest=str(sub)).text=self._exc_info_to_string(e,t)
 def addSkip(self,t,reason):super().addSkip(t,reason);ET.SubElement(self.row,'skipped').text=reason
res=unittest.TextTestRunner(verbosity=2,resultclass=Recorded).run(tests);root=ET.Element('testsuite',name=module,tests=str(res.testsRun),failures=str(len(res.failures)),errors=str(len(res.errors)),skipped=str(len(res.skipped)));root.extend(res.rows);out.parent.mkdir(parents=True,exist_ok=True);ET.ElementTree(root).write(out,encoding='utf-8',xml_declaration=True)
record={'module':module,'discovered':expected,'executed':res.testsRun,'failures':len(res.failures),'errors':len(res.errors),'skipped':len(res.skipped),'xml':str(out),'xml_sha256':hashlib.sha256(out.read_bytes()).hexdigest()};print(json.dumps(record));sys.exit(0 if res.wasSuccessful() and res.testsRun==expected and not res.skipped and not res.expectedFailures else 1)
