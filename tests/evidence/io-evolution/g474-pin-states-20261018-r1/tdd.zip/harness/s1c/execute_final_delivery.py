import pathlib,json,sys,hashlib,subprocess,time
F=pathlib.Path('/dev/shm/nexus-g474-pin-state-s1c-feature-20261018-r1');B=pathlib.Path('/dev/shm/nexus-g474-pin-state-s1b-builds-20261018-r1');R=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018')
scope=json.loads((F/'final-source-scope.json').read_text())['scope']
def snapshot():return {rel:hashlib.sha256((R/rel).read_bytes()).hexdigest() for rel in scope}
before=snapshot();index=hashlib.sha256((R/'.git/index').read_bytes()).hexdigest();commands=[]
plans=[('debug',['nexus_pin_state_test','nexus_g474_pin_state_test','nexus_g474_pin_state_factory_test','nexus_g474_system_test','nexus_g474_provider_test','nexus_g474_factory_test']),('asan',['nexus_pin_state_test','nexus_g474_pin_state_test','nexus_g474_pin_state_factory_test'])]
exitcode=0
for profile,targets in plans:
 for action,inner in [('configure',['/tmp/nexus-io-validation-20261018/.venv/bin/cmake','--preset','native-'+profile,'-B',str(B/profile)]),('build',['/tmp/nexus-io-validation-20261018/.venv/bin/cmake','--build',str(B/profile),'--parallel','1','--target',*targets])]:
  command=[sys.executable,'-B',str(F/'run_stage.py'),'delivery-'+profile+'-'+action,*inner];start=time.monotonic();rc=subprocess.run(command).returncode;commands.append({'command':command,'actual_exit':rc,'elapsed_seconds':time.monotonic()-start})
  if rc:exitcode=rc;break
 if exitcode:break
 command=[sys.executable,'-B',str(F/'run_delivery_native_matrix.py'),profile,*targets];start=time.monotonic();rc=subprocess.run(command).returncode;commands.append({'command':command,'actual_exit':rc,'elapsed_seconds':time.monotonic()-start})
 if rc:exitcode=rc;break
if not exitcode:
 command=[sys.executable,'-B',str(F/'check_final_style.py')];rc=subprocess.run(command).returncode;commands.append({'command':command,'actual_exit':rc});exitcode=rc
record={'scope':'Exact70 final source/doc files and complete9 Google programs, not full staged repository gate or SDK/HIL','source_before':before,'source_after':snapshot(),'index_before':index,'index_after':hashlib.sha256((R/'.git/index').read_bytes()).hexdigest(),'commands':commands,'actual_exit':exitcode,'all_children_joined':True}
record['source_stable']=record['source_before']==record['source_after'];record['index_stable']=record['index_before']==record['index_after']
if not exitcode:
 matrices=[json.loads((B/('delivery-'+profile+'-matrix.json')).read_text()) for profile,_ in plans];record['programs']=sum(x['programs'] for x in matrices);record['actual_cases']=sum(x['cases'] for x in matrices);record['failures']=sum(x['failures'] for x in matrices);record['actual_discovery_sets_match_XML']=all(row['discovery_complete_set_matches_fresh_XML'] for matrix in matrices for row in matrix['rows']);assert record['actual_cases']==205 and record['programs']==9
out=B/'delivery-final70-native-style-result.json';assert not out.exists();out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record.get(k) for k in ('actual_exit','programs','actual_cases','failures','source_stable','index_stable')}));assert record['source_stable'] and record['index_stable'];sys.exit(exitcode)
