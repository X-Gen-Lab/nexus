import sys,pathlib,subprocess,json,hashlib,xml.etree.ElementTree as ET
F=pathlib.Path('/dev/shm/nexus-g474-pin-state-s1b-feature-20261018-r1');B=pathlib.Path('/dev/shm/nexus-g474-pin-state-s1b-builds-20261018-r1');profile=sys.argv[1];targets=sys.argv[2:];rows=[]
for target in targets:
 stage='delivery-'+profile+'-'+target;binary=B/profile/'bin'/target;h=hashlib.sha256(binary.read_bytes()).hexdigest()
 rc=subprocess.run([sys.executable,str(F/'run_stage.py'),stage+'-discovery',str(binary),'--gtest_list_tests']).returncode
 if rc:sys.exit(rc)
 rc=subprocess.run([sys.executable,str(F/'run_whole.py'),stage,profile,target]).returncode
 if rc:sys.exit(rc)
 names=set();suite=''
 for line in (B/'commands'/(stage+'-discovery.stdout')).read_text().splitlines():
  line=line.split('#',1)[0].rstrip()
  if not line:continue
  if line.startswith('  ') and suite:names.add(suite+line.strip())
  elif not line.startswith(' ') and line.endswith('.'):suite=line
 root=ET.parse(B/'xml'/(stage+'.xml')).getroot();actual={t.attrib['classname']+'.'+t.attrib['name'] for t in root.iter('testcase')};assert names==actual,(target,names^actual);assert h==hashlib.sha256(binary.read_bytes()).hexdigest()
 r=json.loads((B/'commands'/(stage+'-whole.json')).read_text());r['discovery_complete_set_matches_fresh_XML']=True;r['discovered_names']=sorted(names);rows.append(r)
report={'profile':profile,'programs':len(rows),'cases':sum(x['tests'] for x in rows),'failures':sum(x['failures'] for x in rows),'rows':rows};(B/('delivery-'+profile+'-matrix.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('profile','programs','cases','failures')}))
