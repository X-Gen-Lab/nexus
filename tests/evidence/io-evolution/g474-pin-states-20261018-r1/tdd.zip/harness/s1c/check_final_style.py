import pathlib,sys,json,hashlib
import author
R,F=author.R,author.F;B=author.B
sys.path[:0]=[str(R/'scripts/ci'),str(R/'scripts/tools')]
import comment_style,style_gate,format as formatting
author.guard();records=[];errors=[];tool='/tmp/nexus-io-validation-20261018/.venv/bin/clang-format'
_,version=formatting.check_tool(tool,R/'.clang-format');assert '14.0.6' in version
for rel in json.loads((F/'final-source-scope.json').read_text())['scope']:
 p=R/rel;b=p.read_bytes();r={'path':rel,'sha256':hashlib.sha256(b).hexdigest(),'text_errors':style_gate.check_text(p,rel)};errors.extend(r['text_errors'])
 if p.suffix in {'.h','.c','.cpp'}:
  r['format_matches']=formatting.formatted_source(p,tool,R/'.clang-format')==b;r['comments']=comment_style.inspect_source(rel,b)
  if not r['format_matches']:errors.append(rel+': format mismatch')
  if r['comments']['rules']:errors.append(rel+': '+str(r['comments']['rules']))
 records.append(r)
q=B/'delivery-focused-style70.json';assert not q.exists();q.write_text(json.dumps({'scope':'Direct maintained formatter/comment_style/check_text functions for approved70 unique source/doc files, including all untracked new files; not full staged-index gate','tool':version,'records':records,'errors':errors},indent=2)+'\n');print(json.dumps({'report':str(q),'files':len(records),'errors':errors}));author.guard();sys.exit(bool(errors))
