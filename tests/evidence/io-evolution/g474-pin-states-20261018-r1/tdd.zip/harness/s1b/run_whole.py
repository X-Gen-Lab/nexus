import pathlib,sys,subprocess,hashlib,json,gzip,xml.etree.ElementTree as ET
F=pathlib.Path('/dev/shm/nexus-g474-pin-state-s1b-feature-20261018-r1');B=pathlib.Path('/dev/shm/nexus-g474-pin-state-s1b-builds-20261018-r1');stage,profile,target=sys.argv[1:];binary=B/profile/'bin'/target;xml=B/'xml'/(stage+'.xml');xml.parent.mkdir(exist_ok=True);assert not xml.exists();before=hashlib.sha256(binary.read_bytes()).hexdigest()
rc=subprocess.run([sys.executable,str(F/'run_stage.py'),stage,str(binary),'--gtest_output=xml:'+str(xml)]).returncode
assert binary.exists();after=hashlib.sha256(binary.read_bytes()).hexdigest();assert before==after
retained=B/'retained';retained.mkdir(exist_ok=True);q=retained/(stage+'.elf.gz');assert not q.exists();raw=binary.read_bytes();q.write_bytes(gzip.compress(raw,mtime=0));assert hashlib.sha256(gzip.decompress(q.read_bytes())).hexdigest()==before
r={'stage':stage,'target':target,'profile':profile,'actual_exit':rc,'ELF':{'original':str(binary),'bytes':len(raw),'sha256':before,'gzip':str(q),'gzip_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'full_decompress_sha_matches':True},'xml':str(xml),'receipt':str(B/'commands'/(stage+'.json'))}
if xml.exists():
 x=ET.parse(xml).getroot();r['tests']=int(x.attrib['tests']);r['failures']=int(x.attrib.get('failures',0));r['errors']=int(x.attrib.get('errors',0));r['disabled']=int(x.attrib.get('disabled',0));r['skipped']=sum(len(z.findall('skipped')) for z in x.iter('testcase'));r['actual_case_count']=len(list(x.iter('testcase')));r['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest();assert r['tests']==r['actual_case_count'];assert r['skipped']==r['disabled']==0
(B/'commands'/(stage+'-whole.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(rc)
