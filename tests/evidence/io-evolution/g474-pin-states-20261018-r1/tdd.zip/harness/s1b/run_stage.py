import pathlib,os,sys,json,subprocess,resource,time,hashlib,importlib.util
F=pathlib.Path('/dev/shm/nexus-g474-pin-state-s1b-feature-20261018-r1');B=pathlib.Path('/dev/shm/nexus-g474-pin-state-s1b-builds-20261018-r1');R=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018')
spec=importlib.util.spec_from_file_location('author',F/'author.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
def allocation(p):
 seen=set();total=0
 if not p.exists():return 0
 for q in [p,*p.rglob('*')]:
  st=q.lstat();key=(st.st_dev,st.st_ino)
  if key not in seen:seen.add(key);total+=st.st_blocks*512
 return total
def obs():
 c=pathlib.Path('/sys/fs/cgroup');v={x:int((c/x).read_text()) for x in ('memory.current','memory.max')};v['headroom']=v['memory.max']-v['memory.current'];v['events']=(c/'memory.events').read_text();v['fs_free']={x:os.statvfs(x).f_bavail*os.statvfs(x).f_frsize for x in ('/workspace','/tmp','/dev/shm')};v['build_allocated']=allocation(B);v['feature_allocated']=allocation(F);return v
name=sys.argv[1];cmd=sys.argv[2:];a.guard();before=obs();assert before['headroom']>=943718400,before;assert before['fs_free']['/tmp']>=209715200,before;assert before['build_allocated']<201326592,before;assert 'oom 0\n' in before['events'] and 'oom_kill 0\n' in before['events']
B.mkdir(exist_ok=True);(B/'tmp').mkdir(exist_ok=True);D=B/'commands';D.mkdir(exist_ok=True);p=D/name;assert not p.with_suffix('.json').exists()
env=os.environ.copy();env['PATH']='/tmp/nexus-io-validation-20261018/.venv/bin:'+env['PATH'];env['TMPDIR']=str(B/'tmp');env['PYTHONDONTWRITEBYTECODE']='1';env['CMAKE_BUILD_PARALLEL_LEVEL']='1';env['CTEST_PARALLEL_LEVEL']='1'
for k in list(env):
 if k.startswith('GTEST_'):env.pop(k)
start=time.time();source_before={x:hashlib.sha256((R/x).read_bytes()).hexdigest() for x in a.ALLOWED if (R/x).exists()};ru=resource.getrusage(resource.RUSAGE_CHILDREN)
with p.with_suffix('.stdout').open('wb') as out,p.with_suffix('.stderr').open('wb') as err:
 child=subprocess.Popen(cmd,cwd=R,env=env,stdout=out,stderr=err);print(json.dumps({'stage':name,'pid':child.pid,'command':cmd,'before':before}),flush=True);rc=child.wait()
guard_after_error=None
try:a.guard()
except Exception as error:guard_after_error=type(error).__name__+': '+str(error)
after=obs();source_after={x:hashlib.sha256((R/x).read_bytes()).hexdigest() for x in a.ALLOWED if (R/x).exists()};result={'runner_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'guard_after_error':guard_after_error,'stage':name,'command':cmd,'cwd':str(R),'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),'elapsed_seconds':time.time()-start,'actual_exit':rc,'child_joined':True,'ru_maxrss_KiB':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'before':before,'after':after,'source_before':source_before,'source_after':source_after,'source_unchanged':source_before==source_after,'index_sha256':hashlib.sha256((R/'.git/index').read_bytes()).hexdigest(),'method':'Popen/wait with complete stdout/stderr; no process-family qualification','raw':{}}
for q in (p.with_suffix('.stdout'),p.with_suffix('.stderr')):result['raw'][str(q)]={'bytes':q.stat().st_size,'sha256':hashlib.sha256(q.read_bytes()).hexdigest()}
p.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ("stage","actual_exit","child_joined","ru_maxrss_KiB","source_unchanged")}),flush=True);assert source_before==source_after;assert guard_after_error is None,guard_after_error;assert after['build_allocated']<=201326592 and after['feature_allocated']<=3145728,after;sys.exit(rc)
