import gzip,hashlib,json,shutil,sys,tarfile
from pathlib import Path
R=Path('/dev/shm/nexus-qualification-transport-20261018-r1');F=Path('/dev/shm/nexus-qualification-transport-feature-20261018-r1');D=F/'r2'
sys.path.insert(0,str(R))
from tools.evidence.identity import observe_git_source

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  while b:=s.read(65536):h.update(b)
 return h.hexdigest()
def e(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'mode':p.stat().st_mode&0o777}
def w(n,v):
 p=D/n;assert not p.exists();p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');return e(p)
parent=json.loads((F/'transport-map-r1.json').read_text());source=observe_git_source(R)
assert sha(R/'.git/index')==parent['expected_index_sha256']
files=[]
for old in parent['files']:
 p=R/old['relative_path']
 if sha(p)==old['sha256']:files.append(old);continue
 q=D/'files'/old['relative_path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 files.append({'relative_path':old['relative_path'],'source':str(q),**{k:v for k,v in e(q).items() if k!='path'}})
stages=['r2-final-unit-r1','r2-final-workflow-r1','r2-source-check-r1','r2-actionlint-r1']
for n in stages:
 x=json.loads((F/'runs'/(n+'.json')).read_text());assert x['returncode']==0
 assert x['source_before']==x['source_after']==source
 assert x['index_before']==x['index_after']==parent['expected_index_sha256']
red=json.loads((F/'runs/r2-sparse-bound-red-r1.json').read_text());assert red['returncode']==1
assert red['source_before']==red['source_after']
assert red['index_before']==red['index_after']==parent['expected_index_sha256']
freeze=w('source-and-execution-freeze-r2.json',{'source':source,'source_count':5,'files':files,'final_stages':stages,'expected_index_sha256':parent['expected_index_sha256'],'parent_map':e(F/'transport-map-r1.json'),'qualified':False,'persistence':'volatile exec-shm only'})
summary=w('validation-summary-r2.json',{'final_whole_unit_tests':31,'final_whole_workflow_tests':52,'fail':0,'skip':0,'same_source_tuple':source,'checks':['full5 maintained text and3PythonAST actual0','wholeRepo actual locked actionlint1.7.12 actual0'],'new_RED':{'scope':'whole31 /4 failures /0errors; original28 still pass','cases':['GNU sparse empty member','PAX sparse64B member','256B single logical file under scaled128B cap','2x80B cumulative logical payload under scaled128B cap'],'limitation':'scaled tiny bound exercises real gzip/TAR/store; no8GiB allocation and no MCU/SDK/OCI execution'},'fix':'wrapper refuses sparse and per-entry/aggregate payload size before store extraction; original generic store/schema unchanged','parent_all_originals_preserved':True,'qualification':'not_qualified'})
leafs=[p for p in D.rglob('*') if p.is_file()]
for p in (F/'runs').rglob('*'):
 if p.is_file() and p.relative_to(F/'runs').parts[0].startswith('r2-'):leafs.append(p)
leafs.sort(key=lambda p:str(p.relative_to(F)))
expected={str(p.relative_to(F)):e(p) for p in leafs}
archive=D/'execution-evidence-r2.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as g,tarfile.open(fileobj=g,mode='w|') as t:
 for p in leafs:
  info=t.gettarinfo(str(p),arcname=str(p.relative_to(F)))
  with p.open('rb') as s:t.addfile(info,s)
seen=set()
with tarfile.open(archive,'r|gz') as t:
 for m in t:
  assert m.isfile() and m.name in expected and m.name not in seen
  x=expected[m.name];assert m.size==x['bytes'] and m.mode&0o777==x['mode']
  h=hashlib.sha256()
  with t.extractfile(m) as s:
   while b:=s.read(65536):h.update(b)
  assert h.hexdigest()==x['sha256'];seen.add(m.name);t.members.clear()
assert seen==set(expected)
with gzip.open(archive,'rb') as s:
 while s.read(65536):pass
emap=w('execution-evidence-map-r2.json',{'archive':e(archive),'member_count':len(expected),'members':expected,'validation':'all original memberSHA/size/mode and gzipCRC/EOF actual0'})
transport=w('transport-map-r2.json',{'source_count':5,'files':files,'freeze':freeze,'validation_summary':summary,'parent_transport_map':e(F/'transport-map-r1.json'),'parent_all_original_evidence_archive':e(F/'execution-evidence-r1.tar.gz'),'new_original_evidence_archive':e(archive),'new_evidence_map':emap,'expected_head':parent['expected_head'],'expected_index_sha256':parent['expected_index_sha256'],'qualified':False})
assert observe_git_source(R)==source
for x in json.loads((F/'execution-evidence-map-r1.json').read_text())['members'].values():assert sha(Path(x['path']))==x['sha256']
assert sha(R/'.git/index')==parent['expected_index_sha256']
allocated=sum(p.stat().st_blocks*512 for p in F.rglob('*') if p.is_file());assert allocated<=4194304
handoff=w('handoff-r2.json',{'final_transport_map':transport,'freeze':freeze,'new_evidence_archive':e(archive),'new_evidence_map':emap,'parent_handoff':e(F/'handoff-r1.json'),'same_source_index_before_after':True,'parent167_originals_still_exact':True,'feature_allocated_before_handoff':allocated,'limits':{'feature_cap':4194304,'test_output_cap':33554432},'qualification':'not_qualified','not_executed':['actual new remotequalification','localSDK/OCI/ARM','physicalHIL'],'persistence':'volatile only until Root normal commit/push'})
print(json.dumps({'map':transport,'freeze':freeze,'archive':e(archive),'new_members':len(expected),'handoff':handoff,'allocated_before_handoff':allocated}))
