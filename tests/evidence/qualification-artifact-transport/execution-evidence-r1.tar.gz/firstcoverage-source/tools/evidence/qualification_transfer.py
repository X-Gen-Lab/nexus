#!/usr/bin/env python3
"""Lossless bounded CI transport; never a qualification or candidate authority."""

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tarfile
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from tools.evidence import store
from tools.evidence.common import (EvidenceError, atomic_json, fields,
    load_json, regular_file, sha256_value, stream_digest)
from tools.evidence.identity import canonical_digest

ROOTS = (('qualification', 'build/software-qualification'),
         ('delivery', 'build/delivery'),
         ('job_identity', 'build/job-identities/software-qualification'))
PART_BYTES = 256 * 1024 ** 2
MAX_PARTS = 8
MAX_BYTES = 8 * 1024 ** 3
MAX_FILES = 100000
CORE_BYTES = 64 * 1024 ** 2


def safe_directory(path):
    path = Path(path).absolute()
    if '..' in path.parts or any(p.is_symlink() for p in (path, *path.parents)):
        raise EvidenceError('Unsafe directory or symlink ancestor')
    return path


def signature(path):
    value = path.stat(follow_symlinks=False)
    return [value.st_dev, value.st_ino, value.st_mode, value.st_size,
            value.st_uid, value.st_gid, value.st_mtime_ns, value.st_ctime_ns]


def safe_name(name):
    store._safe_path(name)
    if len(name.encode()) > 4096 or any(ord(c) < 32 for c in name):
        raise EvidenceError('Archive path exceeds its safe bound')
    return name


def inventory(root):
    """Snapshot all three exact trees, including hidden/empty input entries."""
    root = safe_directory(root)
    entries, signatures, identities = [], {}, set()
    for role, relative in ROOTS:
        directory = safe_directory(root / relative)
        if not directory.is_dir():
            raise EvidenceError('Required original role is missing: ' + role)
        identity = signature(directory)[:2]
        if tuple(identity) in identities:
            raise EvidenceError('Aliased role roots')
        identities.add(tuple(identity))
        entries.append({'path': role, 'kind': 'directory',
                        'mode': directory.stat().st_mode & 0o777})
        signatures[role] = signature(directory)
        for item in store.inventory(directory):
            name = safe_name(role + '/' + item['path'])
            entries.append({**item, 'path': name})
            signatures[name] = signature(directory / item['path'])
    if len(entries) > MAX_FILES or sum(x.get('size', 0) for x in entries) > MAX_BYTES:
        raise EvidenceError('Original evidence exceeds transport admission')
    return {'entries': sorted(entries, key=lambda x: x['path']),
            'signatures': signatures}


def unchanged(root, before):
    if inventory(root) != before:
        raise EvidenceError('Original input changed during transport')


def context(value):
    fields(value, {'commit', 'run_id', 'attempt'})
    if (any(not isinstance(v, str) for v in value.values()) or
            not re.fullmatch('[0-9a-f]{40}', value['commit']) or
            any(not re.fullmatch('[1-9][0-9]*', value[k])
                for k in ('run_id', 'attempt'))):
        raise EvidenceError('Exact source/run/attempt required')
    return value


def original_identity(root, expected):
    path = root / dict(ROOTS)['job_identity'] / 'identity.json'
    record = load_json(path)
    check = dict(record)
    checksum = check.pop('record_sha256', None)
    if (canonical_digest(check) != checksum or record.get('schema_version') != 1
            or record.get('kind') != 'ci_job_identity'
            or record.get('source', {}).get('commit') != expected['commit']
            or record.get('run', {}).get('GITHUB_RUN_ID') != expected['run_id']
            or record.get('run', {}).get('GITHUB_RUN_ATTEMPT') != expected['attempt']
            or record.get('job_result') not in ('success', 'failure', 'cancelled')
            or record.get('qualification') != 'not_a_software_candidate'):
        raise EvidenceError('Original CI identity differs from transport context')
    return record


class SplitWriter:
    """Sequential gzip sink; tiny internal sizes exercise boundaries in tests."""
    def __init__(self, directory, *, part_bytes=PART_BYTES):
        if type(part_bytes) is not int or not 0 < part_bytes <= PART_BYTES:
            raise EvidenceError('Invalid internal part size')
        self.directory = directory
        self.part_bytes = part_bytes
        self.parts, self.stream, self.part_hash = [], None, None
        self.part_size, self.total = 0, 0
        self.checksum = hashlib.sha256()

    def write(self, data):
        if len(data) > self.part_bytes * MAX_PARTS - self.total:
            raise EvidenceError('Ninth transport part is not admitted')
        original = len(data)
        while data:
            if self.stream is None:
                name = 'part-' + str(len(self.parts)).zfill(3)
                self.stream = (self.directory / name).open('xb')
                self.part_hash = hashlib.sha256()
                self.part_size = 0
            chunk = data[:self.part_bytes - self.part_size]
            self.stream.write(chunk)
            self.part_hash.update(chunk)
            self.checksum.update(chunk)
            self.part_size += len(chunk)
            self.total += len(chunk)
            data = data[len(chunk):]
            if self.part_size == self.part_bytes:
                self._close_part()
        return original

    def _close_part(self):
        if self.stream is not None:
            self.stream.close()
            self.parts.append({'ordinal': len(self.parts),
                               'name': self.stream.name.split('/')[-1],
                               'offset': self.total - self.part_size,
                               'size': self.part_size,
                               'sha256': self.part_hash.hexdigest()})
            self.stream = None

    def flush(self):
        if self.stream is not None:
            self.stream.flush()

    def close(self):
        self._close_part()


def validate_archive(package, archive):
    """Prove framing as well as the unchanged store inventory contract."""
    archive = regular_file(archive)
    with archive.open('rb') as stream:
        checksum = stream_digest(stream)
    if (archive.stat().st_size != package['archive']['size'] or
            checksum != package['archive']['sha256']):
        raise EvidenceError('Whole compressed archive identity differs')
    decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
    expanded = 0
    try:
        with archive.open('rb') as source:
            while chunk := source.read(65536):
                while chunk:
                    data = decoder.decompress(chunk, 65536)
                    expanded += len(data)
                    if expanded > MAX_BYTES + (MAX_FILES + 1) * 4096:
                        raise EvidenceError('Expanded archive exceeds bound')
                    if decoder.eof:
                        if decoder.unused_data or source.read(1):
                            raise EvidenceError('Trailing/concatenated gzip data')
                        break
                    chunk = decoder.unconsumed_tail
            if not decoder.eof:
                raise EvidenceError('Truncated gzip stream')
    except zlib.error as error:
        raise EvidenceError('Invalid gzip CRC/ISIZE') from error
    try:
        with tarfile.open(archive, 'r:gz') as source:
            seen = set()
            for member in source:
                safe_name(member.name)
                if (member.name in seen or len(seen) >= MAX_FILES + 1 or
                        not (member.isfile() or member.isdir())):
                    raise EvidenceError('Unexpected/duplicate TAR entry')
                seen.add(member.name)
                source.members.clear()
            source.fileobj.seek(source.offset)
            tail_bytes = 0
            while tail := source.fileobj.read(65536):
                tail_bytes += len(tail)
                if any(tail):
                    raise EvidenceError('Nonzero logical TAR tail')
            if tail_bytes < 1024:
                raise EvidenceError('Missing TAR end blocks')
        return store.verify_package(package, archive_override=archive)
    except (tarfile.TarError, EOFError) as error:
        raise EvidenceError('Invalid TAR stream') from error


def join(manifest, parts, destination):
    """Reconstruct exact bytes only; a caller separately admits API identity."""
    parts, destination = safe_directory(parts), safe_directory(destination)
    if destination.exists() or destination.is_relative_to(parts):
        raise EvidenceError('Join output must be fresh and outside inputs')
    declared = manifest['parts']
    if not isinstance(declared, list) or not 1 <= len(declared) <= MAX_PARTS:
        raise EvidenceError('Invalid part count')
    names = {'part-' + str(i).zfill(3) for i in range(len(declared))}
    if {p.name for p in parts.iterdir()} != names:
        raise EvidenceError('Missing or extra transport parts')
    destination.parent.mkdir(parents=True, exist_ok=True)
    checksum, total = hashlib.sha256(), 0
    with destination.open('xb') as target:
        for index, item in enumerate(declared):
            fields(item, {'ordinal', 'name', 'offset', 'size', 'sha256'})
            if (item['ordinal'] != index or item['name'] != 'part-' +
                    str(index).zfill(3) or item['offset'] != total or
                    type(item['size']) is not int or not 0 < item['size'] <= PART_BYTES
                    or (index < len(declared) - 1 and item['size'] != PART_BYTES)):
                raise EvidenceError('Invalid part order/offset/size')
            sha256_value(item['sha256'])
            path = regular_file(parts / item['name'])
            before, local, size = signature(path), hashlib.sha256(), 0
            with path.open('rb') as source:
                while block := source.read(65536):
                    size += len(block)
                    if size > item['size']:
                        raise EvidenceError('Part exceeds its declared size')
                    target.write(block)
                    checksum.update(block)
                    local.update(block)
            if (signature(path) != before or size != item['size'] or
                    local.hexdigest() != item['sha256']):
                raise EvidenceError('Changed/corrupt transport part')
            total += size
    expected = manifest['package']['archive']
    if total != expected['size'] or checksum.hexdigest() != expected['sha256']:
        raise EvidenceError('Joined original SHA/size differs')
    return destination


def prepare(root, output, expected):
    root, output = safe_directory(root), safe_directory(output)
    expected = context(expected)
    if output.exists() or any(output.is_relative_to(root / p) or
                             (root / p).is_relative_to(output) for _, p in ROOTS):
        raise EvidenceError('Transport output overlaps input or already exists')
    original = original_identity(root, expected)
    before = inventory(root)
    if original['job_result'] == 'success' and original['source'].get('dirty'):
        raise EvidenceError('Successful identity requires clean source')
    observed = {}
    for item in before['entries']:
        role, _, relative = item['path'].partition('/')
        if item['kind'] == 'file' and role != 'job_identity':
            name = dict(ROOTS)[role] + '/' + relative
            observed[name] = {k: item[k] for k in ('size', 'sha256')}
    recorded = original.get('artifacts', [])
    if (not isinstance(recorded, list) or
            len({x['relative_path'] for x in recorded}) != len(recorded) or
            {x['relative_path']: {k: x[k] for k in ('size', 'sha256')}
             for x in recorded} != observed):
        raise EvidenceError('Original job artifact inventory differs')
    output.parent.mkdir(parents=True, exist_ok=True)
    needed = min(PART_BYTES * MAX_PARTS,
                 sum(x.get('size', 0) for x in before['entries']) * 2 +
                 len(before['entries']) * 16384 + 1048576)
    if shutil.disk_usage(output.parent).free < 2 * needed + CORE_BYTES:
        raise EvidenceError('Insufficient parts and reassembly headroom')
    output.mkdir()
    (output / 'parts').mkdir()
    sink = SplitWriter(output / 'parts')
    encoded = (json.dumps({'schema_version': 1, 'kind': 'evidence_tree',
                          'entries': before['entries']}, sort_keys=True,
                         separators=(',', ':')) + '\n').encode()
    try:
        with gzip.GzipFile(fileobj=sink, mode='wb', filename='', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|') as archive:
                for record in before['entries']:
                    info = tarfile.TarInfo('payload/' + record['path'])
                    info.mode = record['mode']
                    if record['kind'] == 'directory':
                        info.type = tarfile.DIRTYPE
                        archive.addfile(info)
                    else:
                        info.size = record['size']
                        role, relative = record['path'].split('/', 1)
                        path = root / dict(ROOTS)[role] / relative
                        with regular_file(path, nonempty=False).open('rb') as source:
                            archive.addfile(info, source)
                import io
                info = tarfile.TarInfo('delivery-manifest.json')
                info.mode, info.size = 0o644, len(encoded)
                archive.addfile(info, io.BytesIO(encoded))
    finally:
        sink.close()
    unchanged(root, before)
    package = {'schema_version': 1, 'kind': 'portable_evidence',
               'archive': {'path': str(output / 'check.tar.gz'),
                           'size': sink.total,
                           'sha256': sink.checksum.hexdigest()},
               'manifest_sha256': hashlib.sha256(encoded).hexdigest(),
               'files': sum(x['kind'] == 'file' for x in before['entries']),
               'bytes': sum(x.get('size', 0) for x in before['entries']),
               'signature_status': 'unsigned', 'product_promotion': False}
    manifest = {'schema_version': 1, 'kind': 'qualification_multipart',
                'context': expected, 'roots': dict(ROOTS), 'parts': sink.parts,
                'part_bytes': PART_BYTES, 'package': package,
                'original_identity_sha256': hashlib.sha256((root / dict(ROOTS)[
                    'job_identity'] / 'identity.json').read_bytes()).hexdigest(),
                'original_job_result': original['job_result'], 'qualified': False}
    joined = join(manifest, output / 'parts', output / 'check.tar.gz')
    validate_archive(package, joined)
    unchanged(root, before)
    (output / 'core').mkdir()
    atomic_json(output / 'core/manifest.json', manifest)
    shutil.copyfile(root / dict(ROOTS)['job_identity'] / 'identity.json',
                    output / 'core/identity.json')
    return manifest


def read_manifest(core, expected=None):
    core = safe_directory(core)
    paths = list(core.iterdir())
    if (any(p.name not in {'manifest.json', 'identity.json', 'uploads.json'}
            or p.is_symlink() or not p.is_file() for p in paths) or
            sum(p.stat().st_size for p in paths) > CORE_BYTES):
        raise EvidenceError('Core exceeds admission bound')
    manifest = load_json(core / 'manifest.json', max_bytes=CORE_BYTES)
    fields(manifest, {'schema_version', 'kind', 'context', 'roots', 'parts',
                     'part_bytes', 'package', 'original_identity_sha256',
                     'original_job_result', 'qualified'})
    if (manifest['schema_version'] != 1 or
            manifest['kind'] != 'qualification_multipart' or
            manifest['roots'] != dict(ROOTS) or manifest['part_bytes'] != PART_BYTES
            or manifest['qualified'] is not False):
        raise EvidenceError('Unsupported multipart contract')
    context(manifest['context'])
    if expected is not None and manifest['context'] != context(expected):
        raise EvidenceError('Different source/run/attempt')
    with regular_file(core / 'identity.json').open('rb') as source:
        if stream_digest(source) != manifest['original_identity_sha256']:
            raise EvidenceError('Original identity copy differs')
    return manifest


def finish(output, outcomes):
    core = safe_directory(output) / 'core'
    manifest = read_manifest(core)
    uploads, complete = [], True
    for index in range(MAX_PARTS):
        step = outcomes.get('part' + str(index), {})
        used = index < len(manifest['parts'])
        outputs = step.get('outputs', {})
        valid = (step.get('outcome') == 'success' and
                 re.fullmatch('[1-9][0-9]*', outputs.get('artifact-id', '')) and
                 re.fullmatch('[0-9a-f]{64}', outputs.get('artifact-digest', '')))
        if used:
            complete = complete and bool(valid)
        elif step.get('outcome', 'skipped') != 'skipped' or outputs:
            complete = False
        uploads.append({'ordinal': index, 'used': used,
                        'outcome': step.get('outcome', 'missing' if used else 'unused'),
                        'artifact_id': outputs.get('artifact-id', ''),
                        'artifact_sha256': outputs.get('artifact-digest', '')})
    result = {'schema_version': 1, 'kind': 'qualification_transfer_uploads',
              'context': manifest['context'], 'uploads': uploads,
              'status': 'uploaded' if complete else 'partial', 'qualified': False,
              'limit': 'Core upload and final API/job identity not observed here'}
    atomic_json(core / 'uploads.json', result)
    return result


def verify(core, parts, destination, expected):
    manifest = read_manifest(core, expected)
    receipt = load_json(Path(core) / 'uploads.json')
    if (receipt.get('status') != 'uploaded' or receipt.get('qualified') is not False
            or receipt.get('context') != manifest['context']):
        raise EvidenceError('Incomplete upload receipt')
    archive = join(manifest, parts, destination)
    result = validate_archive(manifest['package'], archive)
    return {**result, 'status': 'verified_transport', 'qualified': False,
            'scope': 'Original qualification and API identity require independent admission'}


def main(arguments=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=('plan', 'prepare', 'finish', 'verify'))
    parser.add_argument('--root', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--core', type=Path)
    parser.add_argument('--parts', type=Path)
    parser.add_argument('--commit')
    parser.add_argument('--run-id')
    parser.add_argument('--attempt')
    parser.add_argument('--github-output', type=Path)
    args = parser.parse_args(arguments)
    try:
        if args.operation == 'plan':
            if args.github_output is None:
                raise EvidenceError('GitHub output required')
            with args.github_output.open('a') as stream:
                stream.write('identity_inputs<<NEXUS_ROOTS\n' +
                             '\n'.join(p for _, p in ROOTS[:2]) +
                             '\nNEXUS_ROOTS\nidentity_output=' +
                             dict(ROOTS)['job_identity'] + '\n')
            return 0
        if args.output is None:
            raise EvidenceError('Fresh output required')
        if args.operation == 'finish':
            result = finish(args.output, json.loads(os.environ['NEXUS_UPLOAD_STEPS']))
            print(result['status'])
            return 0 if result['status'] == 'uploaded' else 1
        expected = {'commit': args.commit, 'run_id': args.run_id,
                    'attempt': args.attempt}
        if args.operation == 'prepare':
            result = prepare(args.root, args.output, expected)
            if args.github_output:
                with args.github_output.open('a') as stream:
                    stream.write('count=' + str(len(result['parts'])) + '\n')
        else:
            result = verify(args.core, args.parts, args.output, expected)
        print(json.dumps(result, sort_keys=True))
        return 0
    except (EvidenceError, OSError, ValueError, TypeError, KeyError) as error:
        print('Qualification transfer rejected: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
