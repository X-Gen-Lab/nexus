import gzip, hashlib, json, os, shutil, sys, tarfile
from pathlib import Path
ROOT=Path('/dev/shm/nexus-qualification-transport-20261018-r1')
F=Path('/dev/shm/nexus-qualification-transport-feature-20261018-r1')
sys.path.insert(0,str(ROOT))
from tools.evidence.identity import observe_git_source

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  while b:=s.read(65536): h.update(b)
 return h.hexdigest()
def entry(p):
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'mode':p.stat().st_mode&0o777}
def write(name,value):
 p=F/name
 assert not p.exists(),p
 p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
 return entry(p)
paths=['tools/evidence/qualification_transfer.py','tools/testing/test_qualification_transfer.py','.github/workflows/software-qualification.yml','.github/workflows/test_platform_ci.py','tools/evidence/README.md']
before=json.loads((F/'before.json').read_text())
assert sha(ROOT/'.git/index')==before['index_sha256']
with gzip.open(F/'before-index.gz','rb') as s:
 assert hashlib.sha256(s.read()).hexdigest()==before['index_sha256']
source=observe_git_source(ROOT)
assert source['commit']==before['head']
files=[]
for rel in paths:
 p=ROOT/rel; dest=F/'files'/rel
 assert not dest.exists()
 dest.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(p,dest)
 assert sha(p)==sha(dest)
 files.append({'relative_path':rel,'source':str(dest),**{k:v for k,v in entry(dest).items() if k!='path'}})
final_stages=['final-unit-r2','final-workflow-r3','source-check-r2','actionlint-r2']
for name in final_stages:
 r=json.loads((F/'runs'/(name+'.json')).read_text())
 assert r['returncode']==0 and r['source_before']==r['source_after']==source
 assert r['index_before']==r['index_after']==before['index_sha256']
freeze=write('source-and-execution-freeze-r1.json',{'source':source,'index_sha256':before['index_sha256'],'source_count':5,'files':files,'final_stages':final_stages,'qualified':False,'persistence':'volatile exec-shm; not durable before Root commit/push'})
classifications={
'workflow-red-r1':'mixed setup/path/dependency plus new delivery contract failure; not accepted pure behavior RED',
'workflow-red-r2':'whole49, exactly one new delivery-contract failure; accepted delivery RED',
'unit-firstcoverage-r1':'new capability first coverage whole16; ResourceWarning observed and then closed; not a behavior RED',
'parser-red-r1':'whole18 exactly2 fails: boolean ordinal and empty upload receipt',
'upload-identity-red-r1':'whole22 exactly1 fail: reused artifact ID',
'output-alias-red-r1':'whole24 exactly4 failures: protected control output3 and core join output1',
'core-binding-probe-r1':'tiny real rehashed core/source mismatch accepted; probe exits1, not hardware or SDK proof',
'identity-closure-red-r1':'whole28 exactly4 failures: context/job and archive/artifact binding',
}
stages=[]
for p in sorted((F/'runs').glob('*.json')):
 if p.name.endswith('.command.json'):continue
 r=json.loads(p.read_text()); name=p.stem
 stages.append({'name':name,'record':entry(p),'returncode':r['returncode'],'source_stable':r['source_before']==r['source_after'],'index_stable':r['index_before']==r['index_after'],'classification':classifications.get(name,'actual bounded scope; retain historical source identity, not final qualification')})
summary=write('validation-summary-r1.json',{'stages':stages,'final':{'unit_tests':28,'workflow_tests':52,'skip':0,'fail':0,'full_five_file_maintained_text_check':True,'python_asts':3,'all_workflow_actionlint':'actual0 with locked1.7.12; shellcheck/pyflakes disabled per maintained DSL policy'},'limits':{'feature_allocated_cap':4194304,'test_output_cap':33554432,'jobs':1,'no_SDK_OCI_ARM_HIL_or_remote_run':True},'boundary':'transport bytes/modes/context consistency only; actual GitHub API artifacts/final job and inner qualification validators remain independent; historic809844813B ZIP remains unavailable','qualified':False})
write('root-preparation-links-r1.json',{'dependency_proof':'/dev/shm/nexus-qualification-transport-sdk-prepare-20261018-r3/result.json','resolver_probe':'/dev/shm/nexus-qualification-transport-sdk-prepare-20261018-r3/actual-resolver-probe.json','original_plan':'/workspace/nexus-io-recovery-20261018/validation/qualification-artifact-volumes-readonly-r1.json','plan_sha256':'9c59a67b2ae9ab786da5c4e278478cea03835f0ab85db8060d2bdc51322967d9','note':'Root verified three locked dependency closures; not duplicated into bounded feature packet'})
leafs=[p for p in F.rglob('*') if p.is_file() and not p.is_symlink()]
leafs.sort(key=lambda p:str(p.relative_to(F)))
archive=F/'execution-evidence-r1.tar.gz'
assert not archive.exists()
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as g,tarfile.open(fileobj=g,mode='w|') as t:
 for p in leafs:
  info=t.gettarinfo(str(p),arcname=str(p.relative_to(F)))
  with p.open('rb') as s:t.addfile(info,s)
expected={str(p.relative_to(F)):entry(p) for p in leafs}
seen=set()
with tarfile.open(archive,'r|gz') as t:
 for m in t:
  assert m.isfile() and m.name in expected and m.name not in seen
  e=expected[m.name]
  assert m.size==e['bytes'] and m.mode&0o777==e['mode']
  h=hashlib.sha256()
  with t.extractfile(m) as s:
   while b:=s.read(65536):h.update(b)
  assert h.hexdigest()==e['sha256'];seen.add(m.name);t.members.clear()
assert seen==set(expected)
with gzip.open(archive,'rb') as s:
 while s.read(65536):pass
emap=write('execution-evidence-map-r1.json',{'archive':entry(archive),'member_count':len(expected),'members':expected,'validation':'all member bytes/size/mode and complete gzip CRC/EOF actual0; no source/index mutation'})
transport=write('transport-map-r1.json',{'schema_version':1,'source_count':5,'files':files,'freeze':freeze,'validation_summary':summary,'evidence_archive':entry(archive),'evidence_map':emap,'expected_head':before['head'],'expected_index_sha256':before['index_sha256'],'qualified':False})
assert observe_git_source(ROOT)==source and sha(ROOT/'.git/index')==before['index_sha256']
allocated=sum(p.stat().st_blocks*512 for p in F.rglob('*') if p.is_file())
assert allocated<=4194304,allocated
handoff=write('handoff-r1.json',{'transport_map':transport,'freeze':freeze,'evidence_map':emap,'evidence_archive':entry(archive),'source_stable':True,'index_stable':True,'allocated_regular_file_bytes_before_handoff':allocated,'not_executed':['new actual remote qualification','local SDK/OCI build','ARM link','candidate promotion','physical HIL'],'qualification':'not_qualified','persistence':'volatile only; Root normal commit/push required'})
print(json.dumps({'handoff':handoff,'transport_map':transport,'freeze':freeze,'evidence_archive':entry(archive),'evidence_members':len(expected),'allocated_before_handoff':allocated}))
