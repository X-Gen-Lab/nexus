from pathlib import Path
import ast,hashlib,json,sys
ROOT=Path('/dev/shm/nexus-qualification-transport-20261018-r1')
sys.path.insert(0,str(ROOT))
from scripts.ci.style_gate import check_text
from tools.dev.dependencies import verify_actionlint
paths=['tools/evidence/qualification_transfer.py','tools/testing/test_qualification_transfer.py','.github/workflows/software-qualification.yml','.github/workflows/test_platform_ci.py','tools/evidence/README.md']
errors=[];records=[]
for name in paths:
 path=ROOT/name;errors+=check_text(path,name)
 if path.suffix=='.py':ast.parse(path.read_text())
 records.append({'path':name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
exe=verify_actionlint(Path('/tmp/nexus-io-validation-20261018/.venv/nexus-actionlint'),ROOT/'dependencies/actionlint.lock.json')
result={'files':records,'text_errors':errors,'actionlint':str(exe),'tool_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'scope':'complete5 file maintained check_text;3Python AST; normal full-index gate reserved for Root'}
Path('/dev/shm/nexus-qualification-transport-feature-20261018-r1/source-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));sys.exit(bool(errors))
