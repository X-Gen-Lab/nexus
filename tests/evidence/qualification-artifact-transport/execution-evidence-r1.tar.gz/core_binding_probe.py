import hashlib,json,sys
from pathlib import Path
ROOT=Path('/dev/shm/nexus-qualification-transport-20261018-r1')
sys.path.insert(0,str(ROOT))
from tools.testing.test_qualification_transfer import QualificationTransferTests
from tools.evidence import qualification_transfer as transfer
from tools.evidence.identity import canonical_digest
from tools.evidence.common import EvidenceError
case=QualificationTransferTests();case.setUp()
try:
 manifest=case.prepared();transfer.finish(case.output,case.outcomes(manifest))
 path=case.output/'core/identity.json';record=json.loads(path.read_text())
 record['source']['commit']='b'*40;record.pop('record_sha256')
 record['record_sha256']=canonical_digest(record);path.write_text(json.dumps(record))
 manifest['original_identity_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
 (case.output/'core/manifest.json').write_text(json.dumps(manifest))
 try:result=transfer.verify(case.output/'core',case.output/'parts',case.parent/'mixed',case.context)
 except EvidenceError as error:print('rejected:',error);sys.exit(0)
 print(json.dumps({'unexpectedly_accepted':result['status'],'expected_source':case.context['commit'],'core_source':record['source']['commit'],'archive_source':'a'*40,'all_outer_declared_hashes_recomputed':True}));sys.exit(1)
finally:case.doCleanups()
