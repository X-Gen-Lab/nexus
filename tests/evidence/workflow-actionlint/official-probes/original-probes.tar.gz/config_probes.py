"""Verify explicit neutral configuration with the exact official binary."""
import json
from pathlib import Path
import tarfile

import probe

probe.guard()
archive = '/tmp/nexus-actionlint-assets-20261018-r1/actionlint_1.7.12_linux_amd64.tar.gz'
with tarfile.open(archive, 'r:gz') as source:
    raw = source.extractfile('docs/config.md').read()
    (probe.ROOT / 'upstream-config.md.raw').write_bytes(raw)
fixed = probe.ROOT / 'projects/complete-published-fix'
base_files = {p.relative_to(fixed).as_posix(): p.read_bytes()
              for p in fixed.rglob('*')
              if p.is_file() and '.git' not in p.relative_to(fixed).parts}
base_files['.github/actionlint.yaml'] = b'[: invalid default project configuration\n'
base_files['.actionlint-neutral.yaml'] = b'{}\n'
good = probe.initialize('config-explicit-neutral-fixed', base_files)
default = probe.lint('config-default-invalid-lint', good)
paths = sorted(p.relative_to(good).as_posix() for p in (good / '.github/workflows').glob('*.yml'))
explicit = probe.actual('config-explicit-neutral-fixed-lint',
                        [str(probe.TOOL), '-shellcheck=', '-pyflakes=', '-no-color',
                         '-config-file', str(good / '.actionlint-neutral.yaml'), *paths], good)
bad_files = dict(base_files)
bad_files['.github/workflows/software-qualification.yml'] = (probe.ROOT / 'old-bad-workflow.yml.raw').read_bytes()
bad = probe.initialize('config-explicit-neutral-oldbad', bad_files)
paths = sorted(p.relative_to(bad).as_posix() for p in (bad / '.github/workflows').glob('*.yml'))
red = probe.actual('config-explicit-neutral-oldbad-lint',
                   [str(probe.TOOL), '-shellcheck=', '-pyflakes=', '-no-color',
                    '-config-file', str(bad / '.actionlint-neutral.yaml'), *paths], bad)
result = {'default_invalid_project_config': default,
          'explicit_neutral_fixed_full_11': explicit,
          'explicit_neutral_oldbad_full_11': red,
          'neutral_bytes': '{}\n',
          'neutral_sha256': probe.sha(good / '.actionlint-neutral.yaml'),
          'HOME_modified': False}
(probe.ROOT / 'configuration-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'default_exit': default['actual_exit'], 'explicit_fixed_exit': explicit['actual_exit'],
                  'explicit_oldbad_exit': red['actual_exit'], 'neutral_sha256': result['neutral_sha256']}, indent=2))
