"""Small real actionlint metadata probes; not a GA grammar implementation."""
import json
from pathlib import Path

import probe

CALLER = '.github/workflows/caller.yml'
CALLEE = '.github/workflows/callee.yml'
ACTION = '.github/actions/local/action.yml'
reusable_caller = b'''name: Reusable caller
on: workflow_dispatch
jobs:
  call:
    uses: ./.github/workflows/callee.yml
    with:
      required_name: example
      count: 1
'''
reusable_callee = b'''name: Reusable callee
on:
  workflow_call:
    inputs:
      required_name:
        type: string
        required: true
      count:
        type: number
        required: true
jobs:
  run:
    runs-on: ubuntu-24.04
    steps:
      - run: echo fixture
'''
action_caller = b'''name: Local action caller
on: workflow_dispatch
jobs:
  run:
    runs-on: ubuntu-24.04
    steps:
      - id: local
        uses: ./.github/actions/local
        with:
          required_name: example
      - run: echo fixture
        env:
          RESULT: ${{ steps.local.outputs.result }}
'''
action_metadata = b'''name: Local fixture
description: Metadata-only fixture
inputs:
  required_name:
    description: Required fixture input
    required: true
outputs:
  result:
    description: Fixture output
    value: ok
runs:
  using: composite
  steps:
    - shell: bash
      run: echo fixture
'''


def case(name, files, delete=None, empty_action_directory=False):
    project = probe.initialize(name, files)
    if empty_action_directory:
        (project / '.github/actions/local').mkdir(parents=True, exist_ok=True)
    deletion = None
    if delete is not None:
        probe.guard()
        original = (project / delete).read_bytes()
        before = probe.ROOT / 'before-deletion' / name / delete
        before.parent.mkdir(parents=True, exist_ok=True)
        before.write_bytes(original)
        (probe.ROOT / (name + '-index-before.raw')).write_bytes(
            __import__('subprocess').check_output(['git', 'ls-files', '--stage', '-z'],
                                                 cwd=project, env=probe.child_environment()))
        (project / delete).unlink()
        staged = probe.actual(name + '-git-stage-deletion',
                              ['git', 'add', '-u', '--', '.github'], project)
        assert staged['actual_exit'] == 0
        deletion = {'relative': delete, 'before_bytes': len(original),
                    'before_sha256': probe.sha(before),
                    'absent_after': not (project / delete).exists()}
    result = probe.lint(name + '-lint', project)
    result['fixture_kind'] = name
    result['deletion'] = deletion
    return result


results = []
good_reusable = {CALLER: reusable_caller, CALLEE: reusable_callee}
good_action = {CALLER: action_caller, ACTION: action_metadata}
results.append(case('reusable-valid', good_reusable))
results.append(case('reusable-required-missing', {
    CALLER: reusable_caller.replace(b'      required_name: example\n', b''),
    CALLEE: reusable_callee}))
results.append(case('reusable-type-invalid', {
    CALLER: reusable_caller.replace(b'count: 1', b"count: 'not-a-number'"),
    CALLEE: reusable_callee}))
results.append(case('reusable-missing', {CALLER: reusable_caller}))
results.append(case('reusable-deleted', good_reusable, delete=CALLEE))
results.append(case('action-valid', good_action))
results.append(case('action-unknown-input', {
    CALLER: action_caller.replace(b'          required_name: example\n',
                                 b'          required_name: example\n          unexpected: value\n'),
    ACTION: action_metadata}))
results.append(case('action-required-missing', {
    CALLER: action_caller.replace(b'        with:\n          required_name: example\n', b''),
    ACTION: action_metadata}))
results.append(case('action-unknown-output', {
    CALLER: action_caller.replace(b'outputs.result', b'outputs.not_defined'),
    ACTION: action_metadata}))
results.append(case('action-directory-missing', {CALLER: action_caller}))
results.append(case('action-metadata-missing', {CALLER: action_caller},
                    empty_action_directory=True))
results.append(case('action-metadata-deleted', good_action, delete=ACTION))
results.append(case('action-yaml-valid', {CALLER: action_caller,
                                         ACTION.removesuffix('.yml') + '.yaml': action_metadata}))
output = probe.ROOT / 'local-metadata-results.json'
assert not output.exists()
output.write_text(json.dumps({'cases': results}, indent=2) + '\n')
print(json.dumps({'results': [{'case': r['fixture_kind'], 'actual_exit': r['actual_exit']}
                              for r in results]}, indent=2))
