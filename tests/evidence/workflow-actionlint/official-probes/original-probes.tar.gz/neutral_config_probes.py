"""Prove the precise materialized-default neutral configuration mechanism."""
import json
from pathlib import Path

import probe

source = probe.ROOT / 'projects/complete-published-fix'
files = {p.relative_to(source).as_posix(): p.read_bytes()
         for p in source.rglob('*')
         if p.is_file() and '.git' not in p.relative_to(source).parts}
files['.github/actionlint.yaml'] = b'{}\n'
results = []
for label, old in [('fixed', False), ('oldbad', True)]:
    selected = dict(files)
    if old:
        selected['.github/workflows/software-qualification.yml'] = (probe.ROOT / 'old-bad-workflow.yml.raw').read_bytes()
    project = probe.initialize('config-materialized-neutral-' + label, selected)
    paths = sorted(p.relative_to(project).as_posix()
                   for p in (project / '.github/workflows').glob('*.yml'))
    result = probe.actual('config-materialized-neutral-' + label + '-lint',
                          [str(probe.TOOL), '-shellcheck=', '-pyflakes=', '-no-color',
                           '-config-file', str(project / '.github/actionlint.yaml'), *paths], project)
    results.append(result)
(probe.ROOT / 'neutral-configuration-results.json').write_text(json.dumps({'cases': results}, indent=2) + '\n')
print(json.dumps({'results': [{'stage': r['stage'], 'actual_exit': r['actual_exit']}
                              for r in results]}, indent=2))
