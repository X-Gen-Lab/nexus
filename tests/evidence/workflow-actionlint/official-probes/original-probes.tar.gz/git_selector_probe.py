"""Parent selected index stays real; only isolated command environment resets."""
import json
import os

import probe

assert os.environ['GIT_INDEX_FILE'] == probe.BASE['index_path']
assert os.environ['GIT_DIR'] == str(probe.PARENT / '.git')
assert os.environ['GIT_WORK_TREE'] == str(probe.PARENT)
before = probe.git_parent('ls-files', '--stage', '-z')
project = probe.ROOT / 'projects/config-materialized-neutral-fixed'
discovery = probe.actual('selected-parent-isolated-child-git-root',
                         ['git', 'rev-parse', '--show-toplevel'], project)
receipt = json.loads((probe.ROOT / 'evidence/selected-parent-isolated-child-git-root.command.json').read_text())
actual_root = __import__('pathlib').Path(receipt['stdout']['path']).read_text().strip()
assert actual_root == str(project)
paths = sorted(p.relative_to(project).as_posix()
               for p in (project / '.github/workflows').glob('*.yml'))
result = probe.actual('selected-parent-isolated-child-lint',
                      [str(probe.TOOL), '-shellcheck=', '-pyflakes=', '-no-color',
                       '-config-file', str(project / '.github/actionlint.yaml'), *paths], project)
assert probe.git_parent('ls-files', '--stage', '-z') == before
(probe.ROOT / 'git-selector-results.json').write_text(json.dumps({'discovery': discovery,
  'lint': result, 'actual_child_root': actual_root,
  'intended_parent_GIT_INDEX_FILE_preserved_for_capture': True}, indent=2) + '\n')
print(json.dumps({'actual_child_root': actual_root, 'lint_actual_exit': result['actual_exit']}))
