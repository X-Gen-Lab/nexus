"""Exact official-tool DSL probes; no production changes or installation."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import time

ROOT = Path('/tmp/nexus-actionlint-probes-20261018-r1')
DURABLE = Path('/workspace/nexus-io-recovery-20261018/features/actionlint-probes-r1')
PARENT = Path('/tmp/nexus-h743-fixed-hsi-s0-20261018')
TOOL = Path('/tmp/nexus-actionlint-assets-20261018-r1/linux/actionlint')
TOOL_SHA = 'c872d6db8c6bf83a8eaa704fc93999f027d55dffbc63b8a6abdccb47df5f4cd4'
BASE = json.loads((ROOT / 'baseline.json').read_text())
sys.path.insert(0, str(PARENT))
from tools.dev import process


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_parent(*arguments):
    # Preserve a real hook's selected index. Only disable optional Git writes.
    return subprocess.check_output(['git', '-C', str(PARENT), *arguments],
                                   env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))


def allocated(path):
    return sum(p.lstat().st_blocks * 512 for p in path.rglob('*'))


def guard():
    cg = Path('/sys/fs/cgroup')
    events = dict(line.split() for line in (cg / 'memory.events').read_text().splitlines())
    available = int((cg / 'memory.max').read_text()) - int((cg / 'memory.current').read_text())
    state = {'observed_ns': time.time_ns(), 'tmp_free': shutil.disk_usage(ROOT).free,
             'persistent_free': shutil.disk_usage(DURABLE).free,
             'memory_available': available, 'events': events,
             'tmp_task_allocated': allocated(ROOT),
             'persistent_task_allocated': allocated(DURABLE)}
    assert state['tmp_free'] >= 200 * 1024**2
    assert state['persistent_free'] >= 64 * 1024**2
    assert available >= 600 * 1024**2
    assert all(int(events.get(k, 0)) == 0 for k in ('oom', 'oom_kill', 'oom_group_kill'))
    assert state['tmp_task_allocated'] <= 12 * 1024**2
    assert state['persistent_task_allocated'] <= 256 * 1024
    assert git_parent('rev-parse', 'HEAD').decode().strip() == BASE['head']
    assert sha(Path(BASE['index_path'])) == BASE['index_sha256']
    assert hashlib.sha256(git_parent('ls-files', '--stage', '-z')).hexdigest() == BASE['full_index_records_sha256']
    assert not git_parent('diff', '--name-only')
    for record in BASE['untracked']:
        assert sha(PARENT / record['path']) == record['sha256']
    assert sha(TOOL) == TOOL_SHA
    return state


def child_environment():
    # This cleanup happens only after source capture, never to parent Git reads.
    result = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
    result.update(GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull,
                  GIT_CONFIG_SYSTEM=os.devnull, PYTHONDONTWRITEBYTECODE='1',
                  NEXUS_BUILD_JOBS='1')
    return result


def inputs(project):
    return [{'relative': p.relative_to(project).as_posix(),
             'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted(project.rglob('*'))
            if p.is_file() and '.git' not in p.relative_to(project).parts]


def actual(stage, argv, project):
    before = guard()
    parent_environment = dict(os.environ)
    source_before = inputs(project)
    folder = ROOT / 'evidence'
    folder.mkdir(exist_ok=True)
    output = folder / (stage + '-result.json')
    assert not output.exists()
    result = process.run(argv, cwd=project, env=child_environment(),
                         log=folder / (stage + '.raw'), timeout=60, stage=stage)
    assert os.environ == parent_environment
    source_after = inputs(project)
    assert source_before == source_after
    after = guard()
    record = {'stage': stage, 'actual_exit': result.returncode,
              'argv': list(map(str, argv)), 'cwd': str(project),
              'tool': {'path': str(TOOL), 'sha256': TOOL_SHA},
              'inputs': source_before, 'source_stable': True,
              'parent_index_unchanged': True, 'before': before, 'after': after,
              'receipt': str(result.receipt_path),
              'removed_inherited_git_names': [k for k in parent_environment if k.startswith('GIT_')],
              'child_config_isolation': {'GIT_CONFIG_NOSYSTEM': '1',
                                         'GIT_CONFIG_GLOBAL': os.devnull,
                                         'GIT_CONFIG_SYSTEM': os.devnull}}
    output.write_text(json.dumps(record, indent=2) + '\n')
    print(result.stdout, end='')
    print(result.stderr, end='', file=sys.stderr)
    print(json.dumps({'stage': stage, 'actual_exit': result.returncode,
                      'inputs': len(source_before), 'receipt': str(result.receipt_path)}), flush=True)
    return record


def initialize(name, files):
    guard()
    project = ROOT / 'projects' / name
    assert not project.exists()
    project.mkdir(parents=True)
    for relative, contents in files.items():
        path = PurePosixPath(relative)
        assert not path.is_absolute() and '..' not in path.parts
        target = project / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(contents)
    actual(name + '-git-init', ['git', 'init', '-q', '--template=', '.'], project)
    actual(name + '-git-add', ['git', 'add', '--all'], project)
    return project


def lint(name, project):
    paths = sorted(p.relative_to(project).as_posix()
                   for p in (project / '.github/workflows').glob('*')
                   if p.suffix in ('.yml', '.yaml'))
    assert paths
    return actual(name, [str(TOOL), '-shellcheck=', '-pyflakes=', '-no-color', *paths], project)


def full():
    guard()
    records = (ROOT / 'parent-index-records.raw').read_bytes()
    assert hashlib.sha256(records).hexdigest() == BASE['full_index_records_sha256']
    files, identities = {}, []
    for record in records.split(b'\0'):
        if not record:
            continue
        header, raw_path = record.split(b'\t', 1)
        mode, oid, stage = header.decode().split()
        path = os.fsdecode(raw_path)
        selected = (path.startswith('.github/workflows/') and Path(path).suffix in ('.yml', '.yaml')) or Path(path).name in ('action.yml', 'action.yaml') or path in ('.github/actionlint.yml', '.github/actionlint.yaml')
        if not selected:
            continue
        assert stage == '0' and mode in ('100644', '100755')
        contents = git_parent('cat-file', 'blob', oid)
        files[path] = contents
        identities.append({'path': path, 'mode': mode, 'oid': oid,
                           'bytes': len(contents),
                           'sha256': hashlib.sha256(contents).hexdigest()})
    assert len(files) == 13
    fixed = '.github/workflows/software-qualification.yml'
    assert hashlib.sha256(files[fixed]).hexdigest() == '0c96220022feb037b3a93c6eda55b19d52b8276766a4a32ece9b01eefd127d8c'
    (ROOT / 'captured-parent-inputs.json').write_text(json.dumps(identities, indent=2) + '\n')
    bad_files = dict(files)
    bad_files[fixed] = (ROOT / 'old-bad-workflow.yml.raw').read_bytes()
    bad = initialize('complete-old-bad', bad_files)
    red = lint('complete-old-bad-lint', bad)
    good = initialize('complete-published-fix', files)
    green = lint('complete-published-fix-lint', good)
    (ROOT / 'whole-workflow-results.json').write_text(json.dumps({'red': red, 'green': green}, indent=2) + '\n')


if __name__ == '__main__':
    assert sys.argv[1] == 'full'
    full()
