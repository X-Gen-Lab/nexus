from pathlib import Path
import gzip,hashlib,json,os,shutil,sys,time
ROOT=Path('/tmp/nexus-h743-fixed-hsi-s0-20261018')
OUT=Path('/workspace/nexus-io-recovery-20261018/features/workflow-actionlint-r1')
TMP=Path('/tmp/nexus-workflow-actionlint-20261018-r1')
def guard():
 m=Path('/sys/fs/cgroup'); e=dict(x.split() for x in (m/'memory.events').read_text().splitlines())
 g={'tmp_free':shutil.disk_usage('/tmp').free,'persistent_free':shutil.disk_usage(OUT).free,'memory_available':int((m/'memory.max').read_text())-int((m/'memory.current').read_text()),'events':e}
 assert g['tmp_free']>=200*1024**2 and g['persistent_free']>=64*1024**2 and g['memory_available']>=600*1024**2 and not any(int(e[k]) for k in ('oom','oom_kill','oom_group_kill')),g
 with (TMP/'guards.jsonl').open('a') as f:f.write(json.dumps({'time_ns':time.time_ns(),**g})+'\n')
 return g
def put(name,data,revision):
 guard();data=data.encode() if isinstance(data,str) else data
 p=OUT/'authored'/revision/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 target=ROOT/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 assert target.read_bytes()==data
 return target
def edit(name,old,new,revision):
 data=(ROOT/name).read_text();assert old in data,name;return put(name,data.replace(old,new),revision)
if __name__=='__main__':
 sys.path.insert(0,str(ROOT));from tools.dev.process import run
 guard();label=sys.argv[1];command=sys.argv[2:]
 result=run(command,cwd=ROOT,env={**os.environ,'PRE_COMMIT_HOME':'/tmp/nexus-io-precommit-recovery-20261018','PIP_CACHE_DIR':'/tmp/nexus-io-pip-cache-recovery-20261018','VIRTUALENV_OVERRIDE_APP_DATA':'/tmp/nexus-io-virtualenv-appdata-20261018','PIP_CONSTRAINT':'/workspace/nexus-io-recovery-20261018/python-hook-constraints-r1.txt','NEXUS_BUILD_JOBS':'1','CMAKE_BUILD_PARALLEL_LEVEL':'1','PATH':'/workspace/nexus-build-system-20261012/.venv/bin'+os.pathsep+'/tmp/nexus-io-tools-recovery-20261018/arm-gnu-toolchain-14.3.rel1-x86_64-arm-none-eabi/bin'+os.pathsep+os.environ.get('PATH',''),'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(TMP),'NEXUS_ACTIONLINT_TEST_PREFIX':str(TMP/'tool-prefix'),'NEXUS_ACTIONLINT_TEST_EVIDENCE':str(TMP/'test-evidence'/label)},log=TMP/'runs'/f'{label}.log',timeout=900 if label.startswith("whole-testing") else 240,stage=label)
 print('actual exit',result.returncode);sys.exit(result.returncode)
