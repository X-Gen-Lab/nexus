from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
base=Path('/workspace/nexus-io-recovery-20261018/features/workflow-actionlint-r1')
files=sorted(p for p in (base/'authored').rglob('*') if p.is_file())
rows=[{'path':str(p.relative_to(base)),'bytes':p.stat().st_size,
       'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
       'mode':p.stat().st_mode & 0o777} for p in files]
archive=base/'authored-history-r1.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as output:
 for p in files:output.add(p,arcname=str(p.relative_to(base)),recursive=False)
with tarfile.open(archive,'r:gz') as content:
 members=content.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):
  data=content.extractfile(member).read()
  assert member.name==row['path'] and len(data)==row['bytes']
  assert hashlib.sha256(data).hexdigest()==row['sha256']
  assert member.mode==row['mode']
(base/'authored-history-map-r1.json.gz').write_bytes(
 gzip.compress((json.dumps(rows,indent=2)+'\n').encode(),mtime=0))
# Only this task's newly authored, verified transport copies are compacted.
# The live authoring source, original before-images and all raw remain intact.
shutil.rmtree(base/'authored')
print('packed',len(rows),'full source revisions',archive.stat().st_size)
