from pathlib import Path
import json,os,sys
sys.path.insert(0,'/tmp/nexus-workflow-actionlint-20261018-r1')
from author import TMP,guard
sys.path.insert(0,'/tmp/nexus-h743-fixed-hsi-s0-20261018')
from tools.dev import process
base=TMP/'lazy-git-probe';assert not base.exists();base.mkdir()
origin=base/'origin.git';partial=base/'partial';partial.mkdir()
env={key:value for key,value in os.environ.items() if not key.startswith('GIT_')}|{'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull,'GIT_CONFIG_SYSTEM':os.devnull}
def actual(label,args,cwd=base,extra=None,expected=0):
 result=process.run(['git',*args],cwd=cwd,env=env|(extra or {}),log=base/(label+'.log'),timeout=30,stage=label)
 assert result.returncode==expected,(label,result.returncode,result.stderr)
 return result.stdout
actual('init-local-origin',['init','--bare','--quiet',str(origin)])
actual('init-partial',['init','--quiet'],cwd=partial)
for name,value in [('uploadpack.allowAnySHA1InWant','true'),('uploadpack.allowFilter','true')]:
 actual('origin-'+name.replace('.','-'),['--git-dir',str(origin),'config',name,value])
payload=base/'payload.raw';payload.write_bytes(b'local offline lazy-fetch capability probe\n')
oid=actual('origin-object',['--git-dir',str(origin),'hash-object','-w',str(payload)]).strip()
for number,(name,value) in enumerate([('core.repositoryformatversion','1'),('extensions.partialClone','origin'),('remote.origin.url',origin.as_uri()),('remote.origin.promisor','true')]):
 actual('partial-config-'+str(number),['config',name,value],cwd=partial)
blocked=actual('env-disables-lazy-fetch',['cat-file','-s',oid],cwd=partial,extra={'GIT_NO_LAZY_FETCH':'1'},expected=128)
actual('flag-confirms-still-absent',['--no-lazy-fetch','cat-file','-e',oid],cwd=partial,expected=1)
size=actual('ordinary-read-fetches-only-local-file-origin',['cat-file','-s',oid],cwd=partial)
report={'installed_git':'2.52.0','GIT_NO_LAZY_FETCH_1_supported':True,'blocked_exit':128,'object_still_absent_after_block':True,'ordinary_local_origin_read_exit':0,'ordinary_size':int(size),'payload_bytes':payload.stat().st_size,'transport':'file:// dedicated scratch origin; no clone, external network or production repository','classification':'offline read contract hardening capability probe; not production behavior RED','guards':guard()}
assert int(size)==payload.stat().st_size
(base/'probe-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
