from pathlib import Path
import hashlib,importlib.util,json,os,shutil,sys
sys.path.insert(0,'/tmp/nexus-workflow-actionlint-20261018-r1')
from author import ROOT,TMP,guard
sys.path.insert(0,str(ROOT))
from tools.dev import process
spec=importlib.util.spec_from_file_location('probe_lint',ROOT/'scripts/ci/lint_workflows.py')
lint=importlib.util.module_from_spec(spec);spec.loader.exec_module(lint)
spec=importlib.util.spec_from_file_location('probe_cases',ROOT/'scripts/ci/test_lint_workflows.py')
cases=importlib.util.module_from_spec(spec);spec.loader.exec_module(cases)
base=TMP/'replace-probe';assert not base.exists();base.mkdir()
root=base/'project';root.mkdir();env=cases.isolated_environment()
def actual(label,args):
 result=process.run(['git',*args],cwd=root,env=env,log=base/(label+'.log'),timeout=30,stage=label)
 assert result.returncode==0,(label,result.returncode,result.stderr)
 return result.stdout
for name,data in (('dependencies/actionlint.lock.json',(ROOT/'dependencies/actionlint.lock.json').read_bytes()),('dependencies/workflow-tools.txt',(ROOT/'dependencies/workflow-tools.txt').read_bytes()),('.github/workflows/check.yml',cases.BAD.encode())):
 target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
actual('git-init',['init','--quiet']);actual('git-stage',['add','.'])
bad=actual('bad-index-oid',['rev-parse',':.github/workflows/check.yml']).strip()
good_file=root/'good-workflow.raw';good_file.write_text(cases.GOOD)
good=actual('good-object',['hash-object','-w',str(good_file)]).strip()
before=(root/'.git/index').read_bytes()
actual('create-replacement',['replace',bad,good])
observed=actual('actual-default-object-read',['cat-file','blob',bad])
actual('unchanged-index-records',['ls-files','--stage','-z'])
original=dict(os.environ)
try:
 os.environ.clear();os.environ.update(env)
 result=lint.staged(root,TMP/'tool-prefix',base/'driver.log')
finally:
 os.environ.clear();os.environ.update(original)
after=(root/'.git/index').read_bytes()
report={'bad_index_oid':bad,'replacement_good_oid':good,'default_git_read_equals_good':observed==cases.GOOD,'actual_driver_exit':result,'effective_index_unchanged':before==after,'index_sha256':hashlib.sha256(before).hexdigest(),'driver_sha256':hashlib.sha256((ROOT/'scripts/ci/lint_workflows.py').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((TMP/'tool-prefix/actionlint').read_bytes()).hexdigest(),'guards':guard()}
(base/'probe-report.json').write_text(json.dumps(report,indent=2)+'\n')
assert report['default_git_read_equals_good'] and report['effective_index_unchanged']
assert result==0,'Candidate bypass did not reproduce; do not modify production blindly'
print(json.dumps(report))
