from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
base=Path('/tmp/nexus-workflow-actionlint-20261018-r1')
files=sorted(p for p in (base/'test-evidence').rglob('*') if p.is_file())
rows=[{'path':str(p.relative_to(base)),'bytes':p.stat().st_size,
       'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
       'mode':p.stat().st_mode & 0o777} for p in files]
archive=base/'original-test-evidence-r1.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as output:
 for p in files:output.add(p,arcname=str(p.relative_to(base)),recursive=False)
with tarfile.open(archive,'r:gz') as content:
 members=content.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):
  data=content.extractfile(member).read()
  assert member.name==row['path'] and len(data)==row['bytes']
  assert hashlib.sha256(data).hexdigest()==row['sha256']
  assert member.mode==row['mode']
(base/'original-test-evidence-map-r1.json.gz').write_bytes(
 gzip.compress((json.dumps(rows,indent=2)+'\n').encode(),mtime=0))
shutil.rmtree(base/'test-evidence')
print('verified original test evidence',len(rows),'members',archive.stat().st_size)
