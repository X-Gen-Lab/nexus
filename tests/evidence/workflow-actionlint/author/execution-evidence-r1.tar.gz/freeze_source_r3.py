from pathlib import Path
import difflib,gzip,hashlib,json,os,shutil,subprocess
import sys
sys.path.insert(0,'/tmp/nexus-workflow-actionlint-20261018-r1')
from author import ROOT,TMP,OUT,guard
sha=lambda b:hashlib.sha256(b).hexdigest()
guards=guard();baseline=json.loads((OUT/'baseline.json').read_text())
prior=json.loads((OUT/'source-freeze-r2.json').read_text())
paths=json.loads((TMP/'final-source-paths.json').read_text())
index=(ROOT/'.git/index').read_bytes()
assert index==gzip.decompress((OUT/'before/index.gz').read_bytes())
for row in baseline['unrelated_untracked']:
 b=(ROOT/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
records=subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT,env=env)
assert sha(records)==baseline['full_index_records_sha256']
rows=[];patch=[]
for name,previous in zip(paths,prior['sources']):
 assert name==previous['path']
 data=(ROOT/name).read_bytes();before=OUT/'before'/f'{name}.gz'
 old=gzip.decompress(before.read_bytes()) if before.exists() else b''
 if sha(data)==previous['after']['sha256']:
  transport=previous['transport'];assert (OUT/transport).read_bytes()==data
 else:
  transport='files-r3/'+name;target=OUT/transport;assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
 rows.append({'path':name,'before':previous['before'],'after':{'bytes':len(data),'sha256':sha(data)},'transport':transport})
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+name if before.exists() else '/dev/null',tofile='b/'+name))
(OUT/'source-r3.diff').write_text(''.join(patch))
freeze={'schema_version':1,'kind':'workflow_actionlint_source_freeze','revision':3,'base_commit':baseline['head'],'branch':baseline['branch'],'source_count':14,'sources':rows,'source_diff_sha256':sha((OUT/'source-r3.diff').read_bytes()),'prior_freeze_sha256':sha((OUT/'source-freeze-r2.json').read_bytes()),'index_bytes':len(index),'index_sha256':sha(index),'full_index_records_sha256':baseline['full_index_records_sha256'],'unrelated_11_unchanged':True,'guards':guards,'production_scope':'Host GitHub Actions DSL lint only; no SDK, firmware, remote dispatch or hardware qualification.'}
(OUT/'source-freeze-r3.json').write_text(json.dumps(freeze,indent=2)+'\n')
print('source freeze r3',sha((OUT/'source-freeze-r3.json').read_bytes()),'diff',freeze['source_diff_sha256'])
