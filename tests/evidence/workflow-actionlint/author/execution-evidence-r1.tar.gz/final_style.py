from pathlib import Path
import json,sys
sys.path.insert(0,'/tmp/nexus-h743-fixed-hsi-s0-20261018')
from scripts.ci import style_gate
base=Path('/tmp/nexus-workflow-actionlint-20261018-r1')
paths=json.loads((base/'final-source-paths.json').read_text())
result=style_gate.run_checks(base/'final-fixture',paths,base_ref='HEAD')
(base/'strict-style.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'selected':result['selected_files'],'errors':result['errors']}))
raise SystemExit(bool(result['errors']))
