from pathlib import Path
import difflib,gzip,hashlib,json,os,shutil,subprocess
import sys
sys.path.insert(0,'/tmp/nexus-workflow-actionlint-20261018-r1')
from author import ROOT,TMP,OUT,guard
sha=lambda b:hashlib.sha256(b).hexdigest()
guards=guard()
baseline=json.loads((OUT/'baseline.json').read_text())
paths=json.loads((TMP/'final-source-paths.json').read_text())
assert len(paths)==14 and len(set(paths))==14
index=(ROOT/'.git/index').read_bytes()
assert index==gzip.decompress((OUT/'before/index.gz').read_bytes())
for row in baseline['unrelated_untracked']:
 b=(ROOT/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,env=env)
assert git('rev-parse','HEAD').decode().strip()==baseline['head']
assert sha(git('ls-files','--stage','-z'))==baseline['full_index_records_sha256']
changed=set(git('diff','--name-only','-z').decode().strip('\0').split('\0'))
assert changed<=set(paths)
rows=[];patch=[]
for name in paths:
 source=ROOT/name;data=source.read_bytes();before=OUT/'before'/f'{name}.gz'
 old=gzip.decompress(before.read_bytes()) if before.exists() else b''
 target=OUT/'files'/name;assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
 assert target.read_bytes()==data
 rows.append({'path':name,'before':{'bytes':len(old),'sha256':sha(old)} if before.exists() else {'absent':True},'after':{'bytes':len(data),'sha256':sha(data)},'transport':'files/'+name})
 patch.extend(difflib.unified_diff(old.decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+name if before.exists() else '/dev/null',tofile='b/'+name))
(OUT/'source.diff').write_text(''.join(patch))
freeze={'schema_version':1,'kind':'workflow_actionlint_source_freeze','base_commit':baseline['head'],'branch':baseline['branch'],'source_count':14,'sources':rows,'source_diff_sha256':sha((OUT/'source.diff').read_bytes()),'index_bytes':len(index),'index_sha256':sha(index),'full_index_records_sha256':baseline['full_index_records_sha256'],'unrelated_11_unchanged':True,'guards':guards,'production_scope':'Host GitHub Actions DSL lint only; no SDK, firmware, remote dispatch or hardware qualification.'}
(OUT/'source-freeze-r1.json').write_text(json.dumps(freeze,indent=2)+'\n')
print('source freeze',sha((OUT/'source-freeze-r1.json').read_bytes()),'diff',freeze['source_diff_sha256'])
