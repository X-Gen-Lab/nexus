"""Real pinned actionlint against isolated Git indexes and local metadata."""

from contextlib import redirect_stderr
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from tools.dev import dependencies

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location(
    "lint_workflows", ROOT / "scripts/ci/lint_workflows.py")
LINT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(LINT)
GOOD = """name: Fixture
on: push
jobs:
  check:
    runs-on: ubuntu-24.04
    steps:
      - run: echo ok
"""
BAD = GOOD.replace("    steps:", "    env:\n      BAD: ${{ runner.temp }}\n    steps:")
METADATA = """name: Fixture
description: Local action
inputs:
  message:
    description: Message
    required: true
runs:
  using: composite
  steps:
    - run: echo '${{ inputs.message }}'
      shell: bash
"""
REUSABLE = """name: Reusable
on:
  workflow_call:
    inputs:
      message:
        required: true
        type: string
jobs:
  check:
    runs-on: ubuntu-24.04
    steps:
      - run: echo ok
"""


def isolated_environment():
    return {key: value for key, value in os.environ.items()
            if not key.startswith("GIT_")} | {
                "GIT_CONFIG_NOSYSTEM": "1",
                "GIT_CONFIG_GLOBAL": os.devnull,
                "GIT_CONFIG_SYSTEM": os.devnull,
            }


class WorkflowLintTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.prefix = Path(os.environ.get(
            "NEXUS_ACTIONLINT_TEST_PREFIX", ROOT / ".venv/nexus-actionlint"))
        dependencies.verify_actionlint(
            cls.prefix, ROOT / "dependencies/actionlint.lock.json")

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="workflow-lint-test-")
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.root = self.base / "project"
        self.root.mkdir()
        self.env = isolated_environment()
        self.git("init", "--quiet")
        self.write("dependencies/actionlint.lock.json", (
            ROOT / "dependencies/actionlint.lock.json").read_bytes())
        self.write("dependencies/workflow-tools.txt", (
            ROOT / "dependencies/workflow-tools.txt").read_bytes())
        self.write(".github/workflows/check.yml", GOOD)
        self.git("add", ".")
        self.index = self.root / ".git/index"
        self.before = self.index.read_bytes()

    def git(self, *arguments, input=None, env=None):
        return subprocess.run(
            ["git", *arguments], cwd=self.root,
            env=self.env if env is None else env, input=input,
            capture_output=True, check=True).stdout

    def write(self, name, data):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data.encode() if isinstance(data, str) else data)
        return path

    def stage(self, name, data):
        self.write(name, data)
        self.git("add", "--", name)
        self.before = self.index.read_bytes()

    def lint(self, **kwargs):
        with patch.dict(os.environ, self.env, clear=True):
            result = LINT.staged(
                self.root, self.prefix, self.base / "lint.log", **kwargs)
        self.assertEqual(self.index.read_bytes(), self.before)
        return result

    def reject(self, pattern):
        with self.assertRaisesRegex(LINT.WorkflowError, pattern):
            self.lint()

    def test_valid_full_index_ignores_bad_unstaged_workflow(self):
        self.write(".github/workflows/check.yml", BAD)
        self.assertEqual(self.lint(), 0)

    def test_bad_staged_context_cannot_hide_behind_good_worktree(self):
        self.stage(".github/workflows/check.yml", BAD)
        self.write(".github/workflows/check.yml", GOOD)
        self.assertEqual(self.lint(), 1)
        self.assertIn("context", (self.base / "lint.log").read_text())

    def test_all_workflows_are_checked_not_only_index_delta(self):
        self.stage(".github/workflows/unchanged.yml", BAD)
        self.git("-c", "user.name=Fixture", "-c", "user.email=f@example.org",
                 "commit", "--quiet", "--no-verify", "-m", "fixture")
        self.before = self.index.read_bytes()
        self.assertEqual(self.lint(), 1)

    def test_alternate_index_selection_is_preserved_only_in_parent(self):
        alternate = self.base / "alternate-index"
        shutil.copyfile(self.index, alternate)
        env = {**self.env, "GIT_INDEX_FILE": str(alternate),
               "GIT_DIR": str(self.root / ".git"),
               "GIT_WORK_TREE": str(self.root)}
        self.write(".github/workflows/check.yml", BAD)
        self.git("add", ".github/workflows/check.yml", env=env)
        self.write(".github/workflows/check.yml", GOOD)
        before = alternate.read_bytes()
        with patch.dict(os.environ, env, clear=True):
            self.assertEqual(LINT.staged(
                self.root, self.prefix, self.base / "alternate.log"), 1)
        self.assertEqual(alternate.read_bytes(), before)
        self.assertEqual(self.index.read_bytes(), self.before)

    def test_unstaged_and_ambient_config_cannot_suppress_bad_context(self):
        self.stage(".github/workflows/check.yml", BAD)
        self.write(".github/actionlint.yaml", "[invalid config")
        self.env["XDG_CONFIG_HOME"] = str(self.base / "ambient")
        ambient = self.base / "ambient/actionlint/actionlint.yaml"
        ambient.parent.mkdir(parents=True)
        ambient.write_text("[invalid config")
        self.assertEqual(self.lint(), 1)

    def test_staged_config_bytes_are_used_over_worktree(self):
        self.stage(".github/actionlint.yaml", "{}\n")
        self.write(".github/actionlint.yaml", "[invalid config")
        self.assertEqual(self.lint(), 0)

    def test_invalid_staged_config_is_not_repaired(self):
        self.stage(".github/actionlint.yaml", "[invalid config")
        self.write(".github/actionlint.yaml", "{}\n")
        self.assertNotEqual(self.lint(), 0)

    def test_two_staged_config_names_are_rejected(self):
        self.stage(".github/actionlint.yaml", "{}\n")
        self.stage(".github/actionlint.yml", "{}\n")
        self.reject("config")

    def test_reusable_required_input_and_type_are_checked(self):
        self.stage(".github/workflows/reusable.yml", REUSABLE)
        caller = "name: Caller\non: push\njobs:\n  call:\n    uses: ./.github/workflows/reusable.yml\n"
        self.stage(".github/workflows/check.yml", caller)
        self.assertEqual(self.lint(), 1)
        self.stage(".github/workflows/check.yml", caller + "    with:\n      message: hello\n")
        self.assertEqual(self.lint(), 0)
        self.stage(".github/workflows/reusable.yml",
                   REUSABLE.replace("type: string", "type: number"))
        self.stage(".github/workflows/check.yml",
                   caller + "    with:\n      message: hello\n")
        self.assertEqual(self.lint(), 1)

    def local_action(self, suffix="action.yml"):
        self.stage(".github/actions/local/" + suffix, METADATA)
        self.stage(".github/workflows/check.yml", GOOD.replace(
            "      - run: echo ok", "      - uses: ./.github/actions/local\n"
            "        with:\n          message: hello"))

    def test_local_action_staged_inputs_and_outputs_are_checked(self):
        self.local_action()
        self.write(".github/actions/local/action.yml", "[invalid")
        self.assertEqual(self.lint(), 0)
        self.stage(".github/workflows/check.yml", GOOD.replace(
            "      - run: echo ok", "      - uses: ./.github/actions/local\n"
            "        with:\n          unexpected: hello"))
        self.assertEqual(self.lint(), 1)

    def test_action_yaml_metadata_is_supported(self):
        self.local_action("action.yaml")
        self.assertEqual(self.lint(), 0)

    def test_missing_local_action_directory_fails_closed(self):
        self.stage(".github/workflows/check.yml", GOOD.replace(
            "      - run: echo ok", "      - uses: ./absent"))
        self.reject("metadata")

    def test_deleted_metadata_cannot_be_rescued_by_worktree(self):
        self.local_action()
        path = self.root / ".github/actions/local/action.yml"
        self.git("rm", "--cached", "--", str(path))
        self.before = self.index.read_bytes()
        self.reject("metadata")

    def test_missing_reusable_is_rejected(self):
        self.stage(".github/workflows/check.yml", "name: Missing\non: push\njobs:\n  call:\n    uses: ./.github/workflows/missing.yml\n")
        self.reject("reusable")

    def test_composite_direct_local_reference_closure_is_checked(self):
        self.local_action()
        self.stage(".github/actions/local/action.yml", METADATA.replace(
            "    - run: echo '${{ inputs.message }}'\n      shell: bash",
            "    - uses: ./missing-nested"))
        self.reject("metadata")

    def test_local_reference_escape_and_ambiguous_metadata_are_rejected(self):
        self.stage(".github/workflows/check.yml", GOOD.replace(
            "      - run: echo ok", "      - uses: ./../outside"))
        self.reject("local reference")
        self.local_action()
        self.stage(".github/actions/local/action.yaml", METADATA)
        self.reject("metadata")

    def test_symlink_metadata_and_case_aliases_are_rejected(self):
        self.local_action()
        blob = self.git("hash-object", "-w", "--stdin", input=b"outside\n")
        self.git("update-index", "--cacheinfo", "120000", blob.strip().decode(),
                 ".github/actions/local/action.yml")
        self.before = self.index.read_bytes()
        self.reject("regular")

    def test_staged_lock_mismatch_cannot_hide_behind_worktree(self):
        lock = (self.root / "dependencies/actionlint.lock.json").read_bytes()
        data = json.loads(lock)
        data["version"] = "0.0.0"
        self.stage("dependencies/actionlint.lock.json", json.dumps(data))
        self.write("dependencies/actionlint.lock.json", lock)
        self.reject("lock")

    def test_pyyaml_uses_existing_staged_version_authority(self):
        self.stage("dependencies/workflow-tools.txt", "PyYAML==0.0.0\n")
        self.reject("PyYAML")

    def test_unmerged_entry_fails_before_tool_execution(self):
        name = ".github/workflows/check.yml"
        oid = self.git("rev-parse", ":" + name).strip()
        self.git("update-index", "--index-info", input=(
            b"0 " + b"0" * 40 + b"\t" + name.encode() + b"\n" +
            b"100644 " + oid + b" 1\t" + name.encode() + b"\n"))
        self.before = self.index.read_bytes()
        self.reject("unmerged")

    def test_actual_timeout_is_nonzero_and_retains_receipt(self):
        self.assertEqual(self.lint(timeout=0.000001), 124)
        receipt = json.loads((self.base / "lint.command.json").read_text())
        self.assertEqual(receipt["exit_code"], 124)

    def test_index_mutation_during_actual_tool_execution_is_rejected(self):
        actual = LINT.process.run
        def mutate(command, **kwargs):
            result = actual(command, **kwargs)
            self.write("unrelated.txt", "changed by another process\n")
            self.git("add", "unrelated.txt")
            return result
        with patch.object(LINT.process, "run", side_effect=mutate):
            with self.assertRaisesRegex(LINT.WorkflowError, "index changed"):
                self.lint()

    def test_missing_tool_is_setup_failure_without_network(self):
        with self.assertRaisesRegex(LINT.WorkflowError, "prepare"):
            LINT.staged(self.root, self.base / "absent", self.base / "missing.log")

    def test_report_cannot_overwrite_input_or_tool(self):
        with self.assertRaisesRegex(LINT.WorkflowError, "output"):
            LINT.staged(self.root, self.prefix,
                        self.root / ".github/workflows/check.yml")
        self.assertEqual((self.root / ".github/workflows/check.yml").read_text(), GOOD)


if __name__ == "__main__":
    unittest.main()
