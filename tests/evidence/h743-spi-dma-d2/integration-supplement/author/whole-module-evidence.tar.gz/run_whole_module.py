import argparse,hashlib,json,pathlib,resource,sys,time,unittest
parser=argparse.ArgumentParser();parser.add_argument('module');parser.add_argument('report');args=parser.parse_args()
class Result(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.subtests=0
    def addSubTest(self,test,subtest,err):self.subtests+=1;super().addSubTest(test,subtest,err)
root=pathlib.Path.cwd();sub=pathlib.Path('/workspace/nexus-io-recovery-20261018/features/h743-spi-dma-d2/supplement-integration-r1')
source=[x['path'] for x in json.loads((sub/'bootstrap.json').read_text())['before']]
def identities():return {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in source}
before=identities();started=time.time_ns();suite=unittest.defaultTestLoader.loadTestsFromName(args.module);expected=suite.countTestCases();result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite);after=identities()
record={'module':args.module,'discovered':expected,'executed':result.testsRun,'subtests':result.subtests,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'expected_failures':len(result.expectedFailures),'unexpected_successes':len(result.unexpectedSuccesses),'started_ns':started,'finished_ns':time.time_ns(),'source_before':before,'source_after':after,'full_module_no_filters':True,'self_maxrss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
record['actual_exit']=0 if expected>0 and result.testsRun==expected and result.wasSuccessful() and not result.skipped and not result.expectedFailures and before==after else 1
pathlib.Path(args.report).write_text(json.dumps(record,indent=2)+'\n');sys.exit(record['actual_exit'])
