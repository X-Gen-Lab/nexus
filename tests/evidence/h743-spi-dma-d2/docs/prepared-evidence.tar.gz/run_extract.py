import hashlib,json,os,pathlib,resource,subprocess,sys,time
ROOT=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018')
OUT=pathlib.Path('/dev/shm/nexus-h743-d2-capabilities-gettext-20261018-r1')
PREFIX=pathlib.Path('/tmp/nexus-recovery-docs-tools-20261018-r1')
sys.path.insert(0,str(ROOT))
from tools.dev import process
from tools.documentation import install,sphinx_ext
from tools.evidence.identity import observe_git_source
MAX=40*1024*1024

def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def allocated():return sum(p.lstat().st_blocks*512 for p in OUT.rglob('*'))+OUT.stat().st_blocks*512
def metrics():
 cg=pathlib.Path('/sys/fs/cgroup')
 return {'cgroup_current':int((cg/'memory.current').read_text()),'cgroup_max':int((cg/'memory.max').read_text()),'events':dict(line.split() for line in (cg/'memory.events').read_text().splitlines()),'output_allocated':allocated(),'persistent_free':os.statvfs('/workspace').f_bavail*os.statvfs('/workspace').f_frsize}
def guard():
 m=metrics()
 assert m['cgroup_max']-m['cgroup_current']>=600*1024*1024,m
 assert m['persistent_free']>=64*1024*1024,m
 assert m['output_allocated']<=MAX,m
 return m
def write(name,value):
 (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
record={'kind':'targeted_capabilities_gettext_not_html_or_firmware_qualification','resource_limit_bytes':MAX,'phases':[],'before_resources':guard()}
record['source_before']=observe_git_source(ROOT)
index=pathlib.Path(subprocess.check_output(['git','rev-parse','--git-path','index'],cwd=ROOT,text=True).strip())
if not index.is_absolute():index=ROOT/index
record['index_sha256_before']=sha(index)
record['tools']=install.diagnose(PREFIX)
env=install.environment(PREFIX)
for key in tuple(env):
 if key.startswith('NEXUS_DOCS_'):env.pop(key)
policy=json.loads((ROOT/'dependencies/platform-compatibility.json').read_text())
env.update({'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','NEXUS_DOCS_TOOL_PREFIX':str(PREFIX),'NEXUS_DOCS_REVISION':record['source_before']['commit'],'NEXUS_DOCS_CODE_REVISION':record['source_before']['commit'],'NEXUS_DOCS_VERSION':policy['semantic_version'],'NEXUS_DOCS_LANGUAGE':'en','NEXUS_DOCS_LANGUAGES':'en,zh_CN','NEXUS_DOCS_DOXYGEN_XML':str(OUT/'api/xml'),'NEXUS_DOCS_GETTEXT_ROOT':str(OUT/'gettext'),'NEXUS_DOCS_TRANSLATION_ROOT':str(ROOT/'docs/locale')})
(OUT/'Doxyfile').write_text(f'@INCLUDE = "{ROOT}/Doxyfile"\nOUTPUT_DIRECTORY = "{OUT}/api"\nPROJECT_NUMBER = "{policy["semantic_version"]}"\nGENERATE_HTML = NO\nDOT_NUM_THREADS = 1\n')
commands=[('doxygen',[str(PREFIX/'bin/doxygen'),str(OUT/'Doxyfile')]),('gettext',[str(PREFIX/'venv/bin/python'),'-B','-m','sphinx','-E','-n','-W','--keep-going','-j','1','-b','gettext','-c',str(ROOT/'docs/sphinx'),'-d',str(OUT/'doctrees'),str(ROOT/'docs'),str(OUT/'gettext'),str(ROOT/'docs/delivery/capabilities.md')])]
try:
 for stage,argv in commands:
  before=guard()
  r=process.run(argv,cwd=ROOT,env=env,log=OUT/(stage+'.raw'),timeout=900,stage='d2-capabilities-'+stage)
  rec={'stage':stage,'returncode':r.returncode,'receipt':str(r.receipt_path),'before':before,'after':metrics()}
  record['phases'].append(rec);write('execution.json',record)
  if r.returncode:raise RuntimeError(f'{stage} actual exit {r.returncode}')
  guard()
 record['source_after']=observe_git_source(ROOT)
 record['index_sha256_after']=sha(index)
 assert record['source_before']==record['source_after']
 assert record['index_sha256_before']==record['index_sha256_after']
 pot=OUT/'gettext/delivery/capabilities.pot'
 metadata,msgs,fuzzy=sphinx_ext.read_catalog(pot)
 record.update({'status':'passed','source_unchanged':True,'pot_files':[p.relative_to(OUT).as_posix() for p in sorted((OUT/'gettext').rglob('*.pot'))],'target_pot_sha256':sha(pot),'target_message_count':len(msgs),'target_fuzzy':fuzzy,'after_resources':guard(),'max_completed_child_rusage_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss})
 write('execution.json',record)
 print(json.dumps({'status':record['status'],'phases':record['phases'],'pot_sha256':record['target_pot_sha256'],'messages':len(msgs),'pot_files':record['pot_files'],'source':record['source_before'],'after_resources':record['after_resources']},ensure_ascii=False))
except BaseException as exc:
 record.update({'status':'failed','error':repr(exc),'after_resources':metrics()});write('execution.json',record);raise
