import hashlib,json,os,pathlib,sys
import polib
ROOT=pathlib.Path('/tmp/nexus-h743-spi-safe-stop-20261018')
OUT=pathlib.Path('/dev/shm/nexus-h743-d2-capabilities-gettext-20261018-r1')
sys.path.insert(0,str(ROOT))
from tools.documentation import sphinx_ext
POT=OUT/'gettext/delivery/capabilities.pot'
_,required,_=sphinx_ext.read_catalog(POT)
page=ROOT/'docs/delivery/capabilities.md'
source_sha=hashlib.sha256(page.read_bytes()).hexdigest()
assert source_sha=='3ce2824667281bef8c6136cab183183f4f00929f3a6a2e86acdae4dabab206e2'
report={'source_sha256':source_sha,'pot_sha256':hashlib.sha256(POT.read_bytes()).hexdigest(),'catalogs':[],'qualification':False,'algorithm':'locked polib 1.2.0 exact msgid/context merge; Sphinx template header fuzzy is not catalog fuzzy'}
for language in ('en','zh_CN'):
 rel=f'docs/locale/{language}/LC_MESSAGES/delivery/capabilities.po'
 old=ROOT/rel
 _,old_msgs,old_fuzzy=sphinx_ext.read_catalog(old)
 po=polib.pofile(str(old));po.merge(polib.pofile(str(POT)))
 added=[]
 for entry in po:
  if entry.obsolete:continue
  if entry.msgid not in old_msgs:
   assert all(part.startswith('`') and part.endswith('`') and '/' in part for part in entry.msgid.split(', '))
   entry.msgstr=entry.msgid
   added.append({'msgid':entry.msgid,'msgstr':entry.msgstr,'reason':'verbatim code path symbols'})
 po.metadata.update({'Language':language,'X-Nexus-Source-SHA256':source_sha,'X-Nexus-Reviewed':'false'})
 target=OUT/'merge-r2'/rel
 target.parent.mkdir(parents=True,exist_ok=True);po.save(str(target),newline='\n')
 metadata,after,fuzzy=sphinx_ext.read_catalog(target)
 assert set(after)==set(required) and all(after.values()) and not fuzzy and not old_fuzzy
 assert all(after[k]==v for k,v in old_msgs.items() if k in after)
 assert metadata['X-Nexus-Reviewed']=='false'
 report['catalogs'].append({'path':rel,'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'required_messages':len(after),'retained_unchanged_pairs':sum(k in required for k in old_msgs),'added_pairs':added,'obsolete_messages':[k for k in old_msgs if k not in required],'reviewed':metadata['X-Nexus-Reviewed']})
(OUT/'catalog-merge-review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'prepared_unreviewed','catalogs':[{k:v for k,v in r.items() if k not in ('added_pairs','obsolete_messages')} for r in report['catalogs']]},ensure_ascii=False))
