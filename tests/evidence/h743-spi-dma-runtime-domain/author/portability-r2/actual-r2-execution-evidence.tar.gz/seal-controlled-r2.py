from pathlib import Path
import sys,json,hashlib,shutil,tarfile,stat,difflib,os,gzip,xml.etree.ElementTree as E
sys.path.insert(0,'/dev/shm/nexus-h743-spi-dma-runtime-domain-20261018-r1/portability-r2');import runner as r
F=r.F/'portability-r2';T=r.TMP;r.guard()
def put(p,obj):
 assert not p.exists(),p
 p.write_text(json.dumps(obj,indent=2)+'\n')
base=json.loads((r.F/'manifest.json').read_text())
for x in base['files']:
 p=Path(x['path']);assert r.identity(p)['sha256']==x['sha256']
old=F/'before-model.cpp.raw';new=r.ROOT/'tests/google/h743_spi_dma_model.cpp'
for x in base['sources']:
 if x['path']!='tests/google/h743_spi_dma_model.cpp':assert r.identity(r.ROOT/x['path'])['sha256']==x['sha256']
assert r.identity(r.ROOT/'.git/index')['sha256']==r.B['index']['sha256']
p=F/'files/tests/google/h743_spi_dma_model.cpp';p.parent.mkdir(parents=True);shutil.copy2(new,p)
(F/'source-from-r1.diff.raw').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='r1/model.cpp',tofile='r2/model.cpp')))
put(F/'transport-rejection-r1.json',dict(outcome='exec_server_transport_rejected_before_process_creation',session=None,actual_returncode=None,raw_error='CreateProcess { message: Rejected(Failed to create unified exec process: exec-server transport disconnected) }',controlled_probe='Source, XML, receipts and ASAN ELF retained; rejected seal script and final manifest did not exist. Root unified probe authorized continued sealing.',qualification='Not a test/build execution and not RED.'))
cases=[]
for kind in ['debug','asan']:
 q=E.parse(T/(kind+'.xml')).getroot();assert q.attrib['tests']=='53' and all(q.attrib[k]=='0' for k in ['failures','errors','disabled']);cs=list(q.iter('testcase'));assert len(cs)==53 and all(not c.findall('skipped') for c in cs);cases.append([(c.attrib['classname'],c.attrib['name']) for c in cs])
assert cases[0]==cases[1]
commands=[]
for p in sorted(T.glob('*.attempts/*/receipt.json')):
 q=json.loads(p.read_text());assert q['outcome']=='completed' and q['withdrawal_complete'];commands.append(dict(path=str(p),**q))
assert len(commands)==8
for name in ['debug-whole53-r2','asan-whole53-r2']:
 q=json.loads((T/(name+'.command.json')).read_text());assert q['exit_code']==0 and q['stderr']['bytes']==0
assert json.loads((T/'asan-original-tu-r1.command.json').read_text())['exit_code']==1
for label,B in [('asan',T/'asan-build'),('debug',r.ROOT/'build/native-debug')]:
 rows=[q for q in json.loads((B/'compile_commands.json').read_text()) if 'nexus_h743_spi_dma_test.dir' in q.get('command','')];assert len(rows)==7
 if label=='asan':assert all('-fsanitize=address,undefined' in q['command'] and '-Werror' in q['command'] and '-Wconversion' in q['command'] for q in rows)
 put(T/(label+'-actual-target-compile-commands.json'),rows)
cache=T/'asan-build/CMakeCache.txt';assert 'NEXUS_ENABLE_SANITIZERS:BOOL=ON' in cache.read_text()
put(T/'asan-tool-observation.json',dict(cache=r.identity(cache),compiler=r.identity(Path('/usr/bin/c++').resolve()),sanitizer_options={k:os.environ.get(k) for k in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']}))
leaves=[]
for d,ds,fs in os.walk(T):
 ds[:]=[x for x in ds if x not in ['asan-build','__pycache__']]
 for n in fs:
  p=Path(d)/n
  if not p.is_symlink() and not p.name.endswith('.elf'):leaves.append(p)
entries=[];archive=F/'actual-r2-execution-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(leaves):
  x=r.identity(p);entries.append(dict(member=str(p.relative_to(T)),bytes=x['bytes'],sha256=x['sha256'],mode=stat.S_IMODE(p.stat().st_mode)));tar.add(p,arcname=str(p.relative_to(T)),recursive=False)
put(F/'actual-r2-execution-evidence-map.json',entries)
lookup={q['member']:q for q in entries};seen=set()
with tarfile.open(archive,'r:gz') as tar:
 for q in tar:
  x=lookup[q.name];assert q.isfile() and q.name not in seen and q.size==x['bytes'] and q.mode==x['mode'] and hashlib.file_digest(tar.extractfile(q),'sha256').hexdigest()==x['sha256'];seen.add(q.name)
assert seen==set(lookup)
with gzip.open(archive,'rb') as z:
 while z.read(65536):pass
composed=[]
for x in base['sources']:
 q=dict(x)
 if q['path']=='tests/google/h743_spi_dma_model.cpp':q.update(durable_source=str(F/'files'/q['path']),bytes=new.stat().st_size,sha256=r.identity(new)['sha256'])
 composed.append(q)
facts=r.guard()
put(F/'delivery-result-r2.json',dict(kind='model_width_portability_followup',parent_manifest=r.identity(r.F/'manifest.json'),final_composed_four_sources=composed,only_source_changed='tests/google/h743_spi_dma_model.cpp',semantic_note='Explicit uint32_t boundary only. RXP bit0 and (rx_count modulo4)<<13 occupy bits0,13,14, so all previous register bit values are retained.',compile_RED=dict(actual_returncode=1,stage='asan-original-tu-r1',runtime_RED_claimed=False,diagnostic='same unsigned-long to uint32_t -Wconversion under unchanged ASAN/UBSAN/Werror flags'),debug=dict(build=0,runtime=0,tests=53,failures=0,errors=0,disabled=0,skipped=0,xml=r.identity(T/'debug.xml'),elf=r.identity(T/'debug-matching.elf')),asan=dict(build=0,runtime=0,tests=53,failures=0,errors=0,disabled=0,skipped=0,xml=r.identity(T/'asan.xml'),elf=r.identity(T/'asan-build/bin/nexus_h743_spi_dma_test'),stderr_bytes=0,storage='Real ASAN bin frozen in place; no additional copy to keep TMP80MiB limit.'),style=dict(actual_returncode=0,files=4,report=r.identity(T/'style-whole-four-r2.json')),all_eight_actual_commands=commands,all_children_joined=True,old_three_sources_test_assertions_index_and_r1_records_unchanged=True,old_ELFs_retained=True,archive=r.identity(archive),map=r.identity(F/'actual-r2-execution-evidence-map.json'),verified_member_count=len(entries),gzip_CRC_all_member_SHA_size_mode_verified=True,resources=dict(current=facts,new_TMP_plus_debug_build_delta=facts['tmp_alloc']+facts['build_alloc']-r.B['initial_build_allocated'],cap_bytes=80*1024**2,persistent_cap=1024**2,max_child_rss_kib=max(json.loads(p.read_text())['child_maxrss_kib'] for p in T.glob('*.resources.json')),oom_increase=False),limits=['Native focused Debug+ASAN/UBSAN only; no remote CI success/ARM/SDK/HIL/WCET upgrade.','Original r1 runtime RED/GREEN remains its historical tuple; this round establishes compile RED and two fresh same53 executions.','Root normal full hooks and independent delta review pending.']))
records=[dict(relative=str(p.relative_to(F)),**r.identity(p),mode=stat.S_IMODE(p.stat().st_mode))) for p in sorted(F.rglob('*')) if p.is_file()]
put(F/'manifest-r2.json',dict(kind='frozen_single_source_r2_increment',source_count=1,composed_sources=composed,sources=[q for q in composed if q['path']=='tests/google/h743_spi_dma_model.cpp'],files=records,result=r.identity(F/'delivery-result-r2.json'),source_frozen=True))
rows=[dict(target=q['path'],durable_source=q['durable_source'],bytes=q['bytes'],sha256=q['sha256'],role='source') for q in composed if q['path']=='tests/google/h743_spi_dma_model.cpp']
for q in records+[dict(relative='manifest-r2.json',**r.identity(F/'manifest-r2.json'))]:
 target='tests/evidence/h743-spi-dma-runtime-domain-r1/author/portability-r2/'+q['relative']
 if q['relative'].startswith('files/'):target+='.raw'
 rows.append(dict(target=target,durable_source=q['path'],bytes=q['bytes'],sha256=q['sha256'],role='evidence'))
assert len(rows)==len({q['target'] for q in rows})
put(F/'transport-increment-r2.json',dict(source_count=1,target_count=len(rows),parent_transport_sha256=r.identity(r.F/'transport-map.json')['sha256'],files=rows))
print(json.dumps(dict(manifest=r.identity(F/'manifest-r2.json'),result=r.identity(F/'delivery-result-r2.json'),transport=r.identity(F/'transport-increment-r2.json'),members=len(entries),commands=len(commands),budget=r.guard()),indent=2))
