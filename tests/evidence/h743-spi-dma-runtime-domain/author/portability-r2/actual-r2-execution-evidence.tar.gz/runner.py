from pathlib import Path
import os,sys,json,hashlib,resource,time,threading,shutil,signal
ROOT=Path('/tmp/nexus-io36-native-20261018')
TMP=Path('/dev/shm/nexus-h743-spi-dma-runtime-domain-20261018-r1/portability-r2')
F=Path('/workspace/nexus-io-recovery-20261018/features/h743-spi-dma-runtime-domain-r1')
sys.path.insert(0,str(ROOT))
from tools.dev.process import run
B=json.loads((F/'baseline.json').read_text())
def alloc(p):
 total=0
 for d,ds,fs in os.walk(p):
  for n in ds+fs:
   total+=(Path(d)/n).lstat().st_blocks*512
 return total
def facts():
 c=int(Path('/sys/fs/cgroup/memory.current').read_text()); m=int(Path('/sys/fs/cgroup/memory.max').read_text());v=os.statvfs(F)
 return dict(memory_current=c,memory_max=m,headroom=m-c,persistent_free=v.f_bavail*v.f_frsize,persistent_alloc=alloc(F),tmp_alloc=alloc(TMP.parent),build_alloc=alloc(ROOT/'build/native-debug'),oom=Path('/sys/fs/cgroup/memory.events').read_text())
def guard(compile=False):
 x=facts(); assert x['headroom']>=(900 if compile else 600)*1024**2,x
 assert x['persistent_free']>=64*1024**2,x
 assert x['persistent_alloc']<=1024**2,x
 assert x['tmp_alloc']+max(0,x['build_alloc']-B['initial_build_allocated'])<=80*1024**2,x
 return x
def identity(p):
 return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
def execute(name,argv,compile=False):
 before=guard(compile); stop=threading.Event(); samples=[]
 def monitor():
  while not stop.wait(.25):
   c=int(Path('/sys/fs/cgroup/memory.current').read_text()); samples.append(c)
   if int(Path('/sys/fs/cgroup/memory.max').read_text())-c < 600*1024**2:
    os.kill(os.getpid(), signal.SIGTERM); return
 t=threading.Thread(target=monitor);t.start()
 env=os.environ.copy(); env['PATH']='/workspace/nexus-build-system-20261012/.venv/bin:'+env['PATH'];env.update(CMAKE_BUILD_PARALLEL_LEVEL='1',NEXUS_BUILD_JOBS='1',TMPDIR=str(TMP))
 for k in tuple(env):
  if k.startswith('GTEST_'):del env[k]
 started=time.time_ns()
 try:r=run(argv,cwd=ROOT,env=env,log=TMP/(name+'.raw'),timeout=1800,stage=name)
 finally:stop.set();t.join()
 record=dict(name=name,actual_returncode=r.returncode,started_ns=started,finished_ns=time.time_ns(),before=before,after=facts(),sampled_memory_max=max(samples,default=before['memory_current']),child_maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,receipt=str(r.receipt_path))
 (TMP/(name+'.resources.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 return r.returncode
if __name__=='__main__':
 stage=sys.argv[1];A=TMP/'asan-build'
 if stage=='configure-asan':code=execute('configure-asan-r1',['cmake','--preset','native-asan','-B',str(A)])
 elif stage=='original-tu':code=execute('asan-original-tu-r1',['cmake','--build',str(A),'--target','tests/contracts/google/CMakeFiles/nexus_h743_spi_dma_test.dir/h743_spi_dma_model.cpp.o','--parallel','1'],True)
 elif stage=='build-debug':code=execute('build-debug-r2',['cmake','--build','build/native-debug','--target','nexus_h743_spi_dma_test','--parallel','1'],True)
 elif stage=='build-asan':code=execute('build-asan-r2',['cmake','--build',str(A),'--target','nexus_h743_spi_dma_test','--parallel','1'],True)
 elif stage in ('debug','asan'):
  elf=(ROOT/'build/native-debug' if stage=='debug' else A)/'bin/nexus_h743_spi_dma_test'
  target=TMP/(stage+'-matching.elf') if stage=='debug' else elf
  if stage=='debug':
   assert not target.exists();shutil.copy2(elf,target)
  (TMP/(stage+'-elf.json')).write_text(json.dumps(identity(target),indent=2)+'\n')
  code=execute(stage+'-whole53-r2',[str(elf),'--gtest_output=xml:'+str(TMP/(stage+'.xml'))])
 else:raise SystemExit('unknown stage')
 raise SystemExit(code)
