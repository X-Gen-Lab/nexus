from pathlib import Path
import sys,json,hashlib,tarfile,stat,shutil,gzip,xml.etree.ElementTree as E,os
sys.path.insert(0,str(Path(__file__).parent));import runner as r
sys.path.insert(0,str(r.ROOT/'scripts/ci'));import quality_tools
F=r.F/'analysis-r3';T=r.TMP

def ident(p):
 x=r.identity(p);x['mode']=stat.S_IMODE(p.stat().st_mode);return x

def put(p,obj):
 assert not p.exists(),p
 p.write_text(json.dumps(obj,indent=2)+'\n')

full=json.loads((T/'required-clang-whole831-r3.command.json').read_text())
assert full['outcome']=='completed' and full['exit_code']==0 and full['withdrawal_complete']
report=T/'required-clang-whole831.txt';lines=report.read_text().splitlines()
assert lines[0]=='Owned translation units: 831'
inv=[json.loads(s[len('Invocation: '):]) for s in lines if s.startswith('Invocation: ')]
exitcodes=[int(s[len('Exit code: '):]) for s in lines if s.startswith('Exit code: ')]
assert len(inv)==831 and exitcodes==[0]*831
assert all('--checks='+quality_tools.TIDY_CHECKS in a and '--warnings-as-errors=*' in a for a in inv)
assert not any('error:' in s or 'Analysis execution failed:' in s for s in lines)
assert '14.0.6' in report.read_text()
rows=quality_tools.commands(r.ROOT,r.ROOT/'build/native-debug');assert len(rows)==831
assert r.identity(r.ROOT/'.git/index')['sha256']==r.B['index']['sha256']
parent=json.loads((r.F/'portability-r2/manifest-r2.json').read_text());composed=[]
for x in parent['composed_sources']:
 q=dict(x)
 if q['path']=='soc/stm32h743/drivers/spi_dma.c':
  p=F/'files'/q['path'];assert r.identity(p)['sha256']==r.identity(r.ROOT/q['path'])['sha256'];q.update(durable_source=str(p),bytes=p.stat().st_size,sha256=r.identity(p)['sha256'])
 else:assert r.identity(r.ROOT/q['path'])['sha256']==q['sha256']
 composed.append(q)
oldasan=T/'retained-r2-asan.elf';oldnote=json.loads((F/'r2-retention-and-before-r1.json').read_text());assert r.identity(oldasan)['sha256']==oldnote['retained_r2_asan_elf']['sha256']
for label in ['debug','asan']:
 z=E.parse(T/(label+'-r3.xml')).getroot();assert z.attrib['tests']=='53' and all(z.attrib[k]=='0' for k in ['failures','errors','disabled']);assert not any(q.findall('skipped') for q in z.iter('testcase'))
 for st in [label+'-whole53-r3','build-'+label+'-r3']:
  q=json.loads((T/(st+'.command.json')).read_text());assert q['exit_code']==0 and q['outcome']=='completed'
commands=[]
for p in sorted(T.glob('*.attempts/*/receipt.json')):
 q=json.loads(p.read_text());assert q['outcome']=='completed' and q['withdrawal_complete'];commands.append(q)
assert len(commands)==9
ctx=T/'captured-actual-clang-contexts.tar.gz'
with tarfile.open(ctx,'r:gz') as tar:
 m=json.load(tar.extractfile('member-identities.json'));assert len(m)==833
 lookup={q['member']:q for q in m};seen=set()
 for q in tar:
  if q.name=='member-identities.json':continue
  x=lookup[q.name];assert q.isfile() and q.name not in seen and q.size==x['bytes'] and q.mode==x['mode'];assert hashlib.file_digest(tar.extractfile(q),'sha256').hexdigest()==x['sha256'];seen.add(q.name)
 assert seen==set(lookup)
with gzip.open(ctx,'rb') as z:
 while z.read(65536):pass
skip={'actual-r3-execution-evidence.tar.gz','captured-actual-clang-contexts.tar.gz','asan-r2-compile_commands.json','debug-r2-compile_commands.json','asan-r2-CMakeCache.txt','debug-r2-CMakeCache.txt'}
leaves=[]
for d,ds,fs in os.walk(T):
 ds[:]=[x for x in ds if not x.startswith('nexus-analysis-') and x!='__pycache__']
 for n in fs:
  p=Path(d)/n
  if not p.is_symlink() and not n.endswith('.elf') and n not in skip:leaves.append(p)
raw=T/'actual-r3-execution-evidence.tar.gz';emap=[]
with tarfile.open(raw,'w:gz') as tar:
 for p in sorted(leaves):
  x=ident(p);emap.append(dict(member=str(p.relative_to(T)),bytes=x['bytes'],sha256=x['sha256'],mode=x['mode']));tar.add(p,arcname=str(p.relative_to(T)),recursive=False)
 # Keep the map within the same gzip so one immutable object closes every raw leaf.
 import io
 b=(json.dumps(emap,indent=2)+'\n').encode();q=tarfile.TarInfo('member-identities.json');q.size=len(b);q.mode=0o600;tar.addfile(q,io.BytesIO(b))
with tarfile.open(raw,'r:gz') as tar:
 lookup={q['member']:q for q in emap};seen=set()
 for q in tar:
  if q.name=='member-identities.json':continue
  x=lookup[q.name];assert q.isfile() and q.name not in seen and q.size==x['bytes'] and q.mode==x['mode'];assert hashlib.file_digest(tar.extractfile(q),'sha256').hexdigest()==x['sha256'];seen.add(q.name)
 assert seen==set(lookup)
with gzip.open(raw,'rb') as z:
 while z.read(65536):pass
# Admit the final two immutable archives before adding enclosing small metadata.
facts=r.guard();future=((ctx.stat().st_size+4095)//4096+(raw.stat().st_size+4095)//4096)*4096+32768
assert facts['persistent_alloc']+future<=1048576,(facts,ctx.stat().st_size,raw.stat().st_size)
shutil.copy2(ctx,F/ctx.name);shutil.copy2(raw,F/raw.name)
result=dict(kind='behavior_preserving_required_clang_refactor_delivery',parent_r2_manifest=ident(r.F/'portability-r2/manifest-r2.json'),source_head=r.B['head'],index_sha256=r.B['index']['sha256'],composed_sources=composed,only_changed_source='soc/stm32h743/drivers/spi_dma.c',tests_and_other_sources_byte_identical=True,
 diagnostic_TDD=dict(original_TU_actual_returncode=1,original_diagnostics=4,clone=1,null_flow=3,normal_API_crash_claimed=False,whole_required_clang_actual_returncode=0,contexts=831,invocations=831,zero_exits=831,policy_unchanged=True,tool_handoff=ident(T/'tool-handoff.json'),report=ident(report)),
 runtime=dict(debug=dict(build=0,runtime=0,tests=53,failures=0,errors=0,disabled=0,skipped=0,xml=ident(T/'debug-r3.xml'),elf=ident(T/'debug-matching-r3.elf')),asan=dict(build=0,runtime=0,tests=53,failures=0,errors=0,disabled=0,skipped=0,xml=ident(T/'asan-r3.xml'),elf=ident(T/'asan-matching-r3.elf')),strict_style=dict(actual_returncode=0,files=4,report=ident(T/'strict-style-four-r3.json'))),
 preservation=['Existing initialized/live/busy/pins/deadline/divider MMIO order retained.','Request/endpoint local snapshots prove only request-dependent active phases; configure_stream uses proved borrowed request.','STOP_RX..FINISH still supports NULL-active cold rollback.','Tail drain check reads current owner.active after FINISH; no stale snapshot access after SETTLED.','No new fault/taint/IRQ policy, state or ABI. No private-stage corruption presented as normal public API.','Original r1/r2 manifests/results/source/raw remain immutable; new retained-r2-ASAN path preserves exact old ELF bytes before original build-path reuse.'],
 evidence=dict(actual_clang_contexts=ident(F/ctx.name),context_DB_files=833,all_831_actual_per_context_DBs_captured_before_tool_cleanup=True,raw_archive=ident(F/raw.name),raw_members=len(emap),CRC_SHA_size_mode_verified=True,actual_command_count=len(commands),actual_returncodes=[q['exit_code'] for q in commands],all_children_joined=True),
 retained_r2_asan=ident(oldasan),resource_observation=r.guard(),limits=['Focused dirty independent6d+four-source overlay only; no clean Main/remote CI success/ARM/SDK/HIL/WCET qualification.','Root independent review and normal complete Main gates remain pending.','Current original build paths may contain r3 bytes; old r2 bytes remain at exact new retained path documented before reuse.'])
put(F/'delivery-result-r3.json',result)
records=[]
for p in sorted(F.rglob('*')):
 if p.is_file():records.append(dict(relative=str(p.relative_to(F)),**ident(p)))
manifest=dict(kind='frozen_r3_single_source_refactor_increment',sources=[q for q in composed if q['path']=='soc/stm32h743/drivers/spi_dma.c'],composed_sources=composed,files=records,result=ident(F/'delivery-result-r3.json'),source_frozen=True)
put(F/'manifest-r3.json',manifest)
rows=[dict(target=q['path'],durable_source=q['durable_source'],bytes=q['bytes'],sha256=q['sha256'],role='source') for q in manifest['sources']]
for q in records+[dict(relative='manifest-r3.json',**ident(F/'manifest-r3.json'))]:
 target='tests/evidence/h743-spi-dma-runtime-domain-r1/author/analysis-r3/'+q['relative']
 if q['relative'].startswith('files/'):target+='.raw'
 rows.append(dict(target=target,durable_source=q['path'],bytes=q['bytes'],sha256=q['sha256'],role='evidence'))
assert len(rows)==len({q['target'] for q in rows})
put(F/'transport-increment-r3.json',dict(source_count=1,target_count=len(rows),files=rows))
print(json.dumps(dict(manifest=ident(F/'manifest-r3.json'),result=ident(F/'delivery-result-r3.json'),transport=ident(F/'transport-increment-r3.json'),raw_members=len(emap),budget=r.guard()),indent=2))
