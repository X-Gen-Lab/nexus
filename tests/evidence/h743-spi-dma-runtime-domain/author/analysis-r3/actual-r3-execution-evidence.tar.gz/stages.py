from pathlib import Path
import sys,json,shutil
sys.path.insert(0,str(Path(__file__).parent));import runner as r
sys.path.insert(0,str(r.ROOT/'scripts/ci'));import quality_tools
stage=sys.argv[1]
A=r.TMP.parent/'portability-r2/asan-build'
if stage=='configure':
 code=r.execute('configure-r3-baseline',['cmake','--preset','native-debug'])
elif stage=='tu-red':
 handoff=json.loads((r.TMP/'tool-handoff.json').read_text());tool=handoff['binary']
 rows=quality_tools.commands(r.ROOT,r.ROOT/'build/native-debug');assert len(rows)==831
 selected=[q for q in rows if Path(q['file'])==r.ROOT/'soc/stm32h743/drivers/spi_dma.c'];assert len(selected)==1
 db=r.TMP/'actual-tu-context';db.mkdir();(db/'compile_commands.json').write_text(json.dumps([quality_tools.compilation_entry(selected[0])],indent=2)+'\n')
 code=r.execute('required-clang-original-TU-r3',[tool,selected[0]['file'],'-p',str(db),'--checks='+quality_tools.TIDY_CHECKS,'--warnings-as-errors=*','--header-filter='+str(r.ROOT)+'/(core|io|os|components|arch|boards|soc|tools)/.*'])
elif stage=='clang-whole':
 handoff=json.loads((r.TMP/'tool-handoff.json').read_text())
 code=r.execute('required-clang-whole831-r3',['/workspace/nexus-build-system-20261012/.venv/bin/python','scripts/ci/quality_tools.py','tidy','--build-dir','build/native-debug','--tool',handoff['binary'],'--report',str(r.TMP/'required-clang-whole831.txt')])
elif stage in ['build-debug','build-asan']:
 B=r.ROOT/'build/native-debug' if stage=='build-debug' else A
 code=r.execute(stage+'-r3',['cmake','--build',str(B),'--target','nexus_h743_spi_dma_test','--parallel','1'],True)
elif stage in ['debug','asan']:
 B=r.ROOT/'build/native-debug' if stage=='debug' else A;elf=B/'bin/nexus_h743_spi_dma_test';target=r.TMP/(stage+'-matching-r3.elf');assert not target.exists();shutil.copy2(elf,target)
 (r.TMP/(stage+'-elf-r3.json')).write_text(json.dumps(r.identity(target),indent=2)+'\n')
 code=r.execute(stage+'-whole53-r3',[str(elf),'--gtest_output=xml:'+str(r.TMP/(stage+'-r3.xml'))])
else:raise SystemExit('unknown stage')
raise SystemExit(code)
