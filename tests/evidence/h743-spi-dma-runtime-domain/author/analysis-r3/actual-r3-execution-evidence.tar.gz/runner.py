from pathlib import Path
import os,sys,json,hashlib,resource,time,threading,shutil,signal
ROOT=Path('/tmp/nexus-io36-native-20261018')
TMP=Path('/dev/shm/nexus-h743-spi-dma-runtime-domain-20261018-r1/analysis-r3')
F=Path('/workspace/nexus-io-recovery-20261018/features/h743-spi-dma-runtime-domain-r1')
sys.path.insert(0,str(ROOT))
from tools.dev.process import run
B=json.loads((F/'baseline.json').read_text())
def alloc(p):
 total=0
 for d,ds,fs in os.walk(p):
  for n in ds+fs:
   total+=(Path(d)/n).lstat().st_blocks*512
 return total
def facts():
 c=int(Path('/sys/fs/cgroup/memory.current').read_text()); m=int(Path('/sys/fs/cgroup/memory.max').read_text());v=os.statvfs(F)
 return dict(memory_current=c,memory_max=m,headroom=m-c,persistent_free=v.f_bavail*v.f_frsize,persistent_alloc=alloc(F),tmp_alloc=alloc(TMP.parent),build_alloc=alloc(ROOT/'build/native-debug'),oom=Path('/sys/fs/cgroup/memory.events').read_text())
def guard(compile=False):
 x=facts(); assert x['headroom']>=(900 if compile else 600)*1024**2,x
 assert x['persistent_free']>=64*1024**2,x
 assert x['persistent_alloc']<=1024**2,x
 assert x['tmp_alloc']+max(0,x['build_alloc']-B['initial_build_allocated'])<=128*1024**2,x
 return x
def identity(p):
 return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
def execute(name,argv,compile=False):
 before=guard(compile); stop=threading.Event(); samples=[]
 def monitor():
  while not stop.wait(.25):
   c=int(Path('/sys/fs/cgroup/memory.current').read_text()); samples.append(c)
   if int(Path('/sys/fs/cgroup/memory.max').read_text())-c < 600*1024**2:
    os.kill(os.getpid(), signal.SIGTERM); return
 t=threading.Thread(target=monitor);t.start()
 env=os.environ.copy(); env['PATH']='/workspace/nexus-build-system-20261012/.venv/bin:'+env['PATH'];env.update(CMAKE_BUILD_PARALLEL_LEVEL='1',NEXUS_BUILD_JOBS='1',TMPDIR=str(TMP))
 for k in tuple(env):
  if k.startswith('GTEST_'):del env[k]
 started=time.time_ns()
 try:r=run(argv,cwd=ROOT,env=env,log=TMP/(name+'.raw'),timeout=1800,stage=name)
 finally:stop.set();t.join()
 record=dict(name=name,actual_returncode=r.returncode,started_ns=started,finished_ns=time.time_ns(),before=before,after=facts(),sampled_memory_max=max(samples,default=before['memory_current']),child_maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,receipt=str(r.receipt_path))
 (TMP/(name+'.resources.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 return r.returncode
