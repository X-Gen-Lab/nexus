from pathlib import Path
import gzip
import hashlib
import json
import stat
import sys
import tarfile

sys.path.insert(0, '/tmp/nexus-oci-ca-reader-20261018-r1')
from run import ROOT, TMP, OUT, guard

sha = lambda data: hashlib.sha256(data).hexdigest()
def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': sha(data),
            'mode': stat.S_IMODE(path.stat().st_mode)}

def write_new(path, value):
    assert not path.exists()
    path.write_text(json.dumps(value, indent=2) + '\n')

state = guard()
baseline = json.loads((OUT / 'baseline-r1.json').read_text())
sources = []
for before in baseline['before']:
    name = before['path']
    assert (ROOT / name).read_bytes() == (OUT / 'files' / name).read_bytes()
    sources.append({'path': name, 'before': before,
                    'after': identity(ROOT / name),
                    'transport': 'files/' + name})
receipt = json.loads((TMP / 'runs/final-diff-r1.command.json').read_text())
(OUT / 'source.diff').write_bytes(Path(receipt['stdout']['path']).read_bytes())
freeze = {'schema_version': 1, 'kind': 'oci_public_ca_reader_source_freeze',
          'base_commit': baseline['base_commit'], 'branch': baseline['branch'],
          'source_count': 3, 'sources': sources,
          'source_diff': identity(OUT / 'source.diff'),
          'baseline_index': baseline['index'],
          'index_unchanged': True, 'unrelated11_unchanged': True,
          'unchanged_locked_inputs': baseline['unchanged_locked_inputs'],
          'scope': 'Only public proxy CA BuildKit mount mode0444; no OCI execution or historical image identity rewrite.'}
write_new(OUT / 'source-freeze-r1.json', freeze)
commands = []
for path in sorted((TMP / 'runs').glob('*.command.json')):
    if path.name.startswith('seal-evidence-r1'):
        continue
    receipt = json.loads(path.read_text())
    assert receipt['outcome'] == 'completed'
    for role in ('stdout', 'stderr'):
        row = receipt[role]
        assert identity(Path(row['path']))['sha256'] == row['sha256']
        assert Path(row['path']).stat().st_size == row['bytes']
    commands.append({'receipt': str(path.relative_to(TMP)), **receipt})
assert len(commands) == 10
write_new(OUT / 'execution-summary-r1.json', {
    'kind': 'actual_completed_commands', 'commands': commands,
    'accepted_red': {'label': 'whole-recipe-red-r3', 'methods': 8,
                     'failed_subtests': 2, 'errors': 0, 'skipped': 0,
                     'actual_exit': 1, 'reason': 'Both actual emitted mounts default0400 rather than public-CA0444.'},
    'green': {'label': 'whole-recipe-green-r1', 'methods': 8,
              'failed_subtests': 0, 'errors': 0, 'skipped': 0,
              'actual_exit': 0, 'same_test_bytes': True},
    'old_methods_preserved_exactly': 6,
    'normal_recipe_verify_actual_exit': 0,
    'three_file_text_check_actual_exit': 0,
    'prior_reds': 'R1/R2 full8 runs retained, same2subfail/0error; test width-only edits precede acceptedR3. Two inline authoring width assertions also failed, no production changes then; red-source-r1.json records the correction.',
    'remote_red': {'run': '39106146065', 'job_step': 8,
                   'path': '/workspace/nexus-io-recovery-20261018/validation/remote-qualification-dispatch-6d235058-r1/connector-completed-job-log.json',
                   'sha256': 'f2ec4b47fadce2841169b2add355eb3fa1e59b303bdca71401eb163add4dd7e0',
                   'reason': 'APT could not load /run/secrets/proxy_ca: Permission denied; actual exit100. Existing remote raw remains unchanged outside this small feature packet.'},
    'limits': 'No Docker build/pull, new OCI bytes, reproduction, SDK or hardware qualification. Root must run the new remote workflow.'})
# Exclude only the complete3.57MiB TMP index, live guard journal and this active
# packaging command. Its closed receipt/raw will be copied separately.
files = [p for p in (TMP / 'runs').rglob('*') if p.is_file()
         and not p.relative_to(TMP / 'runs').parts[0].startswith('seal-evidence-r1')]
files += [TMP / name for name in ('run.py', 'derive.py', 'verify_final.py',
                                 'seal_evidence.py', 'recipe-inputs.json')]
rows = [{'member': str(p.relative_to(TMP)), 'original_path': str(p),
         **identity(p)} for p in sorted(files)]
assert len({row['member'] for row in rows}) == len(rows)
archive = OUT / 'execution-evidence-r1.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as stream:
    for row in rows:
        stream.add(TMP / row['member'], arcname=row['member'], recursive=False)
with gzip.open(archive, 'rb') as stream:
    while stream.read(65536):
        pass
with tarfile.open(archive, 'r:gz') as stream:
    members = stream.getmembers()
    assert len(members) == len(rows)
    for item, row in zip(members, rows):
        data = stream.extractfile(item).read()
        assert item.name == row['member'] and item.isfile()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        assert item.mode == row['mode']
        assert identity(Path(row['original_path'])) == {
            key: row[key] for key in ('bytes', 'sha256', 'mode')}
map_path = OUT / 'execution-evidence-map-r1.json.gz'
assert not map_path.exists()
map_path.write_bytes(gzip.compress((json.dumps(rows, indent=2) + '\n').encode(),
                                  mtime=0))
print(json.dumps({'status': 'sealed', 'source_freeze': identity(OUT / 'source-freeze-r1.json'),
                  'archive': identity(archive), 'map': identity(map_path),
                  'members': len(rows), 'commands': len(commands),
                  'guards_before': state, 'guards_after': guard()}))
