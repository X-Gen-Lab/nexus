import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, '/tmp/nexus-oci-ca-reader-20261018-r1')
from run import ROOT, OUT, guard
from tools.evidence import recipe

lock = json.loads((ROOT / 'dependencies/build-recipe.lock.json').read_text())
requirements = 'dependencies/python-tools-linux-cp312.txt'
recipe.verify(lock, ROOT / requirements)
data = recipe.emit(lock, requirements).encode()
guard()
saved = OUT / 'files/tools/dev/Dockerfile'
saved.parent.mkdir(parents=True, exist_ok=True)
saved.write_bytes(data)
shutil.copyfile(saved, ROOT / 'tools/dev/Dockerfile')
assert saved.read_bytes() == (ROOT / 'tools/dev/Dockerfile').read_bytes()
print('Derived Dockerfile from unchanged declared lock and requirements')
