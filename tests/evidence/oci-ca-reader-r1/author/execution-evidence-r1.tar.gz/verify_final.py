import ast
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, '/tmp/nexus-oci-ca-reader-20261018-r1')
from run import ROOT, TMP, OUT, guard
from scripts.ci import style_gate

sha = lambda data: hashlib.sha256(data).hexdigest()
baseline = json.loads((OUT / 'baseline-r1.json').read_text())
index = (ROOT / '.git/index').read_bytes()
assert index == (TMP / 'baseline-index.raw').read_bytes()
assert sha(index) == baseline['index']['sha256']
for row in baseline['unrelated'] + baseline['unchanged_locked_inputs']:
    data = (ROOT / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
paths = {row['path'] for row in baseline['before']}
for label, expected in (
    ('final-tracked-names-r1', paths),
    ('final-untracked-names-r1', {row['path'] for row in baseline['unrelated']}),
):
    record = json.loads((TMP / 'runs' / (label + '.command.json')).read_text())
    assert record['exit_code'] == 0
    names = Path(record['stdout']['path']).read_bytes().decode().strip('\0')
    assert set(names.split('\0')) == expected
for name in paths:
    assert (ROOT / name).read_bytes() == (OUT / 'files' / name).read_bytes()
    assert not style_gate.check_text(ROOT / name, name)
for name in ('tools/evidence/recipe.py', 'tools/dev/Dockerfile'):
    original = (OUT / 'before' / name).read_bytes()
    needle = b'--mount=type=secret,id=proxy_ca,required=true'
    assert original.count(needle) == 2
    assert original.replace(needle, needle + b',mode=0444') == (
        ROOT / name).read_bytes()
name = 'tools/testing/test_build_recipe.py'
original, current = ((OUT / directory / name).read_text()
                     for directory in ('before', 'files'))
methods = lambda text: {
    node.name: ast.get_source_segment(text, node)
    for node in ast.walk(ast.parse(text))
    if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')}
old, new = methods(original), methods(current)
assert len(old) == 6 and len(new) == 8
assert all(new[name] == text for name, text in old.items())
red = json.loads((OUT / 'red-source-r1.json').read_text())
assert sha(current.encode()) == red['unchanged_final_test_sha256']
for label, code in (('whole-recipe-red-r3', 1),
                    ('whole-recipe-green-r1', 0)):
    receipt = json.loads((TMP / 'runs' / (label + '.command.json')).read_text())
    raw = Path(receipt['stderr']['path']).read_text()
    assert receipt['exit_code'] == code and 'Ran 8 tests' in raw
    assert ('FAILED (failures=2)' in raw if code else '\nOK\n' in raw)
    assert 'ERROR:' not in raw and 'skipped=' not in raw
report = json.loads((TMP / 'recipe-inputs.json').read_text())
assert report['status'] == 'declared_inputs_verified'
assert report['recipe_reproducible'] is False
assert report['dockerfile_sha256'] == sha((ROOT / 'tools/dev/Dockerfile').read_bytes())
print(json.dumps({'status': 'passed', 'source_count': 3,
                  'maintained_text_files': 3, 'original_methods_preserved': 6,
                  'whole_red_green_methods': 8, 'same_final_test_bytes': True,
                  'index_unchanged': True, 'unrelated_11_unchanged': True,
                  'locked_inputs_unchanged': True, 'guards': guard()}))
