/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#ifndef NX_PLATFORM_REGISTER_WRITE
#define NX_PLATFORM_REGISTER_WRITE(reg, value) ((reg) = (uint32_t)(value))
#endif
#ifndef NX_PLATFORM_PRIORITY_WRITE
#define NX_PLATFORM_PRIORITY_WRITE(reg, value) ((reg) = (uint8_t)(value))
#endif
#include "stm32h743_provider.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static uint32_t s_nx_gpio_clocks_added;
static uint32_t s_nx_uart_clocks_added;
static struct {
    uint32_t mode, type, speed, pull, af0, af1, odr;
    bool captured;
} s_nx_gpiob_lease;
static nx_result_t restore_gpiob(void) {
    if (!s_nx_gpiob_lease.captured) { return NX_SUCCESS; }
    NX_H743_WRITE(&GPIOB->MODER, (NX_H743_READ(&GPIOB->MODER) & ~3u) | 3u);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOB->MODER) & 3u) != 3u) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOB->BSRR, s_nx_gpiob_lease.odr | ((1u & ~s_nx_gpiob_lease.odr) << 16u));
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOB->ODR) & 1u) != s_nx_gpiob_lease.odr) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOB->AFR[0], (NX_H743_READ(&GPIOB->AFR[0]) & ~15u) | s_nx_gpiob_lease.af0);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOB->AFR[0]) & 15u) != s_nx_gpiob_lease.af0) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOB->AFR[1], (NX_H743_READ(&GPIOB->AFR[1]) & ~0u) | s_nx_gpiob_lease.af1);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOB->AFR[1]) & 0u) != s_nx_gpiob_lease.af1) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOB->OTYPER, (NX_H743_READ(&GPIOB->OTYPER) & ~1u) | s_nx_gpiob_lease.type);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOB->OTYPER) & 1u) != s_nx_gpiob_lease.type) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOB->OSPEEDR, (NX_H743_READ(&GPIOB->OSPEEDR) & ~3u) | s_nx_gpiob_lease.speed);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOB->OSPEEDR) & 3u) != s_nx_gpiob_lease.speed) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOB->PUPDR, (NX_H743_READ(&GPIOB->PUPDR) & ~3u) | s_nx_gpiob_lease.pull);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOB->PUPDR) & 3u) != s_nx_gpiob_lease.pull) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOB->MODER, (NX_H743_READ(&GPIOB->MODER) & ~3u) | s_nx_gpiob_lease.mode);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOB->MODER) & 3u) != s_nx_gpiob_lease.mode) { return NX_ERROR_IO; }
    s_nx_gpiob_lease.captured = false;
    return NX_SUCCESS;
}
static struct {
    uint32_t mode, type, speed, pull, af0, af1, odr;
    bool captured;
} s_nx_gpiod_lease;
static nx_result_t restore_gpiod(void) {
    if (!s_nx_gpiod_lease.captured) { return NX_SUCCESS; }
    NX_H743_WRITE(&GPIOD->MODER, (NX_H743_READ(&GPIOD->MODER) & ~983040u) | 983040u);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOD->MODER) & 983040u) != 983040u) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOD->BSRR, s_nx_gpiod_lease.odr | ((768u & ~s_nx_gpiod_lease.odr) << 16u));
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOD->ODR) & 768u) != s_nx_gpiod_lease.odr) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOD->AFR[0], (NX_H743_READ(&GPIOD->AFR[0]) & ~0u) | s_nx_gpiod_lease.af0);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOD->AFR[0]) & 0u) != s_nx_gpiod_lease.af0) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOD->AFR[1], (NX_H743_READ(&GPIOD->AFR[1]) & ~255u) | s_nx_gpiod_lease.af1);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOD->AFR[1]) & 255u) != s_nx_gpiod_lease.af1) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOD->OTYPER, (NX_H743_READ(&GPIOD->OTYPER) & ~768u) | s_nx_gpiod_lease.type);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOD->OTYPER) & 768u) != s_nx_gpiod_lease.type) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOD->OSPEEDR, (NX_H743_READ(&GPIOD->OSPEEDR) & ~983040u) | s_nx_gpiod_lease.speed);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOD->OSPEEDR) & 983040u) != s_nx_gpiod_lease.speed) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOD->PUPDR, (NX_H743_READ(&GPIOD->PUPDR) & ~983040u) | s_nx_gpiod_lease.pull);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOD->PUPDR) & 983040u) != s_nx_gpiod_lease.pull) { return NX_ERROR_IO; }
    NX_H743_WRITE(&GPIOD->MODER, (NX_H743_READ(&GPIOD->MODER) & ~983040u) | s_nx_gpiod_lease.mode);
    nx_arch_dsb();
    if ((NX_H743_READ(&GPIOD->MODER) & 983040u) != s_nx_gpiod_lease.mode) { return NX_ERROR_IO; }
    s_nx_gpiod_lease.captured = false;
    return NX_SUCCESS;
}
static nx_stm32h743_gpio_state_t s_nx_port_led;
static const nx_gpio_port_t s_nx_face_led = {
    &nx_stm32h743_gpio_ops, &s_nx_port_led
};
const nx_gpio_port_t* const nx_binding_led = &s_nx_face_led;
static nx_result_t prepare_led(void) {
    if (s_nx_port_led.retained || s_nx_port_led.initialized) { return NX_ERROR_BUSY; }
    s_nx_port_led.registers = GPIOB;
    s_nx_port_led.mask = 1u;
    s_nx_port_led.output = true;
    return nx_stm32h743_gpio_initialize(&s_nx_port_led, 0u);
}
static nx_stm32h743_uart_state_t s_nx_port_console;
static const nx_uart_port_t s_nx_face_console = {
    &nx_stm32h743_uart_ops, &s_nx_port_console
};
const nx_uart_port_t* const nx_binding_console = &s_nx_face_console;
static uint8_t s_nx_rx_console[64];
static nx_result_t prepare_console(void) {
    if (s_nx_port_console.retained || s_nx_port_console.initialized || s_nx_port_console.active != NULL || s_nx_port_console.wake != NULL || s_nx_port_console.wake_publishers != 0u) { return NX_ERROR_BUSY; }
    s_nx_port_console.registers = USART3;
    s_nx_port_console.rx_storage = s_nx_rx_console;
    s_nx_port_console.rx_capacity = 64u;
    s_nx_port_console.baud = 115200u;
    s_nx_port_console.irq = USART3_IRQn;
    s_nx_port_console.profile = NX_UART_RX_BYTES;
    s_nx_port_console.irq_policy = (nx_irq_policy_t){ NX_IRQ_KERNEL_NONE, 150u, 4u, 0u };
    nx_result_t status = nx_stm32h743_usart3_pins_prepare();
    if (status != NX_SUCCESS) { return status; }
    return nx_stm32h743_uart_initialize(&s_nx_port_console, 64000000u, 1000000u);
}
void USART3_IRQHandler(void);
/** \brief One selected controller, at most one TX/RX byte. */
void USART3_IRQHandler(void) { nx_stm32h743_uart_irq(&s_nx_port_console); }
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 2u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 1u);
        nx_result_t status_0 = nx_uart_port_stop(&s_nx_face_console);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 1u;
    }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = nx_stm32h743_gpio_stop(&s_nx_port_led, 0u);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    if (s_nx_platform_started) {
        nx_result_t restored_d = restore_gpiod();
        if (restored_d != NX_SUCCESS) { return restored_d; }
        nx_result_t restored_b = restore_gpiob();
        if (restored_b != NX_SUCCESS) { return restored_b; }
        NX_H743_WRITE(&RCC->APB1LENR, NX_H743_READ(&RCC->APB1LENR) & ~s_nx_uart_clocks_added);
        nx_arch_dsb();
        if ((NX_H743_READ(&RCC->APB1LENR) & s_nx_uart_clocks_added) != 0u) { return NX_ERROR_IO; }
        s_nx_uart_clocks_added = 0u;
        NX_H743_WRITE(&RCC->AHB4ENR, NX_H743_READ(&RCC->AHB4ENR) & ~s_nx_gpio_clocks_added);
        nx_arch_dsb();
        if ((NX_H743_READ(&RCC->AHB4ENR) & s_nx_gpio_clocks_added) != 0u) { return NX_ERROR_IO; }
        s_nx_gpio_clocks_added = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    if (s_nx_platform_started) {
        nx_result_t system = nx_stm32h743_system_stop(&g_nx_stm32h743_system, 1000000u);
        if (system != NX_SUCCESS) { return system; }
    }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_stm32h743_system_preflight(&g_nx_stm32h743_system);
    if (result.primary != NX_SUCCESS) { return result; }
    if ((NX_H743_READ(&RCC->APB1LENR) & RCC_APB1LENR_USART3EN) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if ((NX_H743_READ(&RCC->D2CCIP2R) & RCC_D2CCIP2R_USART28SEL) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if (!NX_H743_IRQ_AVAILABLE((IRQn_Type)USART3_IRQn)) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if ((NX_H743_READ(&RCC->AHB4ENR) & RCC_AHB4ENR_GPIOBEN) != 0u) {
        uint32_t mode = NX_H743_READ(&GPIOB->MODER);
        if (((mode >> 0u) & 3u) != 0u && ((mode >> 0u) & 3u) != 3u) {
            result.primary = NX_ERROR_BUSY; return result;
        }
        if ((NX_H743_READ(&GPIOB->LCKR) & 1u) != 0u) {
            result.primary = NX_ERROR_BUSY; return result;
        }
    }
    if ((NX_H743_READ(&RCC->AHB4ENR) & RCC_AHB4ENR_GPIODEN) != 0u) {
        uint32_t mode = NX_H743_READ(&GPIOD->MODER);
        if (((mode >> 16u) & 3u) != 0u && ((mode >> 16u) & 3u) != 3u) {
            result.primary = NX_ERROR_BUSY; return result;
        }
        if (((mode >> 18u) & 3u) != 0u && ((mode >> 18u) & 3u) != 3u) {
            result.primary = NX_ERROR_BUSY; return result;
        }
        if ((NX_H743_READ(&GPIOD->LCKR) & 768u) != 0u) {
            result.primary = NX_ERROR_BUSY; return result;
        }
    }
    result.primary = nx_stm32h743_validate_identity();
    if (result.primary != NX_SUCCESS) { return result; }
    nx_stm32h743_start_result_t system = nx_stm32h743_system_start(&g_nx_stm32h743_system, 64000000u, 0u, 1000000u);
    if (system.primary != NX_SUCCESS) {
        result.primary = system.primary;
        result.cleanup = system.cleanup;
        result.remaining_effects = system.remaining_effects;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    s_nx_gpio_clocks_added = ~NX_H743_READ(&RCC->AHB4ENR) & (RCC_AHB4ENR_GPIOBEN | RCC_AHB4ENR_GPIODEN);
    s_nx_uart_clocks_added = ~NX_H743_READ(&RCC->APB1LENR) & RCC_APB1LENR_USART3EN;
    result.primary = nx_stm32h743_gpio_clock_enable(1u);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    result.primary = nx_stm32h743_gpio_clock_enable(3u);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    const uint32_t gpiob_mode = NX_H743_READ(&GPIOB->MODER);
    if ((NX_H743_READ(&GPIOB->LCKR) & 1u) != 0u || (((gpiob_mode >> 0u) & 3u) != 0u && ((gpiob_mode >> 0u) & 3u) != 3u)) {
        result.primary = NX_ERROR_BUSY;
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    const uint32_t gpiod_mode = NX_H743_READ(&GPIOD->MODER);
    if ((NX_H743_READ(&GPIOD->LCKR) & 768u) != 0u || (((gpiod_mode >> 16u) & 3u) != 0u && ((gpiod_mode >> 16u) & 3u) != 3u) || (((gpiod_mode >> 18u) & 3u) != 0u && ((gpiod_mode >> 18u) & 3u) != 3u)) {
        result.primary = NX_ERROR_BUSY;
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_gpiob_lease.mode = NX_H743_READ(&GPIOB->MODER) & 3u;
    s_nx_gpiob_lease.type = NX_H743_READ(&GPIOB->OTYPER) & 1u;
    s_nx_gpiob_lease.speed = NX_H743_READ(&GPIOB->OSPEEDR) & 3u;
    s_nx_gpiob_lease.pull = NX_H743_READ(&GPIOB->PUPDR) & 3u;
    s_nx_gpiob_lease.af0 = NX_H743_READ(&GPIOB->AFR[0]) & 15u;
    s_nx_gpiob_lease.af1 = NX_H743_READ(&GPIOB->AFR[1]) & 0u;
    s_nx_gpiob_lease.odr = NX_H743_READ(&GPIOB->ODR) & 1u;
    s_nx_gpiob_lease.captured = true;
    s_nx_gpiod_lease.mode = NX_H743_READ(&GPIOD->MODER) & 983040u;
    s_nx_gpiod_lease.type = NX_H743_READ(&GPIOD->OTYPER) & 768u;
    s_nx_gpiod_lease.speed = NX_H743_READ(&GPIOD->OSPEEDR) & 983040u;
    s_nx_gpiod_lease.pull = NX_H743_READ(&GPIOD->PUPDR) & 983040u;
    s_nx_gpiod_lease.af0 = NX_H743_READ(&GPIOD->AFR[0]) & 0u;
    s_nx_gpiod_lease.af1 = NX_H743_READ(&GPIOD->AFR[1]) & 255u;
    s_nx_gpiod_lease.odr = NX_H743_READ(&GPIOD->ODR) & 768u;
    s_nx_gpiod_lease.captured = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = prepare_led();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 1u);
    s_nx_platform_initialized = 2u;
    result.primary = prepare_console();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 2u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        case NX_GPIO_ID_LED:
            return nx_binding_led;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return nx_binding_console;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_gpio_led = {
    0U, 0U, 0U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id) {
    switch (id) {
        case NX_GPIO_ID_LED:
            return &s_nx_capability_gpio_led;
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_uart_console = {
    NX_FACTORY_CAP_IRQ, 0U, 1U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return &s_nx_capability_uart_console;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_uart_traits_t s_nx_traits_uart_console = {
    8U,
    0U,
    2U,
    115200U,
    NX_IO_ABORT_REQUEST,
    NX_IO_CONTINUITY_IRQ_BUFFERED,
    NX_IO_TIMESTAMP_UNKNOWN,
    NX_IO_DMA_POLICY_NONE,
    0U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_uart_traits_t* nx_factory_uart_traits(
    nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return &s_nx_traits_uart_console;
        default:
            return NULL;
    }
}
/** \brief Pure lookup; no start or hardware access. */
const nx_usb_activation_port_t* nx_factory_usb_activation(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
