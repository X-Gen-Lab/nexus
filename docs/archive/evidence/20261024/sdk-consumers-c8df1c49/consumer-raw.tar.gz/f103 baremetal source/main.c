#include "nexus_bindings.h"
#include "nexus_factory.h"
#if __has_include("stm32h7xx.h") || __has_include("stm32u5xx.h") || __has_include("stm32f1xx.h") || __has_include("gd32f30x.h") || __has_include("stm32g4xx.h")
#error Vendor SDK leaked into the product
#endif
#if __has_include("stm32h743_provider.h") || __has_include("stm32u575_provider.h") || __has_include("stm32f103_provider.h") || __has_include("gd32f303_provider.h") || __has_include("stm32g474_provider.h") || __has_include("rtc_lptim_provider.h")
#error Provider implementation leaked into the product
#endif
static nx_uart_tx_request_t request;
static uint8_t data[2] = {0x12U, 0x34U};
int main(void) {
    nx_platform_start_result_t start = nx_platform_start();
    if (start.primary != NX_SUCCESS) return (int)start.primary;
    const nx_gpio_port_t* led = nx_factory_gpio(NX_GPIO_ID_LED);
    const nx_uart_port_t* console = nx_factory_uart(NX_UART_ID_CONSOLE);
    nx_request_initialize(&request.base);
    (void)nx_gpio_port_write(led, 1U << 5U, 0U);
    (void)nx_uart_tx_prepare(&request, data, sizeof(data),
        nx_deadline_after(nx_time_now_us(), 1000U));
    (void)nx_uart_port_submit(console, &request);
    (void)nx_uart_port_cancel(console, &request);
    nx_uart_port_service(console);
    return (int)nx_platform_stop();
}
