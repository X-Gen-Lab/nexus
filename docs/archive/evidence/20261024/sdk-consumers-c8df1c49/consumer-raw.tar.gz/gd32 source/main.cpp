#include "nexus/components/log.h"
#include "nexus/components/bmp280.h"
#include "nexus/components/storage.h"
#include "nexus/components/mapped_storage.h"
#include "nexus/components/mapped_storage_owner.h"
#include "nexus/components/amp_ipc_storage.h"
#include "nexus/components/i3c_controller_storage.h"
#include "nexus/components/user_io_async_storage.h"
#include <cstring>
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus_config.h"
#ifndef NEXUS_PLATFORM_VERSION
#error "Missing source interface version"
#endif
#if NEXUS_FACTORY_ABI_EPOCH != 1U
#error "Unsupported factory interface epoch"
#endif
#if __has_include("stm32f4xx.h") || __has_include("gd32f4xx.h")
#error Vendor SDK leaked into product source
#endif
#if __has_include("stm32f407_provider.h") || __has_include("gd32f470_provider.h")
#error Concrete provider leaked into product source
#endif
int main(void) {
 if (nx_factory_gpio(NX_GPIO_ID_COUNT) != 0) return 7;
 nx_log_sink_port_t sink;
 std::memset(&sink, 0, sizeof(sink));
 if (nx_log_init(nullptr, sink, NX_LOG_INFO) != NX_ERROR_INVALID) return 3;
 if (nx_bmp280_compensate(nullptr, 0, 0, nullptr) != NX_ERROR_INVALID) return 4;
 if (nx_mapped_storage_stop(nullptr) != NX_ERROR_INVALID) return 5;
 if (nx_amp_ipc_construct(nullptr, nullptr) != NX_ERROR_INVALID) return 6;
 if (nx_i3c_controller_construct(nullptr, nullptr) != NX_ERROR_INVALID) return 9;
 if (nx_user_io_async_construct(nullptr, nullptr, 0U, nullptr) != NX_ERROR_INVALID) return 10;
 nx_platform_start_result_t result = nx_platform_start();
 if (result.primary != NX_SUCCESS) return 1;
 return nx_platform_stop() == NX_SUCCESS ? 0 : 2;
}
