#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus_config.h"
#ifndef NEXUS_PLATFORM_VERSION
#error "Missing source interface version"
#endif
#if NEXUS_FACTORY_ABI_EPOCH != 1U
#error "Unsupported factory interface epoch"
#endif
#if __has_include("stm32f4xx.h") || __has_include("gd32f4xx.h")
#error Vendor SDK leaked into product source
#endif
#if __has_include("stm32f407_provider.h") || __has_include("gd32f470_provider.h")
#error Concrete provider leaked into product source
#endif
int main(void) {
 if (nx_factory_gpio(NX_GPIO_ID_COUNT) != 0) return 7;
 nx_platform_start_result_t result = nx_platform_start();
 if (result.primary != NX_SUCCESS) return 1;
 return nx_platform_stop() == NX_SUCCESS ? 0 : 2;
}
