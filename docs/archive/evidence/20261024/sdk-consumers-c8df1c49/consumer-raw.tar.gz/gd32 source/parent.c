#ifdef NEXUS_EFFECTIVE_CONFIG
#error SDK leaked into unrelated parent target
#endif
int main(void) { return 0; }
