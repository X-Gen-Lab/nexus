# Install script for directory: /dev/shm/nexus-iteration24-sdk relocated c8df1c49/share/nexus/src/components

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "TRUE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/tmp/nexus-quality-arm/bin/arm-none-eabi-objdump")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/owner_observer/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/dp83848/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/clock_domain/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/user_io_broker/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/usb_control/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/mapped_storage/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/amp_ipc/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/soc/cmake_install.cmake")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/i3c_controller/cmake_install.cmake")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/dev/shm/nexus-iteration24-sdk-consumers-c8df1c49-attempt01/g474 freertos build/nexus-sdk/components/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
