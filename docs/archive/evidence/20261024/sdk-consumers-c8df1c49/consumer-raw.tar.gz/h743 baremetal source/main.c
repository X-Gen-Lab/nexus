#include "nexus_bindings.h"
#include "nexus_factory.h"
#if __has_include("stm32h7xx.h") || __has_include("stm32u5xx.h") || __has_include("stm32f1xx.h") || __has_include("gd32f30x.h") || __has_include("stm32g4xx.h")
#error Vendor SDK leaked into the product
#endif
#if __has_include("stm32h743_provider.h") || __has_include("stm32u575_provider.h") || __has_include("stm32f103_provider.h") || __has_include("gd32f303_provider.h") || __has_include("stm32g474_provider.h") || __has_include("rtc_lptim_provider.h")
#error Provider implementation leaked into the product
#endif
static nx_uart_tx_request_t request;
static uint8_t data[2] = {0x12U, 0x34U};
#include "nexus/components/frame_dma2d.h"
static nx_h743_frame_dma2d_storage_t frame_storage;
static const nx_frame_blitter_t frame_blitter = {
    &nx_h743_frame_dma2d_ops, &frame_storage};
static const nx_h743_frame_dma2d_config_t frame_configuration = {
    NX_H743_FRAME_DMA2D_CONTROLLER, 4U};
static nx_stream_slot_t frame_slot;
static nx_stream_t frame_queue;
static nx_frame_stream_t frame_stream;
static nx_frame_dma_loan_t frame_source;
static nx_frame_blit_request_t frame_request;
static uint32_t frame_pixels[24];
static uint16_t frame_output[48];
int main(void) {
    nx_platform_start_result_t start = nx_platform_start();
    if (start.primary != NX_SUCCESS) return (int)start.primary;
    const nx_gpio_port_t* led = nx_factory_gpio(NX_GPIO_ID_LED);
    const nx_uart_port_t* console = nx_factory_uart(NX_UART_ID_CONSOLE);
    nx_request_initialize(&request.base);
    (void)nx_gpio_port_write(led, 1U << 0U, 0U);
    (void)nx_uart_tx_prepare(&request, data, sizeof(data),
        nx_deadline_after(nx_time_now_us(), 1000U));
    (void)nx_uart_port_submit(console, &request);
    (void)nx_uart_port_cancel(console, &request);
    nx_uart_port_service(console);
    /* Public link reference only: no physical DMA/timing result. */
    const nx_frame_plane_t frame_plane = {0U, 16U, 24U, 4U};
    nx_frame_layout_t frame_layout;
    frame_slot.data = (uint8_t*)frame_pixels;
    frame_slot.capacity = sizeof(frame_pixels);
    if (nx_frame_layout_planar(&frame_plane, 1U, &frame_layout) != NX_SUCCESS ||
        nx_stream_initialize(&frame_queue, &frame_slot, 1U) != NX_SUCCESS ||
        nx_frame_stream_initialize(&frame_stream, &frame_queue, &frame_layout) != NX_SUCCESS ||
        nx_h743_frame_dma2d_initialize(&frame_storage, &frame_blitter,
                                      &frame_configuration) != NX_SUCCESS) return 9;
    nx_stream_fill_t frame_fill;
    if (nx_stream_reserve(&frame_queue, &frame_fill) != NX_SUCCESS ||
        nx_frame_stream_publish(&frame_stream, &frame_fill, 0U) != NX_SUCCESS ||
        nx_frame_stream_acquire(&frame_stream, &frame_source) != NX_SUCCESS) return 10;
    nx_request_initialize(&frame_request.base);
    if (nx_request_prepare(&frame_request.base, NX_DEADLINE_NEVER) != NX_SUCCESS) return 11;
    frame_request.source = &frame_source;
    frame_request.width_bytes = 16U;
    frame_request.rows = 4U;
    frame_request.format = NX_FRAME_BLIT_ARGB8888_TO_RGB565;
    frame_request.destination = (uint8_t*)frame_output;
    frame_request.destination_stride = 24U;
    frame_request.destination_capacity = sizeof(frame_output);
    if (frame_blitter.ops->submit(frame_blitter.context, &frame_request,
                                  nx_time_now_us()) == NX_SUCCESS) {
        (void)frame_blitter.ops->service(frame_blitter.context, nx_time_now_us());
        (void)frame_blitter.ops->cancel(frame_blitter.context, &frame_request);
        (void)frame_blitter.ops->service(frame_blitter.context, nx_time_now_us());
    } else {
        const nx_dma_drain_facts_t unsubmitted = {frame_layout.bytes, 0U, true, true, true};
        (void)nx_frame_dma_release(&frame_stream, &frame_source, &unsubmitted);
    }
    /* Quarantine retains all static storage; this image is never run. */
    (void)frame_blitter.ops->stop(frame_blitter.context);
    return (int)nx_platform_stop();
}
