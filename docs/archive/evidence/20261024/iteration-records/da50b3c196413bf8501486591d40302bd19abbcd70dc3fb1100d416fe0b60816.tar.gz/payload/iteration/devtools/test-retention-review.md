# Tool test retention review, 2026-10-24

Observed discovery: `test-retention-candidates.json`, 79 files and 1385 test
methods at the time of review. AST-identical bodies are candidates, not proof
of duplicate coverage. Five paired bodies were found between
`test_stm32f1_hal_lock.py` and `test_stm32f4_hal_lock.py`:

- unknown/missing/reauthored pairing and release rejection;
- duplicate/boolean/nonfinite schema and missing-file rejection;
- changed notice, symlink and same-byte rewrite rejection;
- wrong dependency commit/origin/dirty/missing Git rejection;
- packaged exact commits and absence of Git requirements.

All five pairs are retained. The F1 fixture imports `stm32f1_hal_lock`, supplies
F1 SDK and CMSIS paths, the F1 lock and its three-source closure. The F4 fixture
imports `stm32f4_hal_lock`, supplies F4 SDK and CMSIS paths, the separate F4
lock and eleven-source closure. These are separate public verifier entry points,
commit identities, source sets and pairings. Passing F1 cannot catch an F4
wrong pin or source registration. Removing either loses independent coverage.
No obsolete behavior or equivalent independent coverage justified deletion.
W8-06 therefore means review completed without a justified removal, not a
claim of fewer tests or reduced complete-gate runtime.

Focused change validation retained existing cache-hit corruption, wrong digest,
compiler namespace invalidation, formal no-cache and finite parallel-budget
regressions. New tests cover project pin/digest/relocation/rollback/space bounds,
explicit per-action equipment, source and lock changes, real failed child output,
serial disconnect, timing deduplication/overlap/raw tampering, and coherent preset
metadata. Original complete gates, four Native modes, fresh reports and owned
process cancellation were not changed.

The only measured speed claim is metadata selection: five alternating samples
of twenty selections, medians 1.734ms before and 0.948ms after using one preset
snapshot. The original JSON retains all samples and source hashes. This is not
whole-build, whole-gate or MCU performance.
