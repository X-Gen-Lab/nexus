"""Static provider wiring and family system lifecycle emission."""
from . import bindings
from ..common import mode_traits
try:
    from ... import can, usb_device, ethernet
except ImportError:
    import can
    import usb_device
    import ethernet


def implementation(item):
    from . import mode_implementation
    return mode_implementation(item.kind, item.mode)


def operations(item):
    """Name the actual readonly table; shared algorithms keep one identity."""
    selected = implementation(item)
    if item.kind == "eth":
        return "nx_eth_mac_ops"
    if item.kind == "can":
        return "nx_classic_can_ops"
    if item.kind == "usb_device":
        return "nx_usb_fs_device_ops"
    if selected == "i2c_async":
        return "nx_i2c_v1_async_ops"
    return f"nx_gd32_{selected}_ops"


def includes(result):
    selections = result.controllers
    source = []
    source += ['#include "gd32f470_provider.h"', '#include "gd32f4xx.h"']
    if any(item["kind"] == "uart" and item["mode"] == "dma-tx" for item in selections):
        source.append('#include "gd32f470_dma.h"')
    if any(item["kind"] == "spi" and item["mode"] == "dma-full-duplex" for item in selections):
        source.append('#include "gd32f470_spi_dma.h"')
    if any(item.kind == "adc" and mode_traits(item.kind, item.mode).dma
           for item in selections):
        source.append('#include "gd32f470_adc_stream.h"')
    if any(item["kind"] == "uart" and item["mode"] == "irq-blocks" for item in selections):
        source.append('#include "gd32f470_uart_stream.h"')
    if any(item.kind == "uart" and mode_traits(item.kind, item.mode).rx_dma
           for item in selections):
        source.append('#include "gd32f470_uart_receive.h"')
    if any(item.kind == "i2c" and mode_traits(item.kind, item.mode).irq
           for item in selections):
        source.append('#include "gd32f470_i2c_async.h"')
    if any(item.kind == "eth" for item in selections):
        source.append('#include "gd32f470_eth.h"')
        source.append('#include "gd32f4xx_syscfg.h"')
    if any(item.kind == "can" for item in selections):
        source.append('#include "gd32f470_can.h"')
    if any(item.kind == "usb_device" for item in selections):
        source.append('#include "gd32f470_usb_device.h"')
    source += ['void _init(void);', 'void _fini(void);',
               r'/** \brief C runtime hooks; constructors use .init_array. */',
               'void _init(void) {}', 'void _fini(void) {}']
    return source


def instance_declarations(item, result):
    source = []
    name = item.id.replace("-", "_")
    kind = item.kind
    if kind in {"spi", "i2c"}:
        source.append('static nx_gd32'
                      f"_{implementation(item)}_endpoint_state_t "
                      f"s_nx_endpoint_{name};")
    return source


def has_dma(result):
    return any(mode_traits(item.kind, item.mode).dma
               for item in result.controllers)


def _dma_clock_mask(result):
    controllers = {dma.split(":", 1)[0]
                   for item in result.controllers for dma in item.get("dma", ())}
    return " | ".join(f"RCU_AHB1EN_{name}EN" for name in sorted(controllers))


def state_declarations(result):
    source = []
    if has_dma(result):
        source.append("static uint32_t s_nx_platform_dma_clocks_added;")
    source.extend(can.state_declarations(result, "gd32"))
    source.extend(ethernet.state_declarations(result, "gd32"))
    source.extend(usb_device.state_declarations(result, "gd32"))
    return source


def shared_irqs(result):
    del result
    return []


def stop_system(result):
    dma_clock = has_dma(result)
    source = can.stop_domain(result, "gd32")
    source.extend(ethernet.stop_system(result, "gd32"))
    source.extend(usb_device.stop_system(result, "gd32"))
    if dma_clock:
        source += ['    if (s_nx_platform_started) { RCU_AHB1EN &= ~s_nx_platform_dma_clocks_added; }',
                   '    nx_arch_dsb();']
    source += ['    if (s_nx_platform_started && nx_gd32_soc_stop() != 0) { return NX_ERROR_IO; }']
    return source


def start_system(result):
    dma_clock = has_dma(result)
    source = []
    if result.get("can_domain") is not None:
        source.append("    s_nx_can_gpio_clocks_added = 0u;")
    if dma_clock:
        source.append('    s_nx_platform_dma_clocks_added = 0u;')
    source += ['    if (nx_gd32_soc_start() != 0) {',
               '        result.primary = NX_ERROR_IO;',
               '        result.cleanup = nx_gd32_soc_stop() == 0 ? NX_SUCCESS : NX_ERROR_IO;',
               '        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;',
               '        s_nx_platform_started = result.remaining_effects != 0u;',
               '        return result;', '    }']
    return source


def start_resources(result):
    source = usb_device.start_resources(result, "gd32")
    source.extend(ethernet.start_resources(result, "gd32"))
    mask = _dma_clock_mask(result)
    if mask:
        source += [f'    s_nx_platform_dma_clocks_added = ~RCU_AHB1EN & ({mask});',
                   f'    RCU_AHB1EN |= ({mask});',
                   '    (void)RCU_AHB1EN;', '    nx_arch_dsb();']
    return source
