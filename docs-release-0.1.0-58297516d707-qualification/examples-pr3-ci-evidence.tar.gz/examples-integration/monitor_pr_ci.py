"""Read-only monitoring of the explicitly selected examples PR workflow run."""
from pathlib import Path
import concurrent.futures
import datetime
import json
import subprocess
import time

OUTPUT = Path('/tmp/nexus-release-0.1.0-20261015/examples-integration/ci-observations')
RUN = 38683631996
EXPECTED_HEAD = '601580990df0e8232c3b6f3cc641cc3a8ee30ab8'
EXPECTED_JOBS = {'Native build and execution'} | {
    preset + ' linked firmware' for preset in (
        'stm32-qiming-baremetal', 'stm32-qiming-freertos',
        'stm32-sky-baremetal', 'stm32-sky-freertos',
        'gd32-liangshan-baremetal', 'gd32-liangshan-freertos',
        'stm32-h743-nucleo-baremetal', 'stm32-h743-nucleo-freertos',
        'stm32-u575-nucleo-baremetal', 'stm32-u575-nucleo-freertos')}

def observe(item):
    name, endpoint = item
    command = ['gh', 'api', 'repos/X-Gen-Lab/nexus-examples/' + endpoint]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(result.stderr.decode())
    return name, (result.stdout, json.loads(result.stdout))

for attempt in range(40):
    stamp = datetime.datetime.now(datetime.UTC).strftime('%Y%m%dT%H%M%SZ')
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        observed = dict(executor.map(observe, (
            ('selected-pr-run', f'actions/runs/{RUN}'),
            ('selected-pr-jobs', f'actions/runs/{RUN}/jobs?per_page=100'))))
    for name, (raw, _) in observed.items():
        (OUTPUT / (stamp + '-' + name + '.json')).write_bytes(raw)
    run = observed['selected-pr-run'][1]
    jobs = observed['selected-pr-jobs'][1]['jobs']
    assert run['head_sha'] == EXPECTED_HEAD
    assert run['event'] == 'pull_request'
    summary = {'observed': stamp, 'run': RUN, 'status': run['status'],
               'conclusion': run['conclusion'], 'jobs': [
                   {'id': j['id'], 'name': j['name'], 'status': j['status'],
                    'conclusion': j['conclusion'], 'active_steps': [
                        s['name'] for s in j['steps'] if s['status'] == 'in_progress']}
                   for j in jobs]}
    print(json.dumps(summary), flush=True)
    if run['status'] == 'completed':
        assert {j['name'] for j in jobs} == EXPECTED_JOBS
        summary['all_eleven_jobs_successful'] = len(jobs) == 11 and all(
            j['status'] == 'completed' and j['conclusion'] == 'success' for j in jobs)
        (OUTPUT / 'selected-pr-completion.json').write_text(json.dumps(summary, indent=2) + '\n')
        raise SystemExit(0 if run['conclusion'] == 'success' and summary['all_eleven_jobs_successful'] else 1)
    time.sleep(45)
raise SystemExit('Selected PR CI still active after monitoring window; no success claimed.')
