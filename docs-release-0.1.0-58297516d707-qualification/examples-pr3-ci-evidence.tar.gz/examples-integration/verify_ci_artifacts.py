"""Read-only byte and semantic verification of preserved examples CI evidence."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--directory', type=Path, required=True)
parser.add_argument('--checkout', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = args.directory
source = Path('/tmp/nexus-release-0.1.0-20261015/examples')
sdk = source / 'external/nexus'
commit = '58297516d707fdee117bd27b5df6af09d72edd2e'
tree = '06feab8ef3e89df60b4cdc5671c66ab0e3c08c21'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
registry = json.loads((root / 'ci-artifacts/artifact-registry.json').read_text())
assert len(registry['artifacts']) == 11
result = {'kind': 'examples_ci_artifact_and_actual_checkout_verification', 'status': 'passed',
          'run_id': registry['run_id'], 'head_commit': registry['head_commit'],
          'actual_checkout': args.checkout, 'sdk_commit': commit, 'sdk_tree': tree,
          'archives': [], 'job_logs': [], 'physical_hil': 'not_executed'}
images = budgets = hil = inputs = generators = members = google = 0
for artifact in registry['artifacts']:
    archive = root / 'ci-artifacts' / (artifact['name'] + '.zip')
    raw = archive.read_bytes()
    assert len(raw) == artifact['size_in_bytes']
    assert 'sha256:' + sha(raw) == artifact['digest']
    assert artifact['workflow_run']['head_sha'] == registry['head_commit']
    assert artifact['workflow_run']['id'] == registry['run_id']
    with zipfile.ZipFile(archive) as zipped:
        names = zipped.namelist()
        assert len(set(names)) == len(names)
        assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts for n in names)
        assert zipped.testzip() is None
        member_records = [{'path': n, 'bytes': len(zipped.read(n)), 'sha256': sha(zipped.read(n))} for n in names]
        members += len(names)
        native = artifact['name'] == 'examples-native-debug-pinned'
        prefix = 'native-debug/' if native else ''
        identity = json.loads(zipped.read(prefix + 'dependency-identity.json'))
        assert identity['nexus_revision'] == identity['formal_locked_nexus_revision'] == commit
        assert identity['nexus_tree'] == identity['formal_locked_nexus_tree'] == tree
        assert identity['source_revision_matches_lock'] and identity['example_gitlink_verified']
        assert not identity['candidate_validation'] and not identity['source_override']
        assert identity['hardware_verified'] is False
        resolved = json.loads(zipped.read(prefix + 'nexus/generated/resolved.json'))
        assert resolved['platform_metadata']['semantic_version'] == '0.1.0'
        assert resolved['platform_metadata']['factory_abi_epoch'] == 1
        assert resolved['platform_metadata']['schemas']['assembly_authoring'] == 2
        for row in resolved['inputs']:
            label = row['path']
            file = source / 'assemblies' / label.removeprefix('external/') if label.startswith('external/') else sdk / label
            assert sha(file.read_bytes()) == row['sha256']
            inputs += 1
        generator = json.loads(zipped.read(prefix + 'nexus/generated/generator-identity.json'))
        for row in generator['files']:
            assert sha((sdk / row['path']).read_bytes()) == row['sha256']
        generators += 1
        if native:
            ctest = ET.fromstring(zipped.read(prefix + 'ctest-results.xml'))
            assert int(ctest.attrib['tests']) == 8
            for field in ('failures', 'errors', 'skipped', 'disabled'):
                assert int(ctest.attrib.get(field, 0)) == 0
            assert len(ctest.findall('.//testcase')) == 8
            assert not ctest.findall('.//skipped') + ctest.findall('.//failure') + ctest.findall('.//error')
            for folder, expected in [('google-execution', 28), ('fault-google-execution', 7), ('reference-google-execution', 8)]:
                base = prefix + 'tests/' + folder + '/'
                xml = zipped.read(base + 'google-results.xml')
                execution = json.loads(zipped.read(base + 'execution.json'))
                assert execution['tests'] == execution['discovered'] == execution['passed'] == expected
                assert all(execution[k] == 0 for k in ('failures', 'errors', 'skipped'))
                assert execution['report_sha256'] == sha(xml)
                node = ET.fromstring(xml)
                assert len(node.findall('.//testcase')) == expected
                assert not node.findall('.//skipped') + node.findall('.//failure') + node.findall('.//error')
                for field in ('failures', 'errors', 'skipped', 'disabled'):
                    assert int(node.attrib.get(field, 0)) == 0
                google += expected
        else:
            for report, app in [('firmware-resource-budget.json', 'platform_reference'), ('uart-owner-resource-budget.json', 'uart_owner_runtime')]:
                resource = json.loads(zipped.read(report))
                assert resource['status'] == 'passed' and not resource['violations']
                assert resource['physical_status'] == 'not_executed'
                for field, name in [('elf', 'bin/' + app + '.elf'), ('resolved', 'nexus/generated/resolved.json'), ('budget', 'nexus/generated/resource-budget.json')]:
                    payload = zipped.read(name)
                    assert sha(payload) == resource[field]['sha256'] and len(payload) == resource[field]['size']
                assert zipped.read('bin/' + app + '.elf').startswith(b'\x7fELF')
                assert zipped.read('bin/' + app + '.bin') and zipped.read('bin/' + app + '.map')
                images += 1
                budgets += 1
            plan = json.loads(zipped.read('hil-preparation.json'))
            assert plan['status'] == 'prepared_unbound' and plan['physical_status'] == 'not_executed'
            hil += 1
        result['archives'].append({'id': artifact['id'], 'path': str(archive), 'bytes': len(raw), 'sha256': sha(raw), 'registry_digest_matches': True, 'members': member_records})
for log in sorted((root / 'ci-observations').glob('*job-*.log')):
    text = log.read_text()
    lines = text.splitlines()
    checkout = [lines[i + 1].rsplit(' ', 1)[-1] for i, line in enumerate(lines[:-1]) if '[command]/usr/bin/git log -1 --format=%H' in line]
    assert checkout == [args.checkout], (log, checkout)
    if log.name.startswith('native-'):
        assert 'Ran 44 tests' in text and '100% tests passed, 0 tests failed out of 8' in text
    result['job_logs'].append({'path': str(log), 'bytes': log.stat().st_size, 'sha256': sha(log.read_bytes()), 'actual_checkout': checkout[0]})
assert len(result['job_logs']) == 11
assert images == budgets == 20 and hil == 10 and google == 43 and generators == 11
result['counts'] = {'archives': 11, 'archive_members': members, 'job_logs': 11, 'python_tests': 44,
                    'ctest_entries': 8, 'google_cases': google, 'arm_images': images,
                    'resource_checks': budgets, 'unbound_hil_plans': hil,
                    'source_configuration_hash_comparisons': inputs, 'generator_identity_reports': generators}
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'receipt': str(args.output), 'sha256': sha(args.output.read_bytes()), 'counts': result['counts']}))
